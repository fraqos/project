# Build and verification record — DHYRA Browser 1.4.1

## Checks completed in this workspace

- Pure Kotlin helper and standalone check code compiled with the installed Kotlin compiler.
- `BrowserLogicChecks` passed: address resolution, homepage validation, HTTPS upgrade and supported Shields host/path rules/exceptions.
- GitHub Actions YAML parsed successfully.
- All Android XML files parsed successfully as well-formed XML.
- Manifest version/security flags were checked for `versionName 1.4.1`, `allowBackup=false` and `usesCleartextTraffic=false`.
- Source ZIP and final ZIP archive integrity were checked with `unzip -t`.

## Checks not completed

A full Android Gradle build, Android lint and APK generation were **not run successfully in this workspace**. There was no installed Android SDK/Gradle distribution, and `./gradlew --version` could not download Gradle 8.7 because DNS resolution for `services.gradle.org` failed (`curl: (6) Could not resolve host`).

The GitHub Actions workflow is configured to run `:app:verifyCoreLogic`, `:app:lintDebug` and `:app:assembleDebug` with JDK 17, Android SDK 35 and Gradle 8.7. The first successful CI run remains the required compile/lint verification. This document does not claim that the APK has already built.


## Follow-up CI failure supplied by user

The supplied GitHub Actions log reached Kotlin compilation and failed on `MainActivity.kt:279` with `Unresolved reference: openTarget`. The external-URL `LaunchedEffect` referenced a local function declared later in the composable scope. In v1.4.1 the effect has been moved below that function. Re-run the GitHub Actions workflow; this local environment does not contain an Android SDK, so a successful Android build cannot be claimed here.
