@echo off
setlocal
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
set VERSION=8.7
set GH=%USERPROFILE%\.gradle\dhyra-wrapper
set DIST=%GH%\gradle-%VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%GH%" mkdir "%GH%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%GH%\gradle-%VERSION%-bin.zip'; Expand-Archive -Force '%GH%\gradle-%VERSION%-bin.zip' '%GH%'"
)
call "%DIST%\bin\gradle.bat" %*
