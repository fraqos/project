# Third-party components and asset notes

The app module currently declares these runtime components:

| Component | Version | License family |
|---|---:|---|
| AndroidX Core KTX | 1.13.1 | Apache-2.0 |
| AndroidX Activity Compose | 1.9.3 | Apache-2.0 |
| AndroidX Lifecycle Runtime KTX / Compose | 2.8.7 | Apache-2.0 |
| AndroidX DataStore Preferences | 1.1.1 | Apache-2.0 |
| AndroidX WebKit | 1.12.1 | Apache-2.0 |
| Jetpack Compose (BOM-managed artifacts) | BOM 2024.10.01 | Apache-2.0 |
| ZXing Core | 3.5.3 | Apache-2.0 |

The application uses Android System WebView provided by the device and does not bundle Chromium. The launcher icon vectors in this repository are DHYRA-authored assets; the UI uses Material icons supplied by the Compose Material Icons dependency. No Brave, Chrome or Firefox logo/artwork is intentionally included.

No analytics, advertising, crash-reporting or telemetry SDK is declared in `app/build.gradle.kts`. This is a source-level dependency statement, not a complete binary/SBOM audit. Before publishing, regenerate a dependency inventory from the resolved Gradle graph and retain the upstream license/notice texts required by the exact resolved artifacts.
