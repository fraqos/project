package com.dhyra.browser.core.shields

import java.net.URI

/**
 * Small, immutable host/path filter matcher for WebView request interception.
 * Supported syntax: ||host^, ||host/path^ and @@ exceptions. This is intentionally
 * not a complete Adblock Plus/uBlock parser: resource types, initiators, regex,
 * cosmetic rules, scriptlets and complex option semantics are not implemented.
 */
class ShieldsFilterEngine(rules: Collection<String>) {
    private data class Rule(
        val host: String,
        val pathPrefix: String?,
        val pathBoundary: Boolean,
        val exception: Boolean
    )

    private val parsedRules: List<Rule> = rules.mapNotNull(::parseRule)

    fun shouldBlock(url: String): Boolean {
        val parsed = runCatching { URI(url) }.getOrNull() ?: return false
        val host = parsed.host?.lowercase()?.trimEnd('.') ?: return false
        val path = parsed.rawPath.orEmpty()
        val matching = parsedRules.filter { rule ->
            val hostMatches = host == rule.host || host.endsWith(".${rule.host}")
            val pathMatches = rule.pathPrefix == null || matchesPath(path, rule.pathPrefix, rule.pathBoundary)
            hostMatches && pathMatches
        }
        if (matching.any { it.exception }) return false
        return matching.any { !it.exception }
    }

    private fun matchesPath(path: String, prefix: String, boundary: Boolean): Boolean {
        if (!path.startsWith(prefix, ignoreCase = true)) return false
        if (!boundary || path.length == prefix.length) return true
        return path[prefix.length] in charArrayOf('/', '?', '#', '&', ';', '=')
    }

    private fun parseRule(raw: String): Rule? {
        var value = raw.trim()
        if (value.isEmpty() || value.startsWith("!") || value.startsWith("#")) return null
        val exception = value.startsWith("@@")
        if (exception) value = value.removePrefix("@@")
        if (!value.startsWith("||")) return null
        value = value.removePrefix("||")
        val optionsIndex = value.indexOf('$')
        if (optionsIndex >= 0) value = value.substring(0, optionsIndex)
        val pathBoundary = value.endsWith('^')
        value = value.removeSuffix("^")
        val slash = value.indexOf('/')
        val host = (if (slash >= 0) value.substring(0, slash) else value)
            .lowercase().trim().trimEnd('.')
        if (host.isBlank() || host.any { !(it.isLetterOrDigit() || it == '.' || it == '-') }) return null
        val path = if (slash >= 0) value.substring(slash).takeIf { it.isNotBlank() } else null
        return Rule(host, path, pathBoundary && path != null, exception)
    }
}
