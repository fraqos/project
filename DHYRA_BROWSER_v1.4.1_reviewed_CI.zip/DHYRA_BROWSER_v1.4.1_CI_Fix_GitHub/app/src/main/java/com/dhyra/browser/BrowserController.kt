package com.dhyra.browser

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.dhyra.browser.core.shields.ShieldsFilterEngine
import java.io.ByteArrayInputStream
import java.util.LinkedHashMap
import java.util.concurrent.ConcurrentHashMap

/** UI-safe state for one browser tab. It deliberately contains no WebView types. */
data class BrowserTab(
    val id: Int,
    val url: String,
    val title: String,
    val progress: Int,
    val loading: Boolean,
    val isPrivate: Boolean
)

/**
 * WebView-backed browser session coordinator.
 *
 * WebView remains the platform engine; this class is kept separate from Compose UI.
 * At most four live WebViews are retained. Other tabs keep an in-memory saved state
 * and are recreated lazily when selected. Saved state is never written to disk here.
 */
class BrowserController(
    private val activity: Activity,
    private val onFileChooser: (ValueCallback<Array<Uri>>) -> Unit,
    private val onPermission: (PermissionRequest) -> Unit,
    private val onGeolocation: (String, GeolocationPermissions.Callback) -> Unit
) {
    val tabs = mutableStateListOf<BrowserTab>()
    var activeTabId by mutableIntStateOf(-1)
        private set

    private val webViews = LinkedHashMap<Int, WebView>()
    private val savedStates = mutableMapOf<Int, Bundle>()
    private val lastActiveAt = mutableMapOf<Int, Long>()
    private val shieldsFilter = ShieldsFilterEngine(DEFAULT_FILTER_RULES)
    private val blockedRequestCounts = ConcurrentHashMap<Int, Int>()
    private var shieldRevision by mutableIntStateOf(0)
    private var nextId = 1
    private var host: FrameLayout? = null
    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var statusBarsWereVisible: Boolean = true
    private var navigationBarsWereVisible: Boolean = true
    private var priorSystemBarsBehavior: Int = WindowInsetsControllerCompat.BEHAVIOR_DEFAULT
    var isFullscreen by androidx.compose.runtime.mutableStateOf(false)
        private set

    var trackingProtection = true
    var popupBlocker = true
    var desktopMode = false
    var httpsFirst = true
    var onPageFinished: (BrowserTab) -> Unit = {}
    var onTabsChanged: (List<BrowserTab>) -> Unit = {}

    fun activeTab(): BrowserTab? = tabs.firstOrNull { it.id == activeTabId }
    fun activeWebView(): WebView? = webViews[activeTabId]
    fun blockedRequestCount(tabId: Int): Int = blockedRequestCounts[tabId] ?: 0
    fun totalBlockedRequestCount(): Int {
        // Reading this Compose state makes the toolbar badge reactive to intercepted requests.
        shieldRevision
        return blockedRequestCounts.values.sum()
    }

    /** New-tab pages do not allocate a WebView until a site is opened. */
    fun createTab(url: String = "about:blank", isPrivate: Boolean = false): Int {
        val id = nextId++
        val initialUrl = HttpsUpgrade.upgrade(url, httpsFirst)
        tabs.add(BrowserTab(id, initialUrl, "New tab", 0, false, isPrivate))
        activeTabId = id
        lastActiveAt[id] = System.currentTimeMillis()
        if (initialUrl != "about:blank") ensureWebView(id, loadInitialUrl = true)
        attachToHost()
        notifyTabsChanged()
        return id
    }

    fun restoreSession(entries: List<Pair<String, String>>) {
        if (tabs.isNotEmpty()) return
        entries.filter { isWebUrl(it.first) }.takeLast(30).forEach { (storedUrl, title) ->
            val url = HttpsUpgrade.upgrade(storedUrl, httpsFirst)
            val id = nextId++
            tabs.add(BrowserTab(id, url, title.ifBlank { url }, 0, false, false))
            lastActiveAt[id] = System.currentTimeMillis()
        }
        if (tabs.isNotEmpty()) activeTabId = tabs.last().id
        attachToHost()
        notifyTabsChanged()
    }

    fun sessionSnapshot(): List<Pair<String, String>> = tabs
        .filter { !it.isPrivate && isWebUrl(it.url) }
        .takeLast(30)
        .map { it.url to it.title }

    fun selectTab(id: Int) {
        if (tabs.none { it.id == id }) return
        activeTabId = id
        lastActiveAt[id] = System.currentTimeMillis()
        if (tabs.firstOrNull { it.id == id }?.url != "about:blank") ensureWebView(id, loadInitialUrl = true)
        attachToHost()
        notifyTabsChanged()
    }

    fun navigate(url: String) {
        val targetUrl = HttpsUpgrade.upgrade(url, httpsFirst)
        val id = activeTabId
        if (id == -1 || tabs.none { it.id == id }) {
            createTab(targetUrl)
            return
        }
        updateTab(id, url = targetUrl, title = targetUrl, loading = true, progress = 0)
        // Always issue the requested navigation, including when the tab was frozen.
        // A restored WebView may contain the previous page's history/state.
        val view = ensureWebView(id, loadInitialUrl = false, allowBlank = true)
        view?.loadUrl(targetUrl)
        attachToHost()
        notifyTabsChanged()
    }

    fun exitFullscreen() {
        val view = fullscreenView ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        fullscreenCallback?.onCustomViewHidden()
        fullscreenView = null
        fullscreenCallback = null
        val decor = activity.window.decorView
        val insetsController = WindowInsetsControllerCompat(activity.window, decor)
        if (statusBarsWereVisible) insetsController.show(WindowInsetsCompat.Type.statusBars())
        else insetsController.hide(WindowInsetsCompat.Type.statusBars())
        if (navigationBarsWereVisible) insetsController.show(WindowInsetsCompat.Type.navigationBars())
        else insetsController.hide(WindowInsetsCompat.Type.navigationBars())
        insetsController.systemBarsBehavior = priorSystemBarsBehavior
        isFullscreen = false
    }

    fun goBack() { activeWebView()?.let { if (it.canGoBack()) it.goBack() } }
    fun goForward() { activeWebView()?.let { if (it.canGoForward()) it.goForward() } }
    fun reload() {
        val tab = activeTab() ?: return
        val view = ensureWebView(tab.id, loadInitialUrl = false, allowBlank = true) ?: return
        val currentUrl = view.url
        if (currentUrl.isNullOrBlank() || currentUrl == "about:blank") view.loadUrl(tab.url)
        else view.reload()
    }
    fun stop() { activeWebView()?.stopLoading() }

    fun closeTab(id: Int) {
        val wasPrivate = tabs.firstOrNull { it.id == id }?.isPrivate == true
        destroyWebView(id, clearPrivate = wasPrivate)
        savedStates.remove(id)
        lastActiveAt.remove(id)
        blockedRequestCounts.remove(id)
        tabs.removeAll { it.id == id }
        if (activeTabId == id) activeTabId = tabs.lastOrNull()?.id ?: -1
        if (tabs.isEmpty()) createTab()
        else attachToHost()

        // AndroidX WebKit multi-profile support is not assumed by this build. As the
        // safest fallback, purge shared WebView storage when the final private tab closes.
        if (wasPrivate && tabs.none { it.isPrivate }) clearSharedWebStorage()
        notifyTabsChanged()
    }

    fun closeAllTabs() {
        val hadPrivateTabs = tabs.any { it.isPrivate }
        webViews.keys.toList().forEach { destroyWebView(it, clearPrivate = false) }
        savedStates.clear()
        lastActiveAt.clear()
        blockedRequestCounts.clear()
        if (hadPrivateTabs) clearSharedWebStorage()
        tabs.clear()
        activeTabId = -1
        createTab()
    }

    fun attach(container: FrameLayout) {
        host = container
        attachToHost()
    }

    private fun attachToHost() {
        val container = host ?: return
        val tab = activeTab()
        val view = if (tab != null && tab.url != "about:blank") ensureWebView(tab.id, loadInitialUrl = true) else null
        if (view == null) {
            container.removeAllViews()
            return
        }
        if (view.parent !== container) {
            (view.parent as? ViewGroup)?.removeView(view)
            container.removeAllViews()
            container.addView(
                view,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }
    }

    fun applySettings(tracking: Boolean, popup: Boolean, desktop: Boolean) {
        val desktopChanged = desktopMode != desktop
        trackingProtection = tracking
        popupBlocker = popup
        desktopMode = desktop
        webViews.forEach { (id, view) ->
            configureSettings(view, tabs.firstOrNull { it.id == id }?.isPrivate == true)
        }
        // Switching the user agent only takes effect on the next request, so reload the visible page.
        if (desktopChanged) activeWebView()?.reload()
    }

    fun clearRegularData() {
        webViews.forEach { (id, view) ->
            if (tabs.firstOrNull { it.id == id }?.isPrivate != true) {
                view.clearCache(true)
                view.clearHistory()
                view.clearFormData()
            }
        }
        // WebView cookies and WebStorage are process-wide without profile isolation.
        clearSharedWebStorage()
    }

    /** Called by Activity.onTrimMemory to release inactive renderers early. */
    fun trimMemory() {
        val active = activeTabId
        webViews.keys.filter { it != active }.toList().forEach { freezeTab(it) }
    }

    fun destroy() {
        val hadPrivateTabs = tabs.any { it.isPrivate }
        webViews.keys.toList().forEach { destroyWebView(it, clearPrivate = false) }
        webViews.clear()
        savedStates.clear()
        if (hadPrivateTabs) clearSharedWebStorage()
        tabs.clear()
        host?.removeAllViews()
        host = null
        exitFullscreen()
    }

    private fun ensureWebView(
        id: Int,
        loadInitialUrl: Boolean = false,
        allowBlank: Boolean = false
    ): WebView? {
        webViews[id]?.let {
            lastActiveAt[id] = System.currentTimeMillis()
            return it
        }
        val tab = tabs.firstOrNull { it.id == id } ?: return null
        if (tab.url == "about:blank" && !allowBlank) return null

        val view = buildWebView(id, tab.isPrivate)
        val saved = savedStates.remove(id)
        val restored = saved?.let { runCatching { view.restoreState(it) != null }.getOrDefault(false) } == true
        webViews[id] = view
        lastActiveAt[id] = System.currentTimeMillis()
        if (loadInitialUrl && !restored && isWebUrl(tab.url)) view.loadUrl(tab.url)
        trimToLiveWebViewLimit(exceptId = id)
        return view
    }

    private fun trimToLiveWebViewLimit(exceptId: Int) {
        while (webViews.size > MAX_LIVE_WEBVIEWS) {
            val victim = webViews.keys
                .filter { it != exceptId && it != activeTabId }
                .minByOrNull { lastActiveAt[it] ?: Long.MIN_VALUE }
                ?: break
            freezeTab(victim)
        }
    }

    private fun freezeTab(id: Int) {
        val view = webViews.remove(id) ?: return
        runCatching { savedStates[id] = Bundle().also { view.saveState(it) } }
        (view.parent as? ViewGroup)?.removeView(view)
        view.stopLoading()
        view.loadUrl("about:blank")
        view.destroy()
    }

    private fun destroyWebView(id: Int, clearPrivate: Boolean) {
        val view = webViews.remove(id) ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        view.stopLoading()
        if (clearPrivate) {
            view.clearHistory()
            view.clearCache(true)
            view.clearFormData()
        }
        view.loadUrl("about:blank")
        view.destroy()
    }

    private fun clearSharedWebStorage() {
        val cookies = CookieManager.getInstance()
        cookies.removeAllCookies { cookies.flush() }
        android.webkit.WebStorage.getInstance().deleteAllData()
    }

    private fun buildWebView(id: Int, isPrivate: Boolean): WebView {
        return WebView(activity).apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            configureSettings(this, isPrivate)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    if (url != null) updateTab(id, url = url, loading = true, progress = 5)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    val finalUrl = url ?: view?.url ?: "about:blank"
                    val current = updateTab(
                        id,
                        url = finalUrl,
                        title = view?.title?.takeIf { it.isNotBlank() } ?: finalUrl,
                        loading = false,
                        progress = 100
                    )
                    if (current != null) {
                        lastActiveAt[id] = System.currentTimeMillis()
                        onPageFinished(current)
                        notifyTabsChanged()
                    }
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        updateTab(id, loading = false)
                        if (error != null) {
                            Toast.makeText(activity, "Page failed to load. Check your connection or try HTTPS.", Toast.LENGTH_LONG).show()
                        }
                    }
                }

                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: android.net.http.SslError?) {
                    // Certificate failures are always cancelled. Never add an implicit bypass.
                    handler?.cancel()
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val scheme = uri.scheme?.lowercase()
                    if (scheme == "http" && request.isForMainFrame && httpsFirst) {
                        view?.loadUrl(HttpsUpgrade.upgrade(uri.toString(), true))
                        return true
                    }
                    if (request.isForMainFrame && scheme in setOf("data", "javascript", "file", "content")) {
                        Toast.makeText(activity, "This top-level navigation was blocked", Toast.LENGTH_SHORT).show()
                        return true
                    }
                    if (scheme in setOf("http", "https", "about", "blob")) return false
                    return openExternal(uri)
                }

                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    if (!trackingProtection || request == null) return super.shouldInterceptRequest(view, request)
                    val uri = request.url
                    if (shieldsFilter.shouldBlock(uri.toString())) {
                        blockedRequestCounts.merge(id, 1, Int::plus)
                        activity.runOnUiThread { shieldRevision++ }
                        return blockedResponse(uri, request)
                    }
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    val crashed = webViews[id]
                    if (crashed != null && (view == null || crashed === view)) {
                        (crashed.parent as? ViewGroup)?.removeView(crashed)
                        webViews.remove(id)
                        savedStates.remove(id)
                        runCatching { crashed.destroy() }
                    }
                    updateTab(id, loading = false, title = "Tab stopped unexpectedly")
                    activity.runOnUiThread {
                        if (activeTabId == id) host?.removeAllViews()
                        Toast.makeText(activity, "A page crashed. Reload this tab to continue.", Toast.LENGTH_LONG).show()
                        notifyTabsChanged()
                    }
                    return true
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    updateTab(id, progress = newProgress, loading = newProgress < 100)
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                    if (!title.isNullOrBlank()) updateTab(id, title = title)
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    if (filePathCallback == null) return false
                    onFileChooser(filePathCallback)
                    return true
                }

                override fun onPermissionRequest(request: PermissionRequest?) {
                    if (request == null) return
                    activity.runOnUiThread { onPermission(request) }
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    if (origin == null || callback == null) return
                    activity.runOnUiThread { onGeolocation(origin, callback) }
                }

                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (view == null) return
                    if (fullscreenView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    fullscreenView = view
                    fullscreenCallback = callback
                    val decor = activity.window.decorView as? ViewGroup
                    if (decor != null) {
                        val currentInsets = ViewCompat.getRootWindowInsets(decor)
                        statusBarsWereVisible = currentInsets?.isVisible(WindowInsetsCompat.Type.statusBars()) ?: true
                        navigationBarsWereVisible = currentInsets?.isVisible(WindowInsetsCompat.Type.navigationBars()) ?: true
                        val insetsController = WindowInsetsControllerCompat(activity.window, decor)
                        priorSystemBarsBehavior = insetsController.systemBarsBehavior
                        decor.addView(
                            view,
                            ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        insetsController.hide(WindowInsetsCompat.Type.systemBars())
                        isFullscreen = true
                    }
                }

                override fun onHideCustomView() { exitFullscreen() }

                override fun onCreateWindow(
                    view: WebView?,
                    isDialog: Boolean,
                    isUserGesture: Boolean,
                    resultMsg: android.os.Message?
                ): Boolean {
                    if (popupBlocker || !isUserGesture) return false
                    val newId = createTab("about:blank", isPrivate)
                    val newView = ensureWebView(newId, allowBlank = true) ?: return false
                    val message = resultMsg ?: return false
                    val transport = message.obj as? WebView.WebViewTransport ?: return false
                    transport.webView = newView
                    message.sendToTarget()
                    return true
                }

                override fun onCloseWindow(window: WebView?) {
                    val tabId = webViews.entries.firstOrNull { it.value == window }?.key
                    if (tabId != null) closeTab(tabId)
                }
            }

            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                enqueueDownload(activity, url, userAgent, contentDisposition, mimeType)
            })
        }
    }

    private fun configureSettings(view: WebView, isPrivate: Boolean) {
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setGeolocationEnabled(true)
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = !popupBlocker
            setSupportMultipleWindows(true)
            setSupportZoom(true)
            useWideViewPort = desktopMode
            loadWithOverviewMode = desktopMode
            builtInZoomControls = true
            displayZoomControls = false
            allowFileAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = if (isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            safeBrowsingEnabled = true
            val systemAgent = WebSettings.getDefaultUserAgent(activity)
            userAgentString = if (desktopMode) {
                systemAgent.replace("; wv", "").replace(" Version/4.0", "").replace(" Mobile", "")
            } else {
                systemAgent.replace("; wv", "").replace(" Version/4.0", "")
            }.replace(Regex("\\s+"), " ").trim()
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, !trackingProtection)
    }

    private fun updateTab(
        id: Int,
        url: String? = null,
        title: String? = null,
        progress: Int? = null,
        loading: Boolean? = null
    ): BrowserTab? {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return null
        val old = tabs[index]
        val updated = old.copy(
            url = url ?: old.url,
            title = title ?: old.title,
            progress = progress ?: old.progress,
            loading = loading ?: old.loading
        )
        tabs[index] = updated
        return updated
    }

    /** External intents are restricted to browser-safe web URLs and standard contact links. */
    private fun openExternal(uri: Uri): Boolean {
        return try {
            if (uri.scheme.equals("intent", ignoreCase = true)) {
                val parsed = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME).apply {
                    action = Intent.ACTION_VIEW
                    component = null
                    selector = null
                    setPackage(null)
                    flags = 0
                    addCategory(Intent.CATEGORY_BROWSABLE)
                }
                val target = parsed.data
                when (target?.scheme?.lowercase()) {
                    "http", "https" -> navigate(target.toString())
                    "mailto", "tel" -> launchBrowsable(target)
                    else -> {
                        val fallback = parsed.getStringExtra("browser_fallback_url")
                        if (isSafeWebUrl(fallback)) navigate(fallback!!)
                        else Toast.makeText(activity, "This external link was blocked for safety", Toast.LENGTH_LONG).show()
                    }
                }
                true
            } else if (uri.scheme.equals("mailto", true) || uri.scheme.equals("tel", true)) {
                launchBrowsable(uri)
                true
            } else {
                Toast.makeText(activity, "This link type is not supported by DHYRA", Toast.LENGTH_SHORT).show()
                true
            }
        } catch (_: Exception) {
            Toast.makeText(activity, "Unable to open this external link", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun launchBrowsable(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            component = null
            selector = null
            addCategory(Intent.CATEGORY_BROWSABLE)
        }
        activity.startActivity(intent)
    }

    private fun blockedResponse(uri: Uri, request: WebResourceRequest): WebResourceResponse {
        val accept = request.requestHeaders["Accept"].orEmpty().lowercase()
        val path = uri.path.orEmpty().lowercase()
        val mime = when {
            accept.contains("javascript") || path.endsWith(".js") -> "application/javascript"
            accept.contains("image/") || path.endsWith(".png") || path.endsWith(".jpg") || path.endsWith(".gif") || path.endsWith(".webp") -> "image/gif"
            else -> "text/plain"
        }
        val body = if (mime == "application/javascript") EMPTY_SCRIPT
            else if (mime == "image/gif") TRANSPARENT_GIF
            else ByteArray(0)
        val emptyResource = mime == "text/plain"
        return WebResourceResponse(
            mime,
            "UTF-8",
            if (emptyResource) 204 else 200,
            if (emptyResource) "No Content" else "OK",
            mapOf("Cache-Control" to "no-store", "X-DHYRA-Blocked" to "1"),
            ByteArrayInputStream(body)
        )
    }

    private fun notifyTabsChanged() = onTabsChanged(tabs.toList())

    private fun isWebUrl(value: String): Boolean = value.startsWith("https://", true) || value.startsWith("http://", true)
    private fun isSafeWebUrl(value: String?): Boolean = value?.startsWith("https://", true) == true || value?.startsWith("http://", true) == true

    private fun enqueueDownload(
        context: Context,
        url: String,
        userAgent: String,
        contentDisposition: String,
        mimeType: String
    ) {
        try {
            val parsed = Uri.parse(url)
            if (parsed.scheme !in setOf("http", "https")) {
                Toast.makeText(context, "Only HTTP/HTTPS downloads are supported", Toast.LENGTH_LONG).show()
                return
            }
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val request = DownloadManager.Request(parsed)
                .setTitle(fileName)
                .setDescription("Downloaded by DHYRA Browser")
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", userAgent)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            val cookie = CookieManager.getInstance().getCookie(url)
            if (!cookie.isNullOrBlank()) request.addRequestHeader("Cookie", cookie)
            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(context, "Download started", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(context, "Unable to start download", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private const val MAX_LIVE_WEBVIEWS = 4
        private val DEFAULT_FILTER_RULES = listOf(
            "||doubleclick.net^",
            "||googlesyndication.com^",
            "||googletagmanager.com^",
            "||google-analytics.com^",
            "||connect.facebook.net^",
            "||pixel.facebook.com^",
            "||facebook.com/tr^",
            "||analytics.twitter.com^",
            "||ads-twitter.com^",
            "||hotjar.com^",
            "||segment.io^",
            "||segment.com^",
            "||scorecardresearch.com^",
            "||quantserve.com^",
            "||adservice.google.com^"
        )
        private val EMPTY_SCRIPT = "/* blocked by DHYRA Shields */".toByteArray(Charsets.UTF_8)
        private val TRANSPARENT_GIF = byteArrayOf(
            0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00,
            0x01, 0x00, 0x80.toByte(), 0x00, 0x00, 0x00, 0x00,
            0x00, 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0x21,
            0xF9.toByte(), 0x04, 0x01, 0x00, 0x00, 0x00, 0x00,
            0x2C, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01,
            0x00, 0x00, 0x02, 0x02, 0x44, 0x01, 0x00, 0x3B
        )
    }
}
