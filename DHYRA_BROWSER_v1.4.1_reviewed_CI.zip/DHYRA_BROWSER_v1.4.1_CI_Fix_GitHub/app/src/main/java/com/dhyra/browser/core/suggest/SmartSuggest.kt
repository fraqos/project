package com.dhyra.browser.core.suggest

import java.net.URI

/** A host suggestion shown under the address bar, e.g. "youtube.com". */
data class HostSuggestion(val host: String) {
    val url: String get() = "https://$host"
}

/**
 * Pure-JVM domain suggestion engine. Bookmarks and history are ranked before
 * the built-in list so that sites the user already visits appear first.
 */
object SmartSuggest {
    private val POPULAR_HOSTS: List<String> = listOf(
        "google.com", "youtube.com", "facebook.com", "instagram.com", "x.com",
        "tiktok.com", "wikipedia.org", "reddit.com", "github.com", "gmail.com",
        "whatsapp.com", "linkedin.com", "netflix.com", "twitch.tv", "amazon.com",
        "yahoo.com", "bing.com", "duckduckgo.com", "chatgpt.com", "claude.ai",
        "openai.com", "anthropic.com", "notion.so", "spotify.com", "medium.com",
        "stackoverflow.com", "pinterest.com", "maps.google.com", "drive.google.com",
        "docs.google.com", "tokopedia.com", "shopee.co.id", "detik.com", "kompas.com",
        "bbc.com", "cnn.com", "developer.android.com", "kotlinlang.org", "brave.com",
        "web.telegram.org"
    )

    /** Lowercases the input and removes scheme, leading "www." and trailing slashes. */
    fun normalize(input: String): String = input.trim().lowercase()
        .removePrefix("https://")
        .removePrefix("http://")
        .removePrefix("www.")
        .trimEnd('/')

    /** Extracts a bare host from a URL or host string, or null if it is not a host. */
    fun hostOf(urlOrHost: String): String? {
        val trimmed = urlOrHost.trim()
        if (trimmed.isEmpty()) return null
        val parsed = runCatching { URI(trimmed).host }.getOrNull()
        val host = (parsed ?: trimmed.substringBefore('/')).lowercase().removePrefix("www.")
        return host.takeIf { it.isNotBlank() && it.contains('.') && !it.contains(' ') }
    }

    fun suggest(
        input: String,
        history: List<String>,
        bookmarks: List<String>,
        limit: Int = 5
    ): List<HostSuggestion> {
        // Only the part before the first slash is matched against hosts ("github.com/x" -> "github.com").
        val query = normalize(input).substringBefore('/')
        if (query.isEmpty() || query.contains(' ')) return emptyList()

        val candidates = LinkedHashSet<String>()
        bookmarks.forEach { hostOf(it)?.let(candidates::add) }
        history.forEach { hostOf(it)?.let(candidates::add) }
        candidates.addAll(POPULAR_HOSTS)

        return candidates
            .mapNotNull { host -> rank(host, query)?.let { host to it } }
            .sortedBy { it.second } // stable: keeps bookmarks/history before the built-in list
            .take(limit)
            .map { HostSuggestion(it.first) }
    }

    private fun rank(host: String, query: String): Int? = when {
        host.startsWith(query) -> 0
        host.split('.').any { it.startsWith(query) } -> 1
        host.contains(query) -> 2
        else -> null
    }
}
