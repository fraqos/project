package com.dhyra.browser

import android.app.DownloadManager
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import com.dhyra.browser.core.suggest.HostSuggestion
import com.dhyra.browser.core.suggest.SmartSuggest
import java.util.Calendar
import kotlinx.coroutines.delay
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

private val Context.dhyraStore by preferencesDataStore(name = "dhyra_settings")
private val HOME_KEY = stringPreferencesKey("homepage")
private val ENGINE_KEY = stringPreferencesKey("search_engine")
private val THEME_KEY = stringPreferencesKey("theme")
private val TRACKING_KEY = booleanPreferencesKey("tracking_protection")
private val POPUP_KEY = booleanPreferencesKey("popup_blocker")
private val DESKTOP_KEY = booleanPreferencesKey("desktop_mode")
private val SESSION_KEY = stringPreferencesKey("session_json")
private val HISTORY_KEY = stringPreferencesKey("history_json")
private val BOOKMARKS_KEY = stringPreferencesKey("bookmarks_json")

private const val BTC_ADDRESS = "bc1qrdlrhldck8pz6mtcaths86htz3g3hjyhsa44q5"
private const val ABOUT_BLANK = "about:blank"

private val Accent = Color(0xFF7CC8E8)
private val AccentLight = Color(0xFF2B8CBE)
private val PrivateTint = Color(0xFF3A2D5C)

private val ENGINE_OPTIONS = listOf("Brave", "Google", "Bing", "DuckDuckGo", "Ecosia", "Startpage", "Qwant")
private val THEME_OPTIONS = listOf("System", "Light", "Dark")

private enum class Route { HOME, BROWSER, SETTINGS, TABS, BOOKMARKS, HISTORY, DOWNLOADS, SUPPORT, ABOUT }

private data class PreferencesState(
    val homepage: String,
    val engine: String,
    val theme: String,
    val tracking: Boolean,
    val popup: Boolean,
    val desktop: Boolean
)

private data class SavedPage(val title: String, val url: String, val timestamp: Long = System.currentTimeMillis())
private data class Shortcut(val label: String, val url: String, val symbol: String)
private data class DownloadRow(val id: Long, val title: String, val status: String, val total: Long, val downloaded: Long)

private val TOP_SITES = listOf(
    Shortcut("Google", "https://www.google.com", "G"),
    Shortcut("YouTube", "https://m.youtube.com", "▶"),
    Shortcut("GitHub", "https://github.com", "⌘"),
    Shortcut("Wikipedia", "https://wikipedia.org", "W"),
    Shortcut("Reddit", "https://www.reddit.com", "r"),
    Shortcut("Telegram", "https://web.telegram.org", "➤"),
    Shortcut("Bing", "https://www.bing.com", "B"),
    Shortcut("Brave", "https://search.brave.com", "🦁")
)

class MainActivity : ComponentActivity() {
    var pendingExternalUrl by mutableStateOf<String?>(null)
    var browserController: BrowserController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        acceptExternalIntent(intent)
        setContent { DhyraApplication() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        acceptExternalIntent(intent)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) browserController?.trimMemory()
    }

    private fun acceptExternalIntent(intent: Intent?) {
        if (intent == null) return
        pendingExternalUrl = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data?.takeIf {
                it.scheme.equals("http", true) || it.scheme.equals("https", true)
            }?.toString()
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_WEB_SEARCH -> intent.getStringExtra(android.app.SearchManager.QUERY)
            else -> null
        }?.takeIf { it.isNotBlank() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DhyraApplication() {
    val context = LocalContext.current
    val activity = context as MainActivity
    val scope = rememberCoroutineScope()

    var pendingFileChooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        pendingFileChooser?.onReceiveValue(uris.toTypedArray())
        pendingFileChooser = null
    }

    var pendingPermission by remember { mutableStateOf<PermissionRequest?>(null) }
    var showSitePermissionDialog by remember { mutableStateOf(false) }
    var pendingGeo by remember { mutableStateOf<Pair<String, GeolocationPermissions.Callback>?>(null) }
    var showGeoPermissionDialog by remember { mutableStateOf(false) }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val pending = pendingGeo
        if (pending != null) {
            val allowed = results.values.any { it }
            pending.second.invoke(pending.first, allowed, false)
        }
        pendingGeo = null
        showGeoPermissionDialog = false
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val request = pendingPermission
        if (request != null) {
            val granted = results.values.all { it }
            val supported = request.resources.filter {
                it == PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
                    it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
                    it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID
            }
            if (granted && supported.isNotEmpty()) runCatching { request.grant(supported.toTypedArray()) }
            else runCatching { request.deny() }
        }
        pendingPermission = null
        showSitePermissionDialog = false
    }

    val controller = remember(activity) {
        BrowserController(
            activity = activity,
            onFileChooser = { callback ->
                pendingFileChooser?.onReceiveValue(null)
                pendingFileChooser = callback
                filePicker.launch(arrayOf("*/*"))
            },
            onPermission = { request ->
                pendingPermission?.let { old -> runCatching { old.deny() } }
                pendingPermission = request
                showSitePermissionDialog = true
            },
            onGeolocation = { origin, callback ->
                pendingGeo?.second?.let { previous -> runCatching { previous.invoke(pendingGeo?.first.orEmpty(), false, false) } }
                pendingGeo = origin to callback
                showGeoPermissionDialog = true
            }
        )
    }

    val prefs by context.dhyraStore.data.collectAsState(
        initial = androidx.datastore.preferences.core.emptyPreferences()
    )
    val state = PreferencesState(
        homepage = prefs[HOME_KEY] ?: "https://www.google.com",
        engine = prefs[ENGINE_KEY] ?: "Brave",
        theme = prefs[THEME_KEY] ?: "System",
        tracking = prefs[TRACKING_KEY] ?: true,
        popup = prefs[POPUP_KEY] ?: true,
        desktop = prefs[DESKTOP_KEY] ?: false
    )
    val historyRaw = prefs[HISTORY_KEY] ?: "[]"
    val bookmarksRaw = prefs[BOOKMARKS_KEY] ?: "[]"
    val history = remember(historyRaw) { decodeEntries(historyRaw) }
    val bookmarks = remember(bookmarksRaw) { decodeEntries(bookmarksRaw) }

    var route by remember { mutableStateOf(Route.HOME) }
    var address by remember { mutableStateOf("") }
    var homeQuery by remember { mutableStateOf("") }
    var findText by remember { mutableStateOf("") }
    var showFind by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showShields by remember { mutableStateOf(false) }
    var refreshDownloads by remember { mutableIntStateOf(0) }
    var addressFocused by remember { mutableStateOf(false) }
    var suggestOpen by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    val historyUrls = remember(history) { history.map { it.url } }
    val bookmarkUrls = remember(bookmarks) { bookmarks.map { it.url } }
    val addressSuggestions = remember(address, historyUrls, bookmarkUrls) {
        SmartSuggest.suggest(address, historyUrls, bookmarkUrls)
    }
    val homeSuggestions = remember(homeQuery, historyUrls, bookmarkUrls) {
        SmartSuggest.suggest(homeQuery, historyUrls, bookmarkUrls)
    }

    val isDark = when (state.theme) {
        "Dark" -> true
        "Light" -> false
        else -> isSystemInDarkTheme()
    }
    SideEffect {
        WindowInsetsControllerCompat(activity.window, activity.window.decorView).isAppearanceLightStatusBars = !isDark
        WindowInsetsControllerCompat(activity.window, activity.window.decorView).isAppearanceLightNavigationBars = !isDark
    }
    val colorScheme = if (isDark) darkColorScheme(
        primary = Accent,
        onPrimary = Color(0xFF0B1014),
        background = Color(0xFF0F1115),
        surface = Color(0xFF171A20),
        surfaceVariant = Color(0xFF202430),
        onSurface = Color(0xFFE9ECF2),
        onSurfaceVariant = Color(0xFF8F97A8),
        outline = Color(0xFF2C313C)
    ) else lightColorScheme(
        primary = AccentLight,
        onPrimary = Color.White,
        background = Color(0xFFFCFCFD),
        surface = Color(0xFFF3F4F7),
        surfaceVariant = Color(0xFFE9EBF0),
        onSurface = Color(0xFF16181D),
        onSurfaceVariant = Color(0xFF626A7A),
        outline = Color(0xFFD5D9E2)
    )

    controller.onPageFinished = { tab ->
        if (!tab.isPrivate && (tab.url.startsWith("https://") || tab.url.startsWith("http://"))) {
            scope.launch {
                val currentRaw = context.dhyraStore.data.first()[HISTORY_KEY] ?: "[]"
                val current = decodeEntries(currentRaw)
                val updated = (listOf(SavedPage(tab.title, tab.url)) + current.filterNot { it.url == tab.url }).take(5000)
                context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(updated) }
            }
        }
    }
    controller.onTabsChanged = { snapshot ->
        val json = JSONArray()
        snapshot.filter { !it.isPrivate && (it.url.startsWith("https://") || it.url.startsWith("http://")) }
            .takeLast(30).forEach { tab ->
                json.put(JSONObject().put("url", tab.url).put("title", tab.title))
            }
        scope.launch { context.dhyraStore.edit { it[SESSION_KEY] = json.toString() } }
    }
    activity.browserController = controller

    LaunchedEffect(controller) {
        if (controller.tabs.isEmpty()) {
            val persistedSession = context.dhyraStore.data.first()[SESSION_KEY] ?: "[]"
            val restored = decodeSession(persistedSession)
            if (restored.isNotEmpty()) controller.restoreSession(restored) else controller.createTab()
        }
    }
    LaunchedEffect(state.tracking, state.popup, state.desktop) {
        controller.applySettings(state.tracking, state.popup, state.desktop)
    }
    DisposableEffect(controller) {
        onDispose {
            pendingFileChooser?.onReceiveValue(null)
            controller.destroy()
            activity.browserController = null
        }
    }

    val activeTab = controller.activeTab()
    LaunchedEffect(activeTab?.id, activeTab?.url) {
        activeTab?.url?.takeIf { it != ABOUT_BLANK }?.let { address = it }
    }

    fun saveValue(key: String, value: Any) {
        scope.launch {
            context.dhyraStore.edit { p ->
                when (value) {
                    is String -> p[stringPreferencesKey(key)] = value
                    is Float -> p[floatPreferencesKey(key)] = value
                    is Boolean -> p[booleanPreferencesKey(key)] = value
                }
            }
        }
    }

    fun openTarget(raw: String, newTab: Boolean = false, isPrivate: Boolean = false) {
        val target = BrowserAddressResolver.resolve(raw, state.engine)
        if (newTab || controller.activeTabId == -1) controller.createTab(target, isPrivate)
        else controller.navigate(target)
        address = target
        route = Route.BROWSER
    }

    // Keep the panel open briefly after focus is lost so a tap on a suggestion still registers.
    LaunchedEffect(addressFocused) {
        if (addressFocused) {
            suggestOpen = true
        } else {
            delay(180)
            suggestOpen = false
        }
    }

    fun pickSuggestion(url: String) {
        focusManager.clearFocus()
        openTarget(url)
    }

    fun submitAddress() {
        focusManager.clearFocus()
        openTarget(address)
    }

    fun submitHomeQuery() {
        val text = homeQuery
        homeQuery = ""
        focusManager.clearFocus()
        openTarget(text)
    }

    LaunchedEffect(activity.pendingExternalUrl) {
        val incoming = activity.pendingExternalUrl
        if (!incoming.isNullOrBlank()) {
            activity.pendingExternalUrl = null
            openTarget(incoming, newTab = true)
        }
    }

    fun addBookmark() {
        val tab = controller.activeTab() ?: return
        if (!tab.url.startsWith("http")) return
        scope.launch {
            val latestRaw = context.dhyraStore.data.first()[BOOKMARKS_KEY] ?: "[]"
            val latest = decodeEntries(latestRaw).filterNot { it.url == tab.url }
            context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries((listOf(SavedPage(tab.title, tab.url)) + latest).take(500)) }
        }
    }

    fun sharePage() {
        val share = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, controller.activeTab()?.url ?: "")
        context.startActivity(Intent.createChooser(share, "Share page"))
    }

    BackHandler(enabled = controller.isFullscreen || route != Route.HOME) {
        when {
            controller.isFullscreen -> controller.exitFullscreen()
            route == Route.BROWSER && controller.activeWebView()?.canGoBack() == true -> controller.goBack()
            else -> route = Route.HOME
        }
    }

    MaterialTheme(colorScheme = colorScheme, typography = Typography()) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (route) {
                Route.HOME -> HomePage(
                    query = homeQuery,
                    onQueryChange = { homeQuery = it },
                    onSubmit = { submitHomeQuery() },
                    onFocusChange = { addressFocused = it },
                    suggestOpen = suggestOpen,
                    suggestions = homeSuggestions,
                    onPick = { pickSuggestion(it) },
                    onSearch = { submitHomeQuery() },
                    recent = history,
                    onRecent = { openTarget(it, newTab = true) },
                    sites = TOP_SITES,
                    onSite = { openTarget(it) },
                    tabCount = controller.tabs.size,
                    onTabs = { route = Route.TABS },
                    onMenu = { showMenu = true }
                )

                Route.BROWSER -> BrowserPage(
                    controller = controller,
                    address = address,
                    onAddressChange = { address = it },
                    onSubmit = { submitAddress() },
                    onFocusChange = { addressFocused = it },
                    suggestOpen = suggestOpen,
                    suggestions = addressSuggestions,
                    onPick = { pickSuggestion(it) },
                    onSearch = { submitAddress() },
                    desktop = state.desktop,
                    onDesktop = { saveValue("desktop_mode", !state.desktop) },
                    onShields = { showShields = true },
                    showFind = showFind,
                    findText = findText,
                    onFindChange = {
                        findText = it
                        controller.activeWebView()?.findAllAsync(it)
                    },
                    onFindClose = {
                        showFind = false
                        findText = ""
                        controller.activeWebView()?.clearMatches()
                    },
                    onHome = { route = Route.HOME },
                    onTabs = { route = Route.TABS },
                    onMenu = { showMenu = true }
                )

                Route.TABS -> TabsScreen(
                    controller = controller,
                    onBack = { route = if (controller.activeTabId == -1) Route.HOME else Route.BROWSER },
                    onSelect = { id ->
                        controller.selectTab(id)
                        route = Route.BROWSER
                    },
                    onClose = { id ->
                        controller.closeTab(id)
                        if (controller.tabs.isEmpty()) controller.createTab()
                    },
                    onNew = {
                        controller.createTab()
                        route = Route.HOME
                    },
                    onNewPrivate = {
                        controller.createTab(isPrivate = true)
                        route = Route.HOME
                    }
                )

                Route.SETTINGS -> SettingsScreen(
                    state = state,
                    onBack = { route = Route.HOME },
                    onSave = ::saveValue,
                    onClear = {
                        controller.clearRegularData()
                        scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                    },
                    onSetDefaultBrowser = { requestDefaultBrowserRole(activity) },
                    onSupport = { route = Route.SUPPORT },
                    onAbout = { route = Route.ABOUT }
                )

                Route.BOOKMARKS -> EntriesScreen(
                    title = "Bookmarks",
                    entries = bookmarks,
                    emptyText = "No bookmarks yet",
                    onBack = { route = Route.HOME },
                    onOpen = { openTarget(it, newTab = true) },
                    onDelete = { url ->
                        scope.launch {
                            val remaining = bookmarks.filterNot { it.url == url }
                            context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries(remaining) }
                        }
                    }
                )

                Route.HISTORY -> EntriesScreen(
                    title = "History",
                    entries = history,
                    emptyText = "No history yet",
                    onBack = { route = Route.HOME },
                    onOpen = { openTarget(it, newTab = true) },
                    onDelete = { url ->
                        scope.launch {
                            val remaining = history.filterNot { it.url == url }
                            context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(remaining) }
                        }
                    },
                    onClearAll = {
                        scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                    }
                )

                Route.DOWNLOADS -> DownloadsScreen(onBack = { route = Route.HOME }, refreshKey = refreshDownloads)
                Route.SUPPORT -> SupportScreen(onBack = { route = Route.SETTINGS })
                Route.ABOUT -> AboutScreen(onBack = { route = Route.SETTINGS })
            }
        }

        if (showMenu) {
            MenuSheet(
                inBrowser = route == Route.BROWSER,
                onDismiss = { showMenu = false },
                onNewTab = { controller.createTab(); route = Route.HOME },
                onNewPrivate = { controller.createTab(isPrivate = true); route = Route.HOME },
                onAddBookmark = { addBookmark() },
                onBookmarks = { route = Route.BOOKMARKS },
                onHistory = { route = Route.HISTORY },
                onDownloads = { refreshDownloads++; route = Route.DOWNLOADS },
                onFind = { showFind = true },
                onShare = { sharePage() },
                onSettings = { route = Route.SETTINGS }
            )
        }

        if (showShields) {
            ShieldsSheet(
                siteLabel = siteLabelOf(activeTab?.url),
                blocked = controller.blockedRequestCount(controller.activeTabId),
                tracking = state.tracking,
                popup = state.popup,
                desktop = state.desktop,
                onDismiss = { showShields = false },
                onSave = ::saveValue
            )
        }

        if (showSitePermissionDialog && pendingPermission != null) {
            val request = pendingPermission
            val origin = request?.origin?.toString() ?: "This website"
            val requestedResources = request?.resources?.joinToString { resource ->
                when (resource) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "camera"
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "microphone"
                    PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID -> "protected media / DRM"
                    else -> "unsupported resource"
                }
            } ?: "device resources"
            AlertDialog(
                onDismissRequest = {
                    runCatching { request?.deny() }
                    pendingPermission = null
                    showSitePermissionDialog = false
                },
                title = { Text("Allow site permission?") },
                text = { Text("$origin is requesting: $requestedResources. Only approve sites you trust.") },
                confirmButton = {
                    TextButton(onClick = {
                        val current = pendingPermission
                        val resources = current?.resources.orEmpty()
                        val runtimePermissions = buildList {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in resources) add(android.Manifest.permission.CAMERA)
                            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in resources) add(android.Manifest.permission.RECORD_AUDIO)
                        }
                        if (runtimePermissions.isNotEmpty()) {
                            permissionLauncher.launch(runtimePermissions.distinct().toTypedArray())
                        } else {
                            val supported = resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }
                            if (supported.isNotEmpty()) runCatching { current?.grant(supported.toTypedArray()) }
                            else runCatching { current?.deny() }
                            pendingPermission = null
                            showSitePermissionDialog = false
                        }
                    }) { Text("Allow") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        runCatching { request?.deny() }
                        pendingPermission = null
                        showSitePermissionDialog = false
                    }) { Text("Block") }
                }
            )
        }

        if (showGeoPermissionDialog && pendingGeo != null) {
            val (origin, callback) = pendingGeo!!
            AlertDialog(
                onDismissRequest = {
                    runCatching { callback.invoke(origin, false, false) }
                    pendingGeo = null
                    showGeoPermissionDialog = false
                },
                title = { Text("Allow location access?") },
                text = { Text("$origin is requesting your device location. This request is not saved for future visits.") },
                confirmButton = {
                    TextButton(onClick = {
                        val fineGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        val coarseGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        if (fineGranted || coarseGranted) {
                            runCatching { callback.invoke(origin, true, false) }
                            pendingGeo = null
                            showGeoPermissionDialog = false
                        } else {
                            locationLauncher.launch(arrayOf(
                                android.Manifest.permission.ACCESS_FINE_LOCATION,
                                android.Manifest.permission.ACCESS_COARSE_LOCATION
                            ))
                        }
                    }) { Text("Allow once") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        runCatching { callback.invoke(origin, false, false) }
                        pendingGeo = null
                        showGeoPermissionDialog = false
                    }) { Text("Block") }
                }
            )
        }
    }
}

// ---------- Browser ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BrowserPage(
    controller: BrowserController,
    address: String,
    onAddressChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onFocusChange: (Boolean) -> Unit,
    suggestOpen: Boolean,
    suggestions: List<HostSuggestion>,
    onPick: (String) -> Unit,
    onSearch: () -> Unit,
    desktop: Boolean,
    onDesktop: () -> Unit,
    onShields: () -> Unit,
    showFind: Boolean,
    findText: String,
    onFindChange: (String) -> Unit,
    onFindClose: () -> Unit,
    onHome: () -> Unit,
    onTabs: () -> Unit,
    onMenu: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val active = controller.activeTab()
    val webView = controller.activeWebView()
    val fullscreen = controller.isFullscreen

    Column(Modifier.fillMaxSize().background(cs.background)) {
        if (!fullscreen) {
            TopAddressBar(
                address = address,
                onAddressChange = onAddressChange,
                onSubmit = onSubmit,
                onFocusChange = onFocusChange,
                blocked = controller.blockedRequestCount(controller.activeTabId),
                loading = active?.loading == true,
                progress = active?.progress ?: 0,
                desktop = desktop,
                onDesktop = onDesktop,
                onShields = onShields,
                onReload = { if (active?.loading == true) controller.stop() else controller.reload() }
            )
            if (suggestOpen && address.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                SuggestionPanel(query = address, suggestions = suggestions, onPick = onPick, onSearch = onSearch)
                Spacer(Modifier.height(6.dp))
            }
            if (showFind) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AddressField(
                        value = findText,
                        onValueChange = onFindChange,
                        onSubmit = {},
                        onFocusChange = {},
                        placeholder = "Find in page",
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onFindClose) { Icon(Icons.Default.Close, "Close find", tint = cs.onSurfaceVariant) }
                }
            }
        }

        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx -> FrameLayout(ctx).apply { controller.attach(this) } },
            update = { controller.attach(it) }
        )

        if (!fullscreen) {
            BottomNav(
                canBack = webView?.canGoBack() == true,
                canForward = webView?.canGoForward() == true,
                onBack = { controller.goBack() },
                onForward = { controller.goForward() },
                onHome = onHome,
                onTabs = onTabs,
                tabCount = controller.tabs.size,
                onMenu = onMenu
            )
        }
    }
}

/**
 * Address input built on BasicTextField so the text height and vertical position are
 * fully controlled by us. Material's TextField has a 56dp minimum height and clips text
 * inside shorter containers, which is why the URL used to look cut off.
 */
@Composable
private fun AddressField(
    value: String,
    onValueChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onFocusChange: (Boolean) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.onFocusChanged { onFocusChange(it.isFocused) },
        singleLine = true,
        textStyle = TextStyle(color = cs.onSurface, fontSize = 15.sp, lineHeight = 20.sp),
        cursorBrush = SolidColor(cs.primary),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
        keyboardActions = KeyboardActions(onGo = { onSubmit() }),
        decorationBox = { inner ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) {
                    Text(
                        placeholder,
                        fontSize = 15.sp,
                        lineHeight = 20.sp,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                inner()
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAddressBar(
    address: String,
    onAddressChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onFocusChange: (Boolean) -> Unit,
    blocked: Int,
    loading: Boolean,
    progress: Int,
    desktop: Boolean,
    onDesktop: () -> Unit,
    onShields: () -> Unit,
    onReload: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val secure = address.startsWith("https://")
    Column(
        Modifier.fillMaxWidth().background(cs.background).statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.weight(1f).height(44.dp),
                shape = RoundedCornerShape(22.dp),
                color = cs.surfaceVariant
            ) {
                Row(
                    Modifier.padding(start = 4.dp, end = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onShields, modifier = Modifier.size(36.dp)) {
                        CountBadge(count = blocked) {
                            Icon(Icons.Default.Shield, "Shields", tint = cs.onSurfaceVariant, modifier = Modifier.size(18.dp))
                        }
                    }
                    Icon(
                        imageVector = if (secure) Icons.Default.Lock else Icons.Default.Search,
                        contentDescription = null,
                        tint = cs.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    AddressField(
                        value = address,
                        onValueChange = onAddressChange,
                        onSubmit = onSubmit,
                        onFocusChange = onFocusChange,
                        placeholder = "Search or enter address",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Spacer(Modifier.width(4.dp))
            IconButton(onClick = onDesktop, modifier = Modifier.size(40.dp)) {
                Icon(
                    imageVector = Icons.Default.DesktopWindows,
                    contentDescription = if (desktop) "Desktop site on" else "Desktop site off",
                    tint = if (desktop) cs.primary else cs.onSurfaceVariant
                )
            }
            IconButton(onClick = onReload, modifier = Modifier.size(40.dp)) {
                Icon(
                    imageVector = if (loading) Icons.Default.Close else Icons.Default.Refresh,
                    contentDescription = if (loading) "Stop" else "Reload",
                    tint = cs.onSurface
                )
            }
        }
        if (loading) {
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0, 100) / 100f },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = cs.primary,
                trackColor = Color.Transparent
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SuggestionPanel(
    query: String,
    suggestions: List<HostSuggestion>,
    onPick: (String) -> Unit,
    onSearch: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        shape = RoundedCornerShape(18.dp),
        color = cs.surface,
        tonalElevation = 2.dp,
        shadowElevation = 6.dp
    ) {
        Column(Modifier.padding(vertical = 6.dp)) {
            suggestions.forEach { suggestion ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(suggestion.url) }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Public, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(suggestion.host, fontSize = 15.sp, color = cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(
                Modifier.fillMaxWidth().clickable { onSearch() }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(12.dp))
                Text(
                    "Search for \"$query\"",
                    fontSize = 15.sp,
                    color = cs.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun BottomNav(
    canBack: Boolean,
    canForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onHome: () -> Unit,
    onTabs: () -> Unit,
    tabCount: Int,
    onMenu: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Column {
        HorizontalDivider(color = cs.outline.copy(alpha = 0.35f))
        Surface(color = cs.background) {
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().height(58.dp).padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavIcon(Icons.Default.ArrowBack, "Back", canBack, onBack)
                NavIcon(Icons.Default.ArrowForward, "Forward", canForward, onForward)
                NavIcon(Icons.Default.Home, "Home", true, onHome)
                IconButton(onClick = onTabs) {
                    Box(
                        Modifier.size(26.dp).border(1.5.dp, cs.onSurface, RoundedCornerShape(7.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(tabCount.toString(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                    }
                }
                NavIcon(Icons.Default.MoreVert, "Menu", true, onMenu)
            }
        }
    }
}

@Composable
private fun NavIcon(icon: ImageVector, description: String, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    IconButton(onClick = onClick, enabled = enabled) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.38f)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CountBadge(count: Int, content: @Composable () -> Unit) {
    if (count > 0) {
        BadgedBox(badge = { Badge { Text(count.toString()) } }) { content() }
    } else {
        content()
    }
}

// ---------- Home (new tab) ----------

@Composable
private fun HomePage(
    query: String,
    onQueryChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onFocusChange: (Boolean) -> Unit,
    suggestOpen: Boolean,
    suggestions: List<HostSuggestion>,
    onPick: (String) -> Unit,
    onSearch: () -> Unit,
    recent: List<SavedPage>,
    onRecent: (String) -> Unit,
    sites: List<Shortcut>,
    onSite: (String) -> Unit,
    tabCount: Int,
    onTabs: () -> Unit,
    onMenu: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val greeting = remember { greetingForHour(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) }

    Column(Modifier.fillMaxSize().background(cs.background).statusBarsPadding()) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
        ) {
            Spacer(Modifier.height(56.dp))
            Text(
                "DHYRA",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 4.sp,
                color = cs.primary
            )
            Spacer(Modifier.height(10.dp))
            Text(
                greeting,
                fontSize = 32.sp,
                lineHeight = 38.sp,
                fontWeight = FontWeight.Light,
                color = cs.onSurface
            )
            Spacer(Modifier.height(28.dp))

            Surface(
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(26.dp),
                color = cs.surfaceVariant
            ) {
                Row(Modifier.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(12.dp))
                    AddressField(
                        value = query,
                        onValueChange = onQueryChange,
                        onSubmit = onSubmit,
                        onFocusChange = onFocusChange,
                        placeholder = "Search or enter address",
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (suggestOpen && query.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                SuggestionPanel(query = query, suggestions = suggestions, onPick = onPick, onSearch = onSearch)
            }

            Spacer(Modifier.height(36.dp))
            SectionLabel("Quick access")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                sites.forEach { site ->
                    Surface(
                        onClick = { onSite(site.url) },
                        shape = RoundedCornerShape(50),
                        color = cs.surfaceVariant
                    ) {
                        Text(
                            site.label,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                            fontSize = 14.sp,
                            color = cs.onSurface
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                }
            }

            if (recent.isNotEmpty()) {
                Spacer(Modifier.height(32.dp))
                SectionLabel("Recent")
                recent.take(5).forEach { entry ->
                    Column(
                        Modifier.fillMaxWidth().clickable { onRecent(entry.url) }.padding(vertical = 11.dp)
                    ) {
                        Text(
                            entry.title.ifBlank { entry.url },
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = cs.onSurface
                        )
                        Text(
                            siteLabelOf(entry.url),
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
        BottomNav(
            canBack = false,
            canForward = false,
            onBack = {},
            onForward = {},
            onHome = {},
            onTabs = onTabs,
            tabCount = tabCount,
            onMenu = onMenu
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text.uppercase(),
        modifier = Modifier.padding(bottom = 12.dp),
        fontSize = 11.sp,
        letterSpacing = 1.5.sp,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

private fun greetingForHour(hour: Int): String = when (hour) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..20 -> "Good evening"
    else -> "Good night"
}

// ---------- Bottom sheets ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MenuSheet(
    inBrowser: Boolean,
    onDismiss: () -> Unit,
    onNewTab: () -> Unit,
    onNewPrivate: () -> Unit,
    onAddBookmark: () -> Unit,
    onBookmarks: () -> Unit,
    onHistory: () -> Unit,
    onDownloads: () -> Unit,
    onFind: () -> Unit,
    onShare: () -> Unit,
    onSettings: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    fun pick(action: () -> Unit) {
        onDismiss()
        action()
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 16.dp)) {
            MenuRow(Icons.Default.Add, "New tab") { pick(onNewTab) }
            MenuRow(Icons.Default.VisibilityOff, "New private tab") { pick(onNewPrivate) }
            if (inBrowser) {
                MenuRow(Icons.Default.BookmarkAdd, "Add bookmark") { pick(onAddBookmark) }
            }
            MenuRow(Icons.Default.BookmarkBorder, "Bookmarks") { pick(onBookmarks) }
            MenuRow(Icons.Default.History, "History") { pick(onHistory) }
            MenuRow(Icons.Default.Download, "Downloads") { pick(onDownloads) }
            if (inBrowser) {
                MenuRow(Icons.Default.Search, "Find in page") { pick(onFind) }
                MenuRow(Icons.Default.Share, "Share page") { pick(onShare) }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            MenuRow(Icons.Default.Settings, "Settings") { pick(onSettings) }
        }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, text: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = cs.onSurfaceVariant)
        Spacer(Modifier.width(18.dp))
        Text(text, fontSize = 16.sp, color = cs.onSurface)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ShieldsSheet(
    siteLabel: String,
    blocked: Int,
    tracking: Boolean,
    popup: Boolean,
    desktop: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, Any) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val sheetState = rememberModalBottomSheetState()
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Shield, null, tint = cs.primary)
                Spacer(Modifier.width(10.dp))
                Text("Shields", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
            }
            Spacer(Modifier.height(4.dp))
            Text(siteLabel, fontSize = 14.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(14.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = cs.surfaceVariant
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        if (blocked > 0) blocked.toString() else "0",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = cs.primary
                    )
                    Text(
                        if (blocked > 0) "trackers and ads blocked on this page" else "Nothing blocked on this page yet",
                        fontSize = 14.sp,
                        color = cs.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            SwitchRow(
                icon = Icons.Default.Shield,
                title = "Block trackers & ads",
                subtitle = "Uses the built-in block list",
                checked = tracking
            ) { onSave("tracking_protection", it) }
            SwitchRow(
                icon = Icons.Default.VisibilityOff,
                title = "Block pop-ups",
                subtitle = "Stops pop-up windows from opening",
                checked = popup
            ) { onSave("popup_blocker", it) }
            SwitchRow(
                icon = Icons.Default.Public,
                title = "Desktop site",
                subtitle = "Request the desktop version of sites",
                checked = desktop
            ) { onSave("desktop_mode", it) }
            Text(
                "Shield settings apply to all sites.",
                modifier = Modifier.padding(top = 10.dp, bottom = 8.dp),
                fontSize = 12.sp,
                color = cs.onSurfaceVariant
            )
        }
    }
}

// ---------- Tabs ----------

@Composable
private fun TabsScreen(
    controller: BrowserController,
    onBack: () -> Unit,
    onSelect: (Int) -> Unit,
    onClose: (Int) -> Unit,
    onNew: () -> Unit,
    onNewPrivate: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        SubpageBar(title = "Tabs (${controller.tabs.size})", onBack = onBack)
        if (controller.tabs.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No open tabs", color = cs.onSurfaceVariant)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                gridItems(controller.tabs, key = { it.id }) { tab ->
                    TabCard(
                        tab = tab,
                        selected = tab.id == controller.activeTabId,
                        onClick = { onSelect(tab.id) },
                        onClose = { onClose(tab.id) }
                    )
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(onClick = onNewPrivate, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.VisibilityOff, null)
                Spacer(Modifier.width(6.dp))
                Text("Private")
            }
            Button(onClick = onNew, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("New tab")
            }
        }
    }
}

@Composable
private fun TabCard(tab: BrowserTab, selected: Boolean, onClick: () -> Unit, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val blank = tab.url.isBlank() || tab.url == ABOUT_BLANK
    val label = if (blank) "New tab" else tab.title.ifBlank { tab.url }
    val origin = when {
        tab.isPrivate -> "Private"
        blank -> ""
        else -> siteLabelOf(tab.url)
    }
    Surface(
        modifier = Modifier.fillMaxWidth().height(140.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (tab.isPrivate) PrivateTint else cs.surfaceVariant,
        border = if (selected) BorderStroke(2.dp, cs.primary) else null
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    origin,
                    modifier = Modifier.weight(1f),
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = if (tab.isPrivate) Color(0xFFD9CCFF) else cs.onSurfaceVariant
                )
                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, "Close tab", modifier = Modifier.size(16.dp), tint = cs.onSurface)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                label,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                color = if (tab.isPrivate) Color.White else cs.onSurface
            )
        }
    }
}

// ---------- Settings ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    state: PreferencesState,
    onBack: () -> Unit,
    onSave: (String, Any) -> Unit,
    onClear: () -> Unit,
    onSetDefaultBrowser: () -> Unit,
    onSupport: () -> Unit,
    onAbout: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var showHome by remember { mutableStateOf(false) }
    var showEngine by remember { mutableStateOf(false) }
    var showTheme by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        SubpageBar(title = "Settings", onBack = onBack)
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            item { SectionTitle("General") }
            item {
                SettingRow(Icons.Default.Language, "Default browser", "Set DHYRA as your default browser") {
                    onSetDefaultBrowser()
                }
            }
            item { SettingRow(Icons.Default.Home, "Homepage", state.homepage) { showHome = true } }
            item { SettingRow(Icons.Default.Search, "Search engine", state.engine) { showEngine = true } }

            item { SectionTitle("Appearance") }
            item { SettingRow(Icons.Default.Palette, "Theme", state.theme) { showTheme = true } }

            item { SectionTitle("Privacy") }
            item {
                SwitchRow(
                    icon = Icons.Default.Shield,
                    title = "Block trackers & ads",
                    subtitle = "Uses the built-in block list",
                    checked = state.tracking
                ) { onSave("tracking_protection", it) }
            }
            item {
                SwitchRow(
                    icon = Icons.Default.VisibilityOff,
                    title = "Block pop-ups",
                    subtitle = "Stops pop-up windows from opening",
                    checked = state.popup
                ) { onSave("popup_blocker", it) }
            }
            item {
                SettingRow(Icons.Default.DeleteOutline, "Clear browsing data", "Cookies, storage and history") {
                    showClear = true
                }
            }

            item { SectionTitle("About") }
            item { SettingRow(Icons.Default.Favorite, "Support DHYRA", "Optional donation") { onSupport() } }
            item { SettingRow(Icons.Default.Info, "About DHYRA", "Version 1.4.1") { onAbout() } }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (showHome) {
        var draft by remember { mutableStateOf(state.homepage) }
        AlertDialog(
            onDismissRequest = { showHome = false },
            title = { Text("Homepage") },
            text = {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("https://example.com") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onSave("homepage", BrowserAddressResolver.normalizeHomepage(draft))
                    showHome = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showHome = false }) { Text("Cancel") } }
        )
    }

    if (showEngine) {
        ChoiceDialog(
            title = "Search engine",
            options = ENGINE_OPTIONS,
            selected = state.engine,
            onPick = {
                onSave("search_engine", it)
                showEngine = false
            },
            onDismiss = { showEngine = false }
        )
    }

    if (showTheme) {
        ChoiceDialog(
            title = "Theme",
            options = THEME_OPTIONS,
            selected = state.theme,
            onPick = {
                onSave("theme", it)
                showTheme = false
            },
            onDismiss = { showTheme = false }
        )
    }

    if (showClear) {
        AlertDialog(
            onDismissRequest = { showClear = false },
            title = { Text("Clear browsing data?") },
            text = { Text("This clears history and regular-tab cookies and site storage. It can sign you out of websites.") },
            confirmButton = {
                TextButton(onClick = {
                    onClear()
                    showClear = false
                }) { Text("Clear", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { showClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<String>,
    selected: String,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { option ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(option) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = option == selected, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Text(option)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        modifier = Modifier.padding(start = 20.dp, top = 22.dp, bottom = 6.dp),
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
private fun SettingRow(icon: ImageVector, title: String, subtitle: String?, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = cs.onSurfaceVariant)
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, color = cs.onSurface)
            if (subtitle != null) {
                Text(subtitle, fontSize = 13.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Icon(Icons.Default.ChevronRight, null, tint = cs.onSurfaceVariant)
    }
}

@Composable
private fun SwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = cs.onSurfaceVariant)
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, color = cs.onSurface)
            Text(subtitle, fontSize = 13.sp, color = cs.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ---------- Sub-pages ----------

@Composable
private fun SubpageBar(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
        Text(
            title,
            modifier = Modifier.weight(1f),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        trailing()
    }
}

@Composable
private fun EntriesScreen(
    title: String,
    entries: List<SavedPage>,
    emptyText: String,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onDelete: (String) -> Unit,
    onClearAll: (() -> Unit)? = null
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        SubpageBar(
            title = title,
            onBack = onBack,
            trailing = {
                if (onClearAll != null && entries.isNotEmpty()) {
                    TextButton(onClick = onClearAll) { Text("Clear", color = cs.primary) }
                }
            }
        )
        if (entries.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(emptyText, color = cs.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(entries, key = { it.url + it.timestamp }) { entry ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(entry.url) }.padding(start = 20.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(entry.title.ifBlank { entry.url }, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurface)
                            Text(
                                siteLabelOf(entry.url) + " • " +
                                    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(entry.timestamp)),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = cs.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { onDelete(entry.url) }) {
                            Icon(Icons.Default.DeleteOutline, "Remove", tint = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DownloadsScreen(onBack: () -> Unit, refreshKey: Int) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var rows by remember { mutableStateOf(emptyList<DownloadRow>()) }
    fun load() {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = manager.query(DownloadManager.Query())
        val result = mutableListOf<DownloadRow>()
        cursor?.use { c ->
            val idCol = c.getColumnIndex(DownloadManager.COLUMN_ID)
            val titleCol = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
            val statusCol = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val totalCol = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val soFarCol = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val status = c.getInt(statusCol)
                val title = c.getString(titleCol) ?: "Download"
                val total = c.getLong(totalCol)
                val soFar = c.getLong(soFarCol)
                result += DownloadRow(id, title, statusLabel(status), total, soFar)
            }
        }
        rows = result
    }
    LaunchedEffect(refreshKey) { load() }

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        SubpageBar(
            title = "Downloads",
            onBack = onBack,
            trailing = { IconButton(onClick = { load() }) { Icon(Icons.Default.Refresh, "Refresh") } }
        )
        if (rows.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No downloads yet", color = cs.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(rows, key = { it.id }) { row ->
                    Row(
                        Modifier.fillMaxWidth().padding(start = 20.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.InsertDriveFile, null, tint = cs.onSurfaceVariant)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(row.title, fontWeight = FontWeight.Medium, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurface)
                            Text(
                                "${row.status} • ${formatBytes(row.downloaded)} / ${if (row.total > 0) formatBytes(row.total) else "—"}",
                                fontSize = 12.sp,
                                color = cs.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = {
                            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            runCatching {
                                val uri = manager.getUriForDownloadedFile(row.id)
                                if (uri != null) {
                                    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, context.contentResolver.getType(uri))
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    context.startActivity(intent)
                                }
                            }
                        }) { Icon(Icons.Default.OpenInNew, "Open", tint = cs.onSurfaceVariant) }
                        IconButton(onClick = {
                            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(row.id)
                            load()
                        }) { Icon(Icons.Default.DeleteOutline, "Delete", tint = cs.onSurfaceVariant) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SupportScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    val qr = remember { makeQr("bitcoin:$BTC_ADDRESS") }
    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        SubpageBar(title = "Support DHYRA", onBack = onBack)
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Text("Contribute voluntarily to support future development.", color = cs.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Surface(shape = RoundedCornerShape(18.dp), color = Color.White) {
                Image(qr.asImageBitmap(), null, Modifier.padding(12.dp).size(200.dp))
            }
            Text(BTC_ADDRESS, fontSize = 11.sp, color = cs.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Button(onClick = {
                clipboard.setText(AnnotatedString(BTC_ADDRESS))
                android.widget.Toast.makeText(context, "Bitcoin address copied", android.widget.Toast.LENGTH_SHORT).show()
            }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.ContentCopy, null)
                Spacer(Modifier.width(8.dp))
                Text("Copy address")
            }
            OutlinedButton(onClick = {
                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("bitcoin:$BTC_ADDRESS"))) }
                    .onFailure { android.widget.Toast.makeText(context, "No compatible wallet found", android.widget.Toast.LENGTH_SHORT).show() }
            }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AccountBalanceWallet, null)
                Spacer(Modifier.width(8.dp))
                Text("Open Bitcoin wallet")
            }
            Text(
                "Verify the address and Bitcoin network before sending.",
                fontSize = 11.sp,
                color = cs.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun AboutScreen(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        SubpageBar(title = "About", onBack = onBack)
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(32.dp))
            Box(
                Modifier.size(82.dp).clip(RoundedCornerShape(24.dp)).background(cs.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Public, null, tint = Color.White, modifier = Modifier.size(44.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text("DHYRA BROWSER", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, color = cs.onSurface)
            Text("Version 1.4.1", color = cs.onSurfaceVariant)
            Spacer(Modifier.height(18.dp))
            Text(
                "An Android browser powered by Android System WebView.",
                color = cs.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

// ---------- Helpers ----------

private fun siteLabelOf(url: String?): String {
    if (url.isNullOrBlank() || url == ABOUT_BLANK) return "New tab"
    return runCatching { Uri.parse(url).host }.getOrNull()?.removePrefix("www.") ?: url
}

private fun statusLabel(status: Int): String = when (status) {
    DownloadManager.STATUS_PENDING -> "Pending"
    DownloadManager.STATUS_RUNNING -> "Downloading"
    DownloadManager.STATUS_PAUSED -> "Paused"
    DownloadManager.STATUS_SUCCESSFUL -> "Completed"
    DownloadManager.STATUS_FAILED -> "Failed"
    else -> "Unknown"
}

private fun formatBytes(value: Long): String {
    if (value < 1024) return "$value B"
    if (value < 1024 * 1024) return "%.1f KB".format(value / 1024f)
    return "%.1f MB".format(value / (1024f * 1024f))
}

private fun makeQr(payload: String): Bitmap {
    val matrix = com.google.zxing.qrcode.QRCodeWriter().encode(payload, com.google.zxing.BarcodeFormat.QR_CODE, 560, 560)
    return Bitmap.createBitmap(560, 560, Bitmap.Config.ARGB_8888).also { bmp ->
        for (x in 0 until 560) for (y in 0 until 560) {
            bmp.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
}

private fun decodeSession(raw: String): List<Pair<String, String>> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val item = array.optJSONObject(index) ?: return@mapNotNull null
        val url = item.optString("url")
        if (url.startsWith("https://", true) || url.startsWith("http://", true)) {
            url to item.optString("title", url)
        } else null
    }
}.getOrDefault(emptyList())

private fun requestDefaultBrowserRole(activity: MainActivity) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val manager = activity.getSystemService(RoleManager::class.java)
            if (manager != null && manager.isRoleAvailable(RoleManager.ROLE_BROWSER)) {
                activity.startActivity(manager.createRequestRoleIntent(RoleManager.ROLE_BROWSER))
            } else {
                activity.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            }
        } else {
            activity.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        }
    } catch (_: Exception) {
        runCatching { activity.startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
}

private fun decodeEntries(raw: String): List<SavedPage> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val obj = array.optJSONObject(index) ?: return@mapNotNull null
        val url = obj.optString("url")
        if (url.isBlank()) null else SavedPage(
            title = obj.optString("title", url),
            url = url,
            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
        )
    }
}.getOrDefault(emptyList())

private fun encodeEntries(entries: List<SavedPage>): String {
    val array = JSONArray()
    entries.forEach { entry ->
        array.put(JSONObject().put("title", entry.title).put("url", entry.url).put("timestamp", entry.timestamp))
    }
    return array.toString()
}
