package com.dhyra.browser

import java.net.URI

/** Conservative HTTPS-first URL transformation. It never downgrades HTTPS URLs. */
object HttpsUpgrade {
    fun upgrade(url: String, enabled: Boolean): String {
        if (!enabled) return url
        return runCatching {
            val parsed = URI(url)
            if (!parsed.scheme.equals("http", ignoreCase = true) || parsed.host.isNullOrBlank()) return url
            val authority = parsed.rawAuthority?.let { raw ->
                if (parsed.port == 80) raw.removeSuffix(":80") else raw
            } ?: return url
            buildString {
                append("https://")
                append(authority)
                append(parsed.rawPath.orEmpty())
                parsed.rawQuery?.let { append('?'); append(it) }
                parsed.rawFragment?.let { append('#'); append(it) }
            }
        }.getOrDefault(url)
    }
}
