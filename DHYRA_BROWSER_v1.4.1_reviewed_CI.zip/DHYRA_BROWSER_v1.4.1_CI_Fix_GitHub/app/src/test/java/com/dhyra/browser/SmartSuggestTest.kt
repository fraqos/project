package com.dhyra.browser

import com.dhyra.browser.core.suggest.SmartSuggest

/** Pure-JVM checks for the address-bar domain suggestions. */
class SmartSuggestTest {
    fun runChecks() {
        val typedY = SmartSuggest.suggest("y", emptyList(), emptyList())
        check(typedY.first().host == "youtube.com") { "typing 'y' should suggest youtube.com, got ${typedY.firstOrNull()}" }

        check(SmartSuggest.suggest("", emptyList(), emptyList()).isEmpty()) { "empty input must give no suggestions" }
        check(SmartSuggest.suggest("hello world", emptyList(), emptyList()).isEmpty()) { "phrases must not be matched as hosts" }

        val fromHistory = SmartSuggest.suggest("y", listOf("https://yoga.example/page"), emptyList())
        check(fromHistory.first().host == "yoga.example") { "history should rank before built-in hosts" }

        check(SmartSuggest.suggest("goo", emptyList(), emptyList()).any { it.host == "google.com" }) { "prefix 'goo' should find google.com" }
        check(SmartSuggest.suggest("https://www.git", emptyList(), emptyList()).first().host == "github.com") { "scheme and www must be ignored" }
        check(SmartSuggest.suggest("github.com/foo", emptyList(), emptyList()).first().host == "github.com") { "path must be ignored while matching" }
        check(SmartSuggest.suggest("zzzz", emptyList(), emptyList()).isEmpty()) { "unknown text should give no suggestions" }
        check(SmartSuggest.suggest("y", emptyList(), emptyList()).first().url == "https://youtube.com") { "suggestion url must be https" }
        println("PASS: smart suggestion checks")
    }
}
