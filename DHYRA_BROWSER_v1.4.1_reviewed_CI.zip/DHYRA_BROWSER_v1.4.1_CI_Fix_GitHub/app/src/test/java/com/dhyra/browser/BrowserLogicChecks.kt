package com.dhyra.browser

/** Standalone JVM verification runner; no test framework dependency is required. */
object BrowserLogicChecks {
    @JvmStatic
    fun main(args: Array<String>) {
        BrowserAddressResolverTest().runChecks()
        HttpsUpgradeTest().runChecks()
        ShieldsFilterEngineTest().runChecks()
        SmartSuggestTest().runChecks()
        println("PASS: browser address resolution, HTTPS upgrade, Shields matcher and smart suggestion checks")
    }
}
