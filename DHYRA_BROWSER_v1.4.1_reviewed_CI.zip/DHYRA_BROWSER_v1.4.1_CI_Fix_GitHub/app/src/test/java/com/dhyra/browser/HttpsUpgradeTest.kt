package com.dhyra.browser

class HttpsUpgradeTest {
    fun runChecks() {
        check(HttpsUpgrade.upgrade("http://example.com/path?q=1", true) == "https://example.com/path?q=1")
        check(HttpsUpgrade.upgrade("http://example.com:80/", true) == "https://example.com/")
        check(HttpsUpgrade.upgrade("https://example.com", true) == "https://example.com")
        check(HttpsUpgrade.upgrade("http://example.com", false) == "http://example.com")
        check(HttpsUpgrade.upgrade("http://example.com/a%20b?q=a%2Fb", true) == "https://example.com/a%20b?q=a%2Fb")
    }
}
