# Keep WebView JavaScript bridge reflection metadata if a restricted bridge is added later.
# Do not add broad keep rules for app packages; allow R8 to optimize application code.

-keepattributes *Annotation*
-keepattributes Signature

# ZXing QR generation is accessed directly; preserve its encoder classes under minification.
-keep class com.google.zxing.** { *; }
-dontwarn com.google.zxing.**
