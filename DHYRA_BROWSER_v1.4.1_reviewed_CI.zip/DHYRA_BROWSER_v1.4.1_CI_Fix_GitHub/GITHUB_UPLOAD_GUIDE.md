# Upload DHYRA BROWSER 1.4.1 to GitHub

1. Create or open your GitHub repository, for example `dhyra-browser`.
2. Extract this ZIP.
3. Upload the **contents inside** the extracted folder to the repository root. Do not upload an extra parent folder.
4. Verify that `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `gradle/wrapper/gradle-wrapper.properties`, `gradlew`, `app/` and `.github/workflows/build.yml` are at repository root.
5. Open the repository's **Actions** tab.
6. Select **DHYRA BROWSER - Android CI** and choose **Run workflow**, or push to `main` / `master`.
7. Wait for core logic checks, lint and debug APK build to finish.
8. Download `DHYRA-BROWSER-v1.4.1-debug` from the successful workflow's Artifacts section.

The CI workflow installs JDK 17, Android SDK Platform 35 and Build Tools 35.0.0, uses Gradle 8.7, runs `:app:verifyCoreLogic`, `:app:lintDebug` and `:app:assembleDebug`, then uploads the APK and diagnostic reports.

The debug APK uses the production application ID `com.dhyra.browser`. Do not commit signing keystores or passwords to the repository. A release-signing workflow is not configured in this version.
