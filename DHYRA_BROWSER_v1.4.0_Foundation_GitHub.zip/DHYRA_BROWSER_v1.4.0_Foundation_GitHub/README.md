# DHYRA Browser 1.4.0

Android browser using Jetpack Compose and the Android System WebView supplied by the device. This is **not** a Chromium fork and does not bundle Chromium.

## Build configuration

- Application ID: `com.dhyra.browser`
- Version: `1.4.0` (version code `5`)
- Kotlin: `2.0.21`
- Android Gradle Plugin: `8.6.1`
- Gradle: `8.7`
- JDK: `17`
- compileSdk / targetSdk: `35` / minSdk: `26`
- Compose BOM: `2024.10.01`
- AndroidX WebKit: `1.12.1`

## Included in this update

- HTTPS-first for address-bar navigation and main-frame HTTP navigations; cleartext network traffic is disabled by Network Security Config.
- Safer external-link handling: `intent:` targets have their component, selector, package and flags stripped; only HTTP(S), `mailto:` and `tel:` targets are accepted. Unsupported schemes are blocked.
- Renderer-process crash callback is handled so a crashed WebView renderer does not directly crash the Activity.
- Navigation from a frozen tab always applies the requested destination; reload recreates or refreshes the selected tab.
- Top-level `data:`, `javascript:`, `file:` and `content:` navigations are blocked; embedded resources still use WebView policy.
- Lazy New Tab creation: an `about:blank` tab does not allocate a WebView until a page is opened.
- A maximum of four live WebViews. Other non-active WebViews are saved in memory and recreated when selected; this is a best-effort memory policy, not a durable per-tab database.
- Regular tab session snapshot is persisted in Preferences DataStore and restored on next launch. Private tabs are excluded from session persistence.
- Camera, microphone and protected-media permission requests receive an in-app site prompt. Android runtime permission is then requested for camera/microphone.
- Basic immutable host/path Shields matcher: supports `||host^`, `||host/path` and `@@` exception rules. A small built-in rule list is included. A request counter is maintained in memory.
- Mobile user-agent cleanup removes WebView markers `; wv` and `Version/4.0`; desktop mode also removes ` Mobile`.
- File URL access from file URLs and universal file URL access are disabled.
- Default-browser role/settings entry point and VIEW, WEB_SEARCH and SEND intent filters.
- Adaptive launcher icon, monochrome layer, backup disabled, network security config, edge-to-edge system bars, R8 and resource shrinking for release builds.
- Pure-JVM checks for address resolution, HTTPS URL upgrades and supported Shields filter matching (no additional test-framework library dependency).
- CI runs the standalone JVM core-logic verification task, Android lint and debug APK build.

## Important limitations — read before release

1. **Private tabs are not isolated profiles.** The `CookieManager` and WebStorage are shared by Android System WebView in this build. Private tabs use no-cache mode, are excluded from history/session persistence, and when the final private tab closes DHYRA clears shared cookies and WebStorage. That cleanup can sign users out of regular tabs. Do not describe this as equivalent to isolated/incognito profiles.
2. **Shields is not a full adblock engine.** The matcher only supports host/path rules and exceptions. It has no EasyList/EasyPrivacy download/update, resource-type or initiator matching, cosmetic filtering, scriptlets, regex rules, per-site policy UI or persistent statistics. WebView does not expose all request metadata; WebSockets and some traffic cannot be filtered this way.
3. **HTTPS-first has no automatic HTTP fallback.** Certificate errors are cancelled. Cleartext is globally denied, so HTTP-only destinations may fail. The current UI does not yet provide a confirmed one-time insecure-connection interstitial.
4. **Permissions are not persisted per site.** Camera, microphone and DRM prompts are explicit, but geolocation currently uses Android runtime permission flow and is not stored as a per-origin Room policy. Unsupported WebView resources are denied.
5. **DRM and media support are device/WebView-dependent.** Protected media permission is passed through after the site prompt, but this does not guarantee Widevine availability or playback. Picture-in-picture and background audio controls are not implemented yet.
6. **Downloads use Android `DownloadManager`.** HTTP(S) downloads are supported; `blob:` and `data:` downloads are not. Pause/resume is not promised.
7. **Not all roadmap items are implemented.** This update does not yet introduce Room/FTS, MVVM ViewModels, a full BrowserEngine/EngineSession migration, GeckoView, tab thumbnails/favicons/groups/pinning, filter-list updates, anti-fingerprinting farbling, reader mode, animated onboarding, full localization, per-site permission/shield storage, or full accessibility QA. The project is not ready to be represented as a Brave-equivalent browser.

## Private-tab cleanup behavior

Because WebView profile isolation is not used here, closing the last private tab triggers deletion of the shared WebView cookies and WebStorage as a best-effort fallback. This is intentionally disclosed in Settings because it affects normal tabs too. It is not a proof that all app or network traces have been erased.

## Build locally

The repository's `gradlew` script downloads Gradle 8.7 when no `gradle` executable is installed. Android SDK Platform 35 and Build Tools 35.0.0 must also be installed.

```bash
./gradlew :app:verifyCoreLogic
./gradlew :app:lintDebug
./gradlew :app:assembleDebug
```

The GitHub Actions workflow performs the same checks and uploads `DHYRA-BROWSER-v1.4.0-debug`. See `MANUAL_TEST_CHECKLIST.md` for device verification steps.

## Existing DHYRA support address

The original Bitcoin support address and QR flow are preserved unchanged in `MainActivity.kt`. See `THIRD_PARTY_NOTICES.md` for the current dependency/license inventory.
