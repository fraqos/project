# DHYRA Browser — implementation status

## Delivered package

- Package version: **1.4.0**
- Version code: **5**
- Application ID: `com.dhyra.browser`
- Engine: Android System WebView
- Toolchain retained: Kotlin 2.0.21, AGP 8.6.1, Gradle 8.7, JDK 17, compile/target SDK 35, min SDK 26.

## Scope actually delivered

This update is a safer foundation release. It includes manifest/network hardening, the DHYRA launcher icon, HTTPS-first behavior, safer external intent handling, lazy tab WebViews with a four-live-view cap, process-memory freeze/restore for inactive tabs, normal-tab session persistence, renderer crash handling, site permission prompts, a limited local Shields matcher with a reactive counter, user-agent cleanup, R8/resource shrinking configuration, core logic checks and GitHub Actions build/lint workflow.

## Roadmap completion

| Roadmap phase | Status |
|---|---|
| F1 — Foundation (v1.4.0) | **Partially implemented.** Core security/session/CI groundwork exists, but target MVVM, Room migration, AppContainer and BrowserEngine abstraction are not complete. |
| F2 — Design system & core UI | Not completed |
| F3 — Full Shields engine | Not completed; current matcher is intentionally limited |
| F4 — Isolated private profiles & per-origin permissions | Not completed; private tabs still share WebView storage |
| F5 — History/bookmark/download/suggestion upgrade | Not completed; existing JSON/DataStore features remain |
| F6 — Advanced features | Not completed |
| F7 — Adaptive polish/accessibility | Not completed |
| F8 — v2.0.0 release & signing | Not completed |
| F9 — Optional extras | Not completed |

## Release gate

Do not publish this version as a Brave-equivalent browser or claim all requested features are complete. Do not publish a production release until the Android CI build/lint succeeds, the APK is tested on physical devices across supported API levels, the private-tab storage limitation is addressed, and the remaining security/accessibility checks are completed.

The full build was not verified in the authoring environment because Android SDK/Gradle were unavailable and the Gradle distribution could not be fetched due to DNS failure. `BUILD_VERIFICATION.md` records exactly which local checks passed and which did not.
