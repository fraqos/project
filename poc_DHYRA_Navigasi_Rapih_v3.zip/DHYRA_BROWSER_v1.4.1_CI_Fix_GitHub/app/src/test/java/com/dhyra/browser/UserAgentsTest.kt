package com.dhyra.browser

import com.dhyra.browser.core.web.UserAgents

/** Pure-JVM checks for the mobile and desktop user agents. */
class UserAgentsTest {
    fun runChecks() {
        val webView = "Mozilla/5.0 (Linux; Android 14; Pixel 7 Build/UP1A.231105.001; wv) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.58 Mobile Safari/537.36"

        val mobile = UserAgents.mobile(webView)
        check(mobile.contains("Mobile")) { "mobile agent keeps Mobile" }
        check(mobile.contains("Android 14")) { "mobile agent keeps Android" }
        check(!mobile.contains("; wv")) { "WebView marker must be removed" }
        check(!mobile.contains("Version/4.0")) { "Version/4.0 must be removed" }
        check(mobile.contains("Chrome/130.0.6723.58")) { "mobile agent keeps the full Chrome version" }

        val desktop = UserAgents.desktop(webView)
        check(desktop.contains("Windows NT 10.0; Win64; x64")) { "desktop agent reports Windows" }
        check(desktop.contains("Chrome/130.0.0.0")) { "desktop agent keeps the Chrome major only" }
        check(!desktop.contains("Mobile")) { "desktop agent must not say Mobile" }
        check(!desktop.contains("Android")) { "desktop agent must not say Android" }
        check(desktop.endsWith("Safari/537.36")) { "desktop agent ends like Chrome" }

        check(UserAgents.desktop("").contains("Windows NT 10.0")) { "desktop agent works without a Chrome token" }
        check(UserAgents.mobile("Mozilla/5.0   (X)   Chrome/1.0") == "Mozilla/5.0 (X) Chrome/1.0") { "spaces must collapse" }

        println("PASS: user agent checks")
    }
}
