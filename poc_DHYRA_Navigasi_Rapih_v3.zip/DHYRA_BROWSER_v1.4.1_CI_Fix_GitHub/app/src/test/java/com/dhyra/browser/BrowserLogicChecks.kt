package com.dhyra.browser

/** Standalone JVM verification runner; no test framework dependency is required. */
object BrowserLogicChecks {
    @JvmStatic
    fun main(args: Array<String>) {
        BrowserAddressResolverTest().runChecks()
        HttpsUpgradeTest().runChecks()
        ShieldsFilterEngineTest().runChecks()
        SmartSuggestTest().runChecks()
        BackPolicyTest().runChecks()
        UserAgentsTest().runChecks()
        TabSelectionTest().runChecks()
        println("PASS: address resolution, HTTPS upgrade, Shields, suggestions, back policy, user agents and tab selection checks")
    }
}
