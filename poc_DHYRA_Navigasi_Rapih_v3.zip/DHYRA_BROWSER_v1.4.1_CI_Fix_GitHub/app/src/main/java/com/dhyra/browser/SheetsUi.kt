@file:OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Main menu. The top row holds the quick controls, including the Desktop site toggle with a
 * clear On/Off label; everything else is a clean list below it.
 */
@Composable
internal fun MenuSheet(
    inPage: Boolean,
    desktop: Boolean,
    onDismiss: () -> Unit,
    onToggleDesktop: () -> Unit,
    onNewTab: () -> Unit,
    onNewPrivate: () -> Unit,
    onFind: () -> Unit,
    onBookmark: () -> Unit,
    onShare: () -> Unit,
    onAddSpeedDial: () -> Unit,
    onBookmarks: () -> Unit,
    onHistory: () -> Unit,
    onDownloads: () -> Unit,
    onSettings: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val sheetState = rememberModalBottomSheetState()
    fun pick(action: () -> Unit) {
        onDismiss()
        action()
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = cs.surface) {
        Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickTile(
                    icon = Icons.Default.DesktopWindows,
                    label = if (desktop) "Desktop: On" else "Desktop: Off",
                    active = desktop,
                    enabled = true,
                    modifier = Modifier.weight(1f),
                    onClick = { pick(onToggleDesktop) }
                )
                QuickTile(
                    icon = Icons.Default.VisibilityOff,
                    label = "Private tab",
                    active = false,
                    enabled = true,
                    modifier = Modifier.weight(1f),
                    onClick = { pick(onNewPrivate) }
                )
                QuickTile(
                    icon = Icons.Default.Search,
                    label = "Find in page",
                    active = false,
                    enabled = inPage,
                    modifier = Modifier.weight(1f),
                    onClick = { pick(onFind) }
                )
                QuickTile(
                    icon = Icons.Default.BookmarkAdd,
                    label = "Bookmark",
                    active = false,
                    enabled = inPage,
                    modifier = Modifier.weight(1f),
                    onClick = { pick(onBookmark) }
                )
            }
            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                color = cs.outline.copy(alpha = 0.5f)
            )
            MenuRow(Icons.Default.Add, "New tab") { pick(onNewTab) }
            MenuRow(Icons.Default.Bookmarks, "Bookmarks") { pick(onBookmarks) }
            MenuRow(Icons.Default.History, "History") { pick(onHistory) }
            MenuRow(Icons.Default.Download, "Downloads") { pick(onDownloads) }
            if (inPage) {
                MenuRow(Icons.Default.Apps, "Add to speed dial") { pick(onAddSpeedDial) }
                MenuRow(Icons.Default.Share, "Share page") { pick(onShare) }
            }
            MenuRow(Icons.Default.Settings, "Settings") { pick(onSettings) }
        }
    }
}

@Composable
private fun QuickTile(
    icon: ImageVector,
    label: String,
    active: Boolean,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val tint = (if (active) cs.primary else cs.onSurface).copy(alpha = if (enabled) 1f else 0.34f)
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(if (active) cs.primary.copy(alpha = 0.2f) else cs.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            lineHeight = 16.sp,
            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
            textAlign = TextAlign.Center,
            color = tint,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun MenuRow(icon: ImageVector, text: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = cs.onSurfaceVariant)
        Spacer(Modifier.width(20.dp))
        Text(text = text, fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface)
    }
}

/** Privacy controls for the open page: how much was blocked and the two global switches. */
@Composable
internal fun ShieldsSheet(
    siteLabel: String,
    blocked: Int,
    tracking: Boolean,
    popup: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, Any) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val sheetState = rememberModalBottomSheetState()
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = cs.surface) {
        Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
            Row(
                Modifier.padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Shield, contentDescription = null, tint = cs.primary)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Shields", fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                    Text(
                        text = siteLabel,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                shape = RoundedCornerShape(18.dp),
                color = cs.surfaceVariant
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text(
                        text = blocked.toString(),
                        fontSize = 30.sp,
                        lineHeight = 38.sp,
                        fontWeight = FontWeight.Light,
                        color = cs.primary
                    )
                    Text(
                        text = if (blocked > 0) "trackers and ads blocked on this page" else "Nothing blocked on this page yet",
                        fontSize = 14.sp,
                        lineHeight = 21.sp,
                        color = cs.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            SwitchRow(
                icon = Icons.Default.Shield,
                title = "Block trackers & ads",
                subtitle = "Uses the built-in block list",
                checked = tracking
            ) { onSave("tracking_protection", it) }
            SwitchRow(
                icon = Icons.Default.VisibilityOff,
                title = "Block pop-ups",
                subtitle = "Stops pop-up windows from opening",
                checked = popup
            ) { onSave("popup_blocker", it) }
            Text(
                text = "Shield settings apply to all sites.",
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                fontSize = 12.sp,
                lineHeight = 18.sp,
                color = cs.onSurfaceVariant
            )
        }
    }
}
