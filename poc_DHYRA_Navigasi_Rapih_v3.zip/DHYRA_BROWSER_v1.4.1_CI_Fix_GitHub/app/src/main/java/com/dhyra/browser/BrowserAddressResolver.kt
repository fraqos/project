package com.dhyra.browser

import java.net.URLEncoder

/** Resolves an address-bar value into a safe HTTP(S) navigation or search URL. */
object BrowserAddressResolver {
    fun resolve(input: String, engine: String): String {
        val value = input.trim()
        if (value.isBlank()) return "https://www.google.com"

        if (value.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))) {
            val scheme = value.substringBefore(":").lowercase()
            return if (scheme == "http" || scheme == "https") value else "https://www.google.com/search?q=${encode(value)}"
        }

        val hostLike = value.contains(".") && !value.contains(" ") &&
            !value.startsWith(".") && !value.endsWith(".")
        if (hostLike) return "https://$value"

        val query = encode(value)
        val endpoint = when (engine) {
            "Bing" -> "https://www.bing.com/search?q="
            "DuckDuckGo" -> "https://duckduckgo.com/?q="
            "Brave" -> "https://search.brave.com/search?q="
            "Ecosia" -> "https://www.ecosia.org/search?q="
            "Startpage" -> "https://www.startpage.com/sp/search?query="
            "Qwant" -> "https://www.qwant.com/?q="
            else -> "https://www.google.com/search?q="
        }
        return endpoint + query
    }

    /** True when [resolve] would open the text as an address instead of searching for it. */
    fun looksLikeAddress(input: String): Boolean {
        val value = input.trim()
        if (value.isBlank()) return false
        if (value.matches(Regex("^(?i)https?://.+"))) return true
        return value.contains(".") && !value.contains(" ") && !value.startsWith(".") && !value.endsWith(".")
    }

    fun normalizeHomepage(input: String): String {
        val value = input.trim()
        if (value.isBlank()) return "https://www.google.com"
        val hasScheme = value.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:.*"))
        if (hasScheme && !value.startsWith("http://", true) && !value.startsWith("https://", true)) {
            return "https://www.google.com"
        }
        val candidate = if (hasScheme) value else "https://$value"
        return runCatching {
            val uri = java.net.URI(candidate)
            if (uri.scheme?.lowercase() in setOf("http", "https") && !uri.host.isNullOrBlank()) candidate
            else "https://www.google.com"
        }.getOrDefault("https://www.google.com")
    }

    private fun encode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())
}
