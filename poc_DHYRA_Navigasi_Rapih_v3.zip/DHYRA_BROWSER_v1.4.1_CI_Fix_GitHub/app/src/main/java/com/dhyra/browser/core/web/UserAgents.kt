package com.dhyra.browser.core.web

/** Builds the mobile and desktop user-agent strings used by the Desktop site toggle. */
object UserAgents {
    private val CHROME_MAJOR = Regex("Chrome/(\\d+)")
    private val SPACES = Regex("\\s+")
    private const val FALLBACK_MAJOR = "124"

    /** The device WebView agent without the WebView-only markers, so sites treat it like Chrome. */
    fun mobile(defaultAgent: String): String =
        defaultAgent.replace("; wv", "").replace(" Version/4.0", "").replace(SPACES, " ").trim()

    /**
     * A real desktop agent. Removing "Mobile" from the Android string is not enough because
     * sites still see "Android" and keep serving the phone layout, so this reports Windows
     * and keeps only the Chrome major version (Chrome freezes the rest on desktop too).
     */
    fun desktop(defaultAgent: String): String {
        val major = CHROME_MAJOR.find(defaultAgent)?.groupValues?.get(1) ?: FALLBACK_MAJOR
        return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/$major.0.0.0 Safari/537.36"
    }
}
