# DHYRA Browser 2.4.5 — Official PNG Branding Integration

Date: 2026-11-27
Input project: `dhyra-browser-2.4.4-source(2).zip`
Logo source: user-provided `25058(1).png` (640×640 RGB PNG)

## Applied changes

- Replaced the canonical app artwork at `app/src/main/res/drawable-nodpi/dhyra_brand_art.png` with the exact user-provided PNG. The original 640×640 pixels are preserved without cropping, stretching, alpha-removal or color modification.
- Replaced the old geometric placeholder adaptive launcher mark with a bitmap foreground derived from the supplied logo. Each density uses a 108dp canvas and fits the complete logo inside 64dp, within the 66dp Android adaptive-icon safe zone.
- Updated adaptive icon resources for both standard and round launcher icons and changed the manifest `roundIcon` reference accordingly.
- Added legacy launcher PNGs (`ic_launcher.png` and `ic_launcher_round.png`) at mdpi, hdpi, xhdpi, xxhdpi and xxxhdpi.
- Updated Android 12+ day/night splash resources to use density-aware `dhyra_splash_logo.png` artwork on a near-white background that blends with the logo's pale edges.
- Replaced the homepage logo and startup intro mark by updating the shared `DhyraMark` Compose component to load the canonical PNG with `ContentScale.Fit`.
- Updated the About screen to use `ContentScale.Fit` without rounded clipping/cropping.
- Replaced the README brand reference image with the exact supplied PNG.
- Updated the branding contract tests and documentation, and advanced app version to `2.4.5` / `versionCode 23`. GitHub Actions APK artifact names were synchronized to `dhyra-v2.4.5`.

## Validation performed

- Source contract suite: **61/61 passed**.
- Page translation JavaScript syntax check: passed.
- Page translation DOM safety test: passed.
- Translation retry test: passed.
- Android XML parsing: **18/18 passed**.
- GitHub Actions workflow YAML parsing: passed.
- Bash syntax: **14/14 workflow run blocks passed**.
- Static Android resource reference scan: passed.
- PNG source identity check: canonical app PNG and README reference are pixel-identical to supplied PNG.
- Density asset dimensions: all launcher, adaptive foreground and splash assets checked.
- ZIP integrity: checked after packaging.

## Not performed / limitations

A complete Android Gradle build, Android Lint, APK generation, emulator test and physical-device launcher/splash visual QA were **not** run. This environment has Java 21 but no installed Gradle command or Android SDK, and the source ZIP intentionally omits `gradle-wrapper.jar`. The included GitHub Actions workflow has a Gradle bootstrap step and is the place to confirm actual Android resource compilation and APK output. No APK success is claimed here.

## Release identity

- `versionName`: `2.4.5`
- `versionCode`: `23`
- Debug artifact expected from CI: `dhyra-v2.4.5.apk`
