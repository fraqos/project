# `space` — privacy architecture and limitations

## Product behavior

The user-facing mode name is always **`space`** (lowercase). Internal Kotlin names such as `isPrivate`, `SpaceSessionPolicy` and `SpaceWebViewProfile` are intentionally retained; they are implementation identifiers, not UI labels.

Normal browsing data remains in the existing default WebView profile and DataStore records. `space` does not write history or restorable tabs to those records. Bookmarks and speed-dial additions are refused in `space`; the `space` homepage receives empty normal speed-dial and recently-visited lists, and its omnibox suggestion index is empty. History, bookmarks and downloads are absent from the `space` menu and are blocked by route guards. Settings also hides the normal Download manager and normal-profile Clear browsing data action while a `space` tab is active.

The tab overview renders only one profile group at a time. After entering the `space` tab group, normal tab titles and previews are not offered from that view; closing the final `space` tab returns the overview to the normal group. `space` pages are not included in normal tab previews or restored-session data.

Android Autofill is excluded from the private WebView and WebView view-state saving is disabled. Native device permission requests (camera, microphone, protected media/DRM and geolocation) are refused in `space`. Persistent Android `DownloadManager` downloads are deliberately blocked in `space` rather than risking a normal/public download record or shared Downloads file.

## WebView profile boundary

The implementation uses an AndroidX WebKit named profile through `SpaceWebViewProfile`:

- Profile name: `dhyra-private-session`.
- Required runtime capabilities: `WebViewFeature.MULTI_PROFILE` and `WebViewFeature.DELETE_BROWSING_DATA`.
- A newly-created `space` WebView is attached with `WebViewCompat.setProfile()` immediately after construction, before WebSettings, clients, storage or navigation are touched.
- Normal WebViews use the provider's default profile. `space` WebViews use the named profile's own `CookieManager`; third-party cookies are disabled and the WebView cache mode is `LOAD_NO_CACHE`.
- `WebStorageCompat.deleteBrowsingData(profile.webStorage, callback)` is used for profile-scoped cleanup. AndroidX WebKit documents this API as clearing website data including network cache, cookies and JavaScript-readable storage; the WebKit 1.13 release notes state the API guarantees deletion of local storage, network cache, cookies and installed service workers.
- Cleanup starts before a new session can be used, after the last `space` tab closes, and when a controller containing `space` tabs is destroyed. The app waits for the deletion callback before marking the profile ready. A missing capability, failed profile attach or failed cleanup disables `space`; it never silently falls back to the default profile.

### Why this build does not call `WebView.setDataDirectorySuffix()`

`WebView.setDataDirectorySuffix()` chooses a data directory for the **current process**. Android requires it to be called before any WebView instance or other `android.webkit` API initializes in that process; a data directory can be used by only one process. It is not a per-WebView switch. DHYRA runs normal and `space` WebViews concurrently in the same process, so attempting to switch suffixes between them would not create two independent profiles and could fail after the first WebView initializes. AndroidX WebKit named profiles are the appropriate API for this same-process, multiple-profile design. A separate-process architecture would be a different design and would need its own process/IPC/data-directory lifecycle.

### What “wipe” means

The app clears all website browsing data exposed by the named profile via `WebStorageCompat`; this is not a filesystem deletion of the provider's entire profile directory, and the named profile remains registered. The clear API is the supported profile-scoped deletion path used here. The profile may be created again after cleanup. Do not replace this with `ProfileStore.deleteProfile()` while profile/WebView instances are loaded.

## Code-level isolation audit

| Area | Current implementation | Privacy status |
|---|---|---|
| Cookies | Normal default `CookieManager`; `space` named-profile `CookieManager` | Profile-isolated |
| HTTP cache | `LOAD_NO_CACHE` in `space`; profile-scoped cleanup at session end | Reduced and wiped |
| localStorage / IndexedDB / website storage / service workers | Named WebView profile; `WebStorageCompat.deleteBrowsingData` cleanup | Profile-isolated and wiped by API contract |
| sessionStorage | Exists only in the page/session context; not copied into normal app storage | Not persisted by DHYRA; validate provider behavior |
| History | `onPageFinished` persistence callback excludes private tabs | Not written by `space` |
| Restored tabs | Session serializer filters out private tabs | Not written/restored |
| Speed dial / recently visited | `space` homepage receives empty lists; add actions are refused | Normal entries hidden; `space` entries not persisted |
| Omnibox suggestions | Empty `SmartSuggest` index while active tab is `space` | Normal history/bookmark suggestions hidden |
| Bookmarks | Add action blocked; menu and route hidden in `space` | Not written or shown |
| Open tabs / previews | Tab overview shows one mode group; no private thumbnails; regular tab segment is not offered after entering `space` | Separate presentation; tabs remain in one in-memory controller collection, see limitations below |
| Autofill / saved passwords | Android Autofill excluded; WebView view-state saving disabled; no DHYRA-owned password-manager repository found in this source | Android Autofill path disabled; external password managers may behave independently |
| Downloads | Private-tab listener refuses persistent downloads; normal Download manager hidden in `space` | Fail-closed; private downloads are unavailable |
| Recent Apps / screenshots | `FLAG_SECURE` and, on API 33+, `setRecentsScreenshotEnabled(false)` while any `space` tab exists | Protected at Activity/window level |
| Device permissions | Camera, microphone, DRM/protected media and geolocation denied in `space` | Requests refused |

## Compatibility and limits

Named-profile and profile-data-deletion support depend on the installed Android System WebView provider. If either feature is unavailable, or profile initialization/cleanup fails, `space` is disabled. Do not weaken this gate by silently using the regular default WebView profile.

The tab controller still keeps both tab types in a single in-memory `tabs` collection tagged with `isPrivate`; the tab overview filters that collection and never renders both groups in the same visible list. Normal tabs are not serialized with `space` tabs. A future architectural hardening could split the controller collection into separate regular/space registries, but doing so safely requires updating tab-parent selection, swipe navigation, lifecycle and close/restore flows together.

`space` is a separate WebView profile, not a separate Android OS user, application UID, guaranteed renderer process, VPN or anonymity network. It does not hide the user's IP address, prevent websites from recognising a signed-in account, or defeat browser/device fingerprinting. App-wide preferences such as theme and search-engine choice remain shared settings; they are not browsing records. An Android keyboard, accessibility service, external password manager or OS component is outside DHYRA's WebView storage boundary. User-initiated share, print, clipboard and external-app actions can intentionally export page information. On older Android versions, `FLAG_SECURE` is the primary screenshot defense; platform/device-specific behavior still needs verification.

## Manual validation matrix

1. Sign in to a test origin in a normal tab, open the same origin in `space`, and confirm the normal cookie/session is absent.
2. Create cookies, localStorage, IndexedDB and a service worker in `space`; close the final `space` tab; reopen `space` and confirm the profile data has been cleared.
3. Force-stop the process with `space` open; relaunch and confirm startup cleanup completes before `space` becomes available.
4. Test cache behavior, sessionStorage, WebSQL (if exposed by the provider), storage estimates, service workers and partitioned cookies on multiple WebView versions.
5. Test unsupported features and forced cleanup/attach errors; confirm `space` remains disabled rather than using the default profile.
6. Confirm `space` URLs do not appear in normal history, bookmarks, speed dial, restored session, normal autocomplete suggestions, tab previews or Download manager.
7. Open Settings from `space`; confirm the normal Download manager and Clear browsing data entries are not available.
8. Confirm the tab overview does not reveal normal tab titles/previews after entering the `space` group and that closing the last `space` tab returns to normal tabs.
9. Confirm Recent Apps shows no `space` screenshot on API 33+ and that screenshot/recording is blocked by `FLAG_SECURE` on supported device builds.
10. Confirm camera, microphone, protected media/DRM and geolocation requests are refused in `space`.

## User-facing privacy statement

`space` keeps supported WebView browsing storage separate from normal DHYRA browsing and clears that profile's website data when the session ends. DHYRA does not persist `space` history, restored tabs, bookmarks, speed-dial entries or downloads. It does not hide the user's IP address, prevent websites from recognising a signed-in account, or provide network anonymity. Compatibility and deletion depend on the installed WebView provider, so the feature is disabled when the required profile and deletion APIs are unavailable.
