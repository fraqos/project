# dhyra — implementation status 2.4.5

## Build and project identity

- App label and visible brand: `dhyra` (lowercase).
- App version: 2.4.5 / versionCode 23.
- Android project: Kotlin, Jetpack Compose Material 3, Preferences DataStore and AndroidX WebKit.
- Rendering engine: Android System WebView supplied by the user's device. `DhyraEngine` is an application-owned facade/policy layer, not a custom Chromium build.
- Toolchain configured in source/CI: JDK 21, AGP 9.3.1, Gradle 9.5.1, compileSdk 37.1, targetSdk 36, minSdk 26.
- Project remains a single Android app module. `MainActivity.kt`, `BrowserController.kt` and `UiModels.kt` are still sizeable coordinators; a full multi-module/MVVM/Room/DI refactor is not complete.

## Implemented in source

### Brand and interface

- The primary brand mark is the user-supplied 640×640 PNG artwork. It is used consistently by the adaptive launcher foreground, five legacy launcher densities, Android 12+ splash artwork, homepage/startup Compose mark, About page and README. The About artwork uses fit scaling without cropping. The app label remains lowercase `dhyra`.
- A single electric-violet accent remains in the app UI theme. Launcher/adaptive-icon and Android 12+ splash backgrounds use a pale near-white surface to blend with the supplied PNG. The theme selector offers only `System` and `Dark`; saved `Dynamic`/`Light` values migrate to `System`, while `AMOLED` migrates to `Dark`.
- Settings no longer exposes UI Styles, Homepage Layout, Reduce Motion, Animation Intensity or Disable Startup Animation. Existing homepage layout data is retained internally for backward compatibility, but users can no longer change that preset through Settings. Obsolete style/motion keys are removed only when found in DataStore.
- Homepage includes live clock/date/greeting, editable speed-dial shortcuts, recent pages, opt-in weather and news feed states.
- Startup shows a brief D-only fade/scale reveal after browser initialization on each app launch. It does not wait for network access or delay Android process shutdown.
- Tab overview supports previews/metadata where available, close gestures, group close and regular-tab undo. Closing one card uses a short exit transition; keyed lazy-grid items animate their placement when the removed card leaves. Close All uses a bounded cascade so the exit remains short even with many tabs.

### Search, data and language

- Built-in providers: Google, Bing, DuckDuckGo, Yahoo, Ecosia, Startpage, Qwant and Brave.
- Custom search provider CRUD: add/edit/delete/select, persistent list, duplicate-name checks, HTTPS URL validation, exactly one `%s` or `{query}` placeholder, optional HTTPS favicon URL and URL-encoded query substitution. The selected provider is wired to the Home selector and address-bar resolver.
- News categories: Top stories, Breaking News, World, Technology, Business, Science, Sports, Entertainment, Politics and Local News. RSS parser includes search/category paths, source attribution, publication timestamp, duplicate suppression and loading/error/retry/empty states.
- Weather uses Open-Meteo after an explicit user tap and Android approximate/precise location grant. A bounded location-fix timeout is used and the GPS provider is avoided when only approximate permission is present.
- Page translation uses Google ML Kit Language Identification and Translate on-device after model download. Preferred target language is persisted. Page text is not sent to a cloud translation service by the current ML Kit provider.

### Downloads, engine and privacy

- Download confirmation displays requested filename, source host from the actual download URL, MIME/type, destination description and warning for executable/APK-like files. Public downloads use Android DownloadManager. UI displays status/progress, supports cancellation/removal and opens completed files.
- Fullscreen WebView presentation adds a transient origin indicator and a Back-to-exit affordance; Android system bars are transiently revealable by gesture.
- WebView settings block mixed content, disable direct file access and media autoplay, enable Safe Browsing where provider supports it, and cancel SSL certificate errors. Browser-initiated top-level HTTP is subject to HTTPS-first handling; this is not a universal HTTPS guarantee for all page subresources/redirects.
- Site camera/microphone requests are origin-labelled and require a browser prompt plus Android runtime permission. Geolocation uses a separate origin-aware prompt. SPACE tabs deny device permission requests.
- SPACE is available only if the installed WebView supports AndroidX WebKit `MULTI_PROFILE` and `DELETE_BROWSING_DATA`. There is no default-profile fallback. SPACE profile data is cleared at startup and when the final SPACE tab closes. SPACE session data is not restored and private downloads are blocked.
- History/bookmark/session persistence remains JSON in Preferences DataStore for compatibility. A migration to Room is not included.

## Known limitations — not implemented or not claimed

- No standalone Chromium build, Gecko engine, independent renderer, custom JavaScript runtime or own network stack. JavaScript execution, HTML/CSS/HTML5 support, cookie behavior and process model depend on the Android System WebView provider/OS.
- No guarantee of Chromium-style full site isolation beyond WebView/provider architecture. AndroidX WebView named profiles are a storage/profile boundary, not an independently configured OS process sandbox.
- The previous UI Style System and Homepage Layout selectors have been removed from Settings in 2.4.2. A saved homepage preset from an earlier version may remain active internally for compatibility, but there is no user-facing preset switcher in this version.
- Homepage remains a curated browser start page; arbitrary widget creation, drag reorder, resize and a widget marketplace/editor are not implemented.
- UI language localization is not complete. Most Compose labels remain in English; the current language preference is for translation target, not the whole app. Indonesian/English app-wide runtime switching is a separate task.
- News RSS is from Google News, an unofficial endpoint with no published API contract or SLA. Content and update time depend on feed results/network. No authenticated/contracted news API is configured.
- Weather has no IP-based approximate location fallback. It only obtains location after tap and Android permission; if no provider/last-known fix is available it reports an error.
- Android DownloadManager does not expose app-controlled pause/resume, precise instantaneous speed or trustworthy remaining time through the current integration. Download destination is the platform Downloads location; a SAF destination picker is not implemented.
- Fullscreen is handled by WebView custom view and transient origin label, but no persistent security overlay can remain visible while arbitrary sites occupy fullscreen. Back and system gesture affordances remain available.
- Permission UX does not yet provide a complete persistent per-origin permissions dashboard, Allow Once/Ask Every Time policy database, clipboard controls, Web Notification engine, file-system permission centre or granular pop-up origin permissions. Camera/mic/geolocation have user prompts; the platform still owns underlying grants.
- SPACE does not make the user anonymous to websites, network operators, ISP or administrators. Complete per-provider isolation of service workers, IndexedDB, cache, WebSQL and all WebView storage must be tested on physical supported devices. SPACE downloads are blocked, not supported in a temporary encrypted file vault.
- Shields is a lightweight host/path matcher, not full EasyList/uBlock syntax/cosmetic filtering/scriptlets. DoH presets, anti-fingerprinting, WebRTC leak prevention and comprehensive Safe Browsing backend integration are not implemented.
- No full English/Indonesian UI string migration, Android App Locale configuration or extension localization framework is implemented.
- Macrobenchmark, LeakCanary, instrumentation coverage, TalkBack/large-font QA and full device matrix remain open. CI can sign an APK/AAB when a user-provided signing key is configured; no key or signed release artifact is included here.

## Release gates still open

1. Hosted green workflow on the exact archive/commit: `:app:checkDebugAarMetadata`, `testDebugUnitTest`, `lintDebug`, `assembleDebug` and APK validation.
2. Real-device and emulator QA across API 26+ and multiple WebView provider versions.
3. Private-profile persistence/isolation tests for cookies, cache, service worker, IndexedDB and localStorage.
4. Camera/microphone/geolocation/file chooser/fullscreen/notification and popup lifecycle tests.
5. TalkBack, keyboard/IME, 200% font scale, tablet, landscape and Android system animator-scale validation.
6. Performance profiling for startup, multi-tab memory pressure, renderer crashes, ANR and battery usage.
7. Hosted release signing, AAB verification, privacy policy/data-safety review and store compliance. The source now has an optional CI signing path but no user keystore was supplied, so a signed build has not been produced.


## 2.4.4 changes

- Omnibox accepts localhost aliases, `.local` hosts, valid IPv4 and bracketed IPv6 addresses, with optional ports; bare single-word input continues to search.
- Shields allow rules take precedence over block rules for the same matching request, independent of filter order.
- Settings offers only System and Dark; legacy theme values are normalized without clearing browser data.
- User-facing private-session UI uses the name SPACE. Internal `isPrivate`/profile identifiers remain in place to avoid a broad persistence migration.
- Activity teardown performs one final named-profile data deletion for a live SPACE session.
- Release signing is optional and supplied through GitHub Secrets; the source ZIP excludes keystores and credential files.


## 2.4.4 Kotlin resource-reference hotfix

- Qualified the About-screen artwork resource as `com.dhyra.browser.R.drawable.dhyra_brand_art` to avoid ambiguous or shadowed `R` resolution in the Compose screen package.
- Confirmed the matching `dhyra_brand_art.png` exists under `app/src/main/res/drawable-nodpi/`.
- Incremented app version to 2.4.4 / versionCode 22 and synchronized the 2.4.4 CI artifact names.
- This source correction addresses the reported Kotlin compile error; a full Android Gradle build still must run in GitHub Actions to verify compilation end-to-end.


## 2.4.5 branding integration

The official user-provided 640×640 PNG is now the canonical DHYRA artwork. It is used by the launcher icon (adaptive plus legacy density resources), Android 12+ splash screen, homepage mark, startup intro, About screen and README reference. The homepage/About artwork uses fit scaling; the About image is no longer cropped. The adaptive foreground scales the whole artwork into Android’s 66dp safe area within a 108dp layer. The app version is 2.4.5 (versionCode 23).
