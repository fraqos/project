# dhyra — UI and Motion Refinement 2.4.2

## Brand identity

- Primary mark: one geometric capital D, without a spider, secondary glyph, wordmark, or decorative icon.
- Brand surface: obsidian (`#101116`).
- Primary accent: electric violet (`#8067F0` in launcher resources; Compose light/dark tonal variants preserve contrast).
- The Compose mark, adaptive launcher foreground, monochrome artwork and legacy icon share the same D silhouette.

## Settings cleanup

The following controls have been removed from Settings: UI Styles, Homepage Layout, Reduce Motion, Animation Intensity and Disable Startup Animation. Existing theme selection (System, Dynamic, Light, Dark and AMOLED), desktop mode, homepage URL, search engine and other browser settings remain. Previously saved homepage layout data is retained to avoid changing an existing user's start page unexpectedly. Retired UI-style and motion preference keys are cleaned from DataStore at initialization only when those keys are present, avoiding an unnecessary preferences write on later launches.

## Motion language

- Startup: D-only fade/scale reveal over a quiet obsidian surface. It appears after browser initialization on each app launch and does not perform network work.
- Screen navigation: short 180 ms fade/scale enter and 120 ms fade exit.
- Single tab close: the card fades/scales/slides out over 190 ms; the keyed lazy grid animates the placement of remaining cards using a low-stiffness spring.
- Close All: cards use a 210 ms exit with a bounded 24 ms cascade step (maximum eight stagger intervals), then the existing controller closes the selected tab group. Regular-tab Undo and private-tab confirmation are preserved.
- Swipe-to-close: a short horizontal exit remains available; drag cancellation returns the card with a 150 ms easing transition.

The motion uses Compose property/lazy-item animations rather than blur or continuously running effects. No blocking application-exit animation is implemented because Android does not provide a safe lifecycle hook to delay process shutdown for visual effects.

## Compatibility notes

The browser's tab controller, navigation APIs, session persistence, downloads, translation, and permission/security layers are not replaced by this UI update. The homepage layout data model remains internal for backward compatibility, but its Settings selector is removed.
