# dhyra — GitHub Actions setup (2.4.5)

The canonical workflow is `.github/workflows/build.yml`. Keep only this workflow active for dhyra to prevent duplicate builds.

## Recommended source-at-root setup

1. Extract the dhyra project ZIP once.
2. Commit the extracted project contents to the root of the GitHub repository.
3. Confirm `settings.gradle.kts`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`, `gradle/` and `.github/workflows/build.yml` are at the expected paths.
4. Push to `main`/`master`, create a pull request, or run the workflow manually.

## ZIP-only setup

1. Commit `.github/workflows/build.yml` separately; GitHub only activates workflows committed under `.github/workflows/`.
2. Commit exactly one dhyra ZIP at repository root.
3. Do not extract it manually. The workflow validates and extracts that ZIP in CI, then locates `settings.gradle.kts` and the app module.
4. Keep only one ZIP at repository root. The workflow rejects multiple ZIPs to avoid building the wrong version.

Root Gradle source takes precedence if both source and ZIP are present.

## Workflow jobs

- Checkout repository.
- Locate Android source or safely extract one root ZIP.
- Set up JDK 21 and Android SDK licences.
- Install Android SDK Platform 37.1. AGP selects the compatible Build Tools version because the project does not pin `buildToolsVersion`.
- Set up Gradle 9.5.1, create a minimal temporary Gradle build (`settings.gradle` + `build.gradle`), generate the standard Wrapper only after the build definition exists, verify the Wrapper JAR SHA-256 and distribution checksum, then build.
- Run `testDebugUnitTest`, `lintDebug`, and `assembleDebug`.
- Validate APK archive integrity, `AndroidManifest.xml` and DEX bytecode.
- Produce `dhyra-v2.4.5.apk`, a clean `dhyra-source.zip` and `SHA256SUMS.txt`.
- Upload APK, source ZIP and checksums as GitHub Actions artifacts.

The normal APK is a debug build. For a signed release APK and AAB, run the workflow manually with both `build_release=true` and `sign_release=true`, and configure repository Actions secrets: `DHYRA_RELEASE_KEYSTORE_BASE64`, `DHYRA_RELEASE_STORE_PASSWORD`, `DHYRA_RELEASE_KEY_ALIAS` and `DHYRA_RELEASE_KEY_PASSWORD`. The keystore is decoded only into `$RUNNER_TEMP/dhyra-signing` and is not added to the source ZIP. With `sign_release=false`, the optional APK is unsigned for engineering tests only. Never put keystores or passwords in the repository.

## Troubleshooting

- Missing settings file: ensure project root is checked in or a single valid ZIP is committed at repository root.
- Invalid ZIP: regenerate the source ZIP and check that it contains Gradle settings, app build file and Android Manifest.
- SDK package errors: use current Android command-line tools; never request obsolete SDK package `tools`.
- Kotlin compilation error: fix the first compiler diagnostic, not only the final Gradle task failure.
- Artifact missing: confirm the test, lint, build, APK validation and checksum steps all passed.
