# Per-tab Mobile / Desktop Mode

dhyra uses the device's Android System WebView. `WebViewModeManager` reads the runtime default User-Agent through `WebSettings.getDefaultUserAgent(context)`. It does not hard-code a Chrome build. For Desktop mode it creates a Linux X11 User-Agent while preserving the exact `Chrome/<version>` token from the WebView provider; if no supported Chromium token is present, it refuses the desktop request rather than inventing a version.

Each tab owns a `WebViewMode` value. The selected mode is serialized in the regular browsing session and reapplied when a WebView is restored/recreated. New tabs use the configurable default mode; changing one tab does not silently change other tabs.

Desktop mode sets `useWideViewPort`, `loadWithOverviewMode`, zoom support and hides on-screen zoom buttons. It does not rewrite the page's viewport meta tag or inject global CSS. A desktop User-Agent changes server-side UA detection and may affect responsive breakpoints, but does not guarantee a desktop document. A page can force a `device-width` CSS viewport, use client-side device detection, or require desktop OS functionality. The CSS/layout viewport defines page layout coordinates; the visual viewport is the currently visible/scaled portion after pinch zoom or overview scaling.

Switching modes updates WebSettings and reloads the active tab. Background tabs are marked stale and reload when selected. On WebView recreation, saved per-tab mode is applied before the first navigation.
