# dhyra 2.4.0 — Source Audit and Engineering Changelog

## 2.2.0 — Browser architecture, navigation and saved-page improvements

- Added the dhyra-owned `DhyraEngine` facade and `DhyraWebViewController` for runtime provider reporting, shared WebView configuration and deterministic teardown. Rendering remains Android System WebView by design.
- Added named modules/facades for search policy, navigation, desktop mode, session restore, cookies/cache, downloads, security/permission policy, settings defaults, history and bookmarks. Existing callers are preserved through compatibility names/typealiases where appropriate.
- Switched first-run search to Google and added real HTTPS search templates for Bing, DuckDuckGo, Yahoo, Ecosia, Startpage, Qwant and Brave. Custom search URLs must be valid HTTPS with a single `{query}` placeholder.
- Hardened address parsing: only HTTP(S) URLs with a host and without user-info credentials are navigated; unsupported schemes and malformed address candidates become Google searches.
- Added dhyra wordmark/monogram on Home and Android 12+ day/night splash branding. Added editable Home shortcuts, including add/edit/remove flows with URL validation and the existing eight-shortcut cap; the fresh-install set leaves room for the Add tile.
- Added bookmark edit name/URL flow and date-grouped History. Existing DataStore JSON remains the persistence layer to avoid a risky storage migration.
- Made private WebView configuration fail closed if the profile CookieManager is missing; no private WebView can fall back to the regular cookie store.
- Made regular WebStorage clear completion exactly-once and marshalled to the main thread, including the provider fallback path. The app avoids the app-wide `WebView.clearCache(true)` call because it can cross the private-profile boundary on providers that share that cache.
- Allowed system-picker-granted `content://` URIs so file upload remains possible in SPACE tabs; `file://` access and top-level `content://` navigation stay blocked. Media with sound requires a user gesture.
- Added pure Kotlin regression coverage for history and bookmark deduplication, editing, searching and deletion.
- Preserved per-tab Desktop/Mobile preference when regular Close All is undone.
- Bumped app version to 2.2.0 / versionCode 14 and aligned CI APK filenames/documentation.

### Verification performed for 2.2.0

- Pure Kotlin/JVM regression harness: PASS (eight suites covering address/search, HTTPS upgrade, Shields, suggestions, Back policy, desktop/mobile UA transform, tab selection/Close All, and history/bookmark list policy).
- `scripts/check-compose-contracts.py`: PASS (20 source contract checks); 18 Android XML files parse; GitHub Actions YAML, Bash script blocks and embedded Python blocks parse.
- Node translation DOM and retry smoke tests: see current verification record below.
- Full Android Gradle test/lint/APK and on-device browser rendering checks remain dependent on hosted Android SDK CI and physical devices; no such result is claimed from this environment.

---

## 2.2.0 — Tab lifecycle and compact tab-switcher reliability

- Bumped the app to version 2.2.0 / versionCode 14.
- Fixed group-wide tab closing so closing one tab group activates the last remaining tab from the other group when available. This prevents creating a redundant regular blank tab while SPACE tabs are still open.
- Added a pure-JVM `afterCloseAll` policy and regression checks for preserving a surviving active tab, switching to a remaining tab, and returning no selection when every tab is closed.
- Added an explicit confirmation step before closing SPACE tabs because SPACE tabs cannot be restored. Regular tabs retain the existing snackbar Undo path.
- Prevented mode switching, card selection, individual close gestures and tab creation while the close-all cascade is running, avoiding competing mutations and animations.
- Reset the tab search before the close-all cascade so every tab in the selected group is included in the visible transition. The operation consistently applies to the selected group, not only filtered search results.
- Reduced tab-card height and enabled two-column layouts at narrower phone widths; compacted the New Tab action while keeping 48dp interactive targets.
- Updated GitHub checkout to the verified `actions/checkout@v7.0.1` release and disabled credential persistence because the pipeline does not push to the repository.
- Added an explicit GitHub Actions YAML syntax parse to the CI workflow.

## Verification performed for 2.2.0

- Passed `node --check app/src/main/assets/PageTranslation.js`.
- Passed `node scripts/test-page-translation.cjs` and `node scripts/test-translation-retries.cjs`.
- Passed `python3 scripts/check-compose-contracts.py`.
- Validated `.github/workflows/build.yml` with a YAML parser.
- Android Gradle unit tests, Android lint, APK build and device UI tests were not run in this environment: Gradle and Android SDK are not installed, and the uploaded source ZIP intentionally does not contain `gradle-wrapper.jar`. The hosted workflow generates the wrapper JAR and runs those Android build gates.

---

## Historical baseline and implementation notes

### dhyra 2.1.2 — Compose translation sheet compile fix

- Updated Material 3 exposed-dropdown anchors to pass `ExposedDropdownMenuAnchorType.PrimaryNotEditable` explicitly.
- Imported and invoked `ExposedDropdownMenu` as the `ExposedDropdownMenuBoxScope` extension instead of using an invalid fully qualified top-level call.
- Changed `BrowserController.restoreSession` to `internal`, matching the internal `SessionTab` parameter type.
- Added a CI source-contract check for the Compose dropdown API and Kotlin visibility boundary.
### Source audited

The current work is based on the uploaded `dhyra-FINAL.zip`. The archive was extracted and reviewed before editing. dhyra is an Android Gradle app using Kotlin, Jetpack Compose Material 3 and Android System WebView.

### Baseline verified in source

- Application ID: `com.dhyra.browser`.
- Historical baseline version: 2.1.2 (versionCode 12); the immediately preceding release candidate was 2.1.0 (versionCode 10).
- Kotlin / Compose plugin 2.4.21; AGP 9.3.1; Gradle 9.5.1; JDK 21 in CI; JVM target 17.
- compileSdk 37.1, targetSdk 36, minSdk 26.
- AndroidX WebKit upgraded to 1.17.1; Compose BOM 2026.11.01, Activity Compose 1.13.0, Lifecycle 2.10.0, Core KTX 1.19.0 and Preferences DataStore 1.2.1 pinned to stable releases.
- App state uses Preferences DataStore with JSON codecs for history, bookmarks and regular session; this package does not claim a Room migration.

## Engineering changes made during this pass

### Privacy and browser engine

1. Added runtime feature detection for WebView `MULTI_PROFILE` and `DELETE_BROWSING_DATA`.
2. Created/uses a named private WebView profile only when both capabilities are present.
3. Assigns SPACE profile via `WebViewCompat.setProfile` immediately after WebView construction and before touching settings, cookies, clients, JavaScript or navigation.
4. Clears only private-profile browsing data on application start, after the last SPACE tab is closed, and when the browser controller is torn down. SPACE remains unavailable until the asynchronous cleanup callback has completed. A generation token prevents an older cleanup callback from incorrectly marking a newer cleanup as complete.
5. Exposes private-profile readiness in Compose so the private-tab action is disabled while cleanup is pending. Unsupported providers do not fall back to default profile storage.
6. Private blank tabs also instantiate/attach the named profile before becoming visible, so a runtime profile-attachment failure is detected at tab creation rather than after first navigation.
7. Blocks downloads from SPACE tabs because Android DownloadManager persists public records and files outside the private WebView profile.
8. Removed application-wide `WebView.clearCache(true)` from private-tab destruction. Profile-scoped cleanup is responsible for private cookies/cache/site storage, avoiding accidental impact on regular-profile cache.
9. Activity teardown now determines whether each WebView is private instead of treating every live WebView as private. Regular cookies/storage are not cleared on ordinary Activity teardown.
10. Preserved regular per-site Shields overrides when a SPACE session ends.
11. Added Activity pause/resume forwarding, memory trimming for inactive tabs and per-tab Reader Mode state restoration.
12. SPACE tabs opt out of Android Autofill and regular View state saving. Persistent private bookmarks and speed-dial additions are blocked. Private-page translation uses on-device ML Kit; page text is not sent to a cloud translation service and no external translation URL is opened. ML Kit language models are app-level downloads shared by regular and SPACE tabs. Private per-site Shields overrides do not affect regular tabs.
13. WebView `shouldInterceptRequest` now reads per-tab URLs and site overrides from concurrent maps rather than accessing Compose snapshot state in its non-UI callback thread.

### Reliability and UX

1. Download status polling runs only while the screen lifecycle is STARTED, refreshes quickly for pending/running downloads and more slowly while idle. If a refresh fails, the last successful list remains visible when available.
2. Settings search now includes isolated SPACE terms.
3. Home speed-dial uses width-adaptive layout, the start-page omnibox includes a search-engine selector, and date/greeting state refreshes every minute.
4. Tab switcher uses adaptive grid sizing and a tab search when the set is large.
5. Tab card close/search/desktop/omnibox actions use larger touch targets; key tab segments meet a 48dp minimum height.
6. AMOLED theme sets Material 3 surface containers to true black/near-black values, not only the background surface.
7. Shields UI reports requests blocked for the current page and explicitly says transferred bytes are not measured; fabricated 32KB-per-request estimates were removed.
8. Translate uses ML Kit on-device models; the target language defaults to the device locale where supported, and no page URL is forwarded to an external translation service.
9. Reader Mode state is associated with each tab and its presentation CSS is re-applied after navigation. It remains CSS presentation, not article extraction.
10. Version bumped to 2.1.2 / versionCode 12 in this final reliability pass.

### Build and documentation

- Target SDK remains API 36; compile SDK and CI platform updated to API 37.1 to satisfy Compose 1.13 AAR metadata. (The later workflow no longer hard-pins Build Tools; AGP selects the compatible version.)
- WebKit support library updated to 1.17.1 for Multi-Profile and profile-scoped data deletion APIs.
- Documentation was rewritten to distinguish implemented behavior from remaining work.
- Canonical CI workflow remains `.github/workflows/build.yml`; it supports committed source at root or exactly one ZIP at repository root, then runs test, strict lint and debug build.

## Important remaining work

- `MainActivity.kt`, `BrowserController.kt` and `UiModels.kt` remain large coordinator/data files. A full ViewModel/use-case/repository separation is not complete.
- History/bookmarks/download metadata are not migrated to Room. Existing JSON DataStore storage is retained to avoid an unsafe/destructive migration. A Room migration requires explicit schema/data migration tests.
- Private-profile behavior needs physical-device verification across WebView provider versions, including cookie and localStorage separation. It is feature-gated and disabled when support or cleanup is unavailable.
- Shields is a lightweight host/path engine; no claim of full EasyList/uBlock compatibility.
- Per-origin permission-management screen, robust article extraction, custom DoH transport, full fingerprinting/WebRTC protections and true download pause/resume are not complete.
- Compose instrumentation tests, WebView instrumentation tests, Macrobenchmark, LeakCanary, release signing and AAB validation remain release work.

## Verification boundary

Source/static checks and pure-JVM tests are performed separately in this environment. No Android Gradle build, Gradle lint, APK assembly, emulator/device QA or Play publication is claimed until the hosted CI and device test results exist.


## Additional privacy hardening

- SPACE profile attachment now fails closed if `WebViewCompat.setProfile` throws, disables SPACE and removes the just-created private WebView rather than leaving an unusable tab.
- Private camera, microphone, protected-media and geolocation requests are denied; regular-tab permission prompts remain explicit and origin-labelled.
- Popup-created tabs are closed if WebView/profile creation or the transport fails, avoiding orphaned tabs.
- Added a pure-JVM policy test ensuring SPACE tabs cannot request device permissions.
- Sanitised untrusted download filenames before passing them to the public Downloads destination; path separators and invalid/control characters are removed and names are length-limited.
- Moved history/bookmark JSON decoding and suggestion index generation to a background dispatcher to avoid doing large in-memory transforms on the Compose UI thread.
- Version advanced to 2.1.2 / versionCode 12 in this package.


## Desktop mode and on-device translation follow-up

- Per-tab Mobile/Desktop mode remains based on the installed WebView runtime UA; Desktop mode preserves the runtime Chromium version and does not hard-code a Chrome build.
- Added ML Kit Translate + Language Identification with model download, language pair management, a bounded queue/cache and lifecycle-aware pause/resume.
- Added an origin-checked AndroidX WebMessageListener session with a random per-run token, bounded batches and no general-purpose JavaScript-to-native privilege interface.
- Page translation operates on eligible TextNodes only. It uses incremental TreeWalker scans, viewport priorities, bounded batches and conditional restoration that does not overwrite website-owned mutations.
- Follow-up hardening: retry count now survives batch re-queue and stops after two retries; transient native errors are marked explicitly, while permanent errors are not retried. Hidden ancestor styles are considered when collecting visible text.
- Mutation handling now distinguishes the translator's own `nodeValue` write from a website mutation that lands before the observer callback. Uncorrelated bridge errors are ignored rather than being applied to the oldest pending batch, preventing page-authored malformed messages from cancelling unrelated translation work. Newly added text under hidden ancestors is skipped. When some segments of a long TextNode fail, successful segments can still render while failed segments remain in the original language and the whole node remains restorable.
- Added queue execution tests for translation result mapping and pause/resume, in addition to batch payload validation tests.


## Translation reliability hardening (2026-11-26)

- Bounded retry state is carried across reissued request IDs; JavaScript retries explicitly transient native errors at most twice and does not loop for permanent errors.
- `MutationObserver` now distinguishes dhyra's own translated `nodeValue` update from a website mutation that occurs before the observer callback. The latest website-owned value is queued as new source text instead of being discarded or overwritten.
- Newly inserted TextNodes are visibility-checked through their ancestor chain before enqueueing, so hidden content is not translated.
- Long TextNodes can render successfully translated segments while preserving failed segments in their source language; restore reconstructs the exact current source value when the website has not changed it again.
- Added deterministic Node DOM and retry smoke tests under `scripts/` and wired them into GitHub Actions before the Android Gradle tasks.
- App patch version advanced to 2.1.2 / versionCode 12.


## 2.2.1 — Kotlin saved-page list inference fix

- Fixed the History/Bookmark Compose section collection in `ScreensUi.kt`. The previous conditional mixed `Map.Entry<String, List<SavedPage>>` and `Pair<String, List<SavedPage>>`; Kotlin inferred an overly broad type and Compose could resolve the integer-index `items(count: Int)` overload.
- Convert grouped History sections to `Pair<String, List<SavedPage>>` and type the full collection explicitly.
- Select the Compose `items(items = sectionEntries)` overload and type both the key and content lambdas as `SavedPage`.
- Bump version to 2.2.1 / versionCode 15 and align CI APK naming.


## dhyra 2.2.2 — Kotlin compile correction

- `MainActivity.kt`: `DhyraPermissionManager.supportedResources()` returns `Array<String>`. Pass the result directly to `PermissionRequest.grant()`; calling `toTypedArray()` on an array is invalid. The separate protected-media branch filters a `List<String>`, so its `toTypedArray()` remains valid.
- `MLKitTranslator.kt`: removed default values from overriding `prepare` and `translate` methods. `TranslationProvider` retains `wifiOnly = true`, preserving the default for callers while complying with Kotlin's override rules.
- Added CI source-contract checks for the array grant boundary, interface-owned defaults, and synchronized app/CI version.
- Bumped app version to 2.2.2 / versionCode 16.


## dhyra 2.3.0 — dashboard, brand and Settings pass (2026-11-27)

- Updated launcher adaptive-icon foreground, background, monochrome and legacy art to a dhyra-owned orbit monogram.
- Rebuilt Home header around a live clock/date and added real, keyless homepage data sources: Open-Meteo current weather after explicit Android location consent, and locale-aware Google News RSS headlines.
- Added loading, empty, retry and error states for the feed panels. Weather coordinates are transient and are not written to DataStore.
- Added preferred translation-language persistence and Settings shortcuts to Downloads, app notification controls, and engine diagnostics.
- Version advanced to 2.3.0 / versionCode 17; CI APK artifact names updated.
- Re-ran Python source-contract checks and Node page-translation regression tests. A full Android Gradle build could not be run because Android SDK tooling is not installed in this environment.


## dhyra 2.4.0 — spider identity, style system and browser controls (2026-11-27)

- Replaced orbit branding with an original spider-inspired eight-legged emblem in Compose and Android vector launcher/splash artwork. Visible app label is lowercase `dhyra`.
- Added the ten-entry UI Style catalogue, persistent selection, live preview swatches, per-style palette/shape/type variants, color modes, reduced-motion and motion-intensity preferences. This is a shared theme system rather than ten independent UI implementations.
- Added eight persisted homepage layout presets. They reorder/enable/disable existing homepage sections; there is no freeform widget canvas, drag reorder or resizing yet.
- Replaced the one-off custom search option with a persisted provider catalogue supporting add/edit/delete/select, duplicate detection, HTTPS validation, `%s`/`{query}` templates and encoded search terms.
- Expanded homepage Google News RSS categories and added search, source attribution, publication timestamp and duplicate suppression. The RSS endpoint is unofficial and has no published SLA.
- Added download confirmation with source host, MIME/name, destination explanation and executable warning; existing Android DownloadManager still owns transfer mechanics and does not support app-controlled pause/resume. Private downloads are blocked.
- Added a transient origin banner for WebView fullscreen requests and wired motion preference into tab/screen transitions.
- Updated app version to 2.4.0 / versionCode 18 and synchronized CI artifact names.
- Static source contracts (45), JavaScript translation DOM/retry tests and Android XML parse checks pass. Full Android Gradle build, lint, APK assembly and device QA remain unverified because this environment has no Android SDK/Gradle installation and the source archive omits the wrapper JAR.


## dhyra 2.4.1 — D identity and tab motion refinement (2026-11-27)

- Replaced spider artwork with one geometric capital D in Compose, adaptive launcher, monochrome launcher and legacy launcher resources. The brand uses an obsidian surface and electric-violet accent.
- Standardized the Compose theme around the dhyra violet accent and neutral light/dark surfaces while retaining existing color-mode choices.
- Removed UI Styles, Homepage Layout, Reduce Motion, Animation Intensity and Disable Startup Animation from Settings. Existing homepage layout preference data is retained for compatibility; retired UI-style and motion preference keys are cleaned during app initialization.
- Changed the startup intro from first-run-only to a short D-only reveal after app initialization on every app launch.
- Improved tab close motion: card exit before removal, keyed lazy-grid appearance/removal/placement animations, swipe exit easing and a bounded stagger for Close All. BrowserController tab operations, close-all undo and private-tab confirmation are unchanged.
- Bumped app version to 2.4.1 / versionCode 19 and synchronized CI artifact file names.
- Static source checks and JavaScript/XML/workflow validation were run. A full Android Gradle build and device animation profiling still require the GitHub-hosted Android toolchain/device.


## dhyra 2.4.2 — focused UI/UX cleanup (2026-11-27)

- Removed UI Styles, Homepage Layout, Reduce Motion, Animation Intensity and Disable Startup Animation from Settings. Existing homepage layout storage is retained for backward compatibility; obsolete style/motion keys are deleted only when present.
- Replaced the dual-violet tonal split with the exact `#8067F0` accent shared by launcher assets and Compose light/dark/dynamic color schemes.
- Refined the D-only startup reveal and keyed tab-grid exit/placement transitions for single close and Close All. BrowserController tab operations were not changed.
- Updated package version to 2.4.2 / versionCode 20 and synchronized the CI artifact name.
- Static source checks pass (52/52), translation JavaScript smoke tests pass (2 suites), and all 17 Android XML resources parse. Android Gradle compilation, lint, APK assembly and device animation profiling remain unverified here because the Android SDK/Gradle distribution are unavailable.


## DHYRA 2.4.3 — address, privacy-label and release hardening (2026-11-27)

- Updated the omnibox resolver so `localhost`, `.localhost`, `.local`, IPv4 and bracketed IPv6 literals with optional ports are treated as addresses. Bare single-word input remains a search query. Added regression cases for malformed/oversized ports and local hostnames.
- Corrected Shields exception precedence. A matching `@@` exception now returns allow even when a block rule appears before or after it in the filter list.
- Reduced theme choices to `System` and `Dark`. Existing `Dynamic`/`Light` values normalize to `System`; legacy `AMOLED` normalizes to `Dark`.
- Changed private-session product labels to SPACE without changing stored tab/session identifiers; ensured Activity teardown requests one final profile cleanup for a live SPACE session.
- Added the uploaded DHYRA mark as a compact About-screen asset. Retained the geometric monogram for the launcher and small UI contexts.
- Added opt-in release signing. Manual GitHub Actions dispatch can sign APK/AAB using a runner-temporary keystore populated from four repository secrets, and now verifies signed outputs. No signing key or credential is included in source.
- Added architecture and SPACE privacy docs. The project still relies on Android System WebView and does not claim an independent custom HTML/CSS/JavaScript renderer.
- Verification: 55/55 source contracts; Node translation DOM and retry suites; 18 XML parses; YAML parse; Kotlin compilation plus focused runtime checks for address resolution and Shields. Full Gradle build/lint/APK/AAB and emulator/device validation remain pending hosted Android CI.


## DHYRA 2.4.4 — generated R resource qualification hotfix (2026-11-27)

- Fixed the About-screen artwork reference to use the fully-qualified generated Android resource class: `com.dhyra.browser.R.drawable.dhyra_brand_art`.
- Confirmed the referenced drawable-nodpi asset exists in the project.
- Incremented app version to 2.4.4 / versionCode 22 and synchronized current workflow artifact filenames.
- Full Android compilation remains pending execution by GitHub Actions.


## DHYRA Browser 2.4.5 — official logo integration (2026-11-27)

- Replaced the launcher placeholder monogram with the user-supplied 640×640 PNG artwork.
- Added Android adaptive-icon foreground artwork inside the 66dp safe zone and a matching pale background layer.
- Added legacy launcher PNG resources for mdpi, hdpi, xhdpi, xxhdpi and xxxhdpi devices, including round icon variants.
- Updated the Android 12+ splash icon to use the canonical high-resolution logo artwork on a matching light background in day and night resource sets.
- Replaced the homepage and startup-intro monogram with the same canonical PNG resource.
- Updated the About image to use fit scaling without cropping or rounded clipping.
- Synchronized the README brand image and incremented version to 2.4.5 / versionCode 23.
- Revalidated XML/resource references and CI workflow syntax; a full Android Gradle build remains pending GitHub Actions.


## DHYRA 2.4.5 — homepage, Settings and `space` privacy hardening (2026-11-27)

- Homepage: switched the in-app DHYRA mark to a transparent-background PNG asset; normal speed-dial items now rotate through the exact six requested flat foreground/background pairs at 54dp / 16dp radius, with 12sp secondary labels.
- Homepage: normalized `www.` hostnames and deduplicated Recently visited by domain before rendering it as a 12dp card with 0.5dp dividers. News sections disappear if no data is available after a failed fetch; weather uses a neutral availability message instead of raw error detail.
- Settings: replaced setting-row symbols with Material Icons Outlined at 20dp; grouped them into 12dp bordered surface cards with 24dp group spacing and thin internal dividers. The Download manager row has no selected/pressed fill; toggle and chevron accents use `#7F77DD`.
- Settings: while a `space` tab is active, the normal Download manager and Clear browsing data actions are hidden so regular download/history metadata is not reachable from that context.
- Labels: user-facing private-mode literals in Home, menu, tab overview and Settings use lowercase `space`. Internal Kotlin identifiers were deliberately left unchanged for compatibility.
- Release metadata: set `release.versionNameSuffix = ""`; the existing debug build retains `-debug`.
- Privacy: a new tab opened from the `space` menu inherits `space`. The tab overview does not render the normal tab group while `space` is selected and returns to normal after the final `space` tab closes. Recent Apps screenshots are disabled with `FLAG_SECURE` and, on API 33+, `setRecentsScreenshotEnabled(false)` while any `space` tab exists.
- Kept the existing AndroidX WebKit named-profile design. `WebView.setDataDirectorySuffix()` was not added because it selects the current process's WebView data directory and must be set before WebView initialization; it is not a per-WebView profile switch. Normal and `space` WebViews coexist in one process, so `ProfileStore`/`WebViewCompat.setProfile` is the appropriate separation API.
- Documented remaining limits in `docs/SPACE_PRIVACY.md`: the controller still stores both tab types in one tagged in-memory collection; `space` downloads are blocked rather than stored in a private temporary queue; and profile clearing uses the supported WebStorageCompat data-deletion API rather than deleting the provider's profile directory.
