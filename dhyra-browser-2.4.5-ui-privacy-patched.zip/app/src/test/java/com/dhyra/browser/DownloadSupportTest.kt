package com.dhyra.browser

import com.dhyra.browser.core.downloads.DownloadActions
import com.dhyra.browser.core.downloads.DownloadProgress
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadSupportTest {
    @Test
    fun progressIsBoundedAndHandlesUnknownSize() {
        val half = DownloadProgress(1, "file.zip", 50, 100, DownloadProgress.Status.RUNNING)
        assertEquals(50, half.progressPercent)
        assertEquals(0, DownloadProgress(2, "file", 10, 0, DownloadProgress.Status.RUNNING).progressPercent)
        assertEquals(100, DownloadProgress(3, "file", 500, 100, DownloadProgress.Status.COMPLETE).progressPercent)
    }

    @Test
    fun pauseResumeIsNotAdvertisedWithoutAnImplementedBackend() {
        assertFalse(DownloadActions.supportsPauseResume)
        assertFalse(DownloadActions.canPause(DownloadProgress.Status.RUNNING))
        assertFalse(DownloadActions.canPause(DownloadProgress.Status.COMPLETE))
        assertFalse(DownloadActions.canResume(DownloadProgress.Status.PAUSED))
        assertFalse(DownloadActions.canResume(DownloadProgress.Status.RUNNING))
    }

    @Test
    fun downloadFileNamesCannotEscapeDownloadsDirectory() {
        assertEquals("report.pdf", com.dhyra.browser.core.downloads.DownloadFileNames.safeLeafName("../../report.pdf"))
        assertEquals("report.pdf", com.dhyra.browser.core.downloads.DownloadFileNames.safeLeafName("C:\\temp\\report.pdf"))
        assertEquals("download", com.dhyra.browser.core.downloads.DownloadFileNames.safeLeafName("../../.."))
        assertTrue(com.dhyra.browser.core.downloads.DownloadFileNames.safeLeafName("a".repeat(250)).length <= 180)
    }
}
