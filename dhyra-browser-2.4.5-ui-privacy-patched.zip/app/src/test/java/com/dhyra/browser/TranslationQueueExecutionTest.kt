package com.dhyra.browser

import com.dhyra.browser.core.translation.TranslationBatch
import com.dhyra.browser.core.translation.TranslationQueue
import com.dhyra.browser.core.translation.TranslationTextItem
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TranslationQueueExecutionTest {
    private fun sampleBatch() = TranslationBatch(
        requestId = "request_1",
        batchId = "batch_1",
        sourceLanguage = "en",
        targetLanguage = "id",
        items = listOf(
            TranslationTextItem("segment_1", "node_1", "Hello world"),
            TranslationTextItem("segment_2", "node_2", "Good morning")
        )
    )

    @Test
    fun translatesBatchAndPreservesRequestIds() = runBlocking {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        val completed = CompletableDeferred<com.dhyra.browser.core.translation.TranslationBatchResult>()
        val queue = TranslationQueue(scope, { text, _, target -> "$target:$text" })
        try {
            assertTrue(queue.submit(sampleBatch()) { completed.complete(it) })
            val result = withTimeout(5_000) { completed.await() }
            assertEquals("request_1", result.requestId)
            assertEquals("batch_1", result.batchId)
            assertEquals("id:Hello world", result.translations["segment_1"])
            assertEquals("id:Good morning", result.translations["segment_2"])
            assertTrue(result.failedIds.isEmpty())
        } finally {
            queue.close()
            scope.cancel()
        }
    }

    @Test
    fun pausePreventsQueuedWorkUntilResume() = runBlocking {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        val completed = CompletableDeferred<com.dhyra.browser.core.translation.TranslationBatchResult>()
        val queue = TranslationQueue(scope, { text, _, _ -> text.uppercase() })
        try {
            queue.pause()
            assertTrue(queue.submit(sampleBatch()) { completed.complete(it) })
            kotlinx.coroutines.delay(120)
            assertFalse(completed.isCompleted)
            queue.resume()
            val result = withTimeout(5_000) { completed.await() }
            assertEquals("HELLO WORLD", result.translations["segment_1"])
        } finally {
            queue.close()
            scope.cancel()
        }
    }
}
