package com.dhyra.browser

import com.dhyra.browser.core.storage.DhyraBookmarkManager
import com.dhyra.browser.core.storage.DhyraHistoryManager
import org.junit.Test

/** Pure list-policy regression checks for the DataStore-backed history and bookmark stores. */
class SavedPagesManagerTest {
    fun runChecks() {
        val first = SavedPage("First", "https://example.com/first", 100L)
        val second = SavedPage("Second", "https://example.com/second", 200L)
        val refreshed = SavedPage("First updated", first.url, 300L)

        val history = DhyraHistoryManager.record(listOf(first), second)
        check(history == listOf(second, first)) { "new history visits should be first" }
        val replaced = DhyraHistoryManager.record(history, refreshed)
        check(replaced.size == 2 && replaced.first() == refreshed) { "a repeated URL should update, not duplicate, history" }
        check(DhyraHistoryManager.search(replaced, "UPDATED").single() == refreshed) { "history search should be case-insensitive" }
        check(DhyraHistoryManager.delete(replaced, second.url) == listOf(refreshed)) { "history delete should remove only the requested URL" }

        val bookmarks = DhyraBookmarkManager.add(listOf(first), second)
        check(bookmarks == listOf(second, first)) { "new bookmark should be first" }
        val edited = SavedPage("Renamed", "https://example.com/renamed", 400L)
        val updated = DhyraBookmarkManager.update(bookmarks, first.url, edited)
        check(updated.first() == edited && updated.none { it.url == first.url }) { "bookmark edit should replace the old URL" }
        check(DhyraBookmarkManager.delete(updated, edited.url) == listOf(second)) { "bookmark delete should preserve other entries" }
        check(DhyraBookmarkManager.add(bookmarks, SavedPage("Second revised", second.url, 500L)).size == 2) {
            "adding an existing bookmark URL should replace it rather than duplicate"
        }
        println("PASS: history and bookmark list-policy checks")
    }

    @Test
    fun junitSuite() = runChecks()
}
