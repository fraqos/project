package com.dhyra.browser

import com.dhyra.browser.core.tabs.SpaceSessionPolicy
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SpaceSessionPolicyTest {
    @Test
    fun privateTabIsNotPersistedAndUsesNoCachePolicy() {
        assertFalse(SpaceSessionPolicy.shouldPersistHistory(true))
        assertFalse(SpaceSessionPolicy.shouldPersistSession(true))
        assertFalse(SpaceSessionPolicy.shouldPersistBookmarks(true))
        assertTrue(SpaceSessionPolicy.cacheModeNoCache(true))
    }

    @Test
    fun privateModeRequiresBothProfileIsolationAndCompleteDataDeletion() {
        assertTrue(SpaceSessionPolicy.canStartIsolatedSession(true, true))
        assertFalse(SpaceSessionPolicy.canStartIsolatedSession(false, true))
        assertFalse(SpaceSessionPolicy.canStartIsolatedSession(true, false))
        assertFalse(SpaceSessionPolicy.canStartIsolatedSession(false, false))
    }

    @Test
    fun privateTabRequiresProfileCreationAndCompletedCleanup() {
        assertFalse(SpaceSessionPolicy.canStartIsolatedSession(true, true, profileCreated = false))
        assertFalse(SpaceSessionPolicy.canOpenSpaceTab(isolatedProfileAvailable = true, cleanupCompleted = false))
        assertTrue(SpaceSessionPolicy.canOpenSpaceTab(isolatedProfileAvailable = true, cleanupCompleted = true))
        assertFalse(SpaceSessionPolicy.canOpenSpaceTab(isolatedProfileAvailable = false, cleanupCompleted = true))
    }

    @Test
    fun persistentDownloadsAreDisallowedForPrivateTabs() {
        assertFalse(SpaceSessionPolicy.allowPersistentDownload(true))
        assertTrue(SpaceSessionPolicy.allowPersistentDownload(false))
    }

    @Test
    fun privateTabsCannotRequestPersistentDevicePermissions() {
        assertFalse(SpaceSessionPolicy.allowDevicePermissions(true))
        assertTrue(SpaceSessionPolicy.allowDevicePermissions(false))
    }

    @Test
    fun regularTabKeepsNormalPersistencePolicy() {
        assertTrue(SpaceSessionPolicy.shouldPersistHistory(false))
        assertTrue(SpaceSessionPolicy.shouldPersistSession(false))
        assertTrue(SpaceSessionPolicy.shouldPersistBookmarks(false))
        assertFalse(SpaceSessionPolicy.cacheModeNoCache(false))
    }
}
