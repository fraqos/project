package com.dhyra.browser

import com.dhyra.browser.core.network.WebViewModeManager
import org.junit.Assert.*
import org.junit.Test

class WebViewModeManagerTest {
    @Test fun desktopUserAgentPreservesRuntimeChromiumVersion() {
        val runtime = "Mozilla/5.0 (Linux; Android 15; Pixel; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/140.0.7339.0 Mobile Safari/537.36"
        val desktop = WebViewModeManager.desktopUserAgent(runtime)!!
        assertTrue(desktop.contains("X11; Linux x86_64"))
        assertTrue(desktop.contains("Chrome/140.0.7339.0"))
        assertFalse(desktop.contains("Android"))
        assertFalse(desktop.contains("Mobile"))
    }

    @Test fun desktopUserAgentDoesNotInventVersion() {
        assertNull(WebViewModeManager.desktopUserAgent("Mozilla/5.0 (Android)"))
    }

    @Test fun mobileUserAgentRemovesWebViewMarkersOnly() {
        val input = "Mozilla/5.0 (Linux; Android 15; wv) AppleWebKit/537.36 Version/4.0 Chrome/140.0.7339.0 Mobile Safari/537.36"
        val mobile = WebViewModeManager.mobileUserAgent(input)
        assertFalse(mobile.contains("; wv"))
        assertFalse(mobile.contains("Version/4.0"))
        assertTrue(mobile.contains("Android 15"))
        assertTrue(mobile.contains("Chrome/140.0.7339.0"))
        assertTrue(mobile.contains("Mobile"))
    }
}
