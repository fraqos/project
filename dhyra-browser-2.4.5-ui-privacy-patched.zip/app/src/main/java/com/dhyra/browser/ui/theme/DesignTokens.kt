package com.dhyra.browser.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/** Shared layout scale. Keep new UI aligned to this 4dp rhythm. */
internal object DhyraSpacing {
    val xxs = 4.dp
    val xs = 8.dp
    val sm = 12.dp
    val md = 16.dp
    val lg = 24.dp
    val xl = 32.dp
}

/** Motion timings in milliseconds; animations should remain short and non-blocking. */
internal object DhyraMotion {
    const val fast = 120
    const val standard = 180
    const val emphasized = 240
}
