package com.dhyra.browser.core.search

import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.util.Locale

/** A user-owned HTTPS search endpoint. The favicon is optional and never used as a trust signal. */
data class CustomSearchEngine(
    val name: String,
    val template: String,
    val faviconUrl: String = ""
)

/** Browser-owned search provider registry and URL policy. */
object SearchEngineManager {
    const val GOOGLE = "Google"
    const val CUSTOM = "Custom" // kept as a migration alias for older preferences

    val builtInEngines: List<String> = listOf(
        GOOGLE, "Bing", "DuckDuckGo", "Yahoo", "Ecosia", "Startpage", "Qwant", "Brave"
    )
    val engines: List<String> = builtInEngines + CUSTOM

    private val templates = mapOf(
        GOOGLE to "https://www.google.com/search?q=%s",
        "Bing" to "https://www.bing.com/search?q=%s",
        "DuckDuckGo" to "https://duckduckgo.com/?q=%s",
        "Yahoo" to "https://search.yahoo.com/search?p=%s",
        "Ecosia" to "https://www.ecosia.org/search?q=%s",
        "Startpage" to "https://www.startpage.com/sp/search?query=%s",
        "Qwant" to "https://www.qwant.com/?q=%s",
        "Brave" to "https://search.brave.com/search?q=%s"
    )

    fun availableEngines(custom: List<CustomSearchEngine>): List<String> =
        builtInEngines + custom.map { it.name } + CUSTOM

    fun searchUrl(engine: String, query: String, customTemplate: String? = null): String {
        val template = templates[engine] ?: validateCustomTemplate(customTemplate).getOrNull()
            ?: templates.getValue(GOOGLE)
        val encoded = URLEncoder.encode(query, Charsets.UTF_8.name())
        return template.replace("%s", encoded).replace("{query}", encoded)
    }

    /** Accepts the common %s form and the legacy {query} form, exactly once. */
    fun validateCustomTemplate(raw: String?): Result<String> = runCatching {
        val template = raw?.trim().orEmpty()
        require(template.length in 12..2_000) { "Enter a search URL between 12 and 2,000 characters." }
        val percentCount = template.windowed(2).count { it == "%s" }
        val braceCount = Regex("\\{query}").findAll(template).count()
        require(percentCount + braceCount == 1) { "Use exactly one %s or {query} placeholder." }
        val candidate = template.replace("%s", "dhyra-test-query").replace("{query}", "dhyra-test-query")
        val uri = URI(candidate)
        require(uri.scheme.equals("https", ignoreCase = true)) { "Custom search providers must use HTTPS." }
        require(!uri.host.isNullOrBlank()) { "Enter a valid HTTPS search URL." }
        require(uri.userInfo.isNullOrBlank()) { "Credentials are not allowed in a search URL." }
        require(uri.port == -1 || uri.port in 1..65535) { "Enter a valid server port." }
        template
    }.recoverCatching { error ->
        throw IllegalArgumentException(error.message ?: "Invalid search URL.")
    }

    fun validateName(raw: String?): Result<String> = runCatching {
        val name = raw?.trim().orEmpty()
        require(name.length in 2..32) { "Enter a name between 2 and 32 characters." }
        require(name.none { it.isISOControl() }) { "The name contains unsupported characters." }
        require(builtInEngines.none { it.equals(name, ignoreCase = true) } && !name.equals(CUSTOM, true)) {
            "That name is already reserved by a built-in search engine."
        }
        name
    }

    fun validateFavicon(raw: String?): Result<String> = runCatching {
        val value = raw?.trim().orEmpty()
        if (value.isBlank()) return@runCatching ""
        val uri = URI(value)
        require(uri.scheme.equals("https", true) && !uri.host.isNullOrBlank() && uri.userInfo.isNullOrBlank()) {
            "Favicon URL must be a valid HTTPS URL."
        }
        value
    }

    fun hasDuplicateName(name: String, custom: List<CustomSearchEngine>, exceptName: String? = null): Boolean =
        custom.any { it.name.equals(name, ignoreCase = true) && !it.name.equals(exceptName, ignoreCase = true) }

    fun encodeCustomEngines(items: List<CustomSearchEngine>): String {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().put("name", item.name).put("template", item.template).put("faviconUrl", item.faviconUrl))
        }
        return array.toString()
    }

    fun decodeCustomEngines(raw: String?): List<CustomSearchEngine> = runCatching {
        val array = JSONArray(raw.orEmpty().ifBlank { "[]" })
        val names = mutableSetOf<String>()
        buildList {
            for (index in 0 until array.length()) {
                val obj = array.optJSONObject(index) ?: continue
                val name = validateName(obj.optString("name")).getOrNull() ?: continue
                val template = validateCustomTemplate(obj.optString("template")).getOrNull() ?: continue
                val favicon = validateFavicon(obj.optString("faviconUrl")).getOrDefault("")
                if (names.add(name.lowercase(Locale.ROOT))) add(CustomSearchEngine(name, template, favicon))
            }
        }
    }.getOrDefault(emptyList())
}

/** Stable browser facade consumed by address resolution and settings. */
object DhyraSearchManager {
    val engines: List<String> get() = SearchEngineManager.engines
    fun resolve(engine: String, query: String, customTemplate: String? = null): String =
        SearchEngineManager.searchUrl(engine, query, customTemplate)
    fun validateCustomTemplate(raw: String?): Result<String> = SearchEngineManager.validateCustomTemplate(raw)
}
