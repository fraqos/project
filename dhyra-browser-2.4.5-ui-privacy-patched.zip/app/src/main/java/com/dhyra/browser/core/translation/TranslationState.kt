package com.dhyra.browser.core.translation

enum class TranslationPhase {
    IDLE,
    DOWNLOADING_MODEL,
    READY,
    TRANSLATING,
    PAUSED,
    COMPLETED,
    RESTORING,
    ERROR
}

data class TranslationState(
    val phase: TranslationPhase = TranslationPhase.IDLE,
    val sourceLanguage: String = "auto",
    val targetLanguage: String = "id",
    val translatedSegments: Int = 0,
    val failedSegments: Int = 0,
    val pendingBatches: Int = 0,
    /** True when resource limits intentionally skipped part of a very large page. */
    val contentLimited: Boolean = false,
    val message: String? = null
)

data class TranslationTextItem(
    val id: String,
    val nodeId: String,
    val text: String
)

data class TranslationBatch(
    val requestId: String,
    val batchId: String,
    val sourceLanguage: String,
    val targetLanguage: String,
    val items: List<TranslationTextItem>
)

data class TranslationBatchResult(
    val requestId: String,
    val batchId: String,
    val translations: Map<String, String>,
    val failedIds: Set<String> = emptySet(),
    val error: String? = null
)

sealed interface TranslationBridgeMessage {
    val sessionToken: String

    data class Batch(
        val value: TranslationBatch,
        override val sessionToken: String
    ) : TranslationBridgeMessage

    data class ScanComplete(
        override val sessionToken: String,
        val truncated: Boolean,
        val failedSegments: Int
    ) : TranslationBridgeMessage
}

/** A tiny language catalogue used by the browser's native translation picker. */
data class TranslationLanguage(val tag: String, val label: String) {
    companion object {
        val supported = listOf(
            TranslationLanguage("auto", "Detect language"),
            TranslationLanguage("id", "Indonesian"),
            TranslationLanguage("en", "English"),
            TranslationLanguage("es", "Spanish"),
            TranslationLanguage("fr", "French"),
            TranslationLanguage("de", "German"),
            TranslationLanguage("it", "Italian"),
            TranslationLanguage("pt", "Portuguese"),
            TranslationLanguage("ru", "Russian"),
            TranslationLanguage("ja", "Japanese"),
            TranslationLanguage("ko", "Korean"),
            TranslationLanguage("zh", "Chinese"),
            TranslationLanguage("ar", "Arabic"),
            TranslationLanguage("hi", "Hindi"),
            TranslationLanguage("nl", "Dutch"),
            TranslationLanguage("th", "Thai"),
            TranslationLanguage("tr", "Turkish"),
            TranslationLanguage("vi", "Vietnamese")
        )
    }
}
