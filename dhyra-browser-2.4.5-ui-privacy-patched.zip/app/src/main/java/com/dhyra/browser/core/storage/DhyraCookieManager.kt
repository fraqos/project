package com.dhyra.browser.core.storage

import android.webkit.CookieManager
import android.webkit.WebView

/** Explicit wrapper around the regular WebView cookie store; named SPACE profiles pass their own store. */
class DhyraCookieManager(private val cookies: CookieManager = CookieManager.getInstance()) {
    fun cookieHeader(url: String): String? = cookies.getCookie(url)

    fun configureThirdPartyCookies(view: WebView, enabled: Boolean) {
        cookies.setAcceptThirdPartyCookies(view, enabled)
    }

    fun clearAll(onComplete: () -> Unit = {}) {
        cookies.removeAllCookies {
            cookies.flush()
            onComplete()
        }
    }

    fun flush() = cookies.flush()
}
