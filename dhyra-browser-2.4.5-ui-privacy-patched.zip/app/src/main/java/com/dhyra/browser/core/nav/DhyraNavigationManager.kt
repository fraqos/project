package com.dhyra.browser.core.nav

/** Browser-owned navigation policy, separate from the WebView rendering backend. */
object DhyraNavigationManager {
    fun resolveAddress(input: String, searchEngine: String, customSearchTemplate: String? = null): String =
        BrowserAddressResolver.resolve(input, searchEngine, customSearchTemplate)

    fun isHttpUrl(value: String?): Boolean {
        if (value.isNullOrBlank()) return false
        return com.dhyra.browser.core.security.DhyraSecurityManager.isHttpUrl(value)
    }

    fun normalizeHomepage(value: String): String {
        return BrowserAddressResolver.normalizeHomepage(value)
    }
}
