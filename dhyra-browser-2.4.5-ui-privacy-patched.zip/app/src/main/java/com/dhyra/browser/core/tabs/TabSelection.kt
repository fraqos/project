package com.dhyra.browser.core.tabs

/** Backwards-compatible name for earlier tests; policy is owned by DhyraTabManager. */
object TabSelection {
    fun afterClose(
        order: List<Int>,
        closingId: Int,
        activeId: Int,
        parentOf: (Int) -> Int?
    ): Int? = DhyraTabManager.afterClose(order, closingId, activeId, parentOf)

    fun afterCloseAll(order: List<Int>, closedIds: Set<Int>, activeId: Int): Int? =
        DhyraTabManager.afterCloseAll(order, closedIds, activeId)
}
