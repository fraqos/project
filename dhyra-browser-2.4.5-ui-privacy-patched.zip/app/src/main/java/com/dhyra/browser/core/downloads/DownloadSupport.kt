package com.dhyra.browser.core.downloads

/** Immutable download presentation model shared by internal download screens. */
data class DownloadProgress(
    val id: Long,
    val fileName: String,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val status: Status
) {
    val progressPercent: Int
        get() = if (totalBytes <= 0L) 0 else
            ((downloadedBytes.coerceAtLeast(0).toDouble() / totalBytes.toDouble()) * 100.0)
                .toInt().coerceIn(0, 100)

    enum class Status { QUEUED, RUNNING, PAUSED, COMPLETE, FAILED }
}


/** Keeps untrusted URL/Content-Disposition filenames inside the Downloads directory. */
object DownloadFileNames {
    fun safeLeafName(suggestedName: String): String {
        val leaf = suggestedName.replace('\\', '/').substringAfterLast('/')
        val cleaned = buildString(leaf.length) {
            leaf.forEach { character ->
                if (!character.isISOControl() && character !in "\\/:*?\"<>|") append(character)
            }
        }.trim().trim('.')
        if (cleaned.isBlank() || cleaned == "." || cleaned == "..") return "download"
        return cleaned.take(180)
    }
}

/** Android DownloadManager integration currently exposes no app-controlled pause/resume action. */
object DownloadActions {
    const val supportsPauseResume: Boolean = false

    @Suppress("UNUSED_PARAMETER")
    fun canPause(status: DownloadProgress.Status): Boolean = false

    @Suppress("UNUSED_PARAMETER")
    fun canResume(status: DownloadProgress.Status): Boolean = false
}

/** Poll quickly only while the system download service reports active work. */
fun shouldPollDownloadStatus(statuses: Collection<String>): Boolean =
    statuses.any { it == "Pending" || it == "Downloading" }
