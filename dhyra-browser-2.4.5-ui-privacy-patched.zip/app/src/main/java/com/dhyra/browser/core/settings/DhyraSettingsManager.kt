package com.dhyra.browser.core.settings

import com.dhyra.browser.core.search.CustomSearchEngine
import com.dhyra.browser.core.search.SearchEngineManager

/** Central defaults and validation for user-facing dhyra preferences. */
object DhyraSettingsManager {
    const val DEFAULT_SEARCH_ENGINE = SearchEngineManager.GOOGLE
    const val DEFAULT_THEME = "System"
    const val DEFAULT_HOME_LAYOUT = "Custom Homepage"
    val supportedThemes = setOf("System", "Dark")
    val supportedHomeLayouts = setOf(
        "Minimal Homepage", "Editorial Homepage", "Bento Dashboard", "Glass Dashboard",
        "Productivity Dashboard", "News Dashboard", "Search-Centric Homepage", "Custom Homepage"
    )

    fun normalizeSearchEngine(value: String?, custom: List<CustomSearchEngine> = emptyList()): String =
        value?.takeIf { it in SearchEngineManager.builtInEngines || custom.any { engine -> engine.name == it } || it == SearchEngineManager.CUSTOM }
            ?: DEFAULT_SEARCH_ENGINE

    /**
     * Collapse obsolete palette choices to the two supported modes. Older installations
     * may still have Dynamic, Light or AMOLED persisted from previous builds.
     */
    fun normalizeTheme(value: String?): String = when (value) {
        "Dark", "AMOLED" -> "Dark"
        "System", "Dynamic", "Light", null -> DEFAULT_THEME
        else -> DEFAULT_THEME
    }
    fun normalizeHomeLayout(value: String?): String = value?.takeIf { it in supportedHomeLayouts } ?: DEFAULT_HOME_LAYOUT
}
