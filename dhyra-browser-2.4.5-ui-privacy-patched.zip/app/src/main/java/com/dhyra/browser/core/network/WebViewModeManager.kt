package com.dhyra.browser.core.network

import android.content.Context
import android.webkit.WebSettings
import android.webkit.WebView
import java.util.concurrent.ConcurrentHashMap

/** Rendering mode is a per-tab preference, not a process-wide WebView setting. */
enum class WebViewMode { MOBILE, DESKTOP }

/**
 * Applies Mobile/Desktop presentation to an existing WebView.
 *
 * Desktop mode uses a Linux X11 UA while retaining the Chromium version provided by the
 * installed Android System WebView. A UA only influences server-side layout selection; it
 * cannot guarantee that every site serves a desktop document or desktop-only functionality.
 */
class DhyraDesktopModeManager(context: Context) {
    private val appContext = context.applicationContext
    private val defaultUserAgent = WebSettings.getDefaultUserAgent(appContext)
    private val modes = ConcurrentHashMap<Int, WebViewMode>()

    fun registerTab(tabId: Int, initialMode: WebViewMode = WebViewMode.MOBILE) {
        modes.putIfAbsent(tabId, initialMode)
    }

    fun setMode(tabId: Int, mode: WebViewMode) {
        modes[tabId] = mode
    }

    fun applyCurrentMode(webView: WebView, tabId: Int): Boolean = restoreMode(tabId, webView)

    /** Returns false if the runtime UA does not expose a Chromium version to preserve. */
    fun enableDesktopMode(webView: WebView, tabId: Int): Boolean {
        val desktopAgent = desktopUserAgent(defaultUserAgent) ?: return false
        modes[tabId] = WebViewMode.DESKTOP
        apply(webView, WebViewMode.DESKTOP, desktopAgent)
        return true
    }

    fun enableMobileMode(webView: WebView, tabId: Int) {
        modes[tabId] = WebViewMode.MOBILE
        apply(webView, WebViewMode.MOBILE, mobileUserAgent(defaultUserAgent))
    }

    fun getCurrentMode(tabId: Int): WebViewMode = modes[tabId] ?: WebViewMode.MOBILE

    /** Re-applies a tab's saved mode after a WebView is recreated or restored from Bundle. */
    fun restoreMode(tabId: Int, webView: WebView): Boolean {
        val mode = getCurrentMode(tabId)
        if (mode == WebViewMode.DESKTOP) return enableDesktopMode(webView, tabId)
        enableMobileMode(webView, tabId)
        return true
    }

    /** Reads the saved tab mode without requiring a live WebView. */
    fun restoreMode(tabId: Int): WebViewMode = getCurrentMode(tabId)

    fun removeTab(tabId: Int) {
        modes.remove(tabId)
    }

    private fun apply(webView: WebView, mode: WebViewMode, userAgent: String) {
        webView.settings.apply {
            userAgentString = userAgent
            // Keep the site's own viewport meta tag. Wide viewport permits desktop layout
            // when the server selects it; overview mode scales the resulting wide page to fit.
            useWideViewPort = true
            loadWithOverviewMode = mode == WebViewMode.DESKTOP
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            textZoom = 100
        }
    }

    companion object {
        private val CHROME_TOKEN = Regex("Chrome/([0-9]+(?:\\.[0-9]+){1,3})")
        private val SPACES = Regex("\\s+")

        fun mobileUserAgent(defaultAgent: String): String = defaultAgent
            .replace("; wv", "")
            .replace(" Version/4.0", "")
            .replace(SPACES, " ")
            .trim()

        /**
         * Produces a desktop Linux UA without inventing or hard-coding a Chrome version.
         * Returns null if the WebView UA does not contain a Chromium version token.
         */
        fun desktopUserAgent(defaultAgent: String): String? {
            val chrome = CHROME_TOKEN.find(defaultAgent)?.value ?: return null
            return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) $chrome Safari/537.36"
        }
    }
}

/** Backwards-compatible name retained for existing controller and test call sites. */
typealias WebViewModeManager = DhyraDesktopModeManager
