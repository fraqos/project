package com.dhyra.browser.core.nav

import com.dhyra.browser.core.search.SearchEngineManager
import com.dhyra.browser.core.search.DhyraSearchManager
import com.dhyra.browser.core.security.DhyraSecurityManager
import java.net.URI

/** Resolves address-bar values into safe HTTP(S) navigation or a configured search URL. */
object BrowserAddressResolver {
    fun resolve(input: String, engine: String, customSearchTemplate: String? = null): String {
        val value = input.trim()
        if (value.isBlank()) return "https://www.google.com"

        if (value.startsWith("http://", ignoreCase = true) || value.startsWith("https://", ignoreCase = true)) {
            return if (DhyraSecurityManager.isHttpUrl(value)) value
            else DhyraSearchManager.resolve(SearchEngineManager.GOOGLE, value)
        }

        // Try host:port and local/IP forms before interpreting a colon as a URI scheme.
        val address = addressCandidate(value)
        if (address != null) return address

        if (SCHEME_PATTERN.matches(value)) {
            return DhyraSearchManager.resolve(SearchEngineManager.GOOGLE, value)
        }

        return DhyraSearchManager.resolve(engine, value, customSearchTemplate)
    }

    /** True when [resolve] would open the text as an address instead of searching for it. */
    fun looksLikeAddress(input: String): Boolean {
        val value = input.trim()
        if (value.isBlank()) return false
        if (value.startsWith("http://", ignoreCase = true) || value.startsWith("https://", ignoreCase = true)) {
            return DhyraSecurityManager.isHttpUrl(value)
        }
        return addressCandidate(value) != null
    }

    fun normalizeHomepage(input: String): String {
        val value = input.trim()
        if (value.isBlank()) return "https://www.google.com"
        val hasScheme = SCHEME_PATTERN.matches(value)
        if (hasScheme && !value.startsWith("http://", true) && !value.startsWith("https://", true)) {
            return "https://www.google.com"
        }
        val candidate = if (hasScheme) value else "https://$value"
        return if (DhyraNavigationManager.isHttpUrl(candidate)) candidate else "https://www.google.com"
    }

    /**
     * Accepts domain names, localhost aliases, IPv4 and bracketed IPv6 literals, optionally
     * including a port and path. A plain single word remains a search query.
     */
    private fun addressCandidate(value: String): String? {
        if (value.any(Char::isWhitespace)) return null
        val candidate = "https://$value"
        if (!DhyraSecurityManager.isHttpUrl(candidate)) return null

        val uri = runCatching { URI(candidate) }.getOrNull() ?: return null
        if (uri.port > MAX_PORT) return null
        val host = uri.host?.removePrefix("[")?.removeSuffix("]")?.trimEnd('.') ?: return null
        val normalizedHost = host.lowercase()
        val isLocalhost = normalizedHost == "localhost" ||
            normalizedHost.endsWith(".localhost") || normalizedHost.endsWith(".local")
        val isDomain = normalizedHost.contains('.') && normalizedHost.split('.').all(::isValidHostLabel)
        val isIpv4 = isIpv4Literal(normalizedHost)
        // URI validates bracketed IPv6 syntax; the character check prevents host-like text
        // from being accepted as an IP literal after removing the URI brackets.
        val isIpv6 = normalizedHost.count { it == ':' } >= 2 &&
            normalizedHost.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' || it == ':' || it == '.' }

        return candidate.takeIf { isLocalhost || isDomain || isIpv4 || isIpv6 }
    }

    private fun isValidHostLabel(label: String): Boolean =
        label.isNotEmpty() && label.length <= 63 &&
            label.first().isLetterOrDigit() && label.last().isLetterOrDigit() &&
            label.all { it.isLetterOrDigit() || it == '-' }

    private fun isIpv4Literal(host: String): Boolean {
        val octets = host.split('.')
        return octets.size == 4 && octets.all { part ->
            part.isNotEmpty() && part.length <= 3 && part.all(Char::isDigit) &&
                part.toIntOrNull()?.let { it in 0..255 } == true
        }
    }

    private val SCHEME_PATTERN = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:.*$", RegexOption.DOT_MATCHES_ALL)
    private const val MAX_PORT = 65_535
}
