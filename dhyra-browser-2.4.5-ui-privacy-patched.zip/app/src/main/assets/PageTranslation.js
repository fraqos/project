(function () {
  'use strict';
  if (window.__DhyraPageTranslation && window.__DhyraPageTranslation.version === 2) return;
  if (window.__DhyraPageTranslation && typeof window.__DhyraPageTranslation.destroyTranslationEngine === 'function') {
    try { window.__DhyraPageTranslation.destroyTranslationEngine(); } catch (_) { /* isolated legacy cleanup */ }
  }

  const SKIP_TAGS = new Set([
    'SCRIPT', 'STYLE', 'CODE', 'NOSCRIPT', 'TEXTAREA', 'PRE', 'SVG',
    'INPUT', 'SELECT', 'OPTION', 'BUTTON', 'KBD', 'SAMP', 'IFRAME', 'OBJECT', 'CANVAS'
  ]);
  const MAX_BATCH_CHARS = 2000;
  const MAX_ITEMS = 24;
  const MAX_SEGMENT_CHARS = 900;
  const MAX_IN_FLIGHT = 4;
  const WALK_LIMIT = 180;
  const MAX_QUEUED_SEGMENTS = 1200;
  const MAX_TRACKED_NODES = 8000;
  const MAX_ACTIVE_WALKERS = 64;
  const MAX_BATCH_RETRIES = 2;

  let active = false;
  let paused = false;
  let sourceLanguage = 'auto';
  let targetLanguage = 'id';
  let nextNodeId = 1;
  let nextSegmentId = 1;
  let nextRequestId = 1;
  let walkerQueue = [];
  let candidateQueue = [];
  let scanTimer = 0;
  let flushTimer = 0;
  let mutationTimer = 0;
  let observer = null;
  let scanCompleteSent = false;
  let navigationHooks = null;
  let lastBridgeSendAt = 0;
  let scrollHookInstalled = false;
  let sessionToken = '';
  let translationLimited = false;
  let failedSegments = 0;
  let trackedSincePrune = 0;
  let activeWalkerRoots = new WeakSet();
  const visibilityRange = document.createRange();

  let nodeState = new WeakMap();
  const nodeReferences = new Map();
  let selfModified = new WeakSet();
  const pendingRequests = new Map();
  let processedNodes = new WeakSet();

  function isContentEditable(element) {
    for (let current = element; current && current.nodeType === 1; current = current.parentElement) {
      if (current.isContentEditable || current.getAttribute('contenteditable') === 'true') return true;
      if (current.tagName === 'BODY') break;
    }
    return false;
  }

  function isIgnored(node) {
    const parent = node && node.parentElement;
    if (!parent || !node.nodeValue || !node.nodeValue.trim()) return true;
    if (isContentEditable(parent)) return true;
    for (let element = parent; element && element.nodeType === 1; element = element.parentElement) {
      if (SKIP_TAGS.has(element.tagName)) return true;
      if (element.getAttribute('aria-hidden') === 'true') return true;
      if (element.tagName === 'BODY') break;
    }
    return false;
  }

  function getVisibilityAndPriority(node) {
    const parent = node.parentElement;
    if (!parent) return -1;
    // Visibility is inherited through ancestor layout/compositing. Checking only the
    // immediate parent misses text hidden by an ancestor with display/opacity rules.
    for (let element = parent; element && element.nodeType === 1; element = element.parentElement) {
      const style = window.getComputedStyle(element);
      if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse') return -1;
      const opacity = Number.parseFloat(style.opacity);
      if (Number.isFinite(opacity) && opacity <= 0.01) return -1;
      if (element.tagName === 'BODY') break;
    }
    try {
      visibilityRange.selectNodeContents(node);
      const rect = visibilityRange.getBoundingClientRect();
      if (!rect || (rect.width <= 0 && rect.height <= 0)) return -1;
      const height = Math.max(window.innerHeight || 0, 1);
      if (rect.bottom >= 0 && rect.top <= height) return 0;
      if (rect.bottom >= -height * 1.5 && rect.top <= height * 2.5) return 1;
      return 2;
    } catch (_) {
      // A site may detach a node while the incremental walker is running.
      return -1;
    }
  }

  function splitAtWords(text, maxChars) {
    const parts = [];
    let start = 0;
    while (start < text.length) {
      let end = Math.min(start + maxChars, text.length);
      if (end < text.length) {
        const lastSpace = text.lastIndexOf(' ', end);
        const lastNewline = text.lastIndexOf('\n', end);
        const boundary = Math.max(lastSpace, lastNewline);
        if (boundary > start + Math.floor(maxChars * 0.55)) end = boundary;
      }
      if (end <= start) end = Math.min(start + maxChars, text.length);
      parts.push({ start: start, end: end, text: text.slice(start, end) });
      start = end;
    }
    return parts;
  }

  function pruneNodeReferences() {
    nodeReferences.forEach(function (reference, id) {
      const node = reference && typeof reference.deref === 'function' ? reference.deref() : null;
      // Keep detached-but-still-live nodes so restore can revert them if a SPA reattaches
      // them later. WeakRef does not retain the node; dead references are safe to prune.
      if (!node) nodeReferences.delete(id);
    });
  }

  function enqueueTextNode(node, priority) {
    if (isIgnored(node)) return;
    const raw = node.nodeValue || '';
    const leading = (raw.match(/^\s*/) || [''])[0].length;
    const trailing = (raw.match(/\s*$/) || [''])[0].length;
    const coreEnd = Math.max(leading, raw.length - trailing);
    const text = raw.slice(leading, coreEnd);
    if (!text.trim() || text.length < 2) return;

    const previous = nodeState.get(node);
    if (previous && (node.nodeValue === previous.originalText || node.nodeValue === previous.renderedText)) return;
    if (previous && node.nodeValue !== previous.originalText && node.nodeValue !== previous.renderedText) {
      // The website changed a translated node. Treat the new value as fresh source text;
      // never overwrite application/site mutations with an outdated original snapshot.
      nodeReferences.delete(previous.nodeId);
      nodeState.delete(node);
    }
    if (processedNodes.has(node)) return;
    // A strong-reference fallback would keep detached page nodes alive until restore.
    // Skip safely on engines without WeakRef rather than retaining arbitrary page nodes.
    if (typeof WeakRef !== 'function') {
      translationLimited = true;
      return;
    }
    trackedSincePrune++;
    if (trackedSincePrune >= 256 || nodeReferences.size >= MAX_TRACKED_NODES) {
      pruneNodeReferences();
      trackedSincePrune = 0;
    }
    if (nodeReferences.size >= MAX_TRACKED_NODES) {
      translationLimited = true;
      return;
    }

    const remainingQueueSlots = MAX_QUEUED_SEGMENTS - candidateQueue.length;
    if (remainingQueueSlots <= 0 || text.length > MAX_SEGMENT_CHARS * remainingQueueSlots) {
      translationLimited = true;
      return;
    }
    const segments = splitAtWords(text, MAX_SEGMENT_CHARS).map(part => ({
      id: 's' + (nextSegmentId++).toString(36),
      start: part.start + leading,
      end: part.end + leading,
      text: part.text,
      translated: null
    }));
    // Bound queued text before storing node references or marking the node processed.
    if (candidateQueue.length + segments.length > MAX_QUEUED_SEGMENTS) {
      translationLimited = true;
      return;
    }
    processedNodes.add(node);
    const nodeId = 'n' + (nextNodeId++).toString(36);
    scanCompleteSent = false;
    const state = {
      nodeId: nodeId,
      originalText: raw,
      renderedText: raw,
      segments: segments,
      leading: leading,
      trailing: trailing,
      status: 'queued'
    };
    nodeState.set(node, state);
    nodeReferences.set(nodeId, new WeakRef(node));

    segments.forEach(segment => {
      candidateQueue.push({
        priority: priority,
        sequence: nextSegmentId,
        retries: 0,
        item: { id: segment.id, nodeId: nodeId, text: segment.text }
      });
    });
    scheduleFlush(0);
  }

  function addWalker(root) {
    if (!root || (!root.ownerDocument && root !== document.body && root !== document.documentElement)) return;
    if (activeWalkerRoots.has(root)) return;
    if (walkerQueue.length >= MAX_ACTIVE_WALKERS) {
      translationLimited = true;
      return;
    }
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (node) {
        return isIgnored(node) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
      }
    });
    walkerQueue.push({ walker: walker, root: root });
    activeWalkerRoots.add(root);
    scanCompleteSent = false;
    scheduleScan(0);
  }

  function scanChunk() {
    if (!active || paused) return;
    let visited = 0;
    while (walkerQueue.length && visited < WALK_LIMIT) {
      if (candidateQueue.length >= MAX_QUEUED_SEGMENTS) {
        scheduleFlush(0);
        scheduleScan(180);
        return;
      }
      const entry = walkerQueue[0];
      let node = entry.walker.nextNode();
      if (!node) {
        activeWalkerRoots.delete(entry.root);
        walkerQueue.shift();
        continue;
      }
      visited++;
      if (!isIgnored(node)) {
        const priority = getVisibilityAndPriority(node);
        if (priority >= 0) enqueueTextNode(node, priority);
      }
    }
    if (walkerQueue.length) {
      scheduleScan(20);
    } else {
      maybeSendScanComplete();
    }
  }

  function scheduleScan(delay) {
    if (!active || paused || scanTimer) return;
    scanTimer = window.setTimeout(function () {
      scanTimer = 0;
      scanChunk();
    }, delay);
  }

  function scheduleFlush(delay) {
    if (!active || paused || flushTimer) return;
    flushTimer = window.setTimeout(function () {
      flushTimer = 0;
      flushBatches();
    }, delay);
  }

  function retryCandidates(candidates, previousRetries, delay) {
    const nextRetries = previousRetries + 1;
    if (active && nextRetries <= MAX_BATCH_RETRIES) {
      scanCompleteSent = false;
      candidateQueue.unshift.apply(candidateQueue, candidates.map(candidate => ({
        priority: candidate.priority,
        sequence: candidate.sequence,
        item: candidate.item,
        retries: nextRetries
      })));
      scheduleFlush(delay);
    } else {
      failedSegments += candidates.length;
      maybeSendScanComplete();
    }
  }

  function flushBatches() {
    if (!active || paused) return;
    let inFlight = pendingRequests.size;
    while (candidateQueue.length && inFlight < MAX_IN_FLIGHT) {
      const elapsed = Date.now() - lastBridgeSendAt;
      if (elapsed < 55) { scheduleFlush(55 - elapsed); return; }
      candidateQueue.sort(function (a, b) {
        return a.priority - b.priority || a.sequence - b.sequence;
      });
      const batchCandidates = [];
      const batchItems = [];
      let chars = 0;
      let batchRetries = 0;
      while (candidateQueue.length && batchItems.length < MAX_ITEMS) {
        const candidate = candidateQueue[0];
        const length = candidate.item.text.length;
        if (batchItems.length && chars + length > MAX_BATCH_CHARS) break;
        candidateQueue.shift();
        batchCandidates.push(candidate);
        batchItems.push(candidate.item);
        chars += length;
        batchRetries = Math.max(batchRetries, candidate.retries || 0);
      }
      if (!batchItems.length) break;
      const requestId = 'r' + (nextRequestId++).toString(36);
      const batchId = 'b' + nextRequestId.toString(36);
      const payload = {
        action: 'batch', requestId: requestId, batchId: batchId,
        sessionToken: sessionToken,
        sourceLanguage: sourceLanguage, targetLanguage: targetLanguage,
        items: batchItems
      };
      const bridge = window.DhyraTranslationBridge;
      if (!bridge || typeof bridge.postMessage !== 'function') {
        failedSegments += batchCandidates.length;
        maybeSendScanComplete();
        break;
      }
      const timer = window.setTimeout(function () {
        const pending = pendingRequests.get(requestId);
        if (!pending) return;
        pendingRequests.delete(requestId);
        retryCandidates(pending.candidates, pending.retries, 400 * (pending.retries + 1));
      }, 45000);
      pendingRequests.set(requestId, {
        items: batchItems, candidates: batchCandidates, timer: timer, retries: batchRetries
      });
      try {
        bridge.postMessage(JSON.stringify(payload));
        lastBridgeSendAt = Date.now();
        inFlight++;
      } catch (_) {
        window.clearTimeout(timer);
        pendingRequests.delete(requestId);
        retryCandidates(batchCandidates, batchRetries, 250 * (batchRetries + 1));
        break;
      }
    }
    maybeSendScanComplete();
    if (candidateQueue.length && pendingRequests.size < MAX_IN_FLIGHT) scheduleFlush(80);
  }

  function handleNativeMessage(event) {
    let response;
    try { response = JSON.parse(event.data); } catch (_) { return; }
    if (response.type === 'error') {
      // Only a correlated error may settle a batch. Unsolicited or malformed bridge
      // errors without a known request ID are ignored so page-originated noise cannot
      // cancel an unrelated in-flight translation request.
      const requestId = response.requestId;
      if (!requestId || !pendingRequests.has(requestId)) return;
      const pending = pendingRequests.get(requestId);
      window.clearTimeout(pending.timer);
      pendingRequests.delete(requestId);
      if (response.retryable === true) {
        retryCandidates(pending.candidates, pending.retries, 500 * (pending.retries + 1));
      } else {
        failedSegments += pending.items.length;
        maybeSendScanComplete();
      }
      return;
    }
    if (response.type !== 'batch_result') return;
    const pending = pendingRequests.get(response.requestId);
    if (!pending) return;
    window.clearTimeout(pending.timer);
    pendingRequests.delete(response.requestId);

    const translatedById = new Map();
    (response.translations || []).forEach(entry => translatedById.set(entry.id, entry.text));
    const failedIds = new Set(Array.isArray(response.failedIds) ? response.failedIds : []);
    failedSegments += failedIds.size;
    pending.items.forEach(item => {
      const ref = nodeReferences.get(item.nodeId);
      const node = ref && ref.deref ? ref.deref() : null;
      if (!node) return;
      const state = nodeState.get(node);
      if (!state || state.nodeId !== item.nodeId || node.nodeValue !== state.originalText) return;
      const segment = state.segments.find(part => part.id === item.id);
      if (!segment) return;
      const translated = translatedById.get(item.id);
      if (typeof translated === 'string' && translated.length) {
        segment.translated = translated;
        segment.failed = false;
      } else if (failedIds.has(item.id)) {
        // Keep a failed segment in its original language while allowing other segments
        // in the same long TextNode to render successfully.
        segment.failed = true;
      }
      const allSegmentsResolved = state.segments.every(part =>
        typeof part.translated === 'string' || part.failed === true
      );
      if (allSegmentsResolved) {
        let output = '';
        let cursor = 0;
        let anyTranslated = false;
        state.segments.forEach(part => {
          output += state.originalText.slice(cursor, part.start);
          if (typeof part.translated === 'string') {
            output += part.translated;
            anyTranslated = true;
          } else {
            output += state.originalText.slice(part.start, part.end);
          }
          cursor = part.end;
        });
        output += state.originalText.slice(cursor);
        state.renderedText = output;
        state.status = anyTranslated ? 'translated' : 'failed';
        if (anyTranslated && output !== state.originalText) {
          selfModified.add(node);
          node.nodeValue = output;
        }
      }
    });
    scheduleFlush(40);
    maybeSendScanComplete();
  }

  function maybeSendScanComplete() {
    if (!active || paused || walkerQueue.length || candidateQueue.length || pendingRequests.size || scanCompleteSent) return;
    scanCompleteSent = true;
    const bridge = window.DhyraTranslationBridge;
    if (bridge && typeof bridge.postMessage === 'function') {
      try {
        bridge.postMessage(JSON.stringify({
          action: 'scan_complete',
          sessionToken: sessionToken,
          truncated: translationLimited,
          failedSegments: failedSegments
        }));
      } catch (_) { /* ignored */ }
    }
  }

  function scanVisibleContent() {
    if (!active || paused) return;
    // Sample the viewport to prioritize newly visible subtrees without re-walking the full DOM.
    const xPoints = [0.25, 0.5, 0.75];
    const yPoints = [0.15, 0.5, 0.85];
    const roots = new Set();
    xPoints.forEach(x => yPoints.forEach(y => {
      const element = document.elementFromPoint(window.innerWidth * x, window.innerHeight * y);
      if (element) roots.add(element);
    }));
    roots.forEach(element => addWalker(element));
  }

  function scheduleMutationScan() {
    if (!active || paused || mutationTimer) return;
    mutationTimer = window.setTimeout(function () {
      mutationTimer = 0;
      scheduleFlush(80);
      scanVisibleContent();
    }, 180);
  }

  function onMutations(records) {
    if (!active) return;
    records.forEach(record => {
      if (record.type === 'characterData') {
        const node = record.target;
        if (selfModified.has(node)) {
          selfModified.delete(node);
          const translatedState = nodeState.get(node);
          // Ignore our own mutation only if the node still contains exactly the
          // value we rendered. If the website changed it before this observer turn,
          // treat the latest site-owned value as new source text.
          if (translatedState && node.nodeValue === translatedState.renderedText) return;
        }
        processedNodes.delete(node);
        const priority = getVisibilityAndPriority(node);
        if (priority >= 0) enqueueTextNode(node, priority);
      } else if (record.type === 'childList') {
        record.addedNodes.forEach(node => {
          if (node.nodeType === Node.TEXT_NODE) {
            processedNodes.delete(node);
            const priority = getVisibilityAndPriority(node);
            if (priority >= 0) enqueueTextNode(node, priority);
          } else if (node.nodeType === Node.ELEMENT_NODE) {
            addWalker(node);
          }
        });
      }
    });
    scheduleMutationScan();
  }

  function hookSpaNavigation() {
    const originalPush = history.pushState;
    const originalReplace = history.replaceState;
    const wrappedPush = function () {
      const result = originalPush.apply(this, arguments);
      scheduleMutationScan();
      return result;
    };
    const wrappedReplace = function () {
      const result = originalReplace.apply(this, arguments);
      scheduleMutationScan();
      return result;
    };
    history.pushState = wrappedPush;
    history.replaceState = wrappedReplace;
    const onRoute = function () { scheduleMutationScan(); };
    window.addEventListener('popstate', onRoute, true);
    window.addEventListener('hashchange', onRoute, true);
    navigationHooks = { originalPush, originalReplace, wrappedPush, wrappedReplace, onRoute };
  }

  function removeHooks() {
    if (observer) observer.disconnect();
    observer = null;
    if (scrollHookInstalled) {
      window.removeEventListener('scroll', scanVisibleContent, true);
      window.removeEventListener('resize', scanVisibleContent);
      scrollHookInstalled = false;
    }
    if (navigationHooks) {
      if (history.pushState === navigationHooks.wrappedPush) history.pushState = navigationHooks.originalPush;
      if (history.replaceState === navigationHooks.wrappedReplace) history.replaceState = navigationHooks.originalReplace;
      window.removeEventListener('popstate', navigationHooks.onRoute, true);
      window.removeEventListener('hashchange', navigationHooks.onRoute, true);
      navigationHooks = null;
    }
    if (scanTimer) window.clearTimeout(scanTimer);
    if (flushTimer) window.clearTimeout(flushTimer);
    if (mutationTimer) window.clearTimeout(mutationTimer);
    scanTimer = flushTimer = mutationTimer = 0;
    pendingRequests.forEach(item => window.clearTimeout(item.timer));
    pendingRequests.clear();
    walkerQueue = [];
    candidateQueue = [];
    activeWalkerRoots = new WeakSet();
  }

  function startTranslation(source, target, nativeSessionToken) {
    if (!target || target === 'auto') throw new Error('A target language must be selected.');
    if (typeof nativeSessionToken !== 'string' || !/^[a-fA-F0-9]{32}$/.test(nativeSessionToken)) {
      throw new Error('Invalid native translation session token.');
    }
    if (active && sourceLanguage === source && targetLanguage === target && sessionToken === nativeSessionToken) {
      resumeTranslation();
      return;
    }
    if (active) restoreOriginalText();
    active = true;
    paused = false;
    sourceLanguage = source || 'auto';
    targetLanguage = target;
    sessionToken = nativeSessionToken;
    translationLimited = false;
    failedSegments = 0;
    trackedSincePrune = 0;
    scanCompleteSent = false;
    lastBridgeSendAt = 0;
    nextNodeId = 1;
    nextSegmentId = 1;
    nextRequestId = 1;
    nodeReferences.clear();
    nodeState = new WeakMap();
    processedNodes = new WeakSet();
    selfModified = new WeakSet();
    activeWalkerRoots = new WeakSet();
    if (window.DhyraTranslationBridge && typeof window.DhyraTranslationBridge.addEventListener === 'function') {
      window.DhyraTranslationBridge.addEventListener('message', handleNativeMessage);
    } else if (window.DhyraTranslationBridge) {
      window.DhyraTranslationBridge.onmessage = handleNativeMessage;
    }
    hookSpaNavigation();
    observer = new MutationObserver(onMutations);
    if (document.body) observer.observe(document.body, { childList: true, characterData: true, subtree: true });
    addWalker(document.body || document.documentElement);
    window.addEventListener('scroll', scanVisibleContent, { passive: true, capture: true });
    window.addEventListener('resize', scanVisibleContent, { passive: true });
    scrollHookInstalled = true;
  }

  function pauseTranslation() {
    paused = true;
    if (scanTimer) window.clearTimeout(scanTimer);
    if (flushTimer) window.clearTimeout(flushTimer);
    scanTimer = flushTimer = 0;
  }

  function resumeTranslation() {
    if (!active) return;
    paused = false;
    scheduleScan(0);
    scheduleFlush(0);
    scanVisibleContent();
  }

  function restoreOriginalText() {
    active = false;
    paused = false;
    removeHooks();
    if (window.DhyraTranslationBridge && typeof window.DhyraTranslationBridge.removeEventListener === 'function') {
      window.DhyraTranslationBridge.removeEventListener('message', handleNativeMessage);
    } else if (window.DhyraTranslationBridge) {
      window.DhyraTranslationBridge.onmessage = null;
    }
    nodeReferences.forEach(ref => {
      const node = ref && ref.deref ? ref.deref() : null;
      if (!node) return;
      const state = nodeState.get(node);
      if (state && node.nodeValue === state.renderedText && state.status === 'translated') {
        selfModified.add(node);
        node.nodeValue = state.originalText;
      }
    });
    nodeReferences.clear();
    nodeState = new WeakMap();
    processedNodes = new WeakSet();
    selfModified = new WeakSet();
    activeWalkerRoots = new WeakSet();
    sessionToken = '';
    translationLimited = false;
    failedSegments = 0;
    trackedSincePrune = 0;
    scanCompleteSent = false;
    return true;
  }

  function destroyTranslationEngine() {
    restoreOriginalText();
    if (window.DhyraTranslationBridge && typeof window.DhyraTranslationBridge.removeEventListener === 'function') {
      window.DhyraTranslationBridge.removeEventListener('message', handleNativeMessage);
    } else if (window.DhyraTranslationBridge) {
      window.DhyraTranslationBridge.onmessage = null;
    }
  }

  function translateVisibleContent() {
    scanVisibleContent();
    scheduleScan(0);
    scheduleFlush(0);
  }

  window.__DhyraPageTranslation = Object.freeze({
    version: 2,
    startTranslation: startTranslation,
    pauseTranslation: pauseTranslation,
    resumeTranslation: resumeTranslation,
    restoreOriginalText: restoreOriginalText,
    translateVisibleContent: translateVisibleContent,
    destroyTranslationEngine: destroyTranslationEngine
  });
})();
