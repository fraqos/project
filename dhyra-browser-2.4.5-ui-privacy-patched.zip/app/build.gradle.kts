import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Release signing is opt-in and supplied only by CI secrets or local environment variables.
// No keystore or credential file is stored in the source repository.
val releaseSigningValues = mapOf(
    "storeFile" to (providers.gradleProperty("DHYRA_RELEASE_STORE_FILE").orElse(providers.environmentVariable("DHYRA_RELEASE_STORE_FILE")).orNull),
    "storePassword" to (providers.gradleProperty("DHYRA_RELEASE_STORE_PASSWORD").orElse(providers.environmentVariable("DHYRA_RELEASE_STORE_PASSWORD")).orNull),
    "keyAlias" to (providers.gradleProperty("DHYRA_RELEASE_KEY_ALIAS").orElse(providers.environmentVariable("DHYRA_RELEASE_KEY_ALIAS")).orNull),
    "keyPassword" to (providers.gradleProperty("DHYRA_RELEASE_KEY_PASSWORD").orElse(providers.environmentVariable("DHYRA_RELEASE_KEY_PASSWORD")).orNull)
)
val hasReleaseSigningValues = releaseSigningValues.values.any { !it.isNullOrBlank() }
val hasCompleteReleaseSigningValues = releaseSigningValues.values.all { !it.isNullOrBlank() }
if (hasReleaseSigningValues && !hasCompleteReleaseSigningValues) {
    throw GradleException(
        "Incomplete DHYRA release signing configuration. Set DHYRA_RELEASE_STORE_FILE, " +
            "DHYRA_RELEASE_STORE_PASSWORD, DHYRA_RELEASE_KEY_ALIAS and DHYRA_RELEASE_KEY_PASSWORD, " +
            "or leave all four unset to build an unsigned release."
    )
}

android {
    namespace = "com.dhyra.browser"
    compileSdk {
        version = release(37) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "com.dhyra.browser"
        minSdk = 26
        targetSdk = 36
        versionCode = 23
        versionName = "2.4.5"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    signingConfigs {
        if (hasCompleteReleaseSigningValues) {
            create("dhyraRelease") {
                storeFile = file(releaseSigningValues.getValue("storeFile")!!)
                storePassword = releaseSigningValues.getValue("storePassword")
                keyAlias = releaseSigningValues.getValue("keyAlias")
                keyPassword = releaseSigningValues.getValue("keyPassword")
            }
        }
    }

    buildTypes {
        debug {
            versionNameSuffix = "-debug"
        }
        release {
            // The About screen displays BuildConfig.VERSION_NAME; release must not inherit the debug suffix.
            versionNameSuffix = ""
            if (hasCompleteReleaseSigningValues) {
                signingConfig = signingConfigs.getByName("dhyraRelease")
            }
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }

    lint {
        abortOnError = true
        checkReleaseBuilds = true
    }
}

// Use the typed Kotlin compiler DSL for Kotlin Gradle Plugin 2.4.x.
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.11.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.19.0")
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.10.0")
    implementation("androidx.datastore:datastore-preferences:1.2.1")
    implementation("androidx.webkit:webkit:1.17.1")
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("com.google.zxing:core:3.5.3")
    testImplementation("junit:junit:4.13.2")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
