# DHYRA BROWSER 1.3.0

Android browser project using Jetpack Compose and Android System WebView (Chromium-based).

## Features in this source
- Browse HTTP and HTTPS pages with JavaScript and DOM storage enabled
- Search/address bar with Google, Bing, DuckDuckGo and Brave
- Multi-tab WebView instances with tab switcher
- Private-tab flag: private tabs are excluded from saved history and use no-cache mode
- Bookmark and browsing-history persistence through Preferences DataStore
- DownloadManager integration and downloads list/open/remove UI
- Web page file picker support for HTML file input
- WebRTC camera/microphone runtime permission bridge
- Geolocation runtime permission bridge for sites that request device location
- JavaScript popup handling with optional popup blocking
- HTML5 fullscreen custom-view support for video players
- Desktop-site user-agent preference
- Basic tracker-host blocking and third-party-cookie restriction
- Clear cache, cookies, WebStorage and history
- Light/Dark/System themes and configurable preferences
- Bitcoin support page with ZXing QR and wallet URI
- GitHub Actions workflow to build a debug APK

## Build
See `GITHUB_UPLOAD_GUIDE.md`. GitHub Actions uses JDK 17, Android SDK 35 and Gradle 8.7.

## Important browser-engine limits
This is not a fork of Chromium. It uses the Chromium-based Android System WebView installed and maintained by the Android device. The browser can load normal HTTP/HTTPS sites supported by that WebView, but no app can guarantee every site: DRM/Widevine requirements, browser fingerprint checks, unsupported APIs, CAPTCHA, geographic restrictions, login policies, and sites requiring their own native app may still prevent access. Incognito tabs in this baseline do not have fully isolated cookie profiles because Android WebView cookie storage is shared within the app process; do not treat them as equivalent to hardened private browsing.

Some site capabilities require users to grant Android runtime permissions. File uploads, camera/microphone WebRTC prompts, and geolocation prompts are handled through Android permission requests.

## Security notes
Certificate errors are cancelled rather than bypassed. Mixed content is blocked. Cleartext HTTP is enabled for sites that only serve HTTP, but such connections are not encrypted. Keep Android System WebView up to date.

## Premium mobile UI refresh
The Android-first interface has been refreshed with a restrained acrylic/glass visual language:
- A more spacious start page with a prominent search field and adaptive shortcut rows
- A translucent, highlighted address field with clearer secure-origin feedback
- A one-hand-friendly floating browser control bar
- An Android modal navigation drawer for primary browser destinations
- Redesigned tab cards with active-tab indication, private-tab identity and loading progress
- Harmonized light/dark palettes, rounded surfaces, spacing and system-bar appearance

The acrylic treatment uses translucent gradients, thin highlights and restrained shadows rather than continuous real-time backdrop blur. This keeps the interface lighter on mobile GPUs and avoids imposing a blur cost over the live WebView.

## Air Edition 1.4.0

This build adds the calm ambient UI layer, four persistent mood presets, a sparse New Tab page, a bottom floating address pill, edge-to-edge system bars, and an explicit-only navigation drawer. Browser tab state is exposed as immutable `BrowserSnapshot` values through `StateFlow`; WebView remains native and is not wrapped in a Compose scrolling container. See `AIR_EDITION_NOTES.md` for architecture and verification notes.
