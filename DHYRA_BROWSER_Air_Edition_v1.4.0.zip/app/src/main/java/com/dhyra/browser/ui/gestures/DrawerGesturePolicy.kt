package com.dhyra.browser.ui.gestures

/**
 * Drawer policy for touch surfaces. The drawer is opened by its explicit menu button only.
 * This deliberately avoids edge-drag interception so vertical WebView scrolling can never
 * be mistaken for a navigation gesture. ModalNavigationDrawer's scrim blocks the WebView
 * while the drawer is open.
 */
object DrawerGesturePolicy {
    const val GESTURES_ENABLED: Boolean = false
}
