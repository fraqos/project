package com.dhyra.browser.ui.theme

import androidx.compose.ui.graphics.Color

data class MoodPreset(
    val name: String,
    val shortName: String,
    val accent: Color,
    val canvasTop: Color,
    val canvasBottom: Color
) {
    companion object {
        val all = listOf(
            MoodPreset("Morning Mist", "Mist", Color(0xFF7797A8), Color(0xFFF3F7F8), Color(0xFFE5EEF0)),
            MoodPreset("Warm Sand", "Sand", Color(0xFFB58B69), Color(0xFFFAF4EC), Color(0xFFEFE3D5)),
            MoodPreset("Sage Calm", "Sage", Color(0xFF72927C), Color(0xFFF1F6F0), Color(0xFFE1EDE2)),
            MoodPreset("Midnight Air", "Night", Color(0xFF9A91D8), Color(0xFF111725), Color(0xFF1D2636))
        )
        fun fromName(name: String): MoodPreset = all.firstOrNull { it.name == name } ?: all.first()
    }
}
