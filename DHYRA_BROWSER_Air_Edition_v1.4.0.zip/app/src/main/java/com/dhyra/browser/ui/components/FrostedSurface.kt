package com.dhyra.browser.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Lightweight acrylic fallback: translucent layers and a fine highlight, no per-frame blur. */
@Composable
fun FrostedSurface(
    modifier: Modifier = Modifier,
    radius: Dp = 26.dp,
    dark: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    val fill = if (dark) listOf(Color(0xD91C2736), Color(0xCC17212F)) else listOf(Color(0xEFFFFFFF), Color(0xDDF5F7FA))
    Box(
        modifier.shadow(8.dp, shape, clip = false)
            .clip(shape)
            .background(Brush.verticalGradient(fill))
            .border(BorderStroke(1.dp, if (dark) Color.White.copy(.13f) else Color.White.copy(.88f)), shape),
        content = content
    )
}
