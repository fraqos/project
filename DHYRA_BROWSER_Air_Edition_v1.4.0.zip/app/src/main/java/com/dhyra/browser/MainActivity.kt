package com.dhyra.browser

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.graphicsLayer
import com.dhyra.browser.ui.gestures.DrawerGesturePolicy
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.DateFormat
import java.util.Date

private val Context.dhyraStore by preferencesDataStore(name = "dhyra_settings")
private val HOME_KEY = stringPreferencesKey("homepage")
private val ENGINE_KEY = stringPreferencesKey("search_engine")
private val THEME_KEY = stringPreferencesKey("theme")
private val MOOD_KEY = stringPreferencesKey("ambient_mood")
private val TRANSPARENCY_KEY = floatPreferencesKey("glass_transparency")
private val TRACKING_KEY = booleanPreferencesKey("tracking_protection")
private val POPUP_KEY = booleanPreferencesKey("popup_blocker")
private val DESKTOP_KEY = booleanPreferencesKey("desktop_mode")
private val HISTORY_KEY = stringPreferencesKey("history_json")
private val BOOKMARKS_KEY = stringPreferencesKey("bookmarks_json")
private const val BTC_ADDRESS = "bc1qrdlrhldck8pz6mtcaths86htz3g3hjyhsa44q5"

private val Accent = Color(0xFF6557D9)
private val AccentBright = Color(0xFF8175F2)
private val Cyan = Color(0xFF56C5CB)
private val Muted = Color(0xFF8290A6)
private val Ink = Color(0xFF172136)
private val LightCanvas = Color(0xFFF2F4FA)
private val DarkCanvas = Color(0xFF090E19)

private enum class Route { HOME, BROWSER, SETTINGS, TABS, BOOKMARKS, HISTORY, DOWNLOADS, SUPPORT, ABOUT }

private data class PreferencesState(
    val homepage: String = "https://www.google.com",
    val engine: String = "Google",
    val theme: String = "System",
    val transparency: Float = .78f,
    val tracking: Boolean = true,
    val popup: Boolean = true,
    val desktop: Boolean = false,
    val mood: String = "Morning Mist"
)

private data class SavedPage(val title: String, val url: String, val timestamp: Long = System.currentTimeMillis())
private data class Shortcut(val label: String, val url: String, val symbol: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
        }
        setContent { DhyraApplication() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DhyraApplication() {
    val context = LocalContext.current
    val activity = context as ComponentActivity
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    var pendingFileChooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        pendingFileChooser?.onReceiveValue(uris.toTypedArray())
        pendingFileChooser = null
    }

    var pendingPermission by remember { mutableStateOf<PermissionRequest?>(null) }
    var pendingGeo by remember { mutableStateOf<Pair<String, GeolocationPermissions.Callback>?>(null) }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val pending = pendingGeo
        if (pending != null) {
            val allowed = results.values.any { it }
            pending.second.invoke(pending.first, allowed, false)
        }
        pendingGeo = null
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val request = pendingPermission
        if (request != null) {
            val granted = results.values.all { it }
            if (granted) request.grant(request.resources) else request.deny()
        }
        pendingPermission = null
    }

    val controller = remember(activity) {
        BrowserController(
            activity = activity,
            onFileChooser = { callback ->
                pendingFileChooser?.onReceiveValue(null)
                pendingFileChooser = callback
                filePicker.launch(arrayOf("*/*"))
            },
            onPermission = { request ->
                val requested = mutableListOf<String>()
                if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) requested += android.Manifest.permission.CAMERA
                if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) requested += android.Manifest.permission.RECORD_AUDIO
                if (requested.isEmpty()) request.deny()
                else {
                    pendingPermission = request
                    permissionLauncher.launch(requested.distinct().toTypedArray())
                }
            },
            onGeolocation = { origin, callback ->
                val fineGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                val coarseGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (fineGranted || coarseGranted) {
                    callback.invoke(origin, true, false)
                } else {
                    pendingGeo = origin to callback
                    locationLauncher.launch(arrayOf(
                        android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION
                    ))
                }
            }
        )
    }

    val browserSnapshot by controller.snapshot.collectAsState()
    val prefs by context.dhyraStore.data.collectAsState(
        initial = androidx.datastore.preferences.core.emptyPreferences()
    )
    val state = PreferencesState(
        homepage = prefs[HOME_KEY] ?: "https://www.google.com",
        engine = prefs[ENGINE_KEY] ?: "Google",
        theme = prefs[THEME_KEY] ?: "System",
        transparency = prefs[TRANSPARENCY_KEY] ?: .78f,
        tracking = prefs[TRACKING_KEY] ?: true,
        popup = prefs[POPUP_KEY] ?: true,
        desktop = prefs[DESKTOP_KEY] ?: false,
        mood = prefs[MOOD_KEY] ?: "Morning Mist"
    )
    val historyRaw = prefs[HISTORY_KEY] ?: "[]"
    val bookmarksRaw = prefs[BOOKMARKS_KEY] ?: "[]"
    val history = remember(historyRaw) { decodeEntries(historyRaw) }
    val bookmarks = remember(bookmarksRaw) { decodeEntries(bookmarksRaw) }

    var route by remember { mutableStateOf(Route.HOME) }
    var address by remember { mutableStateOf("") }
    var findText by remember { mutableStateOf("") }
    var showFind by remember { mutableStateOf(false) }
    var showBrowserMenu by remember { mutableStateOf(false) }
    var refreshDownloads by remember { mutableIntStateOf(0) }

    val isDark = when {
        state.mood == "Midnight Air" -> true
        state.theme == "Dark" -> true
        state.theme == "Light" -> false
        else -> isSystemInDarkTheme()
    }
    val moodPalette = com.dhyra.browser.ui.theme.MoodPreset.fromName(state.mood)
    val moodAccent = moodPalette.accent
    val colorScheme = if (isDark) darkColorScheme(
        primary = moodAccent,
        secondary = Color(0xFF67D6D8),
        background = moodPalette.canvasTop,
        surface = moodPalette.canvasBottom.copy(alpha = .96f),
        surfaceVariant = Color(0xFF202D43),
        onSurface = Color(0xFFEAF0FF)
    ) else lightColorScheme(
        primary = moodAccent,
        secondary = Color(0xFF168FA5),
        background = moodPalette.canvasTop,
        surface = Color(0xFFFFFFFF).copy(alpha = .94f),
        surfaceVariant = Color(0xFFE8EDF7),
        onSurface = Ink
    )

    controller.onPageFinished = { tab ->
        if (!tab.isPrivate && (tab.url.startsWith("https://") || tab.url.startsWith("http://"))) {
            scope.launch {
                val currentRaw = context.dhyraStore.data.first()[HISTORY_KEY] ?: "[]"
                val current = decodeEntries(currentRaw)
                val updated = (listOf(SavedPage(tab.title, tab.url)) + current.filterNot { it.url == tab.url }).take(300)
                context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(updated) }
            }
        }
    }

    LaunchedEffect(controller) {
        if (browserSnapshot.tabs.isEmpty()) controller.createTab()
    }
    LaunchedEffect(state.tracking, state.popup, state.desktop) {
        controller.applySettings(state.tracking, state.popup, state.desktop)
    }
    DisposableEffect(controller) {
        onDispose {
            pendingFileChooser?.onReceiveValue(null)
            controller.destroy()
        }
    }

    fun saveValue(key: String, value: Any) {
        scope.launch {
            context.dhyraStore.edit { p ->
                when (value) {
                    is String -> p[stringPreferencesKey(key)] = value
                    is Float -> p[floatPreferencesKey(key)] = value
                    is Boolean -> p[booleanPreferencesKey(key)] = value
                }
            }
        }
    }

    fun openTarget(raw: String, newTab: Boolean = false, isPrivate: Boolean = false) {
        val target = resolveAddress(raw, state.engine)
        if (newTab || browserSnapshot.activeTabId == -1) controller.createTab(target, isPrivate)
        else controller.navigate(target)
        address = target
        route = Route.BROWSER
    }

    fun addBookmark() {
        val tab = controller.activeTab() ?: return
        if (!tab.url.startsWith("http")) return
        scope.launch {
            val latestRaw = context.dhyraStore.data.first()[BOOKMARKS_KEY] ?: "[]"
            val latest = decodeEntries(latestRaw).filterNot { it.url == tab.url }
            context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries((listOf(SavedPage(tab.title, tab.url)) + latest).take(500)) }
        }
    }

    BackHandler(enabled = controller.isFullscreen || route != Route.HOME || (route == Route.BROWSER && controller.activeWebView()?.canGoBack() == true)) {
        when {
            controller.isFullscreen -> controller.exitFullscreen()
            route == Route.BROWSER && controller.activeWebView()?.canGoBack() == true -> controller.goBack()
            route == Route.BROWSER -> route = Route.HOME
            else -> route = Route.HOME
        }
    }

    MaterialTheme(colorScheme = colorScheme, typography = Typography()) {
        SideEffect {
            activity.window.statusBarColor = android.graphics.Color.TRANSPARENT
            activity.window.navigationBarColor = android.graphics.Color.TRANSPARENT
            WindowInsetsControllerCompat(activity.window, activity.window.decorView).apply {
                isAppearanceLightStatusBars = !isDark
                isAppearanceLightNavigationBars = !isDark
            }
        }
        Surface(
            Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = DrawerGesturePolicy.GESTURES_ENABLED,
                scrimColor = Color.Black.copy(alpha = .38f),
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = if (isDark) Color(0xFF111A2A) else Color(0xFFF9FAFE)
                    ) {
                        DrawerHeader(dark = isDark)
                        Spacer(Modifier.height(12.dp))
                        DrawerNavigationItem("Home", Icons.Default.Home, route == Route.HOME) { route = Route.HOME; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("Browse", Icons.Default.Public, route == Route.BROWSER) { route = Route.BROWSER; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("Tabs", Icons.Default.Tab, route == Route.TABS, "${browserSnapshot.tabs.size}") { route = Route.TABS; scope.launch { drawerState.close() } }
                        HorizontalDivider(Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .6f))
                        DrawerNavigationItem("Bookmarks", Icons.Default.Bookmarks, route == Route.BOOKMARKS) { route = Route.BOOKMARKS; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("History", Icons.Default.History, route == Route.HISTORY) { route = Route.HISTORY; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("Downloads", Icons.Default.Download, route == Route.DOWNLOADS) { refreshDownloads++; route = Route.DOWNLOADS; scope.launch { drawerState.close() } }
                        HorizontalDivider(Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .6f))
                        DrawerNavigationItem("Settings", Icons.Default.Tune, route == Route.SETTINGS) { route = Route.SETTINGS; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("Support DHYRA", Icons.Default.Favorite, route == Route.SUPPORT) { route = Route.SUPPORT; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("About", Icons.Default.Info, route == Route.ABOUT) { route = Route.ABOUT; scope.launch { drawerState.close() } }
                        Spacer(Modifier.weight(1f))
                        Text("DHYRA BROWSER  •  1.4.0", modifier = Modifier.padding(horizontal = 24.dp, vertical = 22.dp), color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                    }
                }
            ) {
            when (route) {
                Route.HOME -> HomeScreen(
                    dark = isDark, mood = state.mood, onMood = { saveValue("ambient_mood", it) },
                    address = address, onAddressChange = { address = it },
                    onSearch = { openTarget(address) },
                    tabCount = browserSnapshot.tabs.size,
                    onMenu = { scope.launch { drawerState.open() } },
                    onOpenTabs = { route = Route.TABS },
                    onSettings = { route = Route.SETTINGS },
                    onBookmarks = { route = Route.BOOKMARKS },
                    onHistory = { route = Route.HISTORY },
                    onDownloads = { route = Route.DOWNLOADS },
                    onSupport = { route = Route.SUPPORT }
                )
                Route.BROWSER -> {
                    val active = controller.activeTab()
                    LaunchedEffect(active?.id, active?.url) {
                        active?.url?.takeIf { it != "about:blank" }?.let { address = it }
                    }
                    Column(Modifier.fillMaxSize()) {
                        CalmBrowserTopBar(
                            onMenu = { scope.launch { drawerState.open() } },
                            onMore = { showBrowserMenu = true },
                            loading = active?.loading == true,
                            progress = active?.progress ?: 0
                        )
                        if (showFind) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = findText, onValueChange = { findText = it; controller.activeWebView()?.findAllAsync(it) },
                                    modifier = Modifier.weight(1f), singleLine = true, label = { Text("Find in page") }
                                )
                                IconButton(onClick = { showFind = false; controller.activeWebView()?.clearMatches() }) { Icon(Icons.Default.Close, null) }
                            }
                        }
                        AndroidView(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            factory = { ctx -> android.widget.FrameLayout(ctx).apply { controller.attach(this) } },
                            update = { controller.attach(it) }
                        )
                        FloatingAddressPill(
                            address = address,
                            onAddress = { address = it },
                            onGo = { openTarget(address) },
                            onReload = { if (active?.loading == true) controller.stop() else controller.reload() },
                            secure = active?.url?.startsWith("https://") == true
                        )
                        BrowserBottomBar(
                            canBack = controller.activeWebView()?.canGoBack() == true,
                            canForward = controller.activeWebView()?.canGoForward() == true,
                            onBack = { controller.goBack() },
                            onForward = { controller.goForward() },
                            onHome = { route = Route.HOME },
                            onTabs = { route = Route.TABS },
                            onReload = { controller.reload() }
                        )
                        DropdownMenu(expanded = showBrowserMenu, onDismissRequest = { showBrowserMenu = false }) {
                            DropdownMenuItem(text = { Text("New tab") }, leadingIcon = { Icon(Icons.Default.Add, null) }, onClick = {
                                showBrowserMenu = false; controller.createTab(); route = Route.HOME
                            })
                            DropdownMenuItem(text = { Text("New private tab") }, leadingIcon = { Icon(Icons.Default.VisibilityOff, null) }, onClick = {
                                showBrowserMenu = false; controller.createTab(isPrivate = true); route = Route.HOME
                            })
                            DropdownMenuItem(text = { Text("Add bookmark") }, leadingIcon = { Icon(Icons.Default.BookmarkAdd, null) }, onClick = {
                                showBrowserMenu = false; addBookmark()
                            })
                            DropdownMenuItem(text = { Text("Bookmarks") }, leadingIcon = { Icon(Icons.Default.Bookmarks, null) }, onClick = {
                                showBrowserMenu = false; route = Route.BOOKMARKS
                            })
                            DropdownMenuItem(text = { Text("History") }, leadingIcon = { Icon(Icons.Default.History, null) }, onClick = {
                                showBrowserMenu = false; route = Route.HISTORY
                            })
                            DropdownMenuItem(text = { Text("Downloads") }, leadingIcon = { Icon(Icons.Default.Download, null) }, onClick = {
                                showBrowserMenu = false; refreshDownloads++; route = Route.DOWNLOADS
                            })
                            DropdownMenuItem(text = { Text("Find in page") }, leadingIcon = { Icon(Icons.Default.Search, null) }, onClick = {
                                showBrowserMenu = false; showFind = true
                            })
                            DropdownMenuItem(text = { Text("Share page") }, leadingIcon = { Icon(Icons.Default.Share, null) }, onClick = {
                                showBrowserMenu = false
                                val share = Intent(Intent.ACTION_SEND).setType("text/plain")
                                    .putExtra(Intent.EXTRA_TEXT, controller.activeTab()?.url ?: "")
                                context.startActivity(Intent.createChooser(share, "Share page"))
                            })
                            DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(Icons.Default.Settings, null) }, onClick = {
                                showBrowserMenu = false; route = Route.SETTINGS
                            })
                        }
                    }
                }
                Route.TABS -> TabsScreen(controller, tabs = browserSnapshot.tabs, activeTabId = browserSnapshot.activeTabId, dark = isDark, onBack = { route = Route.HOME }, onOpen = { route = Route.BROWSER }, onNew = {
                    controller.createTab(); route = Route.HOME
                })
                Route.SETTINGS -> SettingsScreen(state, onBack = { route = Route.HOME }, onSave = ::saveValue, onClear = {
                    controller.clearRegularData()
                    scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                })
                Route.BOOKMARKS -> EntriesScreen("Bookmarks", bookmarks, onBack = { route = Route.HOME }, onOpen = {
                    openTarget(it, newTab = true)
                }, onDelete = { url ->
                    scope.launch {
                        val remaining = bookmarks.filterNot { it.url == url }
                        context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries(remaining) }
                    }
                })
                Route.HISTORY -> EntriesScreen("History", history, onBack = { route = Route.HOME }, onOpen = {
                    openTarget(it, newTab = true)
                }, onDelete = { url ->
                    scope.launch {
                        val remaining = history.filterNot { it.url == url }
                        context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(remaining) }
                    }
                }, onClearAll = {
                    scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                })
                Route.DOWNLOADS -> DownloadsScreen(onBack = { route = Route.HOME }, refreshKey = refreshDownloads)
                Route.SUPPORT -> SupportScreen(onBack = { route = Route.HOME })
                Route.ABOUT -> AboutScreen(onBack = { route = Route.HOME })
            }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    dark: Boolean, mood: String, onMood: (String) -> Unit,
    address: String, onAddressChange: (String) -> Unit,
    onSearch: () -> Unit,
    tabCount: Int, onMenu: () -> Unit, onOpenTabs: () -> Unit, onSettings: () -> Unit,
    onBookmarks: () -> Unit, onHistory: () -> Unit, onDownloads: () -> Unit,
    onSupport: () -> Unit
) {
    val keyboard = LocalSoftwareKeyboardController.current
    val presets = com.dhyra.browser.ui.theme.MoodPreset.all
    val palette = com.dhyra.browser.ui.theme.MoodPreset.fromName(mood)
    val animatedTop by animateColorAsState(palette.canvasTop, label = "ambientCanvasTop")
    val animatedBottom by animateColorAsState(palette.canvasBottom, label = "ambientCanvasBottom")
    val animatedAccent by animateColorAsState(palette.accent, label = "ambientAccent")
    val shape = RoundedCornerShape(30.dp)
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(animatedTop, animatedBottom)))) {
        Box(Modifier.align(Alignment.TopEnd).padding(top = 95.dp, end = 6.dp).size(240.dp).clip(CircleShape)
            .background(Brush.radialGradient(listOf(animatedAccent.copy(alpha = .10f), Color.Transparent))))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 52.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onMenu, modifier = Modifier.size(44.dp)) { Icon(Icons.Default.Menu, "Open navigation") }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("DHYRA", fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.8.sp)
                    Text("BROWSER  /  AIR EDITION", fontSize = 8.sp, color = Muted, letterSpacing = 1.6.sp)
                }
                IconButton(onClick = onOpenTabs) { BadgedBox(badge = { if (tabCount > 0) Badge { Text(tabCount.toString()) } }) { Icon(Icons.Default.Tab, "Open tabs") } }
                IconButton(onClick = onSettings) { Icon(Icons.Default.Tune, "Settings") }
            }
            Spacer(Modifier.height(14.dp))
            Text("A little more\nroom to breathe.", fontSize = 37.sp, lineHeight = 43.sp, letterSpacing = (-1.5).sp,
                fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(12.dp))
            Text("The internet, at your pace.", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(34.dp))
            Surface(shape = shape, color = MaterialTheme.colorScheme.surface.copy(alpha = .76f), tonalElevation = 0.dp,
                shadowElevation = 10.dp, border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = if (dark) .14f else .8f)), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 17.dp, end = 8.dp, top = 7.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, null, tint = animatedAccent)
                    Spacer(Modifier.width(12.dp))
                    OutlinedTextField(value = address, onValueChange = onAddressChange, modifier = Modifier.weight(1f),
                        placeholder = { Text("Search the web or enter address", color = Muted, fontSize = 12.sp) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { keyboard?.hide(); onSearch() }),
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent, focusedContainerColor = Color.Transparent, cursorColor = palette.accent))
                    IconButton(onClick = { keyboard?.hide(); onSearch() }, modifier = Modifier.size(44.dp).clip(CircleShape).background(animatedAccent)) {
                        Icon(Icons.Default.ArrowForward, "Search", tint = Color.White)
                    }
                }
            }
            Spacer(Modifier.height(42.dp))
            Text("YOUR AMBIENCE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { preset ->
                    val selected = preset.name == mood
                    Surface(onClick = { onMood(preset.name) }, shape = RoundedCornerShape(18.dp),
                        color = if (selected) preset.accent.copy(alpha = .15f) else MaterialTheme.colorScheme.surface.copy(alpha = .58f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) preset.accent.copy(alpha = .48f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = .32f)),
                        modifier = Modifier.weight(1f)) {
                        Column(Modifier.padding(vertical = 12.dp, horizontal = 3.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(23.dp).clip(CircleShape).background(Brush.linearGradient(listOf(preset.canvasTop, preset.accent))))
                            Spacer(Modifier.height(7.dp))
                            Text(preset.shortName, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(42.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("A QUIETER START", color = Muted, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(5.dp))
                    Text("Pick up where you left off.", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
                TextButton(onClick = onOpenTabs) { Text("${tabCount} tabs") }
            }
            Spacer(Modifier.height(15.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AirAction(Icons.Default.Bookmarks, "Saved", onBookmarks, Modifier.weight(1f))
                AirAction(Icons.Default.History, "History", onHistory, Modifier.weight(1f))
                AirAction(Icons.Default.Download, "Downloads", onDownloads, Modifier.weight(1f))
            }
            Spacer(Modifier.height(28.dp))
            Surface(onClick = onSupport, shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .55f), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FavoriteBorder, null, tint = palette.accent)
                    Spacer(Modifier.width(12.dp)); Text("Support independent browsing", Modifier.weight(1f), fontSize = 12.sp)
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
            Spacer(Modifier.height(25.dp))
            Text("LESS NOISE. MORE SPACE.", Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = Muted.copy(alpha = .75f), fontSize = 9.sp, letterSpacing = 1.8.sp)
            Spacer(Modifier.height(25.dp))
        }
    }
}

@Composable
private fun AirAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(19.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .65f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .35f))) {
        Column(Modifier.padding(vertical = 17.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(20.dp)); Spacer(Modifier.height(8.dp)); Text(label, fontSize = 11.sp)
        }
    }
}

@Composable
private fun GlassPanel(
    dark: Boolean,
    alpha: Float = .86f,
    radius: Shape = RoundedCornerShape(20.dp),
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val top = if (dark) Color(0xFF24334B).copy(alpha = alpha) else Color.White.copy(alpha = alpha)
    val bottom = if (dark) Color(0xFF172338).copy(alpha = alpha * .96f) else Color(0xFFF7F9FF).copy(alpha = alpha * .96f)
    Box(
        modifier.shadow(7.dp, radius, clip = false)
            .clip(radius)
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .border(1.dp, if (dark) Color.White.copy(alpha = .12f) else Color.White.copy(alpha = .9f), radius)
    ) {
        Box(
            Modifier.fillMaxWidth().height(1.dp).align(Alignment.TopCenter)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = if (dark) .18f else .72f), Color.Transparent)))
        )
        content()
    }
}

@Composable
private fun DrawerHeader(dark: Boolean) {
    Column(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = 22.dp, end = 18.dp, top = 18.dp, bottom = 20.dp)
    ) {
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Accent, AccentBright, Cyan))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Public, null, tint = Color.White, modifier = Modifier.size(27.dp)) }
        Spacer(Modifier.height(14.dp))
        Text("DHYRA", fontWeight = FontWeight.ExtraBold, fontSize = 21.sp, letterSpacing = 2.4.sp)
        Text("A calmer way to explore.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun DrawerNavigationItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    trailing: String? = null,
    onClick: () -> Unit
) {
    NavigationDrawerItem(
        label = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, modifier = Modifier.weight(1f), fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, fontSize = 14.sp)
                if (trailing != null) Text(trailing, color = Muted, fontSize = 11.sp)
            }
        },
        icon = { Icon(icon, null, modifier = Modifier.size(20.dp)) },
        selected = selected,
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
        shape = RoundedCornerShape(14.dp),
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = Accent.copy(alpha = .13f),
            selectedIconColor = Accent,
            selectedTextColor = Accent,
            unselectedIconColor = Muted,
            unselectedTextColor = MaterialTheme.colorScheme.onSurface
        )
    )
}

@Composable
private fun QuickAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    onClick: () -> Unit,
    modifier: Modifier,
    dark: Boolean
) {
    GlassPanel(
        dark = dark, alpha = .88f, radius = RoundedCornerShape(16.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(19.dp))
            Spacer(Modifier.height(5.dp))
            Text(text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun CalmBrowserTopBar(onMenu: () -> Unit, onMore: () -> Unit, loading: Boolean, progress: Int) {
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background.copy(alpha = .72f))) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "Navigation") }
            Column(Modifier.weight(1f)) {
                Text("DHYRA AIR", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Stay in your flow", fontSize = 9.sp, color = Muted)
            }
            IconButton(onClick = onMore) { Icon(Icons.Default.MoreHoriz, "More actions") }
        }
        if (loading) LinearProgressIndicator(progress = { progress.coerceIn(0, 100) / 100f }, modifier = Modifier.fillMaxWidth().height(2.dp), color = Accent, trackColor = Color.Transparent)
    }
}

@Composable
private fun FloatingAddressPill(address: String, onAddress: (String) -> Unit, onGo: () -> Unit, onReload: () -> Unit, secure: Boolean) {
    val keyboard = LocalSoftwareKeyboardController.current
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val shape = RoundedCornerShape(28.dp)
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 17.dp, vertical = 8.dp).shadow(if (focused) 12.dp else 7.dp, shape),
        shape = shape, color = MaterialTheme.colorScheme.surface.copy(alpha = .93f),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (focused) Accent.copy(alpha = .38f) else Color.White.copy(alpha = .76f))
    ) {
        Row(Modifier.padding(start = 13.dp, end = 6.dp, top = 5.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (secure) Icons.Default.Lock else Icons.Default.Language, null, tint = if (secure) Color(0xFF4E9A79) else Muted, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(9.dp))
            OutlinedTextField(value = if (focused) address else cleanDomain(address), onValueChange = onAddress, modifier = Modifier.weight(1f), singleLine = true,
                placeholder = { Text("Search or enter address", fontSize = 12.sp) }, textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { keyboard?.hide(); onGo() }),
                interactionSource = interaction, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent, focusedContainerColor = Color.Transparent, cursorColor = Accent))
            IconButton(onClick = { keyboard?.hide(); onReload() }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Refresh, "Reload", tint = Accent) }
            IconButton(onClick = { keyboard?.hide(); onGo() }, modifier = Modifier.size(38.dp).clip(CircleShape).background(Accent)) { Icon(Icons.Default.ArrowForward, "Go", tint = Color.White, modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
private fun BrowserToolbar(
    address: String, onAddress: (String) -> Unit, onGo: () -> Unit,
    onHome: () -> Unit, onMenu: () -> Unit, loading: Boolean, progress: Int
) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val addressElevation by animateDpAsState(
        targetValue = if (focused) 9.dp else 4.dp,
        label = "addressBarElevation"
    )
    val addressHighlight by animateFloatAsState(
        targetValue = if (focused) .48f else .20f,
        label = "addressBarHighlight"
    )
    Column(
        Modifier.fillMaxWidth().background(
            Brush.verticalGradient(
                listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.background.copy(alpha = .94f))
            )
        )
    ) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onHome, modifier = Modifier.size(43.dp)) {
                Icon(Icons.Default.Menu, "Open navigation", tint = MaterialTheme.colorScheme.onSurface)
            }
            Spacer(Modifier.width(3.dp))
            val shape = RoundedCornerShape(20.dp)
            Box(
                Modifier.weight(1f).shadow(addressElevation, shape)
                    .clip(shape)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                MaterialTheme.colorScheme.surface.copy(alpha = if (focused) .98f else .91f),
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = if (focused) .72f else .66f)
                            )
                        )
                    )
                    .border(1.dp, Accent.copy(alpha = addressHighlight), shape)
            ) {
                Row(Modifier.padding(start = 11.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(29.dp).clip(RoundedCornerShape(10.dp))
                            .background(if (address.startsWith("https://")) Color(0xFF28A875).copy(alpha = .13f) else Accent.copy(alpha = .10f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (address.startsWith("https://")) Icons.Default.Lock else Icons.Default.Language,
                            null,
                            tint = if (address.startsWith("https://")) Color(0xFF24996B) else Accent,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Spacer(Modifier.width(7.dp))
                    OutlinedTextField(
                        value = address,
                        onValueChange = onAddress,
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        placeholder = { Text("Search or URL", fontSize = 12.sp, color = Muted) },
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { onGo() }),
                        interactionSource = interaction,
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent, focusedContainerColor = Color.Transparent,
                            cursorColor = Accent
                        )
                    )
                    IconButton(onClick = onGo, modifier = Modifier.size(38.dp)) {
                        Icon(Icons.Default.ArrowForward, "Go", tint = Accent, modifier = Modifier.size(20.dp))
                    }
                }
            }
            IconButton(onClick = onMenu, modifier = Modifier.size(43.dp)) {
                Icon(Icons.Default.MoreHoriz, "Browser menu", tint = MaterialTheme.colorScheme.onSurface)
            }
        }
        if (loading) {
            LinearProgressIndicator(
                progress = { (progress.coerceIn(0, 100) / 100f) },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = Accent, trackColor = Color.Transparent
            )
        } else {
            Spacer(Modifier.height(2.dp))
        }
    }
}

@Composable
private fun BrowserBottomBar(
    canBack: Boolean, canForward: Boolean, onBack: () -> Unit, onForward: () -> Unit,
    onHome: () -> Unit, onTabs: () -> Unit, onReload: () -> Unit
) {
    Box(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background.copy(alpha = .92f))
            .navigationBarsPadding().padding(start = 17.dp, end = 17.dp, top = 7.dp, bottom = 7.dp)
    ) {
        Surface(
            Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = .94f),
            shadowElevation = 9.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f))
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 5.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, enabled = canBack) { Icon(Icons.Default.ArrowBack, "Back") }
                IconButton(onClick = onForward, enabled = canForward) { Icon(Icons.Default.ArrowForward, "Forward") }
                IconButton(onClick = onHome) {
                    Box(Modifier.size(37.dp).clip(RoundedCornerShape(13.dp)).background(Accent.copy(alpha = .11f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Home, "Home", tint = Accent, modifier = Modifier.size(20.dp))
                    }
                }
                IconButton(onClick = onReload) { Icon(Icons.Default.Refresh, "Reload") }
                IconButton(onClick = onTabs) { Icon(Icons.Default.Tab, "Tabs") }
            }
        }
    }
}

@Composable
private fun TabsScreen(controller: BrowserController, tabs: List<BrowserTab>, activeTabId: Int, dark: Boolean, onBack: () -> Unit, onOpen: () -> Unit, onNew: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .48f)))
        ).statusBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 10.dp, end = 12.dp, top = 9.dp, bottom = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text("Your tabs", fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.5).sp)
                Text("${browserSnapshot.tabs.size} open ${if (browserSnapshot.tabs.size == 1) "tab" else "tabs"}", color = Muted, fontSize = 11.sp)
            }
            Button(onClick = onNew, shape = RoundedCornerShape(15.dp), contentPadding = PaddingValues(horizontal = 15.dp, vertical = 10.dp)) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("New tab")
            }
        }
        if (browserSnapshot.tabs.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No open tabs", color = Muted) }
        } else LazyColumn(
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(tabs, key = { it.id }) { tab ->
                val active = tab.id == activeTabId
                Surface(
                    modifier = Modifier.fillMaxWidth().clickable { controller.selectTab(tab.id); onOpen() },
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = if (active) 5.dp else 1.dp,
                    border = androidx.compose.foundation.BorderStroke(
                        if (active) 1.4.dp else 1.dp,
                        if (active) Accent.copy(alpha = .58f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f)
                    )
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Box(
                            Modifier.fillMaxWidth().height(92.dp).clip(RoundedCornerShape(15.dp))
                                .background(
                                    Brush.linearGradient(
                                        if (dark) listOf(Color(0xFF202C43), Color(0xFF17243A), Color(0xFF25314B))
                                        else listOf(Color(0xFFE6EAF7), Color(0xFFF3F4FB), Color(0xFFDCE7F4))
                                    )
                                )
                        ) {
                            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(if (tab.isPrivate) Icons.Default.VisibilityOff else Icons.Default.Language, null, tint = Accent, modifier = Modifier.size(25.dp))
                                Spacer(Modifier.height(5.dp))
                                Text(if (tab.isPrivate) "Private browsing" else "DHYRA tab preview", color = Muted, fontSize = 10.sp)
                            }
                            if (active) {
                                Surface(Modifier.align(Alignment.TopStart).padding(8.dp), color = Accent, shape = RoundedCornerShape(8.dp)) {
                                    Text("ACTIVE", Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                                }
                            }
                            IconButton(
                                onClick = { controller.closeTab(tab.id) },
                                modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).size(32.dp)
                                    .clip(CircleShape).background(MaterialTheme.colorScheme.surface.copy(alpha = .88f))
                            ) { Icon(Icons.Default.Close, "Close tab", modifier = Modifier.size(17.dp)) }
                            if (tab.loading) LinearProgressIndicator(
                                progress = { tab.progress.coerceIn(0, 100) / 100f },
                                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp), color = Accent
                            )
                        }
                        Spacer(Modifier.height(11.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tab.title.ifBlank { "New tab" }, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(tab.url, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (tab.isPrivate) Icon(Icons.Default.VisibilityOff, "Private tab", tint = Muted, modifier = Modifier.padding(start = 8.dp).size(17.dp))
                            Icon(Icons.Default.ChevronRight, null, tint = Muted, modifier = Modifier.padding(start = 4.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    prefs: PreferencesState, onBack: () -> Unit,
    onSave: (String, Any) -> Unit, onClear: () -> Unit
) {
    var homepage by remember(prefs.homepage) { mutableStateOf(prefs.homepage) }
    var engine by remember(prefs.engine) { mutableStateOf(prefs.engine) }
    var theme by remember(prefs.theme) { mutableStateOf(prefs.theme) }
    var transparency by remember(prefs.transparency) { mutableFloatStateOf(prefs.transparency) }
    var engineExpanded by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                Column {
                    Text("Settings Center", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("Customize your browsing", color = Muted, fontSize = 11.sp)
                }
            }
        }
        item {
            SettingsCard("APPEARANCE", Icons.Default.Palette) {
                Text("Theme mode", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("Light", "Dark", "System").forEach { mode ->
                        FilterChip(selected = theme == mode, onClick = { theme = mode; onSave("theme", mode) }, label = { Text(mode) })
                    }
                }
                Text("Ambient mood", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    com.dhyra.browser.ui.theme.MoodPreset.all.forEach { preset ->
                        FilterChip(selected = prefs.mood == preset.name, onClick = { onSave("ambient_mood", preset.name) }, label = { Text(preset.shortName, fontSize = 10.sp) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Glass transparency", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Text("${(transparency * 100).toInt()}%", color = Accent, fontWeight = FontWeight.Bold)
                }
                Slider(value = transparency, onValueChange = { transparency = it }, valueRange = .2f..1f, onValueChangeFinished = { onSave("glass_transparency", transparency) })
            }
        }
        item {
            SettingsCard("SEARCH & HOMEPAGE", Icons.Default.Search) {
                Text("Default search engine", fontWeight = FontWeight.SemiBold)
                Box {
                    OutlinedButton(onClick = { engineExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(engine, Modifier.weight(1f)); Icon(Icons.Default.ExpandMore, null)
                    }
                    DropdownMenu(engineExpanded, { engineExpanded = false }) {
                        listOf("Google", "Bing", "DuckDuckGo", "Brave").forEach { choice ->
                            DropdownMenuItem(text = { Text(choice) }, onClick = { engine = choice; engineExpanded = false; onSave("search_engine", choice) })
                        }
                    }
                }
                Text("Homepage URL", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(homepage, { homepage = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("https://example.com") })
                Button(onClick = {
                    val normalized = normalizeHomepage(homepage)
                    homepage = normalized
                    onSave("homepage", normalized)
                }, modifier = Modifier.fillMaxWidth()) { Text("Save homepage") }
            }
        }
        item {
            SettingsCard("PRIVACY & SECURITY", Icons.Default.Shield) {
                PreferenceSwitch("Basic tracker blocking", "Blocks a small set of known ad/tracker hosts", prefs.tracking) { onSave("tracking_protection", it) }
                HorizontalDivider()
                PreferenceSwitch("Popup blocker", "Blocks new windows unless you turn this off", prefs.popup) { onSave("popup_blocker", it) }
                HorizontalDivider()
                PreferenceSwitch("Desktop site", "Request desktop user agent", prefs.desktop) { onSave("desktop_mode", it) }
                OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.DeleteSweep, null); Spacer(Modifier.width(7.dp)); Text("Clear cookies, cache & history")
                }
                Text("Tracker blocking is a lightweight built-in list, not a full ad-blocking filter engine.", color = Muted, fontSize = 10.sp)
            }
        }
        item {
            SettingsCard("ABOUT", Icons.Default.Info) {
                Text("DHYRA Browser 1.4.0", fontWeight = FontWeight.Bold)
                Text("Android browser powered by Android System WebView (Chromium-based).", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    GlassPanel(dark = MaterialTheme.colorScheme.background == DarkCanvas, alpha = .9f, radius = RoundedCornerShape(21.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Accent, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
            }
            content()
        }
    }
}

@Composable
private fun PreferenceSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun EntriesScreen(
    title: String, entries: List<SavedPage>, onBack: () -> Unit,
    onOpen: (String) -> Unit, onDelete: (String) -> Unit, onClearAll: (() -> Unit)? = null
) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text(title, Modifier.weight(1f), fontSize = 21.sp, fontWeight = FontWeight.Bold)
            if (onClearAll != null) TextButton(onClick = onClearAll) { Text("Clear") }
        }
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nothing here yet", color = Muted) }
        } else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries, key = { it.url }) { entry ->
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(19.dp), shadowElevation = 1.dp) {
                    Row(Modifier.clickable { onOpen(entry.url) }.padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, null, tint = Accent)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(entry.url, color = Muted, fontSize = 10.sp, maxLines = 1)
                            if (title == "History") Text(DateFormat.getDateTimeInstance().format(Date(entry.timestamp)), color = Muted, fontSize = 9.sp)
                        }
                        IconButton(onClick = { onDelete(entry.url) }) { Icon(Icons.Default.DeleteOutline, "Remove") }
                    }
                }
            }
        }
    }
}

@Composable
private fun DownloadsScreen(onBack: () -> Unit, refreshKey: Int) {
    val context = LocalContext.current
    var rows by remember { mutableStateOf(emptyList<DownloadRow>()) }
    fun load() {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = manager.query(DownloadManager.Query())
        val result = mutableListOf<DownloadRow>()
        cursor?.use { c ->
            val idCol = c.getColumnIndex(DownloadManager.COLUMN_ID)
            val titleCol = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
            val statusCol = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val totalCol = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val soFarCol = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val status = c.getInt(statusCol)
                val title = c.getString(titleCol) ?: "Download"
                val total = c.getLong(totalCol)
                val soFar = c.getLong(soFarCol)
                result += DownloadRow(id, title, statusLabel(status), total, soFar)
            }
        }
        rows = result
    }
    LaunchedEffect(refreshKey) { load() }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Downloads", Modifier.weight(1f), fontSize = 21.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = { load() }) { Icon(Icons.Default.Refresh, "Refresh") }
        }
        if (rows.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No downloads yet", color = Muted) }
        else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(rows, key = { it.id }) { row ->
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(19.dp), shadowElevation = 1.dp) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.InsertDriveFile, null, tint = Accent)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(row.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text("${row.status} • ${formatBytes(row.downloaded)} / ${if (row.total > 0) formatBytes(row.total) else "—"}", color = Muted, fontSize = 10.sp)
                        }
                        IconButton(onClick = {
                            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            runCatching {
                                val uri = manager.getUriForDownloadedFile(row.id)
                                if (uri != null) {
                                    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, context.contentResolver.getType(uri))
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    context.startActivity(intent)
                                }
                            }
                        }) { Icon(Icons.Default.OpenInNew, "Open") }
                        IconButton(onClick = {
                            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(row.id)
                            load()
                        }) { Icon(Icons.Default.DeleteOutline, "Delete") }
                    }
                }
            }
        }
    }
}

private data class DownloadRow(val id: Long, val title: String, val status: String, val total: Long, val downloaded: Long)

private fun statusLabel(status: Int): String = when (status) {
    DownloadManager.STATUS_PENDING -> "Pending"
    DownloadManager.STATUS_RUNNING -> "Downloading"
    DownloadManager.STATUS_PAUSED -> "Paused"
    DownloadManager.STATUS_SUCCESSFUL -> "Completed"
    DownloadManager.STATUS_FAILED -> "Failed"
    else -> "Unknown"
}

private fun formatBytes(value: Long): String {
    if (value < 1024) return "$value B"
    if (value < 1024 * 1024) return "%.1f KB".format(value / 1024f)
    return "%.1f MB".format(value / (1024f * 1024f))
}

@Composable
private fun SupportScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val qr = remember { makeQr("bitcoin:$BTC_ADDRESS") }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
        Icon(Icons.Default.Favorite, null, tint = Accent, modifier = Modifier.size(34.dp))
        Text("Support DHYRA", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Contribute voluntarily to support future development.", color = Muted)
        Surface(shape = RoundedCornerShape(22.dp), color = Color.White, shadowElevation = 3.dp) {
            Image(qr.asImageBitmap(), null, Modifier.padding(13.dp).size(216.dp))
        }
        Text(BTC_ADDRESS, fontSize = 11.sp)
        Button(onClick = {
            clipboard.setText(AnnotatedString(BTC_ADDRESS))
            android.widget.Toast.makeText(context, "Bitcoin address copied", android.widget.Toast.LENGTH_SHORT).show()
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(7.dp)); Text("Copy address") }
        OutlinedButton(onClick = {
            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("bitcoin:$BTC_ADDRESS"))) }
                .onFailure { android.widget.Toast.makeText(context, "No compatible wallet found", android.widget.Toast.LENGTH_SHORT).show() }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AccountBalanceWallet, null); Spacer(Modifier.width(7.dp)); Text("Open Bitcoin wallet") }
        Text("Verify the address and Bitcoin network before sending.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun AboutScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
        Spacer(Modifier.height(50.dp))
        Box(Modifier.size(82.dp).clip(RoundedCornerShape(27.dp)).background(Brush.linearGradient(listOf(Accent, Cyan))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Public, null, tint = Color.White, modifier = Modifier.size(46.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("DHYRA BROWSER", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        Text("Version 1.3.0", color = Muted)
        Spacer(Modifier.height(18.dp))
        Text("An elegant Android browser powered by Android System WebView.", color = Muted)
    }
}

private fun makeQr(payload: String): Bitmap {
    val matrix = com.google.zxing.qrcode.QRCodeWriter().encode(payload, com.google.zxing.BarcodeFormat.QR_CODE, 560, 560)
    return Bitmap.createBitmap(560, 560, Bitmap.Config.ARGB_8888).also { bmp ->
        for (x in 0 until 560) for (y in 0 until 560) {
            bmp.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
}

private fun cleanDomain(value: String): String {
    if (value.isBlank() || value == "about:blank") return ""
    return runCatching {
        val uri = Uri.parse(value)
        val host = uri.host ?: return@runCatching value
        host.removePrefix("www.")
    }.getOrDefault(value)
}

private fun resolveAddress(input: String, engine: String): String {
    val value = input.trim()
    if (value.isBlank()) return "https://www.google.com"
    if (value.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))) return value
    if (value.contains(".") && !value.contains(" ")) return "https://$value"
    val query = URLEncoder.encode(value, "UTF-8")
    val endpoint = when (engine) {
        "Bing" -> "https://www.bing.com/search?q="
        "DuckDuckGo" -> "https://duckduckgo.com/?q="
        "Brave" -> "https://search.brave.com/search?q="
        else -> "https://www.google.com/search?q="
    }
    return endpoint + query
}

private fun normalizeHomepage(value: String): String {
    val raw = value.trim()
    return when {
        raw.startsWith("https://", true) || raw.startsWith("http://", true) -> raw
        raw.isBlank() -> "https://www.google.com"
        else -> "https://$raw"
    }
}

private fun decodeEntries(raw: String): List<SavedPage> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val obj = array.optJSONObject(index) ?: return@mapNotNull null
        val url = obj.optString("url")
        if (url.isBlank()) null else SavedPage(
            title = obj.optString("title", url),
            url = url,
            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
        )
    }
}.getOrDefault(emptyList())

private fun encodeEntries(entries: List<SavedPage>): String {
    val array = JSONArray()
    entries.forEach { entry ->
        array.put(JSONObject().put("title", entry.title).put("url", entry.url).put("timestamp", entry.timestamp))
    }
    return array.toString()
}
