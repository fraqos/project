# Building dhyra 2.4.6

## GitHub Actions (recommended)

Commit `.github/workflows/build.yml` and exactly one dhyra source ZIP to the repository, or commit the extracted Android project root. The workflow listens to ZIP/project/workflow changes and supports manual runs. It safely extracts ZIP input and generates the Gradle Wrapper in the actual Android project root; no empty temporary bootstrap project is used.

CI toolchain: JDK 21, Android SDK Platform 37.1, Android SDK Build Tools 36.0.0, Gradle 9.5.1, Android Gradle Plugin 9.3.1 and Kotlin Gradle Plugin 2.4.21. The workflow verifies the official Gradle distribution checksum and generated Wrapper JAR checksum.

The normal build creates a debug APK. Optional unsigned release and signed release APK/AAB builds are separate paths. Signing secrets are passed only to the signed-release step.

## Local build

Requirements: JDK 17 or newer, Android SDK Platform 37.1, Build Tools 36.0.0 and Gradle 9.5.1. From the project root, run `gradle wrapper --gradle-version 9.5.1 --distribution-type bin` once if `gradle-wrapper.jar` is absent, then `./gradlew testDebugUnitTest lintDebug assembleDebug`.
