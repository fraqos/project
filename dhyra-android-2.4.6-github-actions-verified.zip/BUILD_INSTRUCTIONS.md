# Build instructions — dhyra 2.4.6

## Recommended: GitHub Actions from a source ZIP

1. Place exactly one dhyra Android project ZIP in the GitHub repository (the repository root is recommended). Do not commit old source ZIP versions alongside it.
2. Place the supplied workflow at `.github/workflows/build.yml` and make sure it is the only active dhyra build workflow.
3. Commit both files and push. The workflow also supports `workflow_dispatch` from the Actions tab.
4. Download `dhyra-v2.4.6.apk`, `dhyra-source.zip`, and `SHA256SUMS.txt` from the completed run.

The workflow safely validates and extracts the ZIP, then locates the actual Android project root. It installs JDK 21, Android SDK Platform 37.1 and Build Tools 36.0.0, uses Gradle 9.5.1, generates the standard Gradle Wrapper in the real project root, and verifies both the official Wrapper JAR and Gradle distribution SHA-256 values before building.

The normal workflow builds a debug APK. Optional release builds are available through `workflow_dispatch`. Unsigned release builds do not receive signing secrets. Signed release APK/AAB builds require all four GitHub Secrets listed below.

## Local build

Requirements: JDK 17 or newer, Android SDK Platform 37.1, Android SDK Build Tools 36.0.0, accepted SDK licenses, and Gradle 9.5.1. The source ZIP intentionally omits `gradle-wrapper.jar`. From the actual project root, generate it with `gradle wrapper --gradle-version 9.5.1 --distribution-type bin` if needed, then run `./gradlew testDebugUnitTest lintDebug assembleDebug`.

## Optional release signing

Use `workflow_dispatch` with both `build_release=true` and `sign_release=true`, and set these GitHub Secrets:

- `DHYRA_RELEASE_KEYSTORE_BASE64`
- `DHYRA_RELEASE_STORE_PASSWORD`
- `DHYRA_RELEASE_KEY_ALIAS`
- `DHYRA_RELEASE_KEY_PASSWORD`

Never commit a keystore, signing password, or `local.properties` to the repository.
