@file:OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser

import com.dhyra.browser.ui.localization.localizePlainUiText

import com.dhyra.browser.core.nav.BrowserAddressResolver
import com.dhyra.browser.core.nav.DhyraNavigationManager
import com.dhyra.browser.core.search.SearchEngineManager
import com.dhyra.browser.core.downloads.DhyraDownloadRequest
import com.dhyra.browser.core.storage.DhyraHistoryManager
import com.dhyra.browser.core.storage.DhyraBookmarkManager
import com.dhyra.browser.core.settings.DhyraSettingsManager
import com.dhyra.browser.core.security.DhyraPermissionManager
import com.dhyra.browser.core.network.HttpsUpgrade
import com.dhyra.browser.ui.theme.*
import com.dhyra.browser.ui.components.*
import com.dhyra.browser.ui.screens.*

import android.content.Intent
import android.app.PictureInPictureParams
import android.content.ClipData
import android.content.ClipboardManager
import android.util.Rational
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.widget.Toast
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.datastore.preferences.core.*
import com.dhyra.browser.core.nav.BackAction
import com.dhyra.browser.core.nav.BackContext
import com.dhyra.browser.core.nav.BackPolicy
import com.dhyra.browser.core.suggest.PageRef
import com.dhyra.browser.core.suggest.SmartSuggest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    var pendingExternalUrl by mutableStateOf<String?>(null)
    var browserController: BrowserController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Keep the gesture/3-button bar fully transparent instead of adding a scrim.
            window.isNavigationBarContrastEnforced = false
        }
        acceptExternalIntent(intent)
        setContent { DhyraApplication() }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && browserController?.isFullscreen == true) {
            runCatching {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        acceptExternalIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        browserController?.onHostResume()
    }

    override fun onPause() {
        browserController?.onHostPause()
        super.onPause()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) browserController?.trimMemory()
    }

    private fun acceptExternalIntent(intent: Intent?) {
        if (intent == null) return
        pendingExternalUrl = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data?.takeIf {
                it.scheme.equals("http", true) || it.scheme.equals("https", true)
            }?.toString()
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_WEB_SEARCH -> intent.getStringExtra(android.app.SearchManager.QUERY)
            else -> null
        }?.takeIf { it.isNotBlank() }
    }
}

/**
 * Root of the UI. Responsibilities, in order: web-content callbacks (file chooser and
 * permissions), preferences, screen state and navigation, the omnibox, tabs, Back handling,
 * and finally the layered layout (screen, omnibox overlay, snackbar, sheets, dialogs).
 */
@Composable
private fun DhyraApplication() {
    val context = LocalContext.current
    val activity = context as MainActivity
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current

    val importBookmarksLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val imported = decodeEntries(raw)
                val existing = decodeEntries(context.dhyraStore.data.first()[BOOKMARKS_KEY] ?: "[]")
                val merged = (imported + existing).distinctBy { it.url }.take(500)
                context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries(merged) }
                Toast.makeText(context, localizePlainUiText(context, "Imported ${imported.size} bookmark(s)"), Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(context, localizePlainUiText(context, "Could not import this bookmark file"), Toast.LENGTH_LONG).show()
            }
        }
    }
    val exportBookmarksLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val latest = decodeEntries(context.dhyraStore.data.first()[BOOKMARKS_KEY] ?: "[]")
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(encodeEntries(latest)) }
                    ?: error("Unable to open export destination")
                Toast.makeText(context, localizePlainUiText(context, "Exported ${latest.size} bookmark(s)"), Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(context, localizePlainUiText(context, "Could not export bookmarks"), Toast.LENGTH_LONG).show()
            }
        }
    }

    var pendingFileChooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val singleFilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        pendingFileChooser?.onReceiveValue(uri?.let { arrayOf(it) })
        pendingFileChooser = null
    }
    val multipleFilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        pendingFileChooser?.onReceiveValue(uris.toTypedArray())
        pendingFileChooser = null
    }

    var pendingPermission by remember { mutableStateOf<PermissionRequest?>(null) }
    var pendingDownload by remember { mutableStateOf<DhyraDownloadRequest?>(null) }
    var showSitePermissionDialog by remember { mutableStateOf(false) }
    var pendingGeo by remember { mutableStateOf<Pair<String, GeolocationPermissions.Callback>?>(null) }
    var showGeoPermissionDialog by remember { mutableStateOf(false) }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val pending = pendingGeo
        if (pending != null) {
            val allowed = results.values.any { it }
            pending.second.invoke(pending.first, allowed, false)
        }
        pendingGeo = null
        showGeoPermissionDialog = false
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val request = pendingPermission
        if (request != null) {
            val granted = results.values.all { it }
            val supported = DhyraPermissionManager.supportedResources(request.resources)
            if (granted && supported.isNotEmpty()) runCatching { request.grant(supported) }
            else runCatching { request.deny() }
        }
        pendingPermission = null
        showSitePermissionDialog = false
    }

    val controller = remember(activity) {
        BrowserController(
            activity = activity,
            onFileChooser = { callback, params ->
                pendingFileChooser?.onReceiveValue(null)
                pendingFileChooser = callback
                val acceptedTypes = params?.acceptTypes.orEmpty()
                    .map { it.trim() }
                    .filter { it.contains("/") }
                    .distinct()
                    .toTypedArray()
                    .ifEmpty { arrayOf("*/*") }
                if (params?.mode == android.webkit.WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
                    multipleFilePicker.launch(acceptedTypes)
                } else {
                    singleFilePicker.launch(acceptedTypes)
                }
            },
            onPermission = { request ->
                pendingPermission?.let { old -> runCatching { old.deny() } }
                pendingPermission = request
                showSitePermissionDialog = true
            },
            onGeolocation = { origin, callback ->
                pendingGeo?.second?.let { previous -> runCatching { previous.invoke(pendingGeo?.first.orEmpty(), false, false) } }
                pendingGeo = origin to callback
                showGeoPermissionDialog = true
            },
            onDownloadRequest = { request -> pendingDownload = request }
        )
    }

    // ---------- preferences and saved data ----------
    val prefs by context.dhyraStore.data.collectAsState(initial = emptyPreferences())
    val defaultTranslationTarget = remember {
        val deviceLanguage = java.util.Locale.getDefault().language
        if (com.dhyra.browser.core.translation.TranslationLanguage.supported.any { it.tag == deviceLanguage && it.tag != "auto" }) deviceLanguage else "id"
    }
    val customSearchEngines = remember(prefs[CUSTOM_SEARCH_ENGINES_KEY]) {
        SearchEngineManager.decodeCustomEngines(prefs[CUSTOM_SEARCH_ENGINES_KEY])
    }
    val selectedSearchEngine = DhyraSettingsManager.normalizeSearchEngine(prefs[ENGINE_KEY], customSearchEngines)
    val selectedCustomSearchUrl = customSearchEngines.firstOrNull { it.name == selectedSearchEngine }?.template
        ?: prefs[CUSTOM_SEARCH_URL_KEY].orEmpty()
    val state = PreferencesState(
        homepage = prefs[HOME_KEY] ?: "",
        engine = selectedSearchEngine,
        customSearchUrl = selectedCustomSearchUrl,
        theme = DhyraSettingsManager.normalizeTheme(prefs[THEME_KEY]),
        appLanguage = DhyraSettingsManager.normalizeAppLanguage(AppCompatDelegate.getApplicationLocales().toLanguageTags()),
        customSearchEngines = customSearchEngines,
        tracking = prefs[TRACKING_KEY] ?: true,
        popup = prefs[POPUP_KEY] ?: true,
        desktop = prefs[DESKTOP_KEY] ?: false,
        focusOnNewTab = prefs[FOCUS_NEW_TAB_KEY] ?: true,
        translationTarget = prefs[TRANSLATION_TARGET_KEY] ?: defaultTranslationTarget
    )
    val historyRaw = prefs[HISTORY_KEY] ?: "[]"
    val bookmarksRaw = prefs[BOOKMARKS_KEY] ?: "[]"
    val speedDialRaw = prefs[SPEED_DIAL_KEY]
    val history by produceState(initialValue = emptyList<SavedPage>(), key1 = historyRaw) {
        value = withContext(Dispatchers.Default) { decodeEntries(historyRaw) }
    }
    val bookmarks by produceState(initialValue = emptyList<SavedPage>(), key1 = bookmarksRaw) {
        value = withContext(Dispatchers.Default) { decodeEntries(bookmarksRaw) }
    }
    val speedDial = remember(speedDialRaw) { speedDialRaw?.let { decodeShortcuts(it) } ?: DEFAULT_SPEED_DIAL }
    val suggestIndex by produceState(
        initialValue = SmartSuggest.buildIndex(emptyList(), emptyList()),
        key1 = history,
        key2 = bookmarks
    ) {
        value = withContext(Dispatchers.Default) {
            SmartSuggest.buildIndex(
                history.map { PageRef(it.title, it.url) },
                bookmarks.map { PageRef(it.title, it.url) }
            )
        }
    }
    val emptySuggestIndex = remember { SmartSuggest.buildIndex(emptyList(), emptyList()) }

    // ---------- screen state ----------
    var route by remember { mutableStateOf(Route.HOME) }
    val routeStack = remember { mutableStateListOf<Route>() }
    var omniboxOpen by remember { mutableStateOf(false) }
    var omniboxValue by remember { mutableStateOf(TextFieldValue("")) }
    var showMenu by remember { mutableStateOf(false) }
    var showShields by remember { mutableStateOf(false) }
    var showTranslationSheet by remember { mutableStateOf(false) }
    var translationSource by remember { mutableStateOf("auto") }
    var translationSheetTabId by remember { mutableIntStateOf(-1) }
    var translationTarget by remember(state.translationTarget) { mutableStateOf(state.translationTarget) }
    var showQrDialog by remember { mutableStateOf(false) }
    var showFind by remember { mutableStateOf(false) }
    var findText by remember { mutableStateOf("") }
    var refreshDownloads by remember { mutableIntStateOf(0) }
    var focusAfterNewTab by remember { mutableStateOf(false) }
    var tabsStartPrivate by remember { mutableStateOf(false) }
    var initialized by remember { mutableStateOf(false) }
    var showOpeningIntro by remember { mutableStateOf(false) }
    val snackbarHost = remember { SnackbarHostState() }

    LaunchedEffect(initialized) {
        if (initialized) {
            // Show the short logo reveal only on a cold launch, not when AppCompat
            // recreates the Activity for a Theme or app-language change.
            if (savedInstanceState == null) {
                showOpeningIntro = true
                delay(180)
                showOpeningIntro = false
            }
            // Clean up retired preferences only when an older installation contains them.
            val storedPreferences = context.dhyraStore.data.first()
            val hasRetiredPreferences =
                storedPreferences.contains(stringPreferencesKey("ui_style")) ||
                storedPreferences.contains(booleanPreferencesKey("reduced_motion")) ||
                storedPreferences.contains(stringPreferencesKey("animation_intensity")) ||
                storedPreferences.contains(booleanPreferencesKey("startup_animation_disabled")) ||
                storedPreferences.contains(booleanPreferencesKey("intro_seen")) ||
                storedPreferences.contains(stringPreferencesKey("homepage_layout"))
            if (hasRetiredPreferences) {
                context.dhyraStore.edit { preferences ->
                    preferences.remove(stringPreferencesKey("ui_style"))
                    preferences.remove(booleanPreferencesKey("reduced_motion"))
                    preferences.remove(stringPreferencesKey("animation_intensity"))
                    preferences.remove(booleanPreferencesKey("startup_animation_disabled"))
                    preferences.remove(booleanPreferencesKey("intro_seen"))
                    preferences.remove(stringPreferencesKey("homepage_layout"))
                }
            }
        }
    }

    val isDark = when (state.theme) {
        "Dark" -> true
        "Light" -> false
        else -> isSystemInDarkTheme()
    }
    LaunchedEffect(state.theme) {
        val requestedMode = when (state.theme) {
            "Light" -> AppCompatDelegate.MODE_NIGHT_NO
            "Dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        val currentMode = AppCompatDelegate.getDefaultNightMode()
        // MODE_NIGHT_UNSPECIFIED already follows the device by default. Keep it on
        // first launch to avoid an unnecessary Activity recreation and startup flicker.
        val alreadyFollowsSystem = state.theme == "System default" &&
            currentMode == AppCompatDelegate.MODE_NIGHT_UNSPECIFIED
        if (currentMode != requestedMode && !alreadyFollowsSystem) {
            AppCompatDelegate.setDefaultNightMode(requestedMode)
        }
    }
    SideEffect {
        val insets = WindowInsetsControllerCompat(activity.window, activity.window.decorView)
        insets.isAppearanceLightStatusBars = !isDark
        insets.isAppearanceLightNavigationBars = !isDark
    }

    controller.onPageFinished = { tab ->
        if (!tab.isPrivate && (tab.url.startsWith("https://") || tab.url.startsWith("http://"))) {
            scope.launch(Dispatchers.IO) {
                val currentRaw = context.dhyraStore.data.first()[HISTORY_KEY] ?: "[]"
                val current = decodeEntries(currentRaw)
                val updated = DhyraHistoryManager.record(current, SavedPage(tab.title, tab.url), limit = 5000)
                context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(updated) }
            }
        }
    }
    controller.onTabsChanged = { snapshot ->
        val session = snapshot
            .filter { !it.isPrivate && DhyraNavigationManager.isHttpUrl(it.url) }
            .takeLast(30)
            .map { SessionTab(it.url, it.title, it.isDesktop) }
        scope.launch { context.dhyraStore.edit { it[SESSION_KEY] = encodeSession(session) } }
    }
    activity.browserController = controller

    LaunchedEffect(controller) {
        // Read persisted preferences before creating the initial tab so its default
        // Mobile/Desktop mode is correct on the first frame after process recreation.
        val initialPreferences = context.dhyraStore.data.first()
        controller.applySettings(
            tracking = initialPreferences[TRACKING_KEY] ?: true,
            popup = initialPreferences[POPUP_KEY] ?: true,
            desktop = initialPreferences[DESKTOP_KEY] ?: false
        )
        if (controller.tabs.isEmpty()) {
            val persisted = initialPreferences[SESSION_KEY] ?: "[]"
            val restored = decodeSession(persisted)
            if (restored.isNotEmpty()) controller.restoreSession(restored)
            // Always land on a clean start page; restored tabs wait in the tab switcher.
            controller.createTab()
        }
        initialized = true
    }
    LaunchedEffect(state.tracking, state.popup, state.desktop) {
        controller.applySettings(state.tracking, state.popup, state.desktop)
    }
    DisposableEffect(controller) {
        onDispose {
            pendingFileChooser?.onReceiveValue(null)
            pendingPermission?.let { runCatching { it.deny() } }
            pendingGeo?.let { (origin, callback) -> runCatching { callback.invoke(origin, false, false) } }
            controller.destroy()
            activity.browserController = null
        }
    }

    val activeTab = controller.activeTab()
    val isSpaceActive = activeTab?.isPrivate == true
    // Keep the task snapshot protected while any space tab exists, including when
    // the user temporarily switches back to a regular tab.
    val hasSpaceTabs = controller.tabs.any { it.isPrivate }
    val protectTaskSnapshot = isSpaceActive || hasSpaceTabs
    SideEffect {
        if (protectTaskSnapshot) {
            activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            activity.setRecentsScreenshotEnabled(!protectTaskSnapshot)
        }
    }
    // A blank tab without a WebView is the start page, whatever route was requested.
    val contentRoute = when {
        isSpaceActive && route in setOf(Route.BOOKMARKS, Route.HISTORY, Route.DOWNLOADS) -> Route.BROWSER
        route != Route.BROWSER -> route
        activeTab == null -> Route.HOME
        isBlankPage(activeTab.url) && !controller.hasWebView(activeTab.id) -> Route.HOME
        else -> Route.BROWSER
    }

    LaunchedEffect(activeTab?.id, activeTab?.isPrivate) {
        if (activeTab?.isPrivate == true && route in setOf(Route.BOOKMARKS, Route.HISTORY, Route.DOWNLOADS)) {
            routeStack.clear()
            route = Route.BROWSER
        }
    }

    // ---------- IME policy: the page must not jump while the omnibox is typing ----------
    val imeVisible = WindowInsets.isImeVisible
    var imeLockedByOmnibox by remember { mutableStateOf(false) }
    LaunchedEffect(omniboxOpen) { if (omniboxOpen) imeLockedByOmnibox = true }
    LaunchedEffect(imeVisible, omniboxOpen) {
        if (!imeVisible && !omniboxOpen) imeLockedByOmnibox = false
    }
    val resizeForIme = !imeLockedByOmnibox

    // ---------- helpers ----------
    fun saveValue(key: String, value: Any) {
        if (key == "app_language" && value is String) {
            val languageTag = value.takeUnless { it == "system" }.orEmpty()
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(languageTag))
            return
        }
        scope.launch {
            context.dhyraStore.edit { p ->
                when (value) {
                    is String -> p[stringPreferencesKey(key)] = value
                    is Boolean -> p[booleanPreferencesKey(key)] = value
                }
            }
        }
    }

    /** Desktop mode is scoped to the active tab; Settings controls the default for new tabs. */
    fun toggleDesktop() {
        val tab = controller.activeTab() ?: return
        val next = !tab.isDesktop
        if (!controller.setDesktopMode(tab.id, next)) {
            Toast.makeText(context, localizePlainUiText(context, "This WebView could not apply the requested desktop mode."), Toast.LENGTH_LONG).show()
        }
    }

    fun go(target: Route) {
        if (target == route) return
        routeStack.add(route)
        route = target
    }

    fun resetTo(target: Route) {
        routeStack.clear()
        route = target
    }

    fun popRoute(): Boolean {
        if (routeStack.isEmpty()) return false
        route = routeStack.removeAt(routeStack.size - 1)
        return true
    }

    fun closeFind() {
        showFind = false
        findText = ""
        controller.clearFind()
    }

    fun closeOmnibox() {
        omniboxOpen = false
        focusManager.clearFocus()
        keyboard?.hide()
    }

    fun openOmnibox(prefill: String) {
        omniboxValue = TextFieldValue(prefill, TextRange(0, prefill.length))
        omniboxOpen = true
    }

    fun openTarget(raw: String, newTab: Boolean = false, isPrivate: Boolean = false) {
        val target = DhyraNavigationManager.resolveAddress(raw, state.engine, state.customSearchUrl)
        closeOmnibox()
        if (newTab || controller.activeTabId == -1) controller.createTab(target, isPrivate)
        else controller.navigate(target)
        resetTo(Route.BROWSER)
    }

    fun submitOmnibox() {
        if (omniboxValue.text.isBlank()) closeOmnibox() else openTarget(omniboxValue.text)
    }

    /** Typing forward completes the best host inline (the completion stays selected, so Backspace removes it). */
    fun onOmniboxChange(new: TextFieldValue) {
        val previous = omniboxValue
        val typedPart = previous.text.substring(0, previous.selection.min.coerceIn(0, previous.text.length))
        val typedForward = new.selection.collapsed &&
            new.selection.start == new.text.length &&
            new.text.length > typedPart.length &&
            new.text.startsWith(typedPart)
        omniboxValue = new
        if (typedForward) {
            val completion = SmartSuggest.inlineCompletion(new.text, if (activeTab?.isPrivate == true) emptySuggestIndex else suggestIndex)
            if (completion != null) {
                omniboxValue = TextFieldValue(completion, TextRange(new.text.length, completion.length))
            }
        }
    }

    fun openTabs() {
        controller.captureThumbnail()
        tabsStartPrivate = controller.activeTab()?.isPrivate == true
        go(Route.TABS)
    }

    fun goHome() {
        if (contentRoute == Route.HOME) return
        val custom = state.homepage
        if (custom.isNotBlank()) controller.navigate(custom) else go(Route.HOME)
    }

    /** Reuses an untouched start-page tab; otherwise opens a new tab whose parent is the current one. */
    fun newTab(isPrivate: Boolean) {
        if (isPrivate && !controller.supportsSpaceProfiles) {
            Toast.makeText(
                context,
                localizePlainUiText(context, "This Android System WebView does not support isolated space profiles. Update Android System WebView and try again."),
                Toast.LENGTH_LONG
            ).show()
            return
        }
        if (isPrivate && !controller.spaceReady) {
            Toast.makeText(context, localizePlainUiText(context, "Secure space storage is being cleared. Please try again in a moment."), Toast.LENGTH_SHORT).show()
            return
        }
        val current = controller.activeTab()
        val reusable = current != null &&
            isBlankPage(current.url) &&
            !controller.hasWebView(current.id) &&
            current.isPrivate == isPrivate
        if (!reusable) {
            val parent = controller.activeTabId.takeIf { it != -1 }
            controller.createTab(isPrivate = isPrivate, parentId = parent)
        }
        resetTo(Route.BROWSER)
        if (state.focusOnNewTab) focusAfterNewTab = true
    }

    fun closeAllWithUndo(privateGroup: Boolean) {
        val closing = controller.tabs.filter { it.isPrivate == privateGroup }
        if (closing.isEmpty()) return
        val restorable: List<SessionTab> = if (privateGroup) {
            emptyList()
        } else {
            closing.filter { DhyraNavigationManager.isHttpUrl(it.url) }
                .map { SessionTab(it.url, it.title, it.isDesktop) }
        }
        val count = closing.size
        controller.closeAllTabs(onlyPrivate = privateGroup)
        resetTo(Route.BROWSER)
        scope.launch {
            snackbarHost.currentSnackbarData?.dismiss()
            val result = snackbarHost.showSnackbar(
                message = when {
                    privateGroup && count == 1 -> "1 space tab closed"
                    privateGroup -> "$count space tabs closed"
                    count == 1 -> "1 tab closed"
                    else -> "$count tabs closed"
                },
                actionLabel = if (restorable.isEmpty()) null else "Undo",
                duration = SnackbarDuration.Long
            )
            if (result == SnackbarResult.ActionPerformed && restorable.isNotEmpty()) {
                controller.restoreClosedTabs(restorable)
                resetTo(Route.BROWSER)
            }
        }
    }

    fun addBookmark() {
        val tab = controller.activeTab() ?: return
        if (tab.isPrivate) {
            Toast.makeText(context, localizePlainUiText(context, "Bookmarks are disabled in space to avoid saving session activity."), Toast.LENGTH_LONG).show()
            return
        }
        if (!tab.url.startsWith("http")) return
        scope.launch(Dispatchers.IO) {
            val latestRaw = context.dhyraStore.data.first()[BOOKMARKS_KEY] ?: "[]"
            val latest = decodeEntries(latestRaw)
            val updated = DhyraBookmarkManager.add(latest, SavedPage(tab.title, tab.url))
            context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries(updated) }
        }
        Toast.makeText(context, localizePlainUiText(context, "Bookmark added"), Toast.LENGTH_SHORT).show()
    }

    fun addSpeedDial() {
        val tab = controller.activeTab() ?: return
        if (tab.isPrivate) {
            Toast.makeText(context, localizePlainUiText(context, "Speed dial is disabled in space to avoid saving session activity."), Toast.LENGTH_LONG).show()
            return
        }
        val host = runCatching { Uri.parse(tab.url).host }.getOrNull()?.removePrefix("www.") ?: return
        if (!tab.url.startsWith("http")) return
        val site = "https://$host"
        if (speedDial.any { it.url.equals(site, true) }) {
            Toast.makeText(context, localizePlainUiText(context, "Already in your speed dial"), Toast.LENGTH_SHORT).show()
            return
        }
        if (speedDial.size >= 8) {
            Toast.makeText(context, localizePlainUiText(context, "Speed dial is full. Long-press a site to remove it."), Toast.LENGTH_LONG).show()
            return
        }
        val label = tab.title.takeIf { it.isNotBlank() && it.length <= 14 } ?: host
        val updated = speedDial + Shortcut(label, site)
        scope.launch { context.dhyraStore.edit { it[SPEED_DIAL_KEY] = encodeShortcuts(updated) } }
        Toast.makeText(context, localizePlainUiText(context, "Added to speed dial"), Toast.LENGTH_SHORT).show()
    }

    fun removeSpeedDial(site: Shortcut) {
        val updated = speedDial.filterNot { it.url == site.url }
        scope.launch { context.dhyraStore.edit { it[SPEED_DIAL_KEY] = encodeShortcuts(updated) } }
    }

    fun saveSpeedDial(original: Shortcut?, replacement: Shortcut) {
        val existing = speedDial.filterNot { original != null && it.url == original.url }
        if (existing.any { it.url.equals(replacement.url, ignoreCase = true) }) {
            Toast.makeText(context, localizePlainUiText(context, "That website is already in your speed dial"), Toast.LENGTH_SHORT).show()
            return
        }
        if (original == null && existing.size >= 8) {
            Toast.makeText(context, localizePlainUiText(context, "Speed dial is full"), Toast.LENGTH_SHORT).show()
            return
        }
        val updated = (listOf(replacement) + existing).take(8)
        scope.launch { context.dhyraStore.edit { it[SPEED_DIAL_KEY] = encodeShortcuts(updated) } }
    }

    fun translatePage() {
        val tab = controller.activeTab() ?: return
        if (isBlankPage(tab.url)) {
            Toast.makeText(context, localizePlainUiText(context, "Open a web page before translating."), Toast.LENGTH_SHORT).show()
            return
        }
        translationSource = "auto"
        translationTarget = state.translationTarget
        translationSheetTabId = tab.id
        showTranslationSheet = true
    }

    fun toggleReaderMode() {
        controller.setReaderMode(!controller.readerModeActive)
    }

    fun printPage() { controller.printCurrentPage() }

    fun burnPrivateSession() {
        val privateCount = controller.tabs.count { it.isPrivate }
        if (privateCount == 0) {
            Toast.makeText(context, localizePlainUiText(context, "There are no space tabs to clear"), Toast.LENGTH_SHORT).show()
            return
        }
        controller.closeAllTabs(onlyPrivate = true)
        resetTo(Route.BROWSER)
        Toast.makeText(context, localizePlainUiText(context, "space tabs closed. Clearing space storage…"), Toast.LENGTH_SHORT).show()
    }

    fun sharePage() {
        val url = controller.activeTab()?.url?.takeUnless { isBlankPage(it) } ?: return
        val share = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url)
        context.startActivity(Intent.createChooser(share, "Share page"))
    }

    // An external link reuses the untouched start-page tab, otherwise it gets its own tab.
    LaunchedEffect(activity.pendingExternalUrl, initialized) {
        val incoming = activity.pendingExternalUrl
        if (initialized && !incoming.isNullOrBlank()) {
            activity.pendingExternalUrl = null
            val current = controller.activeTab()
            val reuse = current != null &&
                isBlankPage(current.url) &&
                !controller.hasWebView(current.id) &&
                !current.isPrivate
            openTarget(incoming, newTab = !reuse)
        }
    }

    // After a deliberate "new tab", wait out the transition and open the keyboard. The flag is
    // always cleared so the keyboard can never pop up later for a request that already expired.
    LaunchedEffect(focusAfterNewTab, contentRoute) {
        if (focusAfterNewTab) {
            if (contentRoute == Route.HOME) {
                delay(260)
                openOmnibox("")
            }
            focusAfterNewTab = false
        }
    }
    LaunchedEffect(contentRoute, controller.activeTabId) {
        if (showFind && contentRoute != Route.BROWSER) closeFind()
        if (showTranslationSheet && (contentRoute != Route.BROWSER || controller.activeTabId != translationSheetTabId)) {
            showTranslationSheet = false
        }
    }

    // ---------- omnibox suggestions ----------
    // Suggestions follow what was actually typed, not the inline completion that follows it.
    val typedText = omniboxValue.text.substring(
        0,
        omniboxValue.selection.min.coerceIn(0, omniboxValue.text.length)
    )
    val activeSuggestIndex = if (activeTab?.isPrivate == true) emptySuggestIndex else suggestIndex
    val omniItems = remember(typedText, activeSuggestIndex, activeTab?.url) {
        buildOmniItems(typedText, activeTab?.url.orEmpty(), activeSuggestIndex)
    }
    val pageSecure: Boolean? = activeTab?.url?.let {
        when {
            it.startsWith("https://") -> true
            it.startsWith("http://") -> false
            else -> null
        }
    }

    // ---------- Back: Chromium-style priority ----------
    fun currentBackAction(): BackAction = BackPolicy.decide(
        BackContext(
            omniboxOpen = omniboxOpen,
            findOpen = showFind && contentRoute == Route.BROWSER,
            hasScreenToPop = routeStack.isNotEmpty(),
            fullscreen = controller.isFullscreen,
            onBrowserPage = contentRoute == Route.BROWSER,
            canGoBack = controller.canGoBack(),
            hasParentTab = controller.parentOfActive() != null
        )
    )
    BackHandler(enabled = currentBackAction() != BackAction.SYSTEM) {
        when (currentBackAction()) {
            BackAction.CLOSE_OMNIBOX -> closeOmnibox()
            BackAction.CLOSE_FIND -> closeFind()
            BackAction.POP_SCREEN -> popRoute()
            BackAction.EXIT_FULLSCREEN -> controller.exitFullscreen()
            BackAction.WEB_BACK -> controller.goBack()
            BackAction.CLOSE_TAB_TO_PARENT -> {
                controller.closeActiveTabToParent()
                resetTo(Route.BROWSER)
            }
            BackAction.GO_TO_START_PAGE -> resetTo(Route.HOME)
            BackAction.SYSTEM -> Unit
        }
    }

    // ---------- layout ----------
    DhyraTheme(state.theme) {
        val cs = MaterialTheme.colorScheme
        Box(Modifier.fillMaxSize().background(cs.background)) {
            AnimatedContent(
                targetState = contentRoute,
                modifier = Modifier.fillMaxSize(),
                transitionSpec = {
                    (fadeIn(animationSpec = tween(DhyraMotion.standard, easing = FastOutSlowInEasing)) +
                        scaleIn(
                            initialScale = 0.985f,
                            animationSpec = tween(DhyraMotion.standard, easing = FastOutSlowInEasing)
                        )).togetherWith(
                        fadeOut(animationSpec = tween(DhyraMotion.fast, easing = FastOutLinearInEasing))
                    )
                },
                label = "screen"
            ) { target ->
                when (target) {
                    Route.HOME -> HomePage(
                        isPrivate = activeTab?.isPrivate == true,
                        searchEngine = state.engine,
                        searchEngineOptions = SearchEngineManager.availableEngines(state.customSearchEngines),
                        onSearchEngine = { saveValue("search_engine", it) },
                        speedDial = if (activeTab?.isPrivate == true) emptyList() else speedDial,
                        recent = if (activeTab?.isPrivate == true) emptyList() else history,
                        onOpenOmnibox = { openOmnibox("") },
                        onSite = { url -> openTarget(url) },
                        onRemoveSite = { site -> removeSpeedDial(site) },
                        onSaveShortcut = { original, replacement -> saveSpeedDial(original, replacement) },
                        onRecent = { url -> openTarget(url) },
                        tabCount = controller.tabs.count { it.isPrivate == (activeTab?.isPrivate == true) },
                        onTabs = { openTabs() },
                        onMenu = { showMenu = true }
                    )

                    Route.BROWSER -> BrowserPage(
                        controller = controller,
                        desktop = activeTab?.isDesktop == true,
                        resizeForIme = resizeForIme,
                        imeVisible = imeVisible,
                        showFind = showFind,
                        findText = findText,
                        onFindChange = { text ->
                            findText = text
                            controller.find(text)
                        },
                        onFindClose = { closeFind() },
                        onOpenOmnibox = {
                            openOmnibox(activeTab?.url.orEmpty().takeUnless { isBlankPage(it) } ?: "")
                        },
                        onShields = { showShields = true },
                        onToggleDesktop = { toggleDesktop() },
                        onHome = { goHome() },
                        onTabs = { openTabs() },
                        onMenu = { showMenu = true },
                        onSwipeTabs = { direction -> controller.selectRelativeTab(direction) }
                    )

                    Route.TABS -> TabsScreen(
                        controller = controller,
                        startOnPrivate = tabsStartPrivate,
                        onBack = { if (!popRoute()) resetTo(Route.BROWSER) },
                        onSelect = { id ->
                            controller.selectTab(id)
                            resetTo(Route.BROWSER)
                        },
                        onClose = { id -> controller.closeTab(id) },
                        onNew = { privateTab -> newTab(privateTab) },
                        onCloseAll = { privateGroup -> closeAllWithUndo(privateGroup) }
                    )

                    Route.SETTINGS -> SettingsScreen(
                        state = state,
                        onBack = { if (!popRoute()) resetTo(Route.HOME) },
                        onSave = { key, value -> saveValue(key, value) },
                        onClear = {
                            controller.clearRegularData()
                            scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                        },
                        onResetSettings = {
                            AppCompatDelegate.setApplicationLocales(LocaleListCompat.getEmptyLocaleList())
                            scope.launch {
                                context.dhyraStore.edit { preferences ->
                                    preferences.remove(HOME_KEY)
                                    preferences.remove(ENGINE_KEY)
                                    preferences.remove(CUSTOM_SEARCH_URL_KEY)
                                    preferences.remove(CUSTOM_SEARCH_ENGINES_KEY)
                                    preferences.remove(THEME_KEY)
                                    preferences.remove(stringPreferencesKey("ui_style"))
                                    preferences.remove(booleanPreferencesKey("reduced_motion"))
                                    preferences.remove(stringPreferencesKey("animation_intensity"))
                                    preferences.remove(booleanPreferencesKey("startup_animation_disabled"))
                                    preferences.remove(booleanPreferencesKey("intro_seen"))
                                    preferences.remove(TRACKING_KEY)
                                    preferences.remove(POPUP_KEY)
                                    preferences.remove(DESKTOP_KEY)
                                    preferences.remove(FOCUS_NEW_TAB_KEY)
                                    preferences.remove(TRANSLATION_TARGET_KEY)
                                }
                            }
                        },
                        onSetDefaultBrowser = { requestDefaultBrowserRole(activity) },
                        onAbout = { go(Route.ABOUT) },
                        onDownloads = {
                            refreshDownloads++
                            go(Route.DOWNLOADS)
                        },
                        onNotifications = {
                            val intent = Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
                            runCatching { context.startActivity(intent) }
                        },
                        privateBrowsingSupported = controller.supportsSpaceProfiles,
                        isSpace = activeTab?.isPrivate == true
                    )

                    Route.BOOKMARKS -> EntriesScreen(
                        title = "Bookmarks",
                        entries = if (activeTab?.isPrivate == true) emptyList() else bookmarks,
                        emptyText = "No bookmarks yet",
                        onBack = { if (!popRoute()) resetTo(Route.HOME) },
                        onOpen = { url -> openTarget(url) },
                        onDelete = { url ->
                            scope.launch {
                                val remaining = DhyraBookmarkManager.delete(bookmarks, url)
                                context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries(remaining) }
                            }
                        },
                        onEdit = { original, replacement ->
                            scope.launch {
                                val remaining = DhyraBookmarkManager.update(bookmarks, original.url, replacement)
                                context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries(remaining) }
                            }
                        },
                        onImport = { importBookmarksLauncher.launch(arrayOf("application/json", "text/json", "text/*")) },
                        onExport = { exportBookmarksLauncher.launch("dhyra-bookmarks.json") }
                    )

                    Route.HISTORY -> EntriesScreen(
                        title = "History",
                        entries = if (activeTab?.isPrivate == true) emptyList() else history,
                        emptyText = "No history yet",
                        onBack = { if (!popRoute()) resetTo(Route.HOME) },
                        onOpen = { url -> openTarget(url) },
                        onDelete = { url ->
                            scope.launch {
                                val remaining = DhyraHistoryManager.delete(history, url)
                                context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(remaining) }
                            }
                        },
                        onClearAll = {
                            scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                        }
                    )

                    Route.DOWNLOADS -> DownloadsScreen(
                        onBack = { if (!popRoute()) resetTo(Route.HOME) },
                        refreshKey = refreshDownloads
                    )
                    Route.ABOUT -> AboutScreen(
                        engineInfo = controller.engineInfo,
                        onBack = { if (!popRoute()) resetTo(Route.SETTINGS) }
                    )
                }
            }

            OmniboxOverlay(
                visible = omniboxOpen,
                value = omniboxValue,
                onValueChange = { onOmniboxChange(it) },
                items = omniItems,
                secure = pageSecure,
                onSubmit = { submitOmnibox() },
                onPick = { item -> openTarget(item.target()) },
                onFill = { item ->
                    val text = item.fillText()
                    omniboxValue = TextFieldValue(text, TextRange(text.length))
                },
                onDismiss = { closeOmnibox() }
            )

            SnackbarHost(
                hostState = snackbarHost,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 68.dp)
            ) { data ->
                Snackbar(
                    snackbarData = data,
                    shape = RoundedCornerShape(16.dp),
                    containerColor = cs.surfaceVariant,
                    contentColor = cs.onSurface,
                    actionColor = cs.primary
                )
            }

            AnimatedVisibility(
                visible = showOpeningIntro,
                modifier = Modifier.fillMaxSize(),
                enter = fadeIn(animationSpec = tween(130, easing = FastOutSlowInEasing)) +
                    scaleIn(
                        initialScale = 0.86f,
                        animationSpec = spring(dampingRatio = 0.78f, stiffness = 620f)
                    ),
                exit = fadeOut(animationSpec = tween(160, easing = FastOutLinearInEasing)) +
                    scaleOut(targetScale = 0.97f, animationSpec = tween(160, easing = FastOutSlowInEasing))
            ) {
                Box(
                    Modifier.fillMaxSize().background(cs.background),
                    contentAlignment = Alignment.Center
                ) {
                    DhyraMark(size = 64.dp)
                }
            }
        }

        if (showMenu) {
            MenuSheet(
                inPage = contentRoute == Route.BROWSER,
                isPrivate = activeTab?.isPrivate == true,
                desktop = activeTab?.isDesktop == true,
                readerMode = controller.readerModeActive,
                onDismiss = { showMenu = false },
                onToggleDesktop = { toggleDesktop() },
                onNewTab = { newTab(activeTab?.isPrivate == true) },
                onNewPrivate = { newTab(true) },
                onFind = { showFind = true },
                onTranslate = { translatePage() },
                onReader = { toggleReaderMode() },
                onPrint = { printPage() },
                onQr = { showQrDialog = true },
                onBurnPrivate = { burnPrivateSession() },
                onBookmark = { addBookmark() },
                onShare = { sharePage() },
                onAddSpeedDial = { addSpeedDial() },
                onBookmarks = { go(Route.BOOKMARKS) },
                onHistory = { go(Route.HISTORY) },
                onDownloads = {
                    refreshDownloads++
                    go(Route.DOWNLOADS)
                },
                onSettings = { go(Route.SETTINGS) }
            )
        }

        if (showShields) {
            ShieldsSheet(
                siteLabel = siteLabelOf(activeTab?.url),
                blocked = controller.blockedRequestCount(controller.activeTabId),
                tracking = state.tracking,
                shieldsEnabled = controller.shieldsEnabledForActiveSite(),
                popup = state.popup,
                onDismiss = { showShields = false },
                onSiteShieldsChange = { enabled -> controller.setShieldsEnabledForActiveSite(enabled) },
                onSave = { key, value -> saveValue(key, value) }
            )
        }

        pendingDownload?.let { request ->
            AlertDialog(
                onDismissRequest = { pendingDownload = null },
                containerColor = cs.surface,
                title = { Text("Download file?") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(request.fileName, style = MaterialTheme.typography.titleMedium, color = cs.onSurface)
                        Text("Source: ${request.origin}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        Text("Format: ${request.mimeType.ifBlank { "Unknown" }} · Size: determined during download", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        Text("Save location: Downloads", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        if (request.mayBeExecutable) {
                            Text("This file may install or run software. dhyra will not open or install it automatically. Only continue if you trust the source.", color = cs.error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        controller.startConfirmedDownload(request)
                        pendingDownload = null
                    }) { Text("Download") }
                },
                dismissButton = { TextButton(onClick = { pendingDownload = null }) { Text("Cancel") } }
            )
        }

        if (showTranslationSheet) {
            TranslationSheet(
                state = controller.translationState,
                initialSource = translationSource,
                initialTarget = translationTarget,
                onDismiss = { showTranslationSheet = false },
                onStart = { source, target, wifiOnly ->
                    translationSource = source
                    translationTarget = target
                    saveValue("translation_target", target)
                    controller.startTranslation(source, target, wifiOnly)
                },
                onPause = { controller.pauseTranslation() },
                onResume = { controller.resumeTranslation() },
                onRestore = { controller.restoreOriginalTranslation() }
            )
        }

        if (showQrDialog) {
            val qrUrl = activeTab?.url?.takeUnless { isBlankPage(it) }.orEmpty()
            AlertDialog(
                onDismissRequest = { showQrDialog = false },
                containerColor = cs.surface,
                title = { Text("Share page QR code") },
                text = {
                    if (qrUrl.isNotBlank()) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(
                                bitmap = remember(qrUrl) { makeQr(qrUrl) }.asImageBitmap(),
                                contentDescription = "QR code for the current page",
                                modifier = Modifier.size(220.dp)
                            )
                            Text(qrUrl, color = cs.onSurfaceVariant, fontSize = 12.sp, maxLines = 2)
                        }
                    } else Text("Open a web page to create its QR code.")
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (qrUrl.isNotBlank()) {
                            val clipboard = context.getSystemService(ClipboardManager::class.java)
                            clipboard?.setPrimaryClip(ClipData.newPlainText("dhyra link", qrUrl))
                        }
                        showQrDialog = false
                    }) { Text("Copy link") }
                },
                dismissButton = { TextButton(onClick = { showQrDialog = false }) { Text("Close") } }
            )
        }

        if (showSitePermissionDialog && pendingPermission != null) {
            val request = pendingPermission
            val origin = request?.origin?.toString() ?: "This website"
            val requestedResources = request?.resources?.joinToString { resource ->
                when (resource) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "camera"
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "microphone"
                    PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID -> "protected media / DRM"
                    else -> "unsupported resource"
                }
            } ?: "device resources"
            AlertDialog(
                containerColor = cs.surface,
                onDismissRequest = {
                    runCatching { request?.deny() }
                    pendingPermission = null
                    showSitePermissionDialog = false
                },
                title = { Text("Allow site permission?") },
                text = { Text("$origin is requesting: $requestedResources. Only approve sites you trust.") },
                confirmButton = {
                    TextButton(onClick = {
                        val current = pendingPermission
                        val resources = current?.resources.orEmpty()
                        val runtimePermissions = buildList {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in resources) add(android.Manifest.permission.CAMERA)
                            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in resources) add(android.Manifest.permission.RECORD_AUDIO)
                        }
                        if (runtimePermissions.isNotEmpty()) {
                            permissionLauncher.launch(runtimePermissions.distinct().toTypedArray())
                        } else {
                            val supported = resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }
                            if (supported.isNotEmpty()) runCatching { current?.grant(supported.toTypedArray()) }
                            else runCatching { current?.deny() }
                            pendingPermission = null
                            showSitePermissionDialog = false
                        }
                    }) { Text("Allow") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        runCatching { request?.deny() }
                        pendingPermission = null
                        showSitePermissionDialog = false
                    }) { Text("Block") }
                }
            )
        }

        if (showGeoPermissionDialog && pendingGeo != null) {
            val (origin, callback) = pendingGeo!!
            AlertDialog(
                containerColor = cs.surface,
                onDismissRequest = {
                    runCatching { callback.invoke(origin, false, false) }
                    pendingGeo = null
                    showGeoPermissionDialog = false
                },
                title = { Text("Allow location access?") },
                text = { Text("$origin is requesting your device location. This request is not saved for future visits.") },
                confirmButton = {
                    TextButton(onClick = {
                        val fineGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        val coarseGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        if (fineGranted || coarseGranted) {
                            runCatching { callback.invoke(origin, true, false) }
                            pendingGeo = null
                            showGeoPermissionDialog = false
                        } else {
                            locationLauncher.launch(arrayOf(
                                android.Manifest.permission.ACCESS_FINE_LOCATION,
                                android.Manifest.permission.ACCESS_COARSE_LOCATION
                            ))
                        }
                    }) { Text("Allow once") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        runCatching { callback.invoke(origin, false, false) }
                        pendingGeo = null
                        showGeoPermissionDialog = false
                    }) { Text("Block") }
                }
            )
        }
    }
}
