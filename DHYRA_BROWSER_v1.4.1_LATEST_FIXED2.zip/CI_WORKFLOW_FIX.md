# CI workflow hotfix

This package updates the GitHub Actions workflow to use `actions/setup-java@v5`, the valid `accept-android-sdk-licenses` input for Android SDK setup, install Android platform 35/build-tools 35.0.0/platform-tools, and verify the APK exists before upload. The invalid inputs `accept-android-sdk-license` and `accept-android-sdk-package-licenses` should not be used.
