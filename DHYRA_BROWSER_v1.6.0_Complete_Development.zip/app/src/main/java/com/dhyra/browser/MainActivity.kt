package com.dhyra.browser

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitHorizontalTouchSlopOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.DrawerState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.consume
import com.dhyra.browser.ui.gestures.DrawerGesturePolicy
import com.dhyra.browser.ui.components.FrostedSurface
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.DateFormat
import java.util.Date

private val Context.dhyraStore by preferencesDataStore(name = "dhyra_settings")
private val HOME_KEY = stringPreferencesKey("homepage")
private val ENGINE_KEY = stringPreferencesKey("search_engine")
private val THEME_KEY = stringPreferencesKey("theme")
private val MOOD_KEY = stringPreferencesKey("ambient_mood")
private val TRANSPARENCY_KEY = floatPreferencesKey("glass_transparency")
private val TRACKING_KEY = booleanPreferencesKey("tracking_protection")
private val POPUP_KEY = booleanPreferencesKey("popup_blocker")
private val DESKTOP_KEY = booleanPreferencesKey("desktop_mode")
private val HISTORY_KEY = stringPreferencesKey("history_json")
private val BOOKMARKS_KEY = stringPreferencesKey("bookmarks_json")
private val SESSION_KEY = stringPreferencesKey("regular_session_json")
private val FONT_COLOR_KEY = stringPreferencesKey("font_color_hex")
private val ACCENT_COLOR_KEY = stringPreferencesKey("accent_color_hex")
private val AUTO_CONTRAST_KEY = booleanPreferencesKey("auto_text_contrast")
private const val BTC_ADDRESS = "bc1qrdlrhldck8pz6mtcaths86htz3g3hjyhsa44q5"

private val AccentBright = Color(0xFF8175F2)
private val Cyan = Color(0xFF56C5CB)
private val Muted = Color(0xFF8290A6)
private val Ink = Color(0xFF172136)
private val LightCanvas = Color(0xFFF2F4FA)
private val DarkCanvas = Color(0xFF090E19)

private enum class Route { HOME, BROWSER, SETTINGS, TABS, BOOKMARKS, HISTORY, DOWNLOADS, SUPPORT, ABOUT }

private data class PreferencesState(
    val homepage: String = "https://www.google.com",
    val engine: String = "Google",
    val theme: String = "System",
    val transparency: Float = .78f,
    val tracking: Boolean = true,
    val popup: Boolean = true,
    val desktop: Boolean = false,
    val mood: String = "Morning Mist",
    val fontColorHex: String = "#172136",
    val accentColorHex: String = "#6557D9",
    val autoTextContrast: Boolean = true
)

private data class SavedPage(val title: String, val url: String, val timestamp: Long = System.currentTimeMillis())
private data class Shortcut(val label: String, val url: String, val symbol: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
        }
        setContent { DhyraApplication() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DhyraApplication() {
    val context = LocalContext.current
    val activity = context as ComponentActivity
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val density = LocalDensity.current
    val drawerEdgeWidthPx = with(density) { 24.dp.toPx() }
    val drawerOpenThresholdPx = with(density) { 52.dp.toPx() }

    var pendingFileChooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        pendingFileChooser?.onReceiveValue(uris.toTypedArray())
        pendingFileChooser = null
    }

    var pendingPermission by remember { mutableStateOf<PermissionRequest?>(null) }
    var pendingGeo by remember { mutableStateOf<Pair<String, GeolocationPermissions.Callback>?>(null) }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val pending = pendingGeo
        if (pending != null) {
            val allowed = results.values.any { it }
            pending.second.invoke(pending.first, allowed, false)
        }
        pendingGeo = null
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val request = pendingPermission
        if (request != null) {
            val granted = results.values.all { it }
            if (granted) request.grant(request.resources) else request.deny()
        }
        pendingPermission = null
    }

    val controller = remember(activity) {
        BrowserController(
            activity = activity,
            onFileChooser = { callback ->
                pendingFileChooser?.onReceiveValue(null)
                pendingFileChooser = callback
                filePicker.launch(arrayOf("*/*"))
            },
            onPermission = { request ->
                val requested = mutableListOf<String>()
                if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) requested += android.Manifest.permission.CAMERA
                if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) requested += android.Manifest.permission.RECORD_AUDIO
                if (requested.isEmpty()) request.deny()
                else {
                    pendingPermission = request
                    permissionLauncher.launch(requested.distinct().toTypedArray())
                }
            },
            onGeolocation = { origin, callback ->
                val fineGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                val coarseGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (fineGranted || coarseGranted) {
                    callback.invoke(origin, true, false)
                } else {
                    pendingGeo = origin to callback
                    locationLauncher.launch(arrayOf(
                        android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION
                    ))
                }
            }
        )
    }

    val browserSnapshot by controller.snapshot.collectAsState()
    val prefs by context.dhyraStore.data.collectAsState(
        initial = androidx.datastore.preferences.core.emptyPreferences()
    )
    val state = PreferencesState(
        homepage = prefs[HOME_KEY] ?: "https://www.google.com",
        engine = prefs[ENGINE_KEY] ?: "Google",
        theme = prefs[THEME_KEY] ?: "System",
        transparency = prefs[TRANSPARENCY_KEY] ?: .78f,
        tracking = prefs[TRACKING_KEY] ?: true,
        popup = prefs[POPUP_KEY] ?: true,
        desktop = prefs[DESKTOP_KEY] ?: false,
        mood = prefs[MOOD_KEY] ?: "Morning Mist",
        fontColorHex = prefs[FONT_COLOR_KEY] ?: "#172136",
        accentColorHex = prefs[ACCENT_COLOR_KEY] ?: "#6557D9",
        autoTextContrast = prefs[AUTO_CONTRAST_KEY] ?: true
    )
    val historyRaw = prefs[HISTORY_KEY] ?: "[]"
    val bookmarksRaw = prefs[BOOKMARKS_KEY] ?: "[]"
    val history = remember(historyRaw) { decodeEntries(historyRaw) }
    val bookmarks = remember(bookmarksRaw) { decodeEntries(bookmarksRaw) }

    var route by remember { mutableStateOf(Route.HOME) }
    var address by remember { mutableStateOf("") }
    var findText by remember { mutableStateOf("") }
    var showFind by remember { mutableStateOf(false) }
    var showBrowserMenu by remember { mutableStateOf(false) }
    var refreshDownloads by remember { mutableIntStateOf(0) }

    val isDark = when (state.theme) {
        "Dark" -> true
        "Light" -> false
        else -> state.mood == "Midnight Air" || isSystemInDarkTheme()
    }
    val moodPalette = com.dhyra.browser.ui.theme.MoodPreset.fromName(state.mood)
    val moodAccent = parseHexColor(state.accentColorHex, moodPalette.accent)
    val resolvedBackground = if (isDark) Color(0xFF101722) else if (state.mood == "Midnight Air") LightCanvas else moodPalette.canvasTop
    val resolvedSurface = if (isDark) Color(0xFF192536) else Color(0xFFFFFEFD)
    val automaticText = readableTextColor(resolvedBackground)
    val customText = parseHexColor(state.fontColorHex, automaticText)
    val preferredText = if (state.autoTextContrast) automaticText else ensureReadable(customText, resolvedBackground)
    val colorScheme = if (isDark) darkColorScheme(
        primary = moodAccent,
        secondary = moodAccent.copy(alpha = .82f),
        background = resolvedBackground,
        surface = resolvedSurface.copy(alpha = .96f),
        surfaceVariant = Color(0xFF253247),
        onSurface = preferredText,
        onBackground = preferredText,
        onSurfaceVariant = preferredText.copy(alpha = .78f)
    ) else lightColorScheme(
        primary = moodAccent,
        secondary = moodAccent.copy(alpha = .82f),
        background = resolvedBackground,
        surface = resolvedSurface.copy(alpha = .96f),
        surfaceVariant = Color(0xFFE8EDF7),
        onSurface = preferredText,
        onBackground = preferredText,
        onSurfaceVariant = preferredText.copy(alpha = .76f)
    )

    controller.onPageFinished = { tab ->
        if (!tab.isPrivate && (tab.url.startsWith("https://") || tab.url.startsWith("http://"))) {
            scope.launch {
                val currentRaw = context.dhyraStore.data.first()[HISTORY_KEY] ?: "[]"
                val current = decodeEntries(currentRaw)
                val updated = (listOf(SavedPage(tab.title, tab.url)) + current.filterNot { it.url == tab.url }).take(300)
                context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(updated) }
            }
        }
    }

    // Restore regular tabs from the last session; private tabs are never persisted.
    LaunchedEffect(controller) {
        val savedSession = decodeSession(context.dhyraStore.data.first()[SESSION_KEY] ?: "[]")
        if (savedSession.isNotEmpty()) savedSession.forEach { controller.createTab(it, isPrivate = false) }
        else if (browserSnapshot.tabs.isEmpty()) controller.createTab()
    }
    LaunchedEffect(browserSnapshot.tabs) {
        if (browserSnapshot.tabs.isNotEmpty()) {
            val urls = browserSnapshot.tabs.filterNot { it.isPrivate }
                .map { it.url }.filter { it.startsWith("http://") || it.startsWith("https://") }.takeLast(30)
            context.dhyraStore.edit { it[SESSION_KEY] = encodeSession(urls) }
        }
    }
    LaunchedEffect(state.tracking, state.popup, state.desktop) {
        controller.applySettings(state.tracking, state.popup, state.desktop)
    }
    DisposableEffect(controller) {
        onDispose {
            pendingFileChooser?.onReceiveValue(null)
            controller.destroy()
        }
    }
    DisposableEffect(activity, controller) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> controller.pause()
                Lifecycle.Event.ON_RESUME -> controller.resume()
                else -> Unit
            }
        }
        activity.lifecycle.addObserver(observer)
        onDispose { activity.lifecycle.removeObserver(observer) }
    }

    fun saveValue(key: String, value: Any) {
        scope.launch {
            context.dhyraStore.edit { p ->
                when (value) {
                    is String -> p[stringPreferencesKey(key)] = value
                    is Float -> p[floatPreferencesKey(key)] = value
                    is Boolean -> p[booleanPreferencesKey(key)] = value
                }
            }
        }
    }

    fun openTarget(raw: String, newTab: Boolean = false, isPrivate: Boolean = false) {
        val target = resolveAddress(raw, state.engine)
        if (newTab || browserSnapshot.activeTabId == -1) controller.createTab(target, isPrivate)
        else controller.navigate(target)
        address = target
        route = Route.BROWSER
    }

    fun addBookmark() {
        val tab = controller.activeTab() ?: return
        if (!tab.url.startsWith("http")) return
        scope.launch {
            val latestRaw = context.dhyraStore.data.first()[BOOKMARKS_KEY] ?: "[]"
            val latest = decodeEntries(latestRaw).filterNot { it.url == tab.url }
            context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries((listOf(SavedPage(tab.title, tab.url)) + latest).take(500)) }
        }
    }

    BackHandler(
        enabled = controller.isFullscreen || showBrowserMenu || showFind || drawerState.isOpen ||
            route != Route.HOME || (route == Route.BROWSER && controller.activeWebView()?.canGoBack() == true)
    ) {
        when {
            controller.isFullscreen -> controller.exitFullscreen()
            showBrowserMenu -> showBrowserMenu = false
            showFind -> { showFind = false; controller.activeWebView()?.clearMatches() }
            drawerState.isOpen -> scope.launch { drawerState.close() }
            route == Route.BROWSER && controller.activeWebView()?.canGoBack() == true -> controller.goBack()
            route != Route.HOME -> route = Route.HOME
            else -> Unit
        }
    }

    val refinedTypography = Typography(
        displayLarge = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Light, fontSize = 34.sp, lineHeight = 40.sp, letterSpacing = (-1.1).sp),
        headlineLarge = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 26.sp, lineHeight = 32.sp, letterSpacing = (-.55).sp),
        headlineMedium = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-.35).sp),
        titleLarge = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 24.sp),
        titleMedium = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 21.sp),
        bodyLarge = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
        bodyMedium = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 18.sp),
        bodySmall = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 11.sp, lineHeight = 16.sp),
        labelLarge = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = .1.sp)
    )
    MaterialTheme(colorScheme = colorScheme, typography = refinedTypography) {
        SideEffect {
            activity.window.statusBarColor = android.graphics.Color.TRANSPARENT
            activity.window.navigationBarColor = android.graphics.Color.TRANSPARENT
            WindowInsetsControllerCompat(activity.window, activity.window.decorView).apply {
                isAppearanceLightStatusBars = !isDark
                isAppearanceLightNavigationBars = !isDark
            }
        }
        Surface(
            Modifier.fillMaxSize().edgeDrawerGesture(
                drawerState = drawerState,
                scope = scope,
                enabled = DrawerGesturePolicy.EDGE_SWIPE_ENABLED && drawerState.targetValue == DrawerValue.Closed,
                edgeWidthPx = drawerEdgeWidthPx,
                openThresholdPx = drawerOpenThresholdPx
            ),
            color = MaterialTheme.colorScheme.background
        ) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = DrawerGesturePolicy.GESTURES_ENABLED && drawerState.targetValue == DrawerValue.Open,
                scrimColor = Color.Black.copy(alpha = .38f),
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = if (isDark) Color(0xFF111A2A).copy(alpha = .96f) else Color(0xFFF9FAFE).copy(alpha = .96f)
                    ) {
                        DrawerHeader(dark = isDark)
                        Spacer(Modifier.height(12.dp))
                        DrawerNavigationItem("Home", Icons.Default.Home, route == Route.HOME) { route = Route.HOME; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("Browse", Icons.Default.Public, route == Route.BROWSER) { route = Route.BROWSER; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("Tabs", Icons.Default.Tab, route == Route.TABS, "${browserSnapshot.tabs.size}") { route = Route.TABS; scope.launch { drawerState.close() } }
                        HorizontalDivider(Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .6f))
                        DrawerNavigationItem("Bookmarks", Icons.Default.Bookmarks, route == Route.BOOKMARKS) { route = Route.BOOKMARKS; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("History", Icons.Default.History, route == Route.HISTORY) { route = Route.HISTORY; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("Downloads", Icons.Default.Download, route == Route.DOWNLOADS) { refreshDownloads++; route = Route.DOWNLOADS; scope.launch { drawerState.close() } }
                        HorizontalDivider(Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .6f))
                        DrawerNavigationItem("Settings", Icons.Default.Tune, route == Route.SETTINGS) { route = Route.SETTINGS; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("Support DHYRA", Icons.Default.Favorite, route == Route.SUPPORT) { route = Route.SUPPORT; scope.launch { drawerState.close() } }
                        DrawerNavigationItem("About", Icons.Default.Info, route == Route.ABOUT) { route = Route.ABOUT; scope.launch { drawerState.close() } }
                        Spacer(Modifier.weight(1f))
                        Text("DHYRA BROWSER  •  1.6.0", modifier = Modifier.padding(horizontal = 24.dp, vertical = 22.dp), color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                    }
                }
            ) {
            when (route) {
                Route.HOME -> HomeScreen(
                    dark = isDark, mood = state.mood, onMood = { saveValue("ambient_mood", it) },
                    address = address, onAddressChange = { address = it },
                    onSearch = { openTarget(address) },
                    tabCount = browserSnapshot.tabs.size,
                    onMenu = { scope.launch { drawerState.open() } },
                    onOpenTabs = { route = Route.TABS },
                    onSettings = { route = Route.SETTINGS },
                    onBookmarks = { route = Route.BOOKMARKS },
                    onHistory = { route = Route.HISTORY },
                    onDownloads = { route = Route.DOWNLOADS },
                    onSupport = { route = Route.SUPPORT }
                )
                Route.BROWSER -> {
                    val active = controller.activeTab()
                    LaunchedEffect(active?.id, active?.url) {
                        active?.url?.takeIf { it != "about:blank" }?.let { address = it }
                    }
                    Column(Modifier.fillMaxSize()) {
                        SafariAddressBar(
                            address = address,
                            onAddress = { address = it },
                            onGo = { openTarget(address) },
                            onReload = { if (active?.loading == true) controller.stop() else controller.reload() },
                            secure = active?.url?.startsWith("https://") == true,
                            loading = active?.loading == true,
                            progress = active?.progress ?: 0,
                            dark = isDark,
                            glassOpacity = state.transparency
                        )
                        if (showFind) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = findText, onValueChange = { findText = it; controller.activeWebView()?.findAllAsync(it) },
                                    modifier = Modifier.weight(1f), singleLine = true, label = { Text("Find in page") }
                                )
                                IconButton(onClick = { showFind = false; controller.activeWebView()?.clearMatches() }) { Icon(Icons.Default.Close, null) }
                            }
                        }
                        AndroidView(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            factory = { ctx -> android.widget.FrameLayout(ctx).apply { controller.attach(this) } },
                            update = { controller.attach(it) }
                        )
                        BrowserBottomBar(
                            canBack = controller.activeWebView()?.canGoBack() == true,
                            canForward = controller.activeWebView()?.canGoForward() == true,
                            onBack = { controller.goBack() },
                            onForward = { controller.goForward() },
                            onHome = { route = Route.HOME },
                            onTabs = { route = Route.TABS },
                            tabCount = browserSnapshot.tabs.size,
                            onMenu = { showBrowserMenu = true },
                            dark = isDark,
                            glassOpacity = state.transparency
                        )
                        DropdownMenu(expanded = showBrowserMenu, onDismissRequest = { showBrowserMenu = false }) {
                            DropdownMenuItem(text = { Text("New tab") }, leadingIcon = { Icon(Icons.Default.Add, null) }, onClick = {
                                showBrowserMenu = false; controller.createTab(); route = Route.HOME
                            })
                            DropdownMenuItem(text = { Text("New private tab") }, leadingIcon = { Icon(Icons.Default.VisibilityOff, null) }, onClick = {
                                showBrowserMenu = false; controller.createTab(isPrivate = true); route = Route.HOME
                            })
                            DropdownMenuItem(text = { Text("Duplicate tab") }, leadingIcon = { Icon(Icons.Default.ContentCopy, null) }, onClick = {
                                showBrowserMenu = false; controller.duplicateTab(); route = Route.BROWSER
                            })
                            DropdownMenuItem(text = { Text("Close all tabs") }, leadingIcon = { Icon(Icons.Default.Close, null) }, onClick = {
                                showBrowserMenu = false; controller.closeAllTabs(); route = Route.HOME
                            })
                            DropdownMenuItem(text = { Text("Add bookmark") }, leadingIcon = { Icon(Icons.Default.BookmarkAdd, null) }, onClick = {
                                showBrowserMenu = false; addBookmark()
                            })
                            DropdownMenuItem(text = { Text("Bookmarks") }, leadingIcon = { Icon(Icons.Default.Bookmarks, null) }, onClick = {
                                showBrowserMenu = false; route = Route.BOOKMARKS
                            })
                            DropdownMenuItem(text = { Text("History") }, leadingIcon = { Icon(Icons.Default.History, null) }, onClick = {
                                showBrowserMenu = false; route = Route.HISTORY
                            })
                            DropdownMenuItem(text = { Text("Downloads") }, leadingIcon = { Icon(Icons.Default.Download, null) }, onClick = {
                                showBrowserMenu = false; refreshDownloads++; route = Route.DOWNLOADS
                            })
                            DropdownMenuItem(text = { Text("Find in page") }, leadingIcon = { Icon(Icons.Default.Search, null) }, onClick = {
                                showBrowserMenu = false; showFind = true
                            })
                            DropdownMenuItem(text = { Text("Share page") }, leadingIcon = { Icon(Icons.Default.Share, null) }, onClick = {
                                showBrowserMenu = false
                                val share = Intent(Intent.ACTION_SEND).setType("text/plain")
                                    .putExtra(Intent.EXTRA_TEXT, controller.activeTab()?.url ?: "")
                                context.startActivity(Intent.createChooser(share, "Share page"))
                            })
                            DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(Icons.Default.Settings, null) }, onClick = {
                                showBrowserMenu = false; route = Route.SETTINGS
                            })
                        }
                    }
                }
                Route.TABS -> TabsScreen(controller, tabs = browserSnapshot.tabs, activeTabId = browserSnapshot.activeTabId, dark = isDark, onBack = { route = Route.HOME }, onOpen = { route = Route.BROWSER }, onNew = {
                    controller.createTab(); route = Route.HOME
                })
                Route.SETTINGS -> SettingsScreen(state, onBack = { route = Route.HOME }, onSave = ::saveValue, onClear = {
                    controller.clearRegularData()
                    scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                })
                Route.BOOKMARKS -> EntriesScreen("Bookmarks", bookmarks, onBack = { route = Route.HOME }, onOpen = {
                    openTarget(it, newTab = true)
                }, onDelete = { url ->
                    scope.launch {
                        val remaining = bookmarks.filterNot { it.url == url }
                        context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries(remaining) }
                    }
                })
                Route.HISTORY -> EntriesScreen("History", history, onBack = { route = Route.HOME }, onOpen = {
                    openTarget(it, newTab = true)
                }, onDelete = { url ->
                    scope.launch {
                        val remaining = history.filterNot { it.url == url }
                        context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(remaining) }
                    }
                }, onClearAll = {
                    scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                })
                Route.DOWNLOADS -> DownloadsScreen(onBack = { route = Route.HOME }, refreshKey = refreshDownloads)
                Route.SUPPORT -> SupportScreen(onBack = { route = Route.HOME })
                Route.ABOUT -> AboutScreen(onBack = { route = Route.HOME })
            }
            }
        }
    }
}

/** Only a rightward drag that starts within the left edge strip opens the drawer.
 * Vertical WebView scrolling and horizontal carousels away from that strip remain untouched. */
@OptIn(ExperimentalFoundationApi::class)
private fun Modifier.edgeDrawerGesture(
    drawerState: DrawerState,
    scope: CoroutineScope,
    enabled: Boolean,
    edgeWidthPx: Float,
    openThresholdPx: Float
): Modifier = pointerInput(drawerState, enabled, edgeWidthPx, openThresholdPx) {
    if (!enabled) return@pointerInput
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        if (down.position.x > edgeWidthPx) return@awaitEachGesture

        var dragDistance = 0f
        val dragStart = awaitHorizontalTouchSlopOrCancellation(down.id) { change, overSlop ->
            dragDistance += overSlop
            change.consume()
        }
        if (dragStart != null) {
            while (true) {
                val event = awaitPointerEvent()
                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                val deltaX = change.positionChange().x
                dragDistance += deltaX
                if (deltaX != 0f) change.consume()
                if (!change.pressed) break
            }
            if (dragDistance >= openThresholdPx) {
                scope.launch { drawerState.open() }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    dark: Boolean, mood: String, onMood: (String) -> Unit,
    address: String, onAddressChange: (String) -> Unit,
    onSearch: () -> Unit,
    tabCount: Int, onMenu: () -> Unit, onOpenTabs: () -> Unit, onSettings: () -> Unit,
    onBookmarks: () -> Unit, onHistory: () -> Unit, onDownloads: () -> Unit,
    onSupport: () -> Unit
) {
    val keyboard = LocalSoftwareKeyboardController.current
    val presets = com.dhyra.browser.ui.theme.MoodPreset.all
    val palette = com.dhyra.browser.ui.theme.MoodPreset.fromName(mood)
    val animatedTop by animateColorAsState(palette.canvasTop, label = "ambientCanvasTop")
    val animatedBottom by animateColorAsState(palette.canvasBottom, label = "ambientCanvasBottom")
    val animatedAccent by animateColorAsState(MaterialTheme.colorScheme.primary, label = "ambientAccent")
    val shape = RoundedCornerShape(22.dp)
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(animatedTop, animatedBottom)))) {
        Box(Modifier.align(Alignment.TopEnd).padding(top = 95.dp, end = 6.dp).size(240.dp).clip(CircleShape)
            .background(Brush.radialGradient(listOf(animatedAccent.copy(alpha = .10f), Color.Transparent))))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onMenu, modifier = Modifier.size(44.dp)) { Icon(Icons.Default.Menu, "Open navigation") }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("DHYRA", fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.8.sp)
                    Text("BROWSER  /  iOS EDITION", fontSize = 8.sp, color = Muted, letterSpacing = 1.6.sp)
                }
                IconButton(onClick = onOpenTabs) { BadgedBox(badge = { if (tabCount > 0) Badge { Text(tabCount.toString()) } }) { Icon(Icons.Default.Tab, "Open tabs") } }
                IconButton(onClick = onSettings) { Icon(Icons.Default.Tune, "Settings") }
            }
            Spacer(Modifier.height(14.dp))
            Text("A little more\nroom to breathe.", fontSize = 30.sp, lineHeight = 35.sp, letterSpacing = (-1.2).sp,
                fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(12.dp))
            Text("The internet, at your pace.", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(24.dp))
            Surface(shape = shape, color = MaterialTheme.colorScheme.surface.copy(alpha = .76f), tonalElevation = 0.dp,
                shadowElevation = 10.dp, border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = if (dark) .14f else .8f)), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 17.dp, end = 8.dp, top = 7.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, null, tint = animatedAccent)
                    Spacer(Modifier.width(12.dp))
                    OutlinedTextField(value = address, onValueChange = onAddressChange, modifier = Modifier.weight(1f),
                        placeholder = { Text("Search the web or enter address", color = Muted, fontSize = 12.sp) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { keyboard?.hide(); onSearch() }),
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent, focusedContainerColor = Color.Transparent, cursorColor = palette.accent))
                    IconButton(onClick = { keyboard?.hide(); onSearch() }, modifier = Modifier.size(44.dp).clip(CircleShape).background(animatedAccent)) {
                        Icon(Icons.Default.ArrowForward, "Search", tint = Color.White)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("YOUR AMBIENCE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { preset ->
                    val selected = preset.name == mood
                    Surface(onClick = { onMood(preset.name) }, shape = RoundedCornerShape(18.dp),
                        color = if (selected) preset.accent.copy(alpha = .15f) else MaterialTheme.colorScheme.surface.copy(alpha = .58f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) preset.accent.copy(alpha = .48f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = .32f)),
                        modifier = Modifier.weight(1f)) {
                        Column(Modifier.padding(vertical = 12.dp, horizontal = 3.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(23.dp).clip(CircleShape).background(Brush.linearGradient(listOf(preset.canvasTop, preset.accent))))
                            Spacer(Modifier.height(7.dp))
                            Text(preset.shortName, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("A QUIETER START", color = Muted, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(5.dp))
                    Text("Pick up where you left off.", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
                TextButton(onClick = onOpenTabs) { Text("${tabCount} tabs") }
            }
            Spacer(Modifier.height(15.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AirAction(Icons.Default.Bookmarks, "Saved", onBookmarks, Modifier.weight(1f))
                AirAction(Icons.Default.History, "History", onHistory, Modifier.weight(1f))
                AirAction(Icons.Default.Download, "Downloads", onDownloads, Modifier.weight(1f))
            }
            Spacer(Modifier.height(20.dp))
            Surface(onClick = onSupport, shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .55f), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FavoriteBorder, null, tint = palette.accent)
                    Spacer(Modifier.width(12.dp)); Text("Support independent browsing", Modifier.weight(1f), fontSize = 12.sp)
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
            Spacer(Modifier.height(25.dp))
            Text("LESS NOISE. MORE SPACE.", Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = Muted.copy(alpha = .75f), fontSize = 9.sp, letterSpacing = 1.8.sp)
            Spacer(Modifier.height(25.dp))
        }
    }
}

@Composable
private fun AirAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(onClick = onClick, modifier = modifier.animateContentSize(), shape = RoundedCornerShape(19.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .65f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .35f))) {
        Column(Modifier.padding(vertical = 13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)); Spacer(Modifier.height(8.dp)); Text(label, fontSize = 11.sp)
        }
    }
}

@Composable
private fun GlassPanel(
    dark: Boolean,
    alpha: Float = .86f,
    radius: Shape = RoundedCornerShape(20.dp),
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val top = if (dark) Color(0xFF24334B).copy(alpha = alpha) else Color.White.copy(alpha = alpha)
    val bottom = if (dark) Color(0xFF172338).copy(alpha = alpha * .96f) else Color(0xFFF7F9FF).copy(alpha = alpha * .96f)
    Box(
        modifier.shadow(7.dp, radius, clip = false)
            .clip(radius)
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .border(1.dp, if (dark) Color.White.copy(alpha = .12f) else Color.White.copy(alpha = .9f), radius)
    ) {
        Box(
            Modifier.fillMaxWidth().height(1.dp).align(Alignment.TopCenter)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = if (dark) .18f else .72f), Color.Transparent)))
        )
        content()
    }
}

@Composable
private fun DrawerHeader(dark: Boolean) {
    Column(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = 22.dp, end = 18.dp, top = 18.dp, bottom = 20.dp)
    ) {
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, AccentBright, Cyan))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Public, null, tint = Color.White, modifier = Modifier.size(27.dp)) }
        Spacer(Modifier.height(14.dp))
        Text("DHYRA", fontWeight = FontWeight.ExtraBold, fontSize = 21.sp, letterSpacing = 2.4.sp)
        Text("A calmer way to explore.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun DrawerNavigationItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    trailing: String? = null,
    onClick: () -> Unit
) {
    NavigationDrawerItem(
        label = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, modifier = Modifier.weight(1f), fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, fontSize = 14.sp)
                if (trailing != null) Text(trailing, color = Muted, fontSize = 11.sp)
            }
        },
        icon = { Icon(icon, null, modifier = Modifier.size(20.dp)) },
        selected = selected,
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
        shape = RoundedCornerShape(14.dp),
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = .13f),
            selectedIconColor = MaterialTheme.colorScheme.primary,
            selectedTextColor = MaterialTheme.colorScheme.primary,
            unselectedIconColor = Muted,
            unselectedTextColor = MaterialTheme.colorScheme.onSurface
        )
    )
}

@Composable
private fun QuickAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    onClick: () -> Unit,
    modifier: Modifier,
    dark: Boolean
) {
    GlassPanel(
        dark = dark, alpha = .88f, radius = RoundedCornerShape(16.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
            Spacer(Modifier.height(5.dp))
            Text(text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun SafariAddressBar(
    address: String,
    onAddress: (String) -> Unit,
    onGo: () -> Unit,
    onReload: () -> Unit,
    secure: Boolean,
    loading: Boolean,
    progress: Int,
    dark: Boolean,
    glassOpacity: Float
) {
    val keyboard = LocalSoftwareKeyboardController.current
    val clipboard = LocalClipboardManager.current
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val shownAddress = if (focused) address else cleanDomain(address)
    Column(
        Modifier.fillMaxWidth()
            .background(MaterialTheme.colorScheme.background.copy(alpha = .76f))
    ) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FrostedSurface(
                modifier = Modifier.weight(1f).height(48.dp),
                radius = 16.dp,
                dark = dark,
                opacity = if (focused) 1f else glassOpacity
            ) {
                Row(
                    Modifier.fillMaxSize().padding(start = 12.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (secure) Icons.Default.Lock else Icons.Default.Language,
                        contentDescription = if (secure) "Secure connection" else "Site information",
                        tint = if (secure) Color(0xFF2E9B72) else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(9.dp))
                    BasicTextField(
                        value = shownAddress,
                        onValueChange = onAddress,
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 13.sp
                        ),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = {
                            keyboard?.hide()
                            onGo()
                        }),
                        interactionSource = interaction,
                        decorationBox = { innerTextField ->
                            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                                if (shownAddress.isBlank()) {
                                    Text("Search or enter website", color = Muted, fontSize = 12.sp, maxLines = 1)
                                }
                                innerTextField()
                            }
                        }
                    )
                    if (focused && shownAddress.isNotBlank()) {
                        IconButton(onClick = { onAddress("") }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Default.Close, "Clear address", modifier = Modifier.size(16.dp))
                        }
                    }
                    IconButton(
                        onClick = {
                            keyboard?.hide()
                            onReload()
                        },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            if (loading) Icons.Default.Close else Icons.Default.Refresh,
                            contentDescription = if (loading) "Stop loading" else "Reload page",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
        Box(
            Modifier.fillMaxWidth().height(2.dp)
                .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = .18f))
        ) {
            if (loading) {
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0, 100) / 100f },
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color.Transparent
                )
            }
        }
    }
}

@Composable
private fun BrowserBottomBar(
    canBack: Boolean,
    canForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onHome: () -> Unit,
    onTabs: () -> Unit,
    tabCount: Int,
    onMenu: () -> Unit,
    dark: Boolean,
    glassOpacity: Float
) {
    Box(
        Modifier.fillMaxWidth()
            .background(MaterialTheme.colorScheme.background.copy(alpha = .78f))
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) {
        FrostedSurface(
            modifier = Modifier.fillMaxWidth().height(48.dp),
            radius = 17.dp,
            dark = dark,
            opacity = glassOpacity
        ) {
            Row(
                Modifier.fillMaxSize().padding(horizontal = 7.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, enabled = canBack, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = if (canBack) MaterialTheme.colorScheme.onSurface else Muted.copy(alpha = .45f), modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onForward, enabled = canForward, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.ArrowForward, "Forward", tint = if (canForward) MaterialTheme.colorScheme.onSurface else Muted.copy(alpha = .45f), modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onHome, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.Home, "Home", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(21.dp))
                }
                IconButton(onClick = onTabs, modifier = Modifier.size(40.dp)) {
                    BadgedBox(badge = { Badge { Text(tabCount.coerceAtMost(99).toString()) } }) {
                        Icon(Icons.Default.Tab, "Tabs", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(20.dp))
                    }
                }
                IconButton(onClick = onMenu, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.MoreHoriz, "More", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
                }
            }
        }
    }
}

@Composable
private fun TabsScreen(controller: BrowserController, tabs: List<BrowserTab>, activeTabId: Int, dark: Boolean, onBack: () -> Unit, onOpen: () -> Unit, onNew: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val visibleTabs = remember(tabs, query) { tabs.filter { query.isBlank() || it.title.contains(query, true) || it.url.contains(query, true) } }
    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .48f)))
        ).statusBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 10.dp, end = 12.dp, top = 9.dp, bottom = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text("Your tabs", fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.5).sp)
                Text("${tabs.size} open ${if (tabs.size == 1) "tab" else "tabs"}", color = Muted, fontSize = 11.sp)
            }
            TextButton(onClick = { controller.closeAllTabs() }) { Text("Close all") }
            Button(onClick = onNew, shape = RoundedCornerShape(15.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("New")
            }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            singleLine = true, placeholder = { Text("Search tabs") },
            leadingIcon = { Icon(Icons.Default.Search, null) }
        )
        if (tabs.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No open tabs", color = Muted) }
        } else LazyColumn(
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            items(visibleTabs, key = { it.id }) { tab ->
                val active = tab.id == activeTabId
                FrostedSurface(
                    modifier = Modifier.fillMaxWidth().clickable { controller.selectTab(tab.id); onOpen() },
                    radius = 16.dp,
                    dark = dark,
                    opacity = if (active) .98f else .88f
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Box(
                            Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(15.dp))
                                .background(
                                    Brush.linearGradient(
                                        if (dark) listOf(Color(0xFF202C43), Color(0xFF17243A), Color(0xFF25314B))
                                        else listOf(Color(0xFFE6EAF7), Color(0xFFF3F4FB), Color(0xFFDCE7F4))
                                    )
                                )
                        ) {
                            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(if (tab.isPrivate) Icons.Default.VisibilityOff else Icons.Default.Language, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(25.dp))
                                Spacer(Modifier.height(5.dp))
                                Text(if (tab.isPrivate) "Private browsing" else "DHYRA tab preview", color = Muted, fontSize = 10.sp)
                            }
                            if (active) {
                                Surface(Modifier.align(Alignment.TopStart).padding(8.dp), color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(8.dp)) {
                                    Text("ACTIVE", Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                                }
                            }
                            IconButton(
                                onClick = { controller.duplicateTab(tab.id) },
                                modifier = Modifier.align(Alignment.TopEnd).padding(top = 5.dp, end = 43.dp).size(32.dp)
                                    .clip(CircleShape).background(MaterialTheme.colorScheme.surface.copy(alpha = .88f))
                            ) { Icon(Icons.Default.ContentCopy, "Duplicate tab", modifier = Modifier.size(15.dp)) }
                            IconButton(
                                onClick = { controller.closeTab(tab.id) },
                                modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).size(32.dp)
                                    .clip(CircleShape).background(MaterialTheme.colorScheme.surface.copy(alpha = .88f))
                            ) { Icon(Icons.Default.Close, "Close tab", modifier = Modifier.size(17.dp)) }
                            if (tab.loading) LinearProgressIndicator(
                                progress = { tab.progress.coerceIn(0, 100) / 100f },
                                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp), color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(Modifier.height(11.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tab.title.ifBlank { "New tab" }, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(tab.url, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (tab.isPrivate) Icon(Icons.Default.VisibilityOff, "Private tab", tint = Muted, modifier = Modifier.padding(start = 8.dp).size(17.dp))
                            Icon(Icons.Default.ChevronRight, null, tint = Muted, modifier = Modifier.padding(start = 4.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    prefs: PreferencesState, onBack: () -> Unit,
    onSave: (String, Any) -> Unit, onClear: () -> Unit
) {
    var homepage by remember(prefs.homepage) { mutableStateOf(prefs.homepage) }
    var engine by remember(prefs.engine) { mutableStateOf(prefs.engine) }
    var theme by remember(prefs.theme) { mutableStateOf(prefs.theme) }
    var transparency by remember(prefs.transparency) { mutableFloatStateOf(prefs.transparency) }
    var autoContrast by remember(prefs.autoTextContrast) { mutableStateOf(prefs.autoTextContrast) }
    var fontColorHex by remember(prefs.fontColorHex) { mutableStateOf(prefs.fontColorHex) }
    var accentColorHex by remember(prefs.accentColorHex) { mutableStateOf(prefs.accentColorHex) }
    var engineExpanded by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                Column {
                    Text("Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Customize your browsing", color = Muted, fontSize = 11.sp)
                }
            }
        }
        item {
            SettingsCard("APPEARANCE", Icons.Default.Palette) {
                Text("Theme mode", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("Light", "Dark", "System").forEach { mode ->
                        FilterChip(selected = theme == mode, onClick = { theme = mode; onSave("theme", mode) }, label = { Text(mode) })
                    }
                }
                Text("Ambient mood", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    com.dhyra.browser.ui.theme.MoodPreset.all.forEach { preset ->
                        FilterChip(selected = prefs.mood == preset.name, onClick = { onSave("ambient_mood", preset.name) }, label = { Text(preset.shortName, fontSize = 10.sp) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Glass transparency", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Text("${(transparency * 100).toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
                Slider(value = transparency, onValueChange = { transparency = it }, valueRange = .2f..1f, onValueChangeFinished = { onSave("glass_transparency", transparency) })
            }
        }
        item {
            SettingsCard("COLOR & CONTRAST", Icons.Default.ColorLens) {
                PreferenceSwitch(
                    "Automatic text contrast",
                    "Choose readable text automatically for the active light or dark palette",
                    autoContrast
                ) { enabled ->
                    autoContrast = enabled
                    onSave("auto_text_contrast", enabled)
                }
                Text("Accent color", fontWeight = FontWeight.SemiBold)
                ColorEditor(
                    title = "Accent RGB / HEX",
                    initialHex = accentColorHex,
                    onColorChanged = { accentColorHex = it },
                    onCommit = { onSave("accent_color_hex", it) }
                )
                Text("Custom font color", fontWeight = FontWeight.SemiBold)
                ColorEditor(
                    title = "Font RGB / HEX",
                    initialHex = fontColorHex,
                    onColorChanged = { fontColorHex = it },
                    onCommit = { onSave("font_color_hex", it) },
                    enabled = !autoContrast
                )
                Text(
                    if (autoContrast) "Automatic contrast is active. Turn it off to apply your custom font color." else "Custom font color is active.",
                    color = Muted,
                    fontSize = 10.sp
                )
            }
        }
        item {
            SettingsCard("SEARCH & HOMEPAGE", Icons.Default.Search) {
                Text("Default search engine", fontWeight = FontWeight.SemiBold)
                Box {
                    OutlinedButton(onClick = { engineExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(engine, Modifier.weight(1f)); Icon(Icons.Default.ExpandMore, null)
                    }
                    DropdownMenu(engineExpanded, { engineExpanded = false }) {
                        listOf("Google", "Bing", "DuckDuckGo", "Yahoo", "Ecosia").forEach { choice ->
                            DropdownMenuItem(text = { Text(choice) }, onClick = { engine = choice; engineExpanded = false; onSave("search_engine", choice) })
                        }
                    }
                }
                Text("Homepage URL", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(homepage, { homepage = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("https://example.com") })
                Button(onClick = {
                    val normalized = normalizeHomepage(homepage)
                    homepage = normalized
                    onSave("homepage", normalized)
                }, modifier = Modifier.fillMaxWidth()) { Text("Save homepage") }
            }
        }
        item {
            SettingsCard("PRIVACY & SECURITY", Icons.Default.Shield) {
                PreferenceSwitch("Basic tracker blocking", "Blocks a small set of known ad/tracker hosts", prefs.tracking) { onSave("tracking_protection", it) }
                HorizontalDivider()
                PreferenceSwitch("Popup blocker", "Blocks new windows unless you turn this off", prefs.popup) { onSave("popup_blocker", it) }
                HorizontalDivider()
                PreferenceSwitch("Desktop site", "Request desktop user agent", prefs.desktop) { onSave("desktop_mode", it) }
                OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.DeleteSweep, null); Spacer(Modifier.width(7.dp)); Text("Clear cookies, cache & history")
                }
                Text("Tracker blocking is a lightweight built-in list, not a full ad-blocking filter engine.", color = Muted, fontSize = 10.sp)
            }
        }
        item {
            SettingsCard("ABOUT", Icons.Default.Info) {
                Text("DHYRA Browser 1.5.2", fontWeight = FontWeight.Bold)
                Text("Android browser powered by Android System WebView (Chromium-based).", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ColorEditor(
    title: String,
    initialHex: String,
    onColorChanged: (String) -> Unit,
    onCommit: (String) -> Unit,
    enabled: Boolean = true
) {
    var hex by remember(initialHex) { mutableStateOf(normalizeHex(initialHex)) }
    val color = parseHexColor(hex, Color(0xFF6557D9))
    val argb = color.toArgb()
    val red = android.graphics.Color.red(argb).toFloat()
    val green = android.graphics.Color.green(argb).toFloat()
    val blue = android.graphics.Color.blue(argb).toFloat()

    fun update(r: Float = red, g: Float = green, b: Float = blue) {
        val next = "#%02X%02X%02X".format(r.toInt().coerceIn(0, 255), g.toInt().coerceIn(0, 255), b.toInt().coerceIn(0, 255))
        hex = next
        onColorChanged(next)
    }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(color).border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape))
            Spacer(Modifier.width(9.dp))
            OutlinedTextField(
                value = hex,
                onValueChange = { raw ->
                    val candidate = raw.uppercase().filter { it == '#' || it.isDigit() || it in 'A'..'F' }.take(7)
                    hex = candidate
                    if (candidate.matches(Regex("^#[0-9A-F]{6}$"))) onColorChanged(candidate)
                },
                modifier = Modifier.weight(1f),
                enabled = enabled,
                singleLine = true,
                label = { Text(title) },
                textStyle = MaterialTheme.typography.bodySmall,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    if (hex.matches(Regex("^#[0-9A-Fa-f]{6}$"))) onCommit(hex.uppercase())
                })
            )
            TextButton(
                enabled = enabled && hex.matches(Regex("^#[0-9A-Fa-f]{6}$")),
                onClick = { onCommit(hex.uppercase()) }
            ) { Text("Apply") }
        }
        Text("Red  ${red.toInt()}", color = Muted, fontSize = 10.sp)
        Slider(
            value = red,
            onValueChange = { update(r = it) },
            onValueChangeFinished = { onCommit(hex) },
            valueRange = 0f..255f,
            enabled = enabled
        )
        Text("Green  ${green.toInt()}", color = Muted, fontSize = 10.sp)
        Slider(
            value = green,
            onValueChange = { update(g = it) },
            onValueChangeFinished = { onCommit(hex) },
            valueRange = 0f..255f,
            enabled = enabled
        )
        Text("Blue  ${blue.toInt()}", color = Muted, fontSize = 10.sp)
        Slider(
            value = blue,
            onValueChange = { update(b = it) },
            onValueChangeFinished = { onCommit(hex) },
            valueRange = 0f..255f,
            enabled = enabled
        )
    }
}

@Composable
private fun SettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    GlassPanel(dark = MaterialTheme.colorScheme.background.luminance() < .42f, alpha = .94f, radius = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
            }
            content()
        }
    }
}

@Composable
private fun PreferenceSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun EntriesScreen(
    title: String, entries: List<SavedPage>, onBack: () -> Unit,
    onOpen: (String) -> Unit, onDelete: (String) -> Unit, onClearAll: (() -> Unit)? = null
) {
    var query by remember(title) { mutableStateOf("") }
    val visibleEntries = remember(entries, query) {
        entries.filter { query.isBlank() || it.title.contains(query, true) || it.url.contains(query, true) }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text(title, Modifier.weight(1f), fontSize = 21.sp, fontWeight = FontWeight.Bold)
            if (onClearAll != null) TextButton(onClick = onClearAll) { Text("Clear") }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            singleLine = true, placeholder = { Text("Search $title") },
            leadingIcon = { Icon(Icons.Default.Search, null) }
        )
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nothing here yet", color = Muted) }
        } else if (visibleEntries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No matching items", color = Muted) }
        } else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(visibleEntries, key = { it.url }) { entry ->
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(19.dp), shadowElevation = 1.dp) {
                    Row(Modifier.clickable { onOpen(entry.url) }.padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(entry.url, color = Muted, fontSize = 10.sp, maxLines = 1)
                            if (title == "History") Text(DateFormat.getDateTimeInstance().format(Date(entry.timestamp)), color = Muted, fontSize = 9.sp)
                        }
                        IconButton(onClick = { onDelete(entry.url) }) { Icon(Icons.Default.DeleteOutline, "Remove") }
                    }
                }
            }
        }
    }
}

@Composable
private fun DownloadsScreen(onBack: () -> Unit, refreshKey: Int) {
    val context = LocalContext.current
    var rows by remember { mutableStateOf(emptyList<DownloadRow>()) }
    fun load() {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = manager.query(DownloadManager.Query())
        val result = mutableListOf<DownloadRow>()
        cursor?.use { c ->
            val idCol = c.getColumnIndex(DownloadManager.COLUMN_ID)
            val titleCol = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
            val statusCol = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val totalCol = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val soFarCol = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val status = c.getInt(statusCol)
                val title = c.getString(titleCol) ?: "Download"
                val total = c.getLong(totalCol)
                val soFar = c.getLong(soFarCol)
                result += DownloadRow(id, title, statusLabel(status), total, soFar)
            }
        }
        rows = result
    }
    LaunchedEffect(refreshKey) { load() }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Downloads", Modifier.weight(1f), fontSize = 21.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = { load() }) { Icon(Icons.Default.Refresh, "Refresh") }
        }
        if (rows.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No downloads yet", color = Muted) }
        else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(rows, key = { it.id }) { row ->
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(19.dp), shadowElevation = 1.dp) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.InsertDriveFile, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(row.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text("${row.status} • ${formatBytes(row.downloaded)} / ${if (row.total > 0) formatBytes(row.total) else "—"}", color = Muted, fontSize = 10.sp)
                        }
                        IconButton(onClick = {
                            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            runCatching {
                                val uri = manager.getUriForDownloadedFile(row.id)
                                if (uri != null) {
                                    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, context.contentResolver.getType(uri))
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    context.startActivity(intent)
                                }
                            }
                        }) { Icon(Icons.Default.OpenInNew, "Open") }
                        IconButton(onClick = {
                            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(row.id)
                            load()
                        }) { Icon(Icons.Default.DeleteOutline, "Delete") }
                    }
                }
            }
        }
    }
}

private data class DownloadRow(val id: Long, val title: String, val status: String, val total: Long, val downloaded: Long)

private fun statusLabel(status: Int): String = when (status) {
    DownloadManager.STATUS_PENDING -> "Pending"
    DownloadManager.STATUS_RUNNING -> "Downloading"
    DownloadManager.STATUS_PAUSED -> "Paused"
    DownloadManager.STATUS_SUCCESSFUL -> "Completed"
    DownloadManager.STATUS_FAILED -> "Failed"
    else -> "Unknown"
}

private fun formatBytes(value: Long): String {
    if (value < 1024) return "$value B"
    if (value < 1024 * 1024) return "%.1f KB".format(value / 1024f)
    return "%.1f MB".format(value / (1024f * 1024f))
}

@Composable
private fun SupportScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val qr = remember { makeQr("bitcoin:$BTC_ADDRESS") }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
        Icon(Icons.Default.Favorite, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
        Text("Support DHYRA", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Contribute voluntarily to support future development.", color = Muted)
        Surface(shape = RoundedCornerShape(22.dp), color = Color.White, shadowElevation = 3.dp) {
            Image(qr.asImageBitmap(), null, Modifier.padding(13.dp).size(216.dp))
        }
        Text(BTC_ADDRESS, fontSize = 11.sp)
        Button(onClick = {
            clipboard.setText(AnnotatedString(BTC_ADDRESS))
            android.widget.Toast.makeText(context, "Bitcoin address copied", android.widget.Toast.LENGTH_SHORT).show()
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(7.dp)); Text("Copy address") }
        OutlinedButton(onClick = {
            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("bitcoin:$BTC_ADDRESS"))) }
                .onFailure { android.widget.Toast.makeText(context, "No compatible wallet found", android.widget.Toast.LENGTH_SHORT).show() }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AccountBalanceWallet, null); Spacer(Modifier.width(7.dp)); Text("Open Bitcoin wallet") }
        Text("Verify the address and Bitcoin network before sending.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun AboutScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
        Spacer(Modifier.height(50.dp))
        Box(Modifier.size(82.dp).clip(RoundedCornerShape(27.dp)).background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, Cyan))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Public, null, tint = Color.White, modifier = Modifier.size(46.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("DHYRA BROWSER", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        Text("Version 1.6.0", color = Muted)
        Spacer(Modifier.height(18.dp))
        Text("An elegant Android browser powered by Android System WebView.", color = Muted)
    }
}

private fun makeQr(payload: String): Bitmap {
    val matrix = com.google.zxing.qrcode.QRCodeWriter().encode(payload, com.google.zxing.BarcodeFormat.QR_CODE, 560, 560)
    return Bitmap.createBitmap(560, 560, Bitmap.Config.ARGB_8888).also { bmp ->
        for (x in 0 until 560) for (y in 0 until 560) {
            bmp.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
}

private fun normalizeHex(value: String): String {
    val cleaned = value.trim().uppercase().removePrefix("#")
    return if (cleaned.matches(Regex("^[0-9A-F]{6}$"))) "#$cleaned" else "#6557D9"
}

private fun parseHexColor(value: String, fallback: Color): Color = runCatching {
    Color(android.graphics.Color.parseColor(normalizeHex(value)))
}.getOrDefault(fallback)

private fun readableTextColor(background: Color): Color {
    fun channel(value: Float): Float = if (value <= .04045f) value / 12.92f else Math.pow(((value + .055f) / 1.055f).toDouble(), 2.4).toFloat()
    val luminance = .2126f * channel(background.red) + .7152f * channel(background.green) + .0722f * channel(background.blue)
    return if (luminance > .48f) Color(0xFF18202D) else Color(0xFFF5F7FC)
}

private fun ensureReadable(foreground: Color, background: Color, minimumRatio: Double = 4.5): Color {
    fun luminance(color: Color): Double {
        fun channel(value: Float): Double {
            val c = value.toDouble()
            return if (c <= 0.04045) c / 12.92 else Math.pow((c + 0.055) / 1.055, 2.4)
        }
        return 0.2126 * channel(color.red) + 0.7152 * channel(color.green) + 0.0722 * channel(color.blue)
    }
    val fg = luminance(foreground)
    val bg = luminance(background)
    val ratio = (maxOf(fg, bg) + 0.05) / (minOf(fg, bg) + 0.05)
    if (ratio >= minimumRatio) return foreground
    val black = Color(0xFF111827)
    val white = Color(0xFFF9FAFB)
    val blackRatio = (bg + 0.05) / (luminance(black) + 0.05)
    val whiteRatio = (luminance(white) + 0.05) / (bg + 0.05)
    return if (blackRatio >= whiteRatio) black else white
}

private fun cleanDomain(value: String): String {
    if (value.isBlank() || value == "about:blank") return ""
    return runCatching {
        val uri = Uri.parse(value)
        val host = uri.host ?: return@runCatching value
        host.removePrefix("www.")
    }.getOrDefault(value)
}

private fun resolveAddress(input: String, engine: String): String {
    val value = input.trim()
    if (value.isBlank()) return "https://www.google.com"
    if (value.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))) return value
    if (value.contains(".") && !value.contains(" ")) return "https://$value"
    val query = URLEncoder.encode(value, "UTF-8")
    val endpoint = when (engine) {
        "Bing" -> "https://www.bing.com/search?q="
        "DuckDuckGo" -> "https://duckduckgo.com/?q="
        "Yahoo" -> "https://search.yahoo.com/search?p="
        "Ecosia" -> "https://www.ecosia.org/search?q="
        else -> "https://www.google.com/search?q="
    }
    return endpoint + query
}

private fun normalizeHomepage(value: String): String {
    val raw = value.trim()
    return when {
        raw.startsWith("https://", true) || raw.startsWith("http://", true) -> raw
        raw.isBlank() -> "https://www.google.com"
        else -> "https://$raw"
    }
}

private fun decodeSession(raw: String): List<String> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        array.optString(index).takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }
}.getOrDefault(emptyList())

private fun encodeSession(urls: List<String>): String {
    val array = JSONArray()
    urls.forEach { array.put(it) }
    return array.toString()
}

private fun decodeEntries(raw: String): List<SavedPage> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val obj = array.optJSONObject(index) ?: return@mapNotNull null
        val url = obj.optString("url")
        if (url.isBlank()) null else SavedPage(
            title = obj.optString("title", url),
            url = url,
            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
        )
    }
}.getOrDefault(emptyList())

private fun encodeEntries(entries: List<SavedPage>): String {
    val array = JSONArray()
    entries.forEach { entry ->
        array.put(JSONObject().put("title", entry.title).put("url", entry.url).put("timestamp", entry.timestamp))
    }
    return array.toString()
}
