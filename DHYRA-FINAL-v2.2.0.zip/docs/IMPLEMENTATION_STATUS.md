# DHYRA Browser — Implementation Status

This describes the source implementation in this archive. It is not a statement of device certification or production readiness.

## Project architecture and toolchain

- Kotlin 2.4.21, AGP 9.3.1, Gradle 9.5.1, JDK 21 in CI, JVM target 17.
- compileSdk 37.1, targetSdk 36, minSdk 26; app version 2.2.0 (versionCode 14).
- Jetpack Compose Material 3, Compose BOM 2026.11.01, Activity Compose 1.13.0, Lifecycle 2.10.0, Core KTX 1.19.0, Preferences DataStore 1.2.1 and AndroidX WebKit 1.17.1.
- Android System WebView is the rendering backend. `DhyraEngine` is the app-owned facade for provider information and WebView creation; DHYRA owns policy, sessions, navigation, tabs, privacy controls and UI. This is not a standalone Chromium rendering engine.
- MainActivity and BrowserController remain large coordinator classes. The project is not yet a multi-module MVVM/Room/DI architecture.

## Implemented in source

- Premium, responsive Compose UI with system, dynamic, light, dark and AMOLED themes; shared spacing/shape/motion tokens; top-positioned address bar; adaptive Home speed dial and tab grid.
- Application branding uses DHYRA in the launcher label, launcher vector, app screens and browser interactions.
- Google is the default first-run search engine. Built-in search templates include Google, Bing, DuckDuckGo, Yahoo, Ecosia, Startpage, Qwant and Brave. Custom search templates require HTTPS, a valid host and exactly one `{query}` placeholder.
- Address navigation validates HTTP(S) host and rejects user-info credentials. Unknown schemes are not executed; they are treated as search text. Invalid custom search settings fail back to Google.
- Home speed-dial additions, edits and removals are supported within the existing eight-shortcut limit. Recently visited pages are shown in the start page.
- `DhyraDesktopModeManager` maintains per-tab mode, preserves the runtime Chromium token in the desktop Linux UA, configures wide viewport/overview/zoom behavior, and reapplies mode after recreation/session restore. Sites may ignore the desktop request or force a device-width viewport.
- `DhyraWebViewController` applies shared settings/security policy and detaches callbacks/views before destroying inactive/closed WebViews. It permits user-selected `content://` URIs for Android file pickers while disallowing `file://` access and blocking top-level `content://` navigation; media with sound requires a user gesture. The browser caps live WebViews and freezes/restores background tabs; renderer-gone callbacks recover from a crashed renderer.
- `DhyraTabManager` contains pure close/selection policy. Closing one tab group preserves a surviving tab from the other group; regular group close supports Undo, private group close requires confirmation and private tabs are not restored.
- `DhyraSessionManager` stores regular tab URL/title/desktop mode; private tabs are deliberately excluded. Undo of regular Close All also preserves each tab's desktop-mode preference.
- `DhyraCookieManager` and `DhyraCacheManager` keep regular-profile cookie/WebStorage clearing separate from the named private profile. The app intentionally avoids `WebView.clearCache(true)` because it may be app-wide on some providers; therefore a complete HTTP disk-cache wipe is not claimed. Private mode is enabled only when the installed WebView supports named profiles and profile-scoped data deletion; attachment/cleanup failures fail closed.
- `DhyraDownloadManager` uses Android DownloadManager for public downloads, validates HTTP(S), sanitises the leaf filename and passes cookies/user-agent for regular browsing. The UI displays state/progress and can open completed files.
- `DhyraHistoryManager` records and searches history; History is grouped by visit date and supports deletion/clear all. `DhyraBookmarkManager` adds, edits, searches through UI, deletes, and preserves JSON import/export. Persistence remains Preferences DataStore JSON to preserve existing user data.
- `DhyraPermissionManager` allowlists WebView camera, microphone and protected-media resource types. The host prompts for Android runtime permissions; private tabs deny device permission requests. Geolocation prompts are separate and not persisted as permanent grants.
- On-device translation is integrated through the `TranslationProvider` interface, Google ML Kit Translate and Language Identification, bounded queues, batch/retry controls and a nonce/origin-validated AndroidX WebMessageListener bridge. The page script changes eligible TextNodes only and can restore original text conditionally.
- Find-in-page, back/forward/reload/stop, bookmark, share, download, history, print/PDF, QR, CSS Reader Mode, private profile and per-tab desktop-site entry points exist in the current UI.
- GitHub Actions checks the source archive, runs Node translation tests and Compose/source contracts, sets JDK/Android SDK/Gradle, generates a standard wrapper, then runs Android unit tests, lint and debug APK build. Optional release APK is unsigned unless secrets-based signing is configured.

## Deliberate limitations (not advertised as complete)

- WebView/Chromium rendering is supplied by Android System WebView. DHYRA does not compile or ship a custom Chromium engine, and supported web platform behavior follows the device provider.
- Desktop mode is a best-effort request using UA + viewport/overview settings. It cannot guarantee desktop layout, full viewport parity, desktop-only features, or prevent a site from choosing its mobile responsive layout.
- Translation is user-triggered. It has no always-translate-language or never-translate-site persistence policy UI. It requires eligible HTTPS pages and supported ML Kit language models; model downloads require network access. Canvas/image text, closed shadow roots, cross-origin iframes, and inaccessible or virtualized SPA content are not guaranteed to translate. The scan is bounded and may skip content on large pages.
- Translation has no external provider wired into the app. The included ML Kit provider is real and on-device; adding another service requires its documented API, contractual/privacy review and credentials (none are embedded).
- DownloadManager does not expose app-level pause/resume in this app; retry/cancel controls and rich download metadata beyond Android DownloadManager's exposed status are limited.
- Bookmark folders, cloud sync, wallpaper downloads/custom images, shortcut drag reordering, and cross-device sync are not implemented. Shortcuts can be added/edited/removed.
- History/bookmarks/session data use JSON in Preferences DataStore rather than Room; a schema/data migration and test plan are needed before changing storage architecture.
- Site permission decisions are origin-labelled and user prompted but are not yet a full persistent per-origin permission centre. Notification permission/Web Notification behavior, WebRTC, PWA/service-worker notification UX and all external custom schemes need broader validation.
- Shields implements a lightweight host/path filter, not full EasyList/uBlock syntax or cosmetic rules. DoH presets are not an active DNS-over-HTTPS transport; anti-fingerprinting and WebRTC leak protection are incomplete. DNT/GPC are request preferences, not enforcement.
- Reader Mode is CSS-based presentation, not semantic article extraction.
- Instrumentation tests, private profile cookie/localStorage isolation tests, Macrobenchmark, LeakCanary, accessibility tests, physical-device QA, signed APK/AAB, SBOM and Play compliance validation remain follow-up work.

## Release criteria still open

1. Successful hosted `testDebugUnitTest`, strict `lintDebug` and `assembleDebug` on the exact commit/archive.
2. Manual tests on multiple Android API levels and WebView provider versions, including heavy video, login, file upload, desktop mode, memory pressure and renderer restart.
3. Private-profile isolation tests for cookies, cache, service workers, IndexedDB and localStorage.
4. Permission lifecycle tests for camera, microphone, geolocation and file chooser.
5. TalkBack, keyboard/IME, tablet/landscape and 200% font-scale validation.
6. Release signing via protected GitHub Secrets, AAB verification, privacy policy/data safety and store compliance.
