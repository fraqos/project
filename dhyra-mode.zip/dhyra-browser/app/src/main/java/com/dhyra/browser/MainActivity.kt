package com.dhyra.browser

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private val android.content.Context.settingsStore by preferencesDataStore(name = "dhyra_settings")
private val HOME_KEY = stringPreferencesKey("homepage")
private val SEARCH_KEY = stringPreferencesKey("search_engine")
private val THEME_KEY = stringPreferencesKey("theme")
private val GLASS_KEY = floatPreferencesKey("glass_transparency")
private val TRACK_KEY = booleanPreferencesKey("tracking_protection")
private val POPUP_KEY = booleanPreferencesKey("popup_blocker")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DhyraApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DhyraApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by context.settingsStore.data.map { p ->
        Settings(
            homepage = p[HOME_KEY] ?: "https://www.google.com",
            search = p[SEARCH_KEY] ?: "Google",
            theme = p[THEME_KEY] ?: "System",
            glass = p[GLASS_KEY] ?: 0.75f,
            tracking = p[TRACK_KEY] ?: true,
            popup = p[POPUP_KEY] ?: true
        )
    }.collectAsState(initial = Settings())
    val dark = when (settings.theme) {
        "Dark" -> true
        "Light" -> false
        else -> androidx.compose.foundation.isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        var page by remember { mutableStateOf("home") }
        var address by remember { mutableStateOf(settings.homepage) }
        var currentUrl by remember { mutableStateOf(settings.homepage) }
        var webView by remember { mutableStateOf<WebView?>(null) }
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("DHYRA Browser") },
                    actions = {
                        TextButton(onClick = { page = "settings" }) { Text("Settings") }
                        TextButton(onClick = { page = "support" }) { Text("Support") }
                    }
                )
            }
        ) { padding ->
            when (page) {
                "settings" -> SettingsPage(settings, onSave = { updated ->
                    scope.launch {
                        context.settingsStore.edit { p ->
                            p[HOME_KEY] = updated.homepage
                            p[SEARCH_KEY] = updated.search
                            p[THEME_KEY] = updated.theme
                            p[GLASS_KEY] = updated.glass
                            p[TRACK_KEY] = updated.tracking
                            p[POPUP_KEY] = updated.popup
                        }
                    }
                }, modifier = Modifier.padding(padding), onBack = { page = "home" })
                "support" -> SupportPage(Modifier.padding(padding), onBack = { page = "home" })
                else -> Column(Modifier.padding(padding).fillMaxSize()) {
                    OutlinedTextField(
                        value = address, onValueChange = { address = it },
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        singleLine = true, label = { Text("Alamat atau kata kunci") },
                        trailingIcon = {
                            TextButton(onClick = {
                                val target = normalize(address, settings.search)
                                currentUrl = target
                                webView?.loadUrl(target)
                            }) { Text("GO") }
                        }
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        IconButton(onClick = { currentUrl = settings.homepage; webView?.loadUrl(currentUrl) }) { Icon(Icons.Default.Home, null) }
                        IconButton(onClick = { webView?.reload() }) { Icon(Icons.Default.Refresh, null) }
                        TextButton(onClick = { page = "settings" }) { Text("Pengaturan") }
                    }
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                webViewClient = WebViewClient()
                                loadUrl(currentUrl)
                                webView = this
                            }
                        },
                        update = { if (it.url != currentUrl) it.loadUrl(currentUrl) }
                    )
                }
            }
        }
    }
}

private data class Settings(
    val homepage: String = "https://www.google.com",
    val search: String = "Google",
    val theme: String = "System",
    val glass: Float = 0.75f,
    val tracking: Boolean = true,
    val popup: Boolean = true
)

private fun normalize(input: String, engine: String): String {
    val value = input.trim()
    if (value.startsWith("https://") || value.startsWith("http://")) return value
    if (value.contains(".") && !value.contains(" ")) return "https://$value"
    val encoded = java.net.URLEncoder.encode(value, "UTF-8")
    val base = when (engine) {
        "Bing" -> "https://www.bing.com/search?q="
        "DuckDuckGo" -> "https://duckduckgo.com/?q="
        "Brave" -> "https://search.brave.com/search?q="
        else -> "https://www.google.com/search?q="
    }
    return base + encoded
}

@Composable
private fun SettingsPage(s: Settings, onSave: (Settings) -> Unit, modifier: Modifier, onBack: () -> Unit) {
    var homepage by remember(s.homepage) { mutableStateOf(s.homepage) }
    var search by remember(s.search) { mutableStateOf(s.search) }
    var theme by remember(s.theme) { mutableStateOf(s.theme) }
    var glass by remember(s.glass) { mutableFloatStateOf(s.glass) }
    var tracking by remember(s.tracking) { mutableStateOf(s.tracking) }
    var popup by remember(s.popup) { mutableStateOf(s.popup) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text("Kembali") }
        Text("Settings Center", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(homepage, { homepage = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Homepage") })
        Text("Search engine")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Google", "Bing", "DuckDuckGo", "Brave").forEach { item ->
                FilterChip(selected = search == item, onClick = { search = item }, label = { Text(item) })
            }
        }
        Text("Theme")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Light", "Dark", "System").forEach { item ->
                FilterChip(selected = theme == item, onClick = { theme = item }, label = { Text(item) })
            }
        }
        Text("Glass transparency: ${(glass * 100).toInt()}%")
        Slider(value = glass, onValueChange = { glass = it }, valueRange = 0.2f..1f)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Tracking protection", Modifier.weight(1f)); Switch(tracking, { tracking = it })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Popup blocker", Modifier.weight(1f)); Switch(popup, { popup = it })
        }
        Button(onClick = {
            val cleanHome = homepage.trim().let { if (it.startsWith("http://") || it.startsWith("https://")) it else "https://$it" }
            onSave(s.copy(homepage = cleanHome, search = search, theme = theme, glass = glass, tracking = tracking, popup = popup))
            onBack()
        }, modifier = Modifier.fillMaxWidth()) { Text("Simpan pengaturan") }
        Text("DHYRA Browser · Settings tersimpan di perangkat", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SupportPage(modifier: Modifier, onBack: () -> Unit) {
    val context = LocalContext.current
    val address = "bc1qrdlrhldck8pz6mtcaths86htz3g3hjyhsa44q5"
    val bitmap = remember {
        try {
            val matrix = com.google.zxing.qrcode.QRCodeWriter().encode("bitcoin:$address", com.google.zxing.BarcodeFormat.QR_CODE, 640, 640)
            Bitmap.createBitmap(640, 640, Bitmap.Config.ARGB_8888).also { bmp ->
                for (x in 0 until 640) for (y in 0 until 640) bmp.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        } catch (_: Exception) { null }
    }
    Column(modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("Kembali") }
        Text("Support DHYRA Browser", style = MaterialTheme.typography.headlineSmall)
        if (bitmap != null) androidx.compose.foundation.Image(bitmap.asImageBitmap(), null, Modifier.size(220.dp))
        Text(address, style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            val clip = android.content.ClipData.newPlainText("Bitcoin address", address)
            (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
        }) { Text("Copy alamat") }
        OutlinedButton(onClick = {
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("bitcoin:$address"))
            runCatching { context.startActivity(Intent.createChooser(intent, "Pilih Bitcoin wallet")) }
        }) { Text("Buka Bitcoin wallet") }
        Text("Pastikan alamat dan jaringan Bitcoin benar sebelum mengirim donasi.")
    }
}
