# DHYRA Browser

Project Android Kotlin + Jetpack Compose dengan browser WebView, Settings Center, DataStore, tema Light/Dark/System, pilihan search engine, homepage, kontrol privasi dasar, dan halaman dukungan Bitcoin dengan QR ZXing.

## Build APK melalui GitHub Actions

1. Buat repository GitHub baru.
2. Upload **isi folder** project ini ke root repository (pastikan `settings.gradle.kts` ada di root).
3. Buka tab **Actions**.
4. Pilih **Build DHYRA BROWSER APK** lalu klik **Run workflow**. Workflow juga berjalan otomatis saat push ke `main` atau `master`.
5. Setelah job selesai, unduh artifact `dhyra-browser-debug-apk`.

APK berada di `app/build/outputs/apk/debug/`.

## Catatan Gradle Wrapper

Workflow menggunakan Gradle 8.7 yang dipasang oleh `gradle/actions/setup-gradle`, sehingga build GitHub Actions tidak bergantung pada `gradle-wrapper.jar`. File `gradlew` disertakan sebagai launcher, tetapi untuk menjalankannya di luar GitHub Actions diperlukan `gradle-wrapper.jar` standar. Buat wrapper lengkap dengan menjalankan `gradle wrapper --gradle-version 8.7` dari instalasi Gradle 8.7.

## Informasi

- Package: `com.dhyra.browser`
- minSdk: 26
- targetSdk: 34
- compileSdk: 35
- JDK: 17
- Gradle: 8.7
- Android Gradle Plugin: 8.6.1

Ini adalah baseline project mandiri, bukan hasil merge otomatis dari semua source Phase 1–4 terdahulu. Fitur privasi pada contoh ini adalah kontrol preferensi UI; proteksi tracker dan pemblokiran popup tingkat jaringan belum diimplementasikan.
