# DHYRA Browser — architecture notes (2.4.4)

## Current runtime layers

```text
Android application layer
  MainActivity / Compose screens / dialogs / system permission prompts
        |
Browser orchestration layer
  BrowserController / tabs / navigation / history / bookmarks / downloads
        |
Browser policy and adapter layer
  DhyraWebViewController / WebViewModeManager / ShieldsFilterEngine / security policy
        |
Rendering and JavaScript engine
  Android System WebView provider installed on the device
        |
Platform services
  Android DownloadManager / AndroidX WebKit profiles / DataStore / ML Kit
```

### Android application layer

`MainActivity.kt` owns the Activity/Compose root, routes, preference collection, browser UI callbacks, Android activity-result flows and selected native integrations. UI screens live under `ui/screens`; reusable Compose widgets and sheets live under `ui/components`. Material 3 color, shape and typography tokens are defined under `ui/theme`.

### Browser orchestration layer

`BrowserController.kt` coordinates tab IDs and state, WebView lifecycle, navigation callbacks, renderer retention, tab selection/closing, reader mode, fullscreen, downloads, translation and privacy policy. It is intentionally the current orchestration boundary. It remains a relatively large class and is not yet split into independent feature modules or a complete ViewModel/use-case graph.

### Web rendering layer

`DhyraEngine` is an application-owned facade that currently creates ordinary Android `WebView` instances and reports the active provider's package, version, Chromium token and supported AndroidX WebKit capabilities. `DhyraWebViewController` centralizes WebSettings configuration and deterministic teardown. Rendering, HTML/CSS implementation, JavaScript execution, DOM and the underlying renderer/network process are supplied by the installed Android System WebView provider.

There is **no standalone DHYRA rendering engine** in this archive. The project does not contain a Chromium/Gecko fork, an independent HTML/CSS layout engine, a browser JavaScript VM or a separate network stack. The `DhyraEngine` facade is not evidence of a custom renderer. Node.js tooling, where used for build-time tests, does not render pages and is not used as the browser engine.

### Networking and policy

WebView owns page networking. DHYRA applies browser-initiated navigation validation, HTTPS-first behavior, request headers, URL-level Shields interception, WebView Safe Browsing/mixed-content/file-access settings and origin-aware native permission prompts. This is not a full proxy/network interception stack and does not guarantee control of every WebView subresource, redirect or provider-internal request.

### Storage

Preferences DataStore currently persists lightweight app preferences, JSON tab session state, bookmarks, history and speed-dial items. This preserves compatibility with the existing project but is not a relational database. AndroidX WebKit owns the regular and named SPACE WebView profile storage. Public downloads are delegated to Android `DownloadManager`.

## Engine extension seam

The current `DhyraEngine` facade is intentionally small. A future second renderer would need an explicit contract covering at least view/surface ownership, navigation, back/forward capability, loading and progress events, title/URL updates, JavaScript/runtime support, cookies/storage profile, downloads, file chooser, permissions, fullscreen, renderer termination and lifecycle. It would also need conformance tests and a supported Android distribution/runtime strategy.

Until an alternative renderer provides those contracts and passes web-platform compatibility tests, Android System WebView remains the only supported rendering backend. Do not route ordinary websites through Node.js or label the existing facade a custom browser engine.

## Build pipeline

`.github/workflows/build.yml` supports source at repository root or one validated source ZIP, checks translation assets and source contracts, provisions JDK/Android SDK/Gradle, generates and checksum-verifies a standard Gradle wrapper for the archive, runs AAR metadata/unit-test/lint/debug-assembly tasks and validates APK contents before creating a clean source ZIP. Manual workflow dispatch can optionally build a release APK and, with GitHub Secrets configured, a signed APK plus AAB.
