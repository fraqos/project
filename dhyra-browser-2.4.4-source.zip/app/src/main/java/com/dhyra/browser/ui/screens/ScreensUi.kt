@file:OptIn(

    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser.ui.screens

import com.dhyra.browser.core.nav.BrowserAddressResolver
import com.dhyra.browser.core.search.SearchEngineManager
import com.dhyra.browser.core.search.CustomSearchEngine
import com.dhyra.browser.core.engine.DhyraEngineInfo
import com.dhyra.browser.core.translation.TranslationLanguage

import com.dhyra.browser.*
import com.dhyra.browser.ui.theme.*
import com.dhyra.browser.ui.components.*

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.lifecycle.repeatOnLifecycle

// ---------- shared building blocks ----------

@Composable
internal fun SubpageBar(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = cs.onSurface)
        }
        Text(
            text = title,
            modifier = Modifier.weight(1f),
            fontSize = 20.sp,
            lineHeight = 28.sp,
            fontWeight = FontWeight.SemiBold,
            color = cs.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        trailing()
    }
}

@Composable
internal fun SectionTitle(text: String) {
    Text(
        text = text,
        modifier = Modifier.padding(start = 24.dp, top = 24.dp, bottom = 6.dp),
        fontSize = 13.sp,
        lineHeight = 18.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
internal fun SettingRow(icon: ImageVector, title: String, subtitle: String?, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = cs.onSurfaceVariant)
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(text = title, fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface)
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = cs.onSurfaceVariant)
    }
}

@Composable
internal fun SwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = cs.onSurfaceVariant)
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(text = title, fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface)
            Text(text = subtitle, fontSize = 13.sp, lineHeight = 19.sp, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<String>,
    selected: String,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                options.forEach { option ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(option) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = option == selected, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(option, fontSize = 16.sp, lineHeight = 24.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun SearchEngineCatalogDialog(
    selected: String,
    custom: List<CustomSearchEngine>,
    legacyCustomConfigured: Boolean,
    onSelect: (String) -> Unit,
    onAdd: () -> Unit,
    onEdit: (CustomSearchEngine) -> Unit,
    onDelete: (CustomSearchEngine) -> Unit,
    onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().heightIn(max = 640.dp),
            shape = RoundedCornerShape(26.dp),
            color = cs.surface,
            tonalElevation = 4.dp
        ) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Search engines", style = MaterialTheme.typography.titleLarge, color = cs.onSurface)
                        Text("Choose a default or add your own HTTPS provider.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }
                Spacer(Modifier.height(14.dp))
                Text("Built-in", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                LazyColumn(Modifier.weight(1f, fill = false)) {
                    items(SearchEngineManager.builtInEngines, key = { "builtin:$it" }) { engine ->
                        SearchEngineChoiceRow(
                            name = engine,
                            subtitle = "Built-in provider",
                            selected = selected == engine,
                            onClick = { onSelect(engine) }
                        )
                    }
                    if (legacyCustomConfigured || selected == SearchEngineManager.CUSTOM) {
                        item {
                            SearchEngineChoiceRow(
                                name = "Custom",
                                subtitle = "Legacy custom search URL",
                                selected = selected == "Custom",
                                onClick = { onSelect("Custom") }
                            )
                        }
                    }
                    if (custom.isNotEmpty()) {
                        item { Text("Your providers", modifier = Modifier.padding(top = 14.dp, bottom = 4.dp), style = MaterialTheme.typography.labelLarge, color = cs.primary) }
                        items(custom, key = { "custom:${it.name}" }) { engine ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.weight(1f)) {
                                    SearchEngineChoiceRow(
                                        name = engine.name,
                                        subtitle = engine.template,
                                        selected = selected == engine.name,
                                        onClick = { onSelect(engine.name) }
                                    )
                                }
                                IconButton(onClick = { onEdit(engine) }) { Icon(Icons.Default.Edit, contentDescription = "Edit ${engine.name}", tint = cs.onSurfaceVariant) }
                                IconButton(onClick = { onDelete(engine) }) { Icon(Icons.Default.DeleteOutline, contentDescription = "Delete ${engine.name}", tint = cs.error) }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Add search engine")
                }
            }
        }
    }
}

@Composable
private fun SearchEngineChoiceRow(name: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
            Text(name.take(1).uppercase(), color = cs.onPrimaryContainer, style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = cs.onSurface, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (selected) Icon(Icons.Default.CheckCircle, contentDescription = "Default", tint = cs.primary)
    }
}

@Composable
private fun CustomSearchEngineEditorDialog(
    initial: CustomSearchEngine?,
    existing: List<CustomSearchEngine>,
    onDismiss: () -> Unit,
    onSave: (CustomSearchEngine) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var name by remember(initial) { mutableStateOf(initial?.name.orEmpty()) }
    var template by remember(initial) { mutableStateOf(initial?.template.orEmpty()) }
    var favicon by remember(initial) { mutableStateOf(initial?.faviconUrl.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
        title = { Text(if (initial == null) "Add search engine" else "Edit search engine") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(value = name, onValueChange = { name = it; error = null }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Name") })
                OutlinedTextField(value = template, onValueChange = { template = it; error = null }, modifier = Modifier.fillMaxWidth(), singleLine = false, minLines = 2, label = { Text("Search URL") }, placeholder = { Text("https://example.com/search?q=%s") })
                Text("Use exactly one %s placeholder (or the legacy {query} form). The search terms are URL-encoded and HTTPS is required.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                OutlinedTextField(value = favicon, onValueChange = { favicon = it; error = null }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Favicon URL (optional)") }, placeholder = { Text("https://example.com/favicon.ico") })
                error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val validName = SearchEngineManager.validateName(name)
                val validTemplate = SearchEngineManager.validateCustomTemplate(template)
                val validFavicon = SearchEngineManager.validateFavicon(favicon)
                when {
                    validName.isFailure -> error = validName.exceptionOrNull()?.message
                    validTemplate.isFailure -> error = validTemplate.exceptionOrNull()?.message
                    validFavicon.isFailure -> error = validFavicon.exceptionOrNull()?.message
                    SearchEngineManager.hasDuplicateName(validName.getOrThrow(), existing, initial?.name) -> error = "A provider with this name already exists."
                    else -> onSave(CustomSearchEngine(validName.getOrThrow(), validTemplate.getOrThrow(), validFavicon.getOrThrow()))
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ---------- settings ----------

@Composable
internal fun SettingsScreen(
    state: PreferencesState,
    onBack: () -> Unit,
    onSave: (String, Any) -> Unit,
    onClear: () -> Unit,
    onResetSettings: () -> Unit,
    onSetDefaultBrowser: () -> Unit,
    onAbout: () -> Unit,
    onDownloads: () -> Unit,
    onNotifications: () -> Unit,
    privateBrowsingSupported: Boolean
) {
    val cs = MaterialTheme.colorScheme
    var showHome by remember { mutableStateOf(false) }
    var showEngine by remember { mutableStateOf(false) }
    var showTheme by remember { mutableStateOf(false) }
    var showCustomSearch by remember { mutableStateOf(false) }
    var showTranslationLanguage by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }
    var showResetSettings by remember { mutableStateOf(false) }
    var editingEngine by remember { mutableStateOf<com.dhyra.browser.core.search.CustomSearchEngine?>(null) }
    var showEngineEditor by remember { mutableStateOf(false) }
    var deletingEngine by remember { mutableStateOf<com.dhyra.browser.core.search.CustomSearchEngine?>(null) }
    var query by remember { mutableStateOf("") }
    val normalizedQuery = query.trim()
    fun rowMatches(section: String, vararg values: String): Boolean = normalizedQuery.isBlank() ||
        section.contains(normalizedQuery, ignoreCase = true) ||
        values.any { it.contains(normalizedQuery, ignoreCase = true) }
    fun sectionMatches(section: String, vararg values: String): Boolean =
        normalizedQuery.isBlank() || section.contains(normalizedQuery, ignoreCase = true) ||
            values.any { it.contains(normalizedQuery, ignoreCase = true) }

    Column(Modifier.fillMaxSize().background(cs.background).navigationBarsPadding()) {
        SubpageBar(title = "Settings", onBack = onBack)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = DhyraSpacing.md, vertical = DhyraSpacing.xs),
            singleLine = true,
            shape = MaterialTheme.shapes.medium,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                    Icon(Icons.Default.Close, contentDescription = "Clear settings search")
                }
            },
            placeholder = { Text("Search settings") }
        )
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (sectionMatches("General", "default browser", "homepage", "search engine", "custom providers", "type on new tab", "reset settings")) {
                item { SectionTitle("General") }
                if (rowMatches("General", "default browser", "set as default")) item {
                    SettingRow(Icons.Default.Language, "Default browser", "Set dhyra as your default browser") { onSetDefaultBrowser() }
                }
                if (rowMatches("General", "homepage", state.homepage, "start page")) item {
                    SettingRow(Icons.Default.Home, "Homepage", state.homepage.ifBlank { "dhyra start page" }) { showHome = true }
                }
                if (rowMatches("General", "search engine", state.engine, "brave", "google", "bing", "duckduckgo", "yahoo", "ecosia", "custom provider")) item {
                    SettingRow(Icons.Default.Search, "Default search engine", state.engine) { showEngine = true }
                }
                if (rowMatches("General", "manage search engines", "custom providers", "add search engine", "edit search engine")) item {
                    SettingRow(
                        Icons.Default.ManageSearch,
                        "Manage search engines",
                        "${SearchEngineManager.builtInEngines.size + state.customSearchEngines.size} available providers"
                    ) { showEngine = true }
                }
                if (state.engine == SearchEngineManager.CUSTOM && rowMatches("General", "custom search url", state.customSearchUrl)) item {
                    SettingRow(Icons.Default.Link, "Legacy custom search URL", state.customSearchUrl.ifBlank { "Set HTTPS template" }) {
                        showCustomSearch = true
                    }
                }
                if (rowMatches("General", "reset settings", "restore defaults", "reset preferences")) item {
                    SettingRow(Icons.Default.RestartAlt, "Reset settings", "Restore default preferences without deleting bookmarks or history") { showResetSettings = true }
                }
                if (rowMatches("General", "type on new tab", "focus", "keyboard")) item {
                    SwitchRow(
                        icon = Icons.Default.Add,
                        title = "Type on new tab",
                        subtitle = "Open the keyboard as soon as a new tab opens",
                        checked = state.focusOnNewTab
                    ) { onSave("focus_on_new_tab", it) }
                }
            }

            if (sectionMatches("Appearance", "theme", "desktop site", "desktop mode", "user agent")) {
                item { SectionTitle("Appearance") }
                if (rowMatches("Appearance", "theme", "theme", state.theme, "system", "dark")) {
                    item { SettingRow(Icons.Default.Brightness6, "Theme", state.theme) { showTheme = true } }
                }
                if (rowMatches("Appearance", "desktop site", "desktop mode", "user agent")) item {
                    SwitchRow(
                        icon = Icons.Default.DesktopWindows,
                        title = "Default desktop mode for new tabs",
                        subtitle = "New tabs request desktop layouts; each tab can be changed separately",
                        checked = state.desktop
                    ) { onSave("desktop_mode", it) }
                }
            }

            if (sectionMatches("Language & translation", "language", "translation", "translate", "translated page", "target language")) {
                item { SectionTitle("Language & translation") }
                if (rowMatches("Language & translation", "preferred translation language", "translate", state.translationTarget)) {
                    val preferredLanguage = TranslationLanguage.supported.firstOrNull { it.tag == state.translationTarget }?.label ?: "Indonesian"
                    item {
                        SettingRow(Icons.Default.Translate, "Preferred translation language", preferredLanguage) {
                            showTranslationLanguage = true
                        }
                    }
                }
            }

            if (sectionMatches("Downloads", "downloads", "download manager", "files")) {
                item { SectionTitle("Downloads") }
                if (rowMatches("Downloads", "downloads", "download manager", "files")) {
                    item { SettingRow(Icons.Default.Download, "Download manager", "View and open downloaded files", onDownloads) }
                }
            }

            if (sectionMatches("Notifications", "notifications", "download alerts", "app alerts")) {
                item { SectionTitle("Notifications") }
                if (rowMatches("Notifications", "notifications", "download alerts", "app alerts")) {
                    item {
                        SettingRow(
                            Icons.Default.Notifications,
                            "App notifications",
                            "Open Android notification controls for dhyra",
                            onNotifications
                        )
                    }
                }
            }

            if (sectionMatches("Advanced", "advanced", "engine", "webview", "provider", "capabilities")) {
                item { SectionTitle("Advanced") }
                if (rowMatches("Advanced", "engine", "webview", "provider", "capabilities")) {
                    item { SettingRow(Icons.Default.Memory, "Browser engine details", "System WebView provider and supported capabilities", onAbout) }
                }
            }

            if (sectionMatches("Privacy & security", "privacy", "security", "shields", "trackers", "ads", "pop-ups", "clear browsing data", "cookies", "site storage", "space", "isolated profile")) {
                item { SectionTitle("Privacy & Security") }
                if (rowMatches("Privacy & security", "shields", "trackers", "ads", "block list", "tracking protection")) item {
                    SwitchRow(
                        icon = Icons.Default.Shield,
                        title = "Block trackers & ads",
                        subtitle = "Uses the built-in block list",
                        checked = state.tracking
                    ) { onSave("tracking_protection", it) }
                }
                if (rowMatches("Privacy & security", "pop-ups", "popup", "windows")) item {
                    SwitchRow(
                        icon = Icons.Default.VisibilityOff,
                        title = "Block pop-ups",
                        subtitle = "Stops pop-up windows from opening",
                        checked = state.popup
                    ) { onSave("popup_blocker", it) }
                }
                if (rowMatches("Privacy & security", "clear browsing data", "cookies", "site storage", "history", "cache")) item {
                    SettingRow(Icons.Default.DeleteOutline, "Clear browsing data", "Cookies, site storage and history") { showClear = true }
                }
                if (rowMatches("Privacy & security", "space", "isolated profile")) item {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VisibilityOff, contentDescription = null, tint = cs.onSurfaceVariant)
                        Spacer(Modifier.width(18.dp))
                        Column(Modifier.weight(1f)) {
                            Text("SPACE", fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface)
                            Text(
                                if (privateBrowsingSupported) "Isolated WebView profile available on this device"
                                else "Unavailable: this WebView provider cannot safely isolate and clear SPACE data",
                                fontSize = 13.sp,
                                lineHeight = 19.sp,
                                color = if (privateBrowsingSupported) cs.onSurfaceVariant else cs.error
                            )
                        }
                    }
                }
            }

            if (sectionMatches("About", "about dhyra", BuildConfig.VERSION_NAME, "version")) {
                item { SectionTitle("About") }
                if (rowMatches("About", "about dhyra", BuildConfig.VERSION_NAME, "version")) {
                    item { SettingRow(Icons.Default.Info, "About dhyra", "Version ${BuildConfig.VERSION_NAME}") { onAbout() } }
                }
            }
            if (normalizedQuery.isNotBlank() && !sectionMatches(
                    "General", "default browser", "homepage", "search engine", "custom providers", "type on new tab", "reset settings"
                ) && !sectionMatches("Appearance", "theme", "desktop site", "desktop mode", "user agent") &&
                !sectionMatches("Language & translation", "language", "translation", "translate", "translated page", "target language") &&
                !sectionMatches("Downloads", "downloads", "download manager", "files") &&
                !sectionMatches("Notifications", "notifications", "download alerts", "app alerts") &&
                !sectionMatches("Advanced", "advanced", "engine", "webview", "provider", "capabilities") &&
                !sectionMatches("Privacy & security", "privacy", "security", "shields", "trackers", "ads", "pop-ups", "clear browsing data", "cookies", "site storage", "space", "isolated profile") &&
                !sectionMatches("About", "about dhyra", BuildConfig.VERSION_NAME, "version")) {
                item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No settings found for ‘$normalizedQuery’", color = cs.onSurfaceVariant)
                    }
                }
            }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }

    if (showEngine) {
        SearchEngineCatalogDialog(
            selected = state.engine,
            custom = state.customSearchEngines,
            legacyCustomConfigured = state.customSearchUrl.isNotBlank(),
            onSelect = { value ->
                if (value == SearchEngineManager.CUSTOM) {
                    showCustomSearch = true
                } else {
                    onSave("search_engine", value)
                }
                showEngine = false
            },
            onAdd = {
                showEngine = false
                editingEngine = null
                showEngineEditor = true
            },
            onEdit = { engine ->
                showEngine = false
                editingEngine = engine
                showEngineEditor = true
            },
            onDelete = { deletingEngine = it },
            onDismiss = { showEngine = false }
        )
    }

    if (showEngineEditor) {
        CustomSearchEngineEditorDialog(
            initial = editingEngine,
            existing = state.customSearchEngines,
            onDismiss = { showEngineEditor = false; editingEngine = null },
            onSave = { replacement ->
                val updated = state.customSearchEngines.filterNot { it.name == editingEngine?.name } + replacement
                onSave("custom_search_engines_json", SearchEngineManager.encodeCustomEngines(updated))
                onSave("search_engine", replacement.name)
                showEngineEditor = false
                editingEngine = null
            }
        )
    }

    deletingEngine?.let { target ->
        AlertDialog(
            onDismissRequest = { deletingEngine = null },
            containerColor = cs.surface,
            title = { Text("Delete search engine?") },
            text = { Text("${target.name} will be removed from your saved search providers.") },
            confirmButton = {
                TextButton(onClick = {
                    val updated = state.customSearchEngines.filterNot { it.name == target.name }
                    onSave("custom_search_engines_json", SearchEngineManager.encodeCustomEngines(updated))
                    if (state.engine == target.name) onSave("search_engine", SearchEngineManager.GOOGLE)
                    deletingEngine = null
                }) { Text("Delete", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { deletingEngine = null }) { Text("Cancel") } }
        )
    }

    if (showResetSettings) {
        AlertDialog(
            onDismissRequest = { showResetSettings = false },
            containerColor = cs.surface,
            title = { Text("Reset settings?") },
            text = { Text("Preferences will return to their defaults. Your bookmarks, history and saved shortcuts will remain.") },
            confirmButton = {
                TextButton(onClick = { onResetSettings(); showResetSettings = false }) { Text("Reset settings", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { showResetSettings = false }) { Text("Cancel") } }
        )
    }

    if (showHome) {
        var draft by remember { mutableStateOf(state.homepage) }
        AlertDialog(
            onDismissRequest = { showHome = false },
            containerColor = cs.surface,
            title = { Text("Homepage") },
            text = {
                Column {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("https://example.com") }
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Leave empty to use the dhyra start page.",
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                        color = cs.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onSave("homepage", if (draft.isBlank()) "" else BrowserAddressResolver.normalizeHomepage(draft))
                    showHome = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showHome = false }) { Text("Cancel") } }
        )
    }

    if (showCustomSearch) {
        var draft by remember(state.customSearchUrl) { mutableStateOf(state.customSearchUrl) }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showCustomSearch = false },
            containerColor = cs.surface,
            title = { Text("Custom search provider") },
            text = {
                Column {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it; error = null },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        isError = error != null,
                        label = { Text("Search URL template") },
                        placeholder = { Text("https://example.com/search?q={query}") }
                    )
                    Text(
                        "Use {query} where the encoded search terms belong. HTTPS is required.",
                        style = MaterialTheme.typography.bodySmall,
                        color = error?.let { cs.error } ?: cs.onSurfaceVariant
                    )
                    error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.error) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val result = SearchEngineManager.validateCustomTemplate(draft)
                    result.onSuccess { normalized ->
                        onSave("custom_search_url", normalized)
                        onSave("search_engine", SearchEngineManager.CUSTOM)
                        showCustomSearch = false
                    }.onFailure { error = it.message ?: "Invalid search URL." }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showCustomSearch = false }) { Text("Cancel") } }
        )
    }

    if (showTheme) {
        ChoiceDialog(
            title = "Theme",
            options = THEME_OPTIONS,
            selected = state.theme,
            onPick = {
                onSave("theme", it)
                showTheme = false
            },
            onDismiss = { showTheme = false }
        )
    }

    if (showTranslationLanguage) {
        val choices = TranslationLanguage.supported.filter { it.tag != "auto" }
        val selectedLabel = choices.firstOrNull { it.tag == state.translationTarget }?.label ?: "Indonesian"
        ChoiceDialog(
            title = "Preferred translation language",
            options = choices.map { it.label },
            selected = selectedLabel,
            onPick = { label ->
                choices.firstOrNull { it.label == label }?.let { onSave("translation_target", it.tag) }
                showTranslationLanguage = false
            },
            onDismiss = { showTranslationLanguage = false }
        )
    }

    if (showClear) {
        AlertDialog(
            onDismissRequest = { showClear = false },
            containerColor = cs.surface,
            title = { Text("Clear browsing data?") },
            text = { Text("This clears history, cookies and site storage of regular tabs. It can sign you out of websites.") },
            confirmButton = {
                TextButton(onClick = {
                    onClear()
                    showClear = false
                }) { Text("Clear", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { showClear = false }) { Text("Cancel") } }
        )
    }
}

// ---------- bookmarks and history ----------

@Composable
internal fun EntriesScreen(
    title: String,
    entries: List<SavedPage>,
    emptyText: String,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onDelete: (String) -> Unit,
    onEdit: ((SavedPage, SavedPage) -> Unit)? = null,
    onClearAll: (() -> Unit)? = null,
    onImport: (() -> Unit)? = null,
    onExport: (() -> Unit)? = null
) {
    val cs = MaterialTheme.colorScheme
    var query by remember(title) { mutableStateOf("") }
    var editingEntry by remember(title) { mutableStateOf<SavedPage?>(null) }
    val filtered = remember(entries, query) {
        val terms = query.trim().lowercase()
        if (terms.isEmpty()) entries else entries.filter {
            it.title.lowercase().contains(terms) || it.url.lowercase().contains(terms)
        }
    }
    Column(Modifier.fillMaxSize().background(cs.background).navigationBarsPadding()) {
        SubpageBar(
            title = title,
            onBack = onBack,
            trailing = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onImport != null) IconButton(onClick = onImport) {
                        Icon(Icons.Default.FileOpen, contentDescription = "Import bookmarks", tint = cs.onSurface)
                    }
                    if (onExport != null) IconButton(onClick = onExport) {
                        Icon(Icons.Default.FileDownload, contentDescription = "Export bookmarks", tint = cs.onSurface)
                    }
                    if (onClearAll != null && entries.isNotEmpty()) {
                        TextButton(onClick = onClearAll) { Text("Clear", color = cs.primary) }
                    }
                }
            }
        )
        if (entries.isNotEmpty()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text("Search $title") }
            )
        }
        if (filtered.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    text = if (entries.isEmpty()) emptyText else "No matching entries",
                    fontSize = 15.sp,
                    lineHeight = 22.sp,
                    color = cs.onSurfaceVariant
                )
            }
        } else {
            // Keep the section collection explicitly typed. Map.Entry and Pair have
            // different component types; mixing them in an if-expression widened the
            // inferred type and made Compose select items(count: Int) instead of
            // items(items: List<SavedPage>) in the Kotlin compiler.
            val sections: List<Pair<String, List<SavedPage>>> = remember(filtered, title) {
                if (title.equals("History", ignoreCase = true)) {
                    filtered.groupBy { page ->
                        DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(page.timestamp))
                    }.map { (dateLabel, pages) -> dateLabel to pages }
                } else {
                    listOf("" to filtered)
                }
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                sections.forEach { section ->
                    val dateLabel = section.first
                    val sectionEntries: List<SavedPage> = section.second
                    if (dateLabel.isNotBlank()) {
                        stickyHeader(key = "history-$dateLabel") {
                            Surface(color = cs.background.copy(alpha = 0.96f)) {
                                Text(
                                    dateLabel,
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 9.dp),
                                    color = cs.primary,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                    items(
                        items = sectionEntries,
                        key = { page: SavedPage -> "${page.url}#${page.timestamp}" }
                    ) { entry: SavedPage ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onOpen(entry.url) }
                                .padding(start = 24.dp, end = 4.dp, top = 7.dp, bottom = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    text = entry.title.ifBlank { entry.url },
                                    fontSize = 15.sp,
                                    lineHeight = 22.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = cs.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = siteLabelOf(entry.url) + " • " +
                                        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                                            .format(Date(entry.timestamp)),
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (onEdit != null) IconButton(onClick = { editingEntry = entry }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit bookmark", tint = cs.onSurfaceVariant)
                            }
                            IconButton(onClick = { onDelete(entry.url) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = cs.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }

    editingEntry?.let { original ->
        var name by remember(original) { mutableStateOf(original.title) }
        var address by remember(original) { mutableStateOf(original.url) }
        var error by remember(original) { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { editingEntry = null },
            containerColor = cs.surface,
            title = { Text("Edit bookmark") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it; error = null }, singleLine = true, label = { Text("Name") })
                    OutlinedTextField(value = address, onValueChange = { address = it; error = null }, singleLine = true, label = { Text("URL") })
                    error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val raw = address.trim()
                    val candidate = if (raw.contains("://")) raw else "https://$raw"
                    if (name.isBlank()) error = "Enter a bookmark name."
                    else if (!com.dhyra.browser.core.nav.DhyraNavigationManager.isHttpUrl(candidate)) error = "Enter a valid HTTP or HTTPS URL."
                    else {
                        onEdit?.invoke(original, original.copy(title = name.trim(), url = candidate))
                        editingEntry = null
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editingEntry = null }) { Text("Cancel") } }
        )
    }
}

// ---------- downloads ----------

@Composable
internal fun DownloadsScreen(onBack: () -> Unit, refreshKey: Int) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf(emptyList<DownloadRow>()) }
    var loadError by remember { mutableStateOf(false) }
    var pendingRemove by remember { mutableStateOf<DownloadRow?>(null) }

    suspend fun load() {
        try {
            val items = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                val cursor = manager.query(DownloadManager.Query())
                val result = mutableListOf<DownloadRow>()
                cursor?.use { c ->
                    val idCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
                    val titleCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
                    val statusCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                    val totalCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                    val soFarCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                    val uriCol = c.getColumnIndex(DownloadManager.COLUMN_URI)
                    while (c.moveToNext()) {
                        result += DownloadRow(
                            id = c.getLong(idCol),
                            title = c.getString(titleCol) ?: "Download",
                            status = statusLabel(c.getInt(statusCol)),
                            total = c.getLong(totalCol),
                            downloaded = c.getLong(soFarCol),
                            origin = if (uriCol >= 0) runCatching { Uri.parse(c.getString(uriCol)).host }.getOrNull() ?: "Unknown source" else "Unknown source"
                        )
                    }
                }
                result
            }
            rows = items.sortedByDescending { row -> row.id }
            loadError = false
        } catch (_: Exception) {
            // Keep the last successful snapshot visible while reporting that refresh failed.
            loadError = true
        }
    }

    LaunchedEffect(refreshKey, lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.STARTED) {
            while (true) {
                load()
                val active = com.dhyra.browser.core.downloads.shouldPollDownloadStatus(rows.map { it.status })
                delay(if (active) 1_200 else 15_000)
            }
        }
    }

    Column(Modifier.fillMaxSize().background(cs.background).navigationBarsPadding()) {
        SubpageBar(
            title = "Downloads",
            onBack = onBack,
            trailing = {
                IconButton(onClick = { scope.launch { load() } }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh downloads", tint = cs.onSurface)
                }
            }
        )
        when {
            loadError && rows.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Downloads could not be loaded", color = cs.onSurface)
                    TextButton(onClick = { scope.launch { load() } }) { Text("Try again") }
                }
            }
            rows.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(text = "No downloads yet", fontSize = 15.sp, lineHeight = 22.sp, color = cs.onSurfaceVariant)
            }
            else -> LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                if (loadError) item {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Showing the last successful refresh.", modifier = Modifier.weight(1f), color = cs.error, fontSize = 12.sp)
                        TextButton(onClick = { scope.launch { load() } }) { Text("Retry") }
                    }
                }
                items(rows, key = { it.id }) { row ->
                    Row(
                        Modifier.fillMaxWidth().padding(start = 20.dp, end = 4.dp, top = 11.dp, bottom = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = cs.onSurfaceVariant)
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = row.title,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium,
                                color = cs.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text("From ${row.origin}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = "${row.status} · ${formatBytes(row.downloaded)} / ${if (row.total > 0) formatBytes(row.total) else "size unknown"}" +
                                    if (row.total > 0) " · ${(row.downloaded * 100 / row.total.coerceAtLeast(1)).coerceIn(0, 100)}%" else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                            if (row.status == "Downloading" && row.total > 0) {
                                Spacer(Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { (row.downloaded.toFloat() / row.total.toFloat()).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(3.dp),
                                    color = cs.primary,
                                    trackColor = cs.surfaceVariant
                                )
                            }
                        }
                        if (row.status == "Completed") {
                            IconButton(onClick = {
                                val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                runCatching {
                                    val uri = manager.getUriForDownloadedFile(row.id)
                                    if (uri != null) {
                                        val mime = context.contentResolver.getType(uri) ?: "*/*"
                                        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, mime)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        })
                                    } else Toast.makeText(context, "File is no longer available", Toast.LENGTH_SHORT).show()
                                }.onFailure { Toast.makeText(context, "No compatible app can open this file", Toast.LENGTH_SHORT).show() }
                            }) { Icon(Icons.Default.OpenInNew, contentDescription = "Open ${row.title}", tint = cs.primary) }
                        }
                        IconButton(onClick = {
                            if (row.status == "Downloading" || row.status == "Pending" || row.status == "Paused") {
                                val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                manager.remove(row.id)
                                scope.launch { load() }
                            } else {
                                pendingRemove = row
                            }
                        }) {
                            Icon(
                                if (row.status == "Downloading" || row.status == "Pending" || row.status == "Paused") Icons.Default.Close else Icons.Default.DeleteOutline,
                                contentDescription = if (row.status == "Downloading" || row.status == "Pending" || row.status == "Paused") "Cancel ${row.title}" else "Remove ${row.title}",
                                tint = cs.onSurfaceVariant
                            )
                        }
                    }
                    HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.55f))
                }
            }
        }
    }

    pendingRemove?.let { row ->
        AlertDialog(
            onDismissRequest = { pendingRemove = null },
            containerColor = cs.surface,
            title = { Text("Remove download?") },
            text = { Text("Remove ${row.title} from download history and delete its downloaded file if it is still present?") },
            confirmButton = {
                TextButton(onClick = {
                    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    manager.remove(row.id)
                    pendingRemove = null
                    scope.launch { load() }
                }) { Text("Remove", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { pendingRemove = null }) { Text("Cancel") } }
        )
    }
}

// ---------- about ----------

@Composable
internal fun AboutScreen(engineInfo: DhyraEngineInfo, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().background(cs.background).navigationBarsPadding()) {
        SubpageBar(title = "About", onBack = onBack)
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(20.dp))
            Image(
                painter = painterResource(id = com.dhyra.browser.R.drawable.dhyra_brand_art),
                contentDescription = "DHYRA Browser logo",
                modifier = Modifier.size(116.dp).clip(RoundedCornerShape(30.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(20.dp))
            Text(
                text = "dhyra",
                fontSize = 22.sp,
                lineHeight = 30.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = cs.onSurface
            )
            Text(
                text = "Version ${BuildConfig.VERSION_NAME}",
                fontSize = 14.sp,
                lineHeight = 21.sp,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(18.dp))
            Text(
                text = "A calm, minimal Android browser powered by Android System WebView.",
                fontSize = 14.sp,
                lineHeight = 21.sp,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(28.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant).padding(16.dp)) {
                Text("dhyra engine", style = MaterialTheme.typography.titleMedium, color = cs.onSurface)
                Text(engineInfo.backend, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Text("Provider: ${engineInfo.providerPackage}", style = MaterialTheme.typography.bodySmall, color = cs.onSurface)
                Text("Provider version: ${engineInfo.providerVersion}", style = MaterialTheme.typography.bodySmall, color = cs.onSurface)
                Text("Chromium: ${engineInfo.chromiumVersion}", style = MaterialTheme.typography.bodySmall, color = cs.onSurface)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Secure Web Messages: ${if (engineInfo.supportsSecureWebMessages) "Supported" else "Unavailable"} · " +
                        "SPACE profiles: ${if (engineInfo.supportsNamedProfiles && engineInfo.supportsProfileDataDeletion) "Supported" else "Unavailable"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
        }
    }
}
