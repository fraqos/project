# DHYRA BROWSER — Air Edition 1.4.0

Android browser project built with Kotlin, Jetpack Compose, AndroidX and Android System WebView.

## Included features

- HTTP/HTTPS browsing through the device's Android System WebView
- Address/search input with Google, Bing, DuckDuckGo and Brave search options
- Multiple WebView tabs and tab switcher
- Private-tab flag and no-cache WebView mode (see privacy limitation below)
- Bookmarks and browsing history stored using Preferences DataStore
- Android DownloadManager integration
- Web page file chooser support
- Camera/microphone permission bridge for WebRTC requests
- Geolocation permission bridge
- Popup-window handling and configurable popup blocking
- HTML5 fullscreen custom-view support
- Desktop user-agent preference
- Basic tracker-host filtering and third-party-cookie restriction
- Clear cache, cookies, WebStorage and WebView history
- Light/Dark/System themes and ambient mood presets
- Calm landing page, floating address pill, bottom controls and navigation drawer
- GitHub Actions workflow for a debug APK build

## Build

The GitHub Actions workflow uses JDK 17, Android SDK platform/build-tools 35 and Gradle 8.7. Open the repository's Actions tab and run **DHYRA BROWSER - Build Android APK**.

For GitHub Actions to detect the workflow, `.github/workflows/build.yml` must exist as a real file in the repository. A workflow file stored only inside a ZIP archive is not discovered by GitHub Actions.

## Important limitations

This app is not a Chromium fork. It uses Android System WebView installed and maintained by the device. Site compatibility depends on that WebView and the target site's policies, APIs, DRM, CAPTCHA, geographic restrictions and login requirements.

Private tabs in this implementation are not fully isolated cookie profiles. Android WebView cookie storage is shared within the app process; private tabs should not be considered equivalent to hardened incognito browsing.

Tracker protection is a small host-based block list, not a comprehensive ad blocker. It does not provide a full filter-list engine, per-site whitelist UI, or guaranteed ad removal. Popup blocking is separate from tracker filtering.

Camera, microphone and location access require Android runtime permission grants. Cleartext HTTP is allowed for compatibility but is not encrypted; HTTPS should be preferred. SSL certificate errors are cancelled rather than bypassed.

## Air Edition 1.4.0 patch note

The tab-list composable previously referenced `browserSnapshot` outside the scope where it is declared. It now reads the `tabs` parameter passed to `TabsScreen`, fixing the reported Kotlin `Unresolved reference: browserSnapshot` errors at lines 847 and 853.

## Verification status

The source ZIP structure and Kotlin reference fix have been inspected. A full Gradle compile has **not** been verified in this environment because the Gradle distribution host (`services.gradle.org`) could not be resolved (DNS/network failure). Run the GitHub Actions workflow to perform the definitive build check.
