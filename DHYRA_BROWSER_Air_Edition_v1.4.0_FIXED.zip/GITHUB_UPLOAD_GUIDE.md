# Build DHYRA BROWSER Air Edition 1.4.0 on GitHub

1. Put the Android project files at the repository root (the `settings.gradle.kts`, `build.gradle.kts`, `app/` and `.github/` entries must be visible to GitHub).
2. Ensure `.github/workflows/build.yml` is a real repository file. GitHub does not discover workflow YAML files stored inside a ZIP archive.
3. Open **Actions** and choose **DHYRA BROWSER - Build Android APK**.
4. Run the workflow, or push a commit to `main`/`master`.
5. When the run succeeds, download `DHYRA-BROWSER-v1.4.0-debug` from the run's **Artifacts** section. The artifact contains `app-debug.apk`.

The workflow uses JDK 17, Android SDK platform/build-tools 35 and Gradle 8.7. It installs only the required SDK packages and does not request the obsolete Android SDK package named `tools`.

If you upload only a ZIP file to a repository, GitHub Actions will not inspect its contents for a workflow. Keep the workflow file separately at `.github/workflows/build.yml`; a workflow can then extract a source ZIP if its YAML explicitly contains an extraction step.
