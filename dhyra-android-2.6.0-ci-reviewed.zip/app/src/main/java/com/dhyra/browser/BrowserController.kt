package com.dhyra.browser

import com.dhyra.browser.ui.localization.localizePlainUiText

import android.app.Activity
import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.print.PrintAttributes
import android.print.PrintManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.os.Environment
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebStorageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import androidx.webkit.ScriptHandler
import com.dhyra.browser.core.network.WebViewMode
import com.dhyra.browser.core.engine.DhyraEngine
import com.dhyra.browser.core.engine.DhyraEngineInfo
import com.dhyra.browser.core.engine.DhyraWebViewController
import com.dhyra.browser.core.downloads.DhyraDownloadManager
import com.dhyra.browser.core.downloads.DhyraDownloadRequest
import com.dhyra.browser.core.storage.DhyraCacheManager
import com.dhyra.browser.core.storage.DhyraCookieManager
import com.dhyra.browser.core.security.DhyraSecurityManager
import com.dhyra.browser.core.network.WebViewModeManager
import com.dhyra.browser.core.translation.MLKitTranslator
import com.dhyra.browser.core.translation.TranslationBridge
import com.dhyra.browser.core.translation.DhyraTranslationManager
import com.dhyra.browser.core.translation.TranslationPhase
import com.dhyra.browser.core.translation.TranslationState
import com.dhyra.browser.core.translation.TranslationTextItem
import com.dhyra.browser.core.translation.TranslationBatch
import com.dhyra.browser.core.translation.TranslationBridgeMessage
import com.dhyra.browser.core.shields.ShieldsFilterEngine
import com.dhyra.browser.core.shields.ShieldsFilterManager
import com.dhyra.browser.core.shields.ShieldsContentScript
import com.dhyra.browser.core.shields.JudolIntelligence
import com.dhyra.browser.core.network.HttpsUpgrade
import com.dhyra.browser.core.network.UserAgents
import com.dhyra.browser.core.network.PrivacyHeaders
import com.dhyra.browser.core.tabs.DhyraTabManager
import com.dhyra.browser.core.tabs.DhyraTabMemoryPolicy
import com.dhyra.browser.core.tabs.DhyraTabLifecycleState
import com.dhyra.browser.core.tabs.RendererRecoveryPolicy
import com.dhyra.browser.core.tabs.DhyraSessionTab
import com.dhyra.browser.core.tabs.SpaceWebViewProfile
import java.io.ByteArrayInputStream
import org.json.JSONObject
import java.util.LinkedHashMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** UI-safe state for one browser tab. It deliberately contains no WebView types. */
data class BrowserTab(
    val id: Int,
    val url: String,
    val title: String,
    val progress: Int,
    val loading: Boolean,
    val isPrivate: Boolean,
    /** The tab this one was opened from; Back closes the child and returns here. */
    val parentId: Int? = null,
    /** Desktop/mobile rendering is independent for every tab. */
    val isDesktop: Boolean = false
)

/**
 * WebView-backed browser session coordinator.
 *
 * WebView remains the platform engine; this class is kept separate from Compose UI.
 * A device-aware policy retains one to three live WebViews. Other tabs are hibernated using
 * a bounded in-memory state cache and recreated lazily when selected. WebView Bundles are
 * never written to disk and are discarded under critical/background memory pressure.
 *
 * The Compose host attaches the active WebView through [attach] and releases it with
 * [detach]; this class re-attaches by itself whenever the active tab changes, so the UI
 * does not need to poll.
 */
class BrowserController(
    private val activity: Activity,
    private val onFileChooser: (ValueCallback<Array<Uri>>, WebChromeClient.FileChooserParams?) -> Unit,
    private val onPermission: (PermissionRequest) -> Unit,
    private val onGeolocation: (String, GeolocationPermissions.Callback) -> Unit,
    private val onDownloadRequest: (DhyraDownloadRequest) -> Unit
) {
    val tabs = mutableStateListOf<BrowserTab>()
    var activeTabId by mutableIntStateOf(-1)
        private set

    private val webViews = LinkedHashMap<Int, WebView>()
    private val activityManager = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val rendererRecoveryPolicy = RendererRecoveryPolicy()
    private var destroyed = false
    private var rendererCrashCount = 0L
    private val savedStates = mutableMapOf<Int, Bundle>()
    private val lastActiveAt = mutableMapOf<Int, Long>()
    private val tabLifecycleStates = mutableMapOf<Int, DhyraTabLifecycleState>()
    private val webViewModeManager = WebViewModeManager(activity)
    private val dhyraEngine = DhyraEngine(activity.applicationContext)
    private val webViewController = DhyraWebViewController(webViewModeManager)
    private val dhyraDownloadManager = DhyraDownloadManager(activity)
    val engineInfo: DhyraEngineInfo get() = dhyraEngine.info()
    private var defaultDesktopMode = false

    private val translationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mlKitTranslator = MLKitTranslator()
    private val translationBridges = mutableMapOf<Int, TranslationBridge>()
    private val translationManagers = mutableMapOf<Int, DhyraTranslationManager>()
    private val translationConfigs = mutableMapOf<Int, TranslationConfig>()
    var translationState by mutableStateOf(TranslationState())
        private set
    private data class TranslationConfig(
        val source: String,
        val target: String,
        val wifiOnly: Boolean,
        val pageUrl: String
    )

    /** Dedicated WebView profile; never silently falls back to the default profile. */
    private var spaceProfileReady by mutableStateOf(false)
    // Also invalidate Compose when a cleanup failure changes support without changing readiness.
    private var spaceProfileRevision by mutableIntStateOf(0)
    private val spaceProfile = SpaceWebViewProfile { ready ->
        spaceProfileReady = ready
        spaceProfileRevision++
    }
    private var hostResumed: Boolean = true

    /** Coalesce bursts of blocked subresources into at most one Compose invalidation per tab/250ms. */
    private fun scheduleShieldCounterUiUpdate(tabId: Int) {
        if (!pendingShieldCounterUpdates.add(tabId)) return
        translationScope.launch {
            try {
                delay(SHIELDS_COUNTER_UI_INTERVAL_MS)
                shieldRevision++
            } finally {
                pendingShieldCounterUpdates.remove(tabId)
            }
        }
    }

    private fun publishShieldsFilterStatus(lastUpdated: String, message: String) {
        shieldsNetworkRuleCount = shieldsFilterEngine.ruleCount
        shieldsCosmeticRuleCount = shieldsFilterEngine.cosmeticRuleCount
        shieldsFilterLastUpdated = lastUpdated
        shieldsFilterMessage = message
        // Apply a refreshed cosmetic snapshot to already-open pages without forcing reloads.
        webViews.forEach { (id, view) ->
            val tab = tabs.firstOrNull { it.id == id } ?: return@forEach
            if (!tab.loading && tab.url.startsWith("http", ignoreCase = true)) {
                applyCosmeticFilters(id, view, tab.url, tab.isPrivate)
            }
        }
        shieldRevision++
    }

    private fun applyCosmeticFilters(tabId: Int, view: WebView?, pageUrl: String, isPrivate: Boolean) {
        if (view == null || pageUrl.length > 8_192) return
        val engine = shieldsFilterEngine
        val enabled = siteShieldsEnabled(pageUrl, isPrivate)
        shieldsUpdateScope.launch(Dispatchers.Default) {
            val css = if (enabled) engine.cosmeticCssFor(pageUrl) else ""
            val hints = if (enabled) engine.blockedDestinationHintsFor(pageUrl)
                else ShieldsFilterEngine.DestinationHostHints.EMPTY
            val script = ShieldsContentScript.build(
                expectedPageUrl = pageUrl,
                cosmeticCss = css,
                blockedDocumentHosts = hints.documentHosts,
                blockedPopupHosts = hints.popupHosts,
                blockedSubdocumentHosts = hints.subdocumentHosts,
                blockedImageHosts = hints.imageHosts
            )
            withContext(Dispatchers.Main) {
                if (webViews[tabId] !== view) return@withContext
                val currentTab = tabs.firstOrNull { it.id == tabId } ?: return@withContext
                if (currentTab.url != pageUrl || view.url != pageUrl) return@withContext
                replaceDocumentStartScript(
                    tabId = tabId,
                    view = view,
                    script = script,
                    enabled = enabled && (css.isNotBlank() || hints.hasAnyHostHints())
                )
                // Fallback also updates the live document, including providers without DOCUMENT_START_SCRIPT.
                view.evaluateJavascript(script, null)
            }
        }
    }

    /**
     * Compile the page-specific cosmetic snapshot off the UI thread, then register it before
     * issuing loadUrl. Document-start injection is feature-gated because support depends on the
     * installed WebView provider, not Android API level alone.
     */
    private fun loadNavigationWithShields(
        tabId: Int,
        view: WebView,
        targetUrl: String,
        isPrivate: Boolean,
        headers: Map<String, String> = PrivacyHeaders.browserNavigationHeaders(),
        bypassShieldOnce: Boolean = false
    ) {
        pendingBlockedNavigationTargets.remove(tabId)
        if (!bypassShieldOnce) bypassMainFrameOnce.remove(tabId)
        val generation = navigationGenerations.getOrPut(tabId) { AtomicInteger() }.incrementAndGet()
        val engine = shieldsFilterEngine
        val enabled = siteShieldsEnabled(targetUrl, isPrivate)
        shieldsUpdateScope.launch(Dispatchers.Default) {
            val css = if (enabled) engine.cosmeticCssFor(targetUrl) else ""
            val hints = if (enabled) engine.blockedDestinationHintsFor(targetUrl)
                else ShieldsFilterEngine.DestinationHostHints.EMPTY
            val script = ShieldsContentScript.build(
                expectedPageUrl = targetUrl,
                cosmeticCss = css,
                blockedDocumentHosts = hints.documentHosts,
                blockedPopupHosts = hints.popupHosts,
                blockedSubdocumentHosts = hints.subdocumentHosts,
                blockedImageHosts = hints.imageHosts
            )
            withContext(Dispatchers.Main) {
                if (navigationGenerations[tabId]?.get() != generation || webViews[tabId] !== view) return@withContext
                replaceDocumentStartScript(
                    tabId = tabId,
                    view = view,
                    script = script,
                    enabled = enabled && (css.isNotBlank() || hints.hasAnyHostHints())
                )
                if (bypassShieldOnce) bypassMainFrameOnce[tabId] = targetUrl
                pageUrls[tabId] = targetUrl
                updateTab(tabId, url = targetUrl, title = targetUrl, loading = true, progress = 0)
                view.loadUrl(targetUrl, headers)
                if (tabId == activeTabId) attachToHost()
                notifyTabsChanged()
            }
        }
    }

    private fun replaceDocumentStartScript(tabId: Int, view: WebView, script: String, enabled: Boolean) {
        documentStartScripts.remove(tabId)?.let { old -> runCatching { old.remove() } }
        if (!enabled || !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return
        runCatching {
            // This script exposes no native object and performs no network/storage operations.
            // '*' lets its DOM-only destination matcher also run inside cross-origin frames;
            // the script itself validates the expected top-frame/referrer host before acting.
            documentStartScripts[tabId] = WebViewCompat.addDocumentStartJavaScript(view, script, setOf("*"))
        }.onFailure { error ->
            Log.w(TAG, "Document-start Shields injection unavailable for tab $tabId; using page-finished fallback", error)
        }
    }

    private fun removeDocumentStartScript(tabId: Int) {
        documentStartScripts.remove(tabId)?.let { handler -> runCatching { handler.remove() } }
        navigationGenerations.remove(tabId)
    }

    private fun shouldBlockTopLevelNavigation(
        tabId: Int,
        destinationUrl: String,
        popup: Boolean = false,
        sourcePageUrl: String? = null
    ): Boolean {
        val tab = tabs.firstOrNull { it.id == tabId } ?: return false
        if (!isWebUrl(destinationUrl)) return false
        val source = sourcePageUrl?.takeIf(::isWebUrl)
            ?: pageUrls[tabId]?.takeIf(::isWebUrl)
            ?: tab.url.takeIf(::isWebUrl)
            ?: destinationUrl
        val siteFilterEnabled = siteShieldsEnabled(source, tab.isPrivate)
        val siteJudolEnabled = judolEnabledForSite(source, tab.isPrivate)
        if (!siteFilterEnabled && !siteJudolEnabled) return false
        val type = if (popup) ShieldsFilterEngine.ResourceType.POPUP else ShieldsFilterEngine.ResourceType.DOCUMENT
        val filterBlocked = siteFilterEnabled && shieldsFilterEngine.shouldBlock(
            url = destinationUrl,
            pageUrl = source,
            resourceType = type,
            documentUrl = destinationUrl
        )
        if (filterBlocked) return true

        if (siteJudolEnabled) {
            val assessment = judolIntelligence.evaluate(destinationUrl)
            if (assessment.shouldBlock) {
                blockedNavigationReasons[tabId] = "High-confidence gambling destination: ${assessment.summary()}."
                return true
            }
        }
        return false
    }

    private fun showBlockedNavigation(tabId: Int, destinationUrl: String, reason: String = "This destination matched a Shields rule.") {
        if (tabs.none { it.id == tabId }) return
        val view = webViews[tabId] ?: ensureWebView(tabId, loadInitialUrl = false, allowBlank = true) ?: return
        navigationGenerations.getOrPut(tabId) { AtomicInteger() }.incrementAndGet()
        removeDocumentStartScript(tabId)
        navigationSourceUrls.remove(tabId)
        bypassMainFrameOnce.remove(tabId)
        pendingBlockedNavigationTargets[tabId] = destinationUrl
        pageUrls[tabId] = destinationUrl
        val safeTarget = escapeHtml(destinationUrl)
        val safeReason = escapeHtml(reason)
        val html = """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><title>Blocked by DHYRA</title><style>
            *{box-sizing:border-box}body{margin:0;min-height:100vh;padding:28px 20px;display:grid;place-items:center;background:#101318;color:#f4f6f8;font:16px system-ui,-apple-system,Segoe UI,sans-serif}.card{width:min(100%,560px);padding:28px;border:1px solid #343a44;border-radius:20px;background:#191e26;box-shadow:0 18px 48px #0005}h1{margin:0 0 10px;font-size:24px}.muted{color:#aeb8c5;line-height:1.5}.target{overflow-wrap:anywhere;padding:12px;border-radius:10px;background:#101318;font-size:13px;margin:18px 0}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:22px}a{display:inline-block;padding:12px 16px;border-radius:10px;text-decoration:none;font-weight:650}.primary{background:#f0f3f7;color:#151a20}.secondary{border:1px solid #596272;color:#f0f3f7}
            </style></head><body><main class="card"><h1>Halaman diblokir oleh DHYRA</h1><p class="muted">$safeReason</p><div class="target">$safeTarget</div><p class="muted">DHYRA menghentikan navigasi ini berdasarkan aturan perlindungan yang aktif.</p><div class="actions"><a class="primary" href="dhyra-shields://continue">Lanjutkan sekali</a><a class="secondary" href="dhyra-shields://whitelist">Whitelist sementara (sesi ini)</a></div></main></body></html>"""
        view.loadDataWithBaseURL(BLOCKED_PAGE_BASE_URL, html, "text/html", "UTF-8", null)
        updateTab(tabId, url = destinationUrl, title = "Blocked by DHYRA", loading = false, progress = 100)
        if (tabId == activeTabId) attachToHost()
        notifyTabsChanged()
    }

    private fun handleBlockedPageAction(tabId: Int, action: String) {
        val target = pendingBlockedNavigationTargets.remove(tabId) ?: return
        val tab = tabs.firstOrNull { it.id == tabId } ?: return
        if (action == "whitelist") {
            val host = runCatching { Uri.parse(target).host?.lowercase() }.getOrNull()
            if (!host.isNullOrBlank()) {
                val overrides = if (tab.isPrivate) spaceSiteShieldsOverrides else regularSiteShieldsOverrides
                overrides[host] = false
            }
        }
        continueBlockedNavigation(tabId, target)
    }

    private fun continueBlockedNavigation(tabId: Int, targetUrl: String) {
        val tab = tabs.firstOrNull { it.id == tabId } ?: return
        val view = ensureWebView(tabId, loadInitialUrl = false, allowBlank = true) ?: return
        val source = pageUrls[tabId]?.takeIf(::isWebUrl) ?: targetUrl
        navigationSourceUrls[tabId] = source
        prepareForNavigation(tabId, targetUrl)
        loadNavigationWithShields(
            tabId = tabId,
            view = view,
            targetUrl = targetUrl,
            isPrivate = tab.isPrivate,
            bypassShieldOnce = true
        )
    }

    private fun escapeHtml(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&#39;")

    /** Refresh the fixed EasyList, EasyPrivacy, Fanboy Annoyance and ABPindo subscriptions over HTTPS; no browsing URLs are sent. */
    fun updateShieldsFilterLists() {
        if (shieldsFilterUpdating) return
        shieldsFilterUpdating = true
        shieldsFilterMessage = "Updating protection lists…"
        shieldsUpdateScope.launch {
            try {
                val manager = shieldsFilterManager
                val result = manager.refreshNow()
                shieldsFilterEngine = manager.engine
                withContext(Dispatchers.Main) {
                    shieldsFilterUpdating = false
                    publishShieldsFilterStatus(manager.lastUpdatedLabel, result.message)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                Log.w(TAG, "Unable to refresh Shields filter lists; previous rules remain active", error)
                withContext(Dispatchers.Main) {
                    shieldsFilterUpdating = false
                    shieldsFilterMessage = "Could not refresh filter lists; previous protection remains active"
                }
            }
        }
    }

    val supportsSpaceProfiles: Boolean
        get() {
            spaceProfileRevision
            return spaceProfile.isSupported
        }

    /** True only after profile-scoped cleanup has completed for the current SPACE session. */
    val spaceReady: Boolean
        get() {
            spaceProfileRevision
            return com.dhyra.browser.core.tabs.SpaceSessionPolicy.canOpenSpaceTab(
                isolatedProfileAvailable = supportsSpaceProfiles,
                cleanupCompleted = spaceProfileReady
            )
        }
    // A small bundled snapshot is ready immediately; downloaded subscriptions are parsed on IO
    // and atomically replace this engine without blocking page-request interception or the UI.
    @Volatile private var shieldsFilterEngine = ShieldsFilterEngine(
        runCatching { activity.assets.open("shields_blocklist.txt").bufferedReader().use { it.readLines() } }
            .getOrDefault(emptyList())
    )
    private val shieldsFilterManager by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        ShieldsFilterManager(activity.applicationContext)
    }
    // Local-only domain data: no page URL, history, or typed text is transmitted.
    private val judolIntelligence = JudolIntelligence(
        blockedDomainRules = readLocalDomainAsset("judol_domains.txt"),
        allowedDomainRules = readLocalDomainAsset("judol_allowlist.txt")
    )
    private fun readLocalDomainAsset(name: String): List<String> = runCatching {
        activity.assets.open(name).bufferedReader().use { it.readLines() }
    }.getOrDefault(emptyList())
    private val shieldsUpdateScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    var shieldsNetworkRuleCount by mutableIntStateOf(shieldsFilterEngine.ruleCount)
        private set
    var shieldsCosmeticRuleCount by mutableIntStateOf(shieldsFilterEngine.cosmeticRuleCount)
        private set
    var shieldsFilterLastUpdated by mutableStateOf("Not updated yet")
        private set
    var shieldsFilterUpdating by mutableStateOf(false)
        private set
    var shieldsFilterMessage by mutableStateOf("Built-in protection is active")
        private set
    private val regularSiteShieldsOverrides = ConcurrentHashMap<String, Boolean>()
    private val spaceSiteShieldsOverrides = ConcurrentHashMap<String, Boolean>()
    /** Request callbacks run off the UI thread; never read Compose tab state from there. */
    private val pageUrls = ConcurrentHashMap<Int, String>()
    private val blockedRequestCounts = ConcurrentHashMap<Int, Int>()
    /** IDs of WebChromeClient-created windows; consumed by their first HTTP(S) main-frame request. */
    private val popupTabIds = ConcurrentHashMap.newKeySet<Int>()
    /** Opener page used to evaluate $popup, $third-party and domain= filters on the popup destination. */
    private val popupOpenerUrls = ConcurrentHashMap<Int, String>()
    /** Source URL captured before a top-level navigation, used for domain/third-party rules. */
    private val navigationSourceUrls = ConcurrentHashMap<Int, String>()
    /** One-shot bypass is consumed only by the matching main-frame request. */
    private val bypassMainFrameOnce = ConcurrentHashMap<Int, String>()
    private val pendingBlockedNavigationTargets = ConcurrentHashMap<Int, String>()
    private val blockedNavigationReasons = ConcurrentHashMap<Int, String>()
    private val documentStartScripts = ConcurrentHashMap<Int, ScriptHandler>()
    private val navigationGenerations = ConcurrentHashMap<Int, AtomicInteger>()
    private val pendingShieldCounterUpdates = ConcurrentHashMap.newKeySet<Int>()
    private var shieldRevision by mutableIntStateOf(0)
    private var nextId = 1
    private val uaStale = mutableSetOf<Int>()
    private val thumbnails = mutableStateMapOf<Int, Bitmap>()
    private val favicons = mutableStateMapOf<Int, Bitmap>()
    /** Small in-memory favicon cache, keyed by normalized host; never stores SPACE icons. */
    private val faviconsByHost = object : LinkedHashMap<String, Bitmap>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Bitmap>?): Boolean = size > 64
    }
    var faviconRevision by mutableIntStateOf(0)
        private set
    private var host: FrameLayout? = null
    private var fullscreenView: View? = null
    private var fullscreenContainer: FrameLayout? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var previousRequestedOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private val readerModeTabs = mutableSetOf<Int>()
    var readerModeActive by androidx.compose.runtime.mutableStateOf(false)
        private set
    private var statusBarsWereVisible: Boolean = true
    private var navigationBarsWereVisible: Boolean = true
    private var priorSystemBarsBehavior: Int = WindowInsetsControllerCompat.BEHAVIOR_DEFAULT
    var isFullscreen by androidx.compose.runtime.mutableStateOf(false)
        private set
    var findActiveMatch by mutableIntStateOf(0)
        private set
    var findMatchCount by mutableIntStateOf(0)
        private set

    @Volatile var trackingProtection = true
    @Volatile var popupBlocker = true
    @Volatile var judolProtectionEnabled = true
    val judolBlockedDomainCount: Int get() = judolIntelligence.blockedDomainCount
    val judolAllowedDomainCount: Int get() = judolIntelligence.allowedDomainCount
    val desktopMode: Boolean
        get() = activeTab()?.isDesktop ?: defaultDesktopMode
    var httpsFirst = true
    var onPageFinished: (BrowserTab) -> Unit = {}
    var onTabsChanged: (List<BrowserTab>) -> Unit = {}

    // Keep this init block after every property it touches. Kotlin initializes member
    // properties in declaration order; launching the Shields coroutine before
    // `shieldsUpdateScope` is initialized would crash BrowserController construction.
    init {
        // Private data left behind by a killed process is erased before SPACE becomes usable.
        clearSpaceProfileData()
        shieldsUpdateScope.launch {
            try {
                val manager = shieldsFilterManager
                shieldsFilterEngine = manager.engine
                withContext(Dispatchers.Main) {
                    publishShieldsFilterStatus(manager.lastUpdatedLabel, "Built-in and saved lists are active")
                    shieldsFilterUpdating = true
                }
                val result = manager.updateIfDue()
                shieldsFilterEngine = manager.engine
                withContext(Dispatchers.Main) {
                    shieldsFilterUpdating = false
                    publishShieldsFilterStatus(manager.lastUpdatedLabel, result.message)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                Log.w(TAG, "Unable to initialize Shields filter subscriptions; bundled rules remain active", error)
                withContext(Dispatchers.Main) {
                    shieldsFilterUpdating = false
                    publishShieldsFilterStatus(shieldsFilterLastUpdated, "Filter lists unavailable; bundled protection remains active")
                }
            }
        }
    }

    fun activeTab(): BrowserTab? = tabs.firstOrNull { it.id == activeTabId }
    val liveWebViewCount: Int get() = webViews.size
    val liveWebViewLimit: Int get() = currentLiveWebViewLimit()
    val totalRendererCrashCount: Long get() = rendererCrashCount
    fun lifecycleStateOf(tabId: Int): DhyraTabLifecycleState? = tabLifecycleStates[tabId]
    fun activeWebView(): WebView? = webViews[activeTabId]
    fun hasWebView(id: Int): Boolean = webViews.containsKey(id)
    fun canGoBack(): Boolean = activeWebView()?.canGoBack() == true
    /** Requests observed and blocked for the current top-level page in this tab. */
    fun blockedRequestCount(tabId: Int): Int {
        shieldRevision
        return blockedRequestCounts[tabId] ?: 0
    }
    fun shieldsEnabledForActiveSite(): Boolean = activeTab()?.let { tab ->
        siteShieldsEnabled(tab.url, tab.isPrivate)
    } ?: trackingProtection

    fun setShieldsEnabledForActiveSite(enabled: Boolean) {
        val tab = activeTab() ?: return
        val host = runCatching { Uri.parse(tab.url).host?.lowercase() }.getOrNull() ?: return
        val overrides = if (tab.isPrivate) spaceSiteShieldsOverrides else regularSiteShieldsOverrides
        if (enabled == trackingProtection) overrides.remove(host) else overrides[host] = enabled
        shieldRevision++
        activeWebView()?.reload()
    }

    private fun siteShieldsEnabled(pageUrl: String, isPrivate: Boolean): Boolean {
        val host = runCatching { Uri.parse(pageUrl).host?.lowercase() }.getOrNull() ?: return trackingProtection
        val overrides = if (isPrivate) spaceSiteShieldsOverrides else regularSiteShieldsOverrides
        return overrides[host] ?: trackingProtection
    }

    /** Judol navigation protection has its own global toggle; an explicit per-site Shields-off override disables it. */
    private fun judolEnabledForSite(pageUrl: String, isPrivate: Boolean): Boolean {
        if (!judolProtectionEnabled) return false
        val host = runCatching { Uri.parse(pageUrl).host?.lowercase() }.getOrNull() ?: return true
        val overrides = if (isPrivate) spaceSiteShieldsOverrides else regularSiteShieldsOverrides
        return overrides[host] != false
    }
    fun totalBlockedRequestCount(): Int {
        // Reading this Compose state makes the toolbar badge reactive to intercepted requests.
        shieldRevision
        return blockedRequestCounts.values.sum()
    }

    /** New-tab pages do not allocate a WebView until a site is opened. */
    fun createTab(url: String = "about:blank", isPrivate: Boolean = false, parentId: Int? = null): Int {
        if (isPrivate) {
            if (!supportsSpaceProfiles) {
                Toast.makeText(
                    activity,
                    "space is unavailable because this WebView provider does not support isolated profiles and complete data deletion.",
                    Toast.LENGTH_LONG
                ).show()
                return -1
            }
            if (!spaceProfileReady) {
                Toast.makeText(activity, localizePlainUiText(activity, "Secure space storage is being cleared. Please try again in a moment."), Toast.LENGTH_SHORT).show()
                return -1
            }
        }
        val previousActiveId = activeTabId
        if (previousActiveId >= 0) {
            tabLifecycleStates[previousActiveId] = if (webViews.containsKey(previousActiveId)) {
                DhyraTabLifecycleState.BACKGROUND
            } else DhyraTabLifecycleState.HIBERNATING
        }
        val id = nextId++
        val initialUrl = HttpsUpgrade.upgrade(url, httpsFirst)
        val initialMode = if (defaultDesktopMode) WebViewMode.DESKTOP else WebViewMode.MOBILE
        webViewModeManager.registerTab(id, initialMode)
        tabs.add(BrowserTab(id, initialUrl, "New tab", 0, false, isPrivate, parentId, initialMode == WebViewMode.DESKTOP))
        tabLifecycleStates[id] = DhyraTabLifecycleState.ACTIVE
        pageUrls[id] = initialUrl
        activeTabId = id
        lastActiveAt[id] = System.currentTimeMillis()
        // A private blank tab also creates its WebView immediately so profile attachment
        // is validated before the tab becomes visible. Regular blank tabs stay lazy.
        if (initialUrl != "about:blank" || isPrivate) {
            val createdView = ensureWebView(
                id,
                loadInitialUrl = true,
                allowBlank = isPrivate && initialUrl == "about:blank"
            )
            if (createdView == null) {
                tabs.removeAll { it.id == id }
                pageUrls.remove(id)
                lastActiveAt.remove(id)
                tabLifecycleStates.remove(id)
                webViewModeManager.removeTab(id)
                activeTabId = previousActiveId.takeIf { previous -> tabs.any { it.id == previous } }
                    ?: tabs.lastOrNull()?.id
                    ?: -1
                attachToHost()
                notifyTabsChanged()
                Toast.makeText(activity, localizePlainUiText(activity, "The space profile could not be attached. space has been disabled."), Toast.LENGTH_LONG).show()
                return -1
            }
            attachToHost()
        }
        // A blank tab has no WebView, so the previous page is left on screen until the UI
        // leaves the browser screen. That lets the screen transition fade the page out
        // smoothly instead of flashing an empty area first (detach() clears the host).
        notifyTabsChanged()
        return id
    }

    internal fun restoreSession(entries: List<SessionTab>) {
        if (tabs.isNotEmpty()) return
        entries.filter { isWebUrl(it.url) }.takeLast(30).forEach { entry ->
            val url = HttpsUpgrade.upgrade(entry.url, httpsFirst)
            val id = nextId++
            val initialMode = if (entry.isDesktop) WebViewMode.DESKTOP else WebViewMode.MOBILE
            webViewModeManager.registerTab(id, initialMode)
            tabs.add(BrowserTab(id, url, entry.title.ifBlank { url }, 0, false, false, isDesktop = initialMode == WebViewMode.DESKTOP))
            pageUrls[id] = url
            lastActiveAt[id] = System.currentTimeMillis()
            tabLifecycleStates[id] = DhyraTabLifecycleState.HIBERNATING
        }
        if (tabs.isNotEmpty()) activeTabId = tabs.last().id
        attachToHost()
        notifyTabsChanged()
    }

    fun sessionSnapshot(): List<DhyraSessionTab> = tabs
        .filter { !it.isPrivate && isWebUrl(it.url) }
        .takeLast(30)
        .map { DhyraSessionTab(it.url, it.title, it.isDesktop) }

    fun selectTab(id: Int) {
        if (tabs.none { it.id == id }) return
        activate(id)
        attachToHost()
        notifyTabsChanged()
    }

    fun selectRelativeTab(direction: Int) {
        if (tabs.size < 2 || direction == 0) return
        val currentIndex = tabs.indexOfFirst { it.id == activeTabId }.coerceAtLeast(0)
        val nextIndex = (currentIndex + if (direction > 0) 1 else -1).mod(tabs.size)
        selectTab(tabs[nextIndex].id)
    }

    private fun activate(id: Int) {
        val previousId = activeTabId
        if (previousId != id) {
            webViews[previousId]?.onPause()
            translationManagers[previousId]?.onTabInactive()
            if (previousId >= 0 && tabs.any { it.id == previousId }) {
                tabLifecycleStates[previousId] = if (webViews.containsKey(previousId)) {
                    DhyraTabLifecycleState.BACKGROUND
                } else DhyraTabLifecycleState.HIBERNATING
            }
        }
        activeTabId = id
        tabLifecycleStates[id] = if (webViews.containsKey(id)) DhyraTabLifecycleState.ACTIVE else DhyraTabLifecycleState.RESTORING
        translationManagers[id]?.onTabActive()
        readerModeActive = id in readerModeTabs
        translationState = translationManagers[id]?.state ?: TranslationState()
        lastActiveAt[id] = System.currentTimeMillis()
        val tab = tabs.firstOrNull { it.id == id } ?: return
        if (tab.url != "about:blank") ensureWebView(id, loadInitialUrl = true)
        tabLifecycleStates[id] = if (webViews.containsKey(id)) DhyraTabLifecycleState.ACTIVE else DhyraTabLifecycleState.RESTORING
        val selected = webViews[id]
        if (hostResumed) selected?.onResume() else selected?.onPause()
        // A Desktop/Mobile switch made while this tab was in the background applies on return.
        if (uaStale.remove(id)) selected?.reload()
    }

    /** Forward the Activity lifecycle to live WebViews without globally pausing WebView timers. */
    fun onHostPause() {
        hostResumed = false
        webViews.values.forEach { runCatching { it.onPause() } }
        translationManagers.values.forEach { it.onHostPaused() }
    }

    fun onHostResume() {
        hostResumed = true
        val tab = activeTab()
        if (tab != null && tab.url != "about:blank" && !webViews.containsKey(tab.id) &&
            tabLifecycleStates[tab.id] != DhyraTabLifecycleState.CRASHED
        ) {
            ensureWebView(tab.id, loadInitialUrl = true)
            attachToHost()
        }
        webViews[activeTabId]?.let { runCatching { it.onResume() } }
        translationManagers.values.forEach { it.onHostResumed() }
    }

    /** The parent of [id], but only while that parent tab is still open. */
    private fun liveParentOf(id: Int): Int? {
        val parent = tabs.firstOrNull { it.id == id }?.parentId ?: return null
        return parent.takeIf { candidate -> candidate != id && tabs.any { it.id == candidate } }
    }

    fun parentOfActive(): Int? = liveParentOf(activeTabId)

    /** Closes the active tab and returns to its parent. Returns false when there is no parent. */
    fun closeActiveTabToParent(): Boolean {
        if (parentOfActive() == null) return false
        closeTab(activeTabId)
        return true
    }

    fun navigate(url: String) {
        val targetUrl = HttpsUpgrade.upgrade(url, httpsFirst)
        val id = activeTabId
        if (id == -1 || tabs.none { it.id == id }) {
            createTab(targetUrl)
            return
        }
        val tab = tabs.firstOrNull { it.id == id } ?: return
        val sourceUrl = pageUrls[id]?.takeIf(::isWebUrl) ?: tab.url
        if (shouldBlockTopLevelNavigation(id, targetUrl, sourcePageUrl = sourceUrl)) {
            showBlockedNavigation(id, targetUrl)
            return
        }
        navigationSourceUrls[id] = sourceUrl
        prepareForNavigation(id, targetUrl)
        updateTab(id, url = targetUrl, title = targetUrl, loading = true, progress = 0)
        // Always issue the requested navigation, including when the tab was frozen.
        // A restored WebView may contain the previous page's history/state.
        val view = ensureWebView(id, loadInitialUrl = false, allowBlank = true)
        if (view != null) loadNavigationWithShields(id, view, targetUrl, tab.isPrivate)
        attachToHost()
        notifyTabsChanged()
    }

    fun exitFullscreen() {
        val view = fullscreenView ?: return
        (fullscreenContainer ?: view).let { container ->
            (container.parent as? ViewGroup)?.removeView(container)
        }
        fullscreenCallback?.onCustomViewHidden()
        fullscreenView = null
        fullscreenContainer = null
        fullscreenCallback = null
        val decor = activity.window.decorView
        val insetsController = WindowInsetsControllerCompat(activity.window, decor)
        if (statusBarsWereVisible) insetsController.show(WindowInsetsCompat.Type.statusBars())
        else insetsController.hide(WindowInsetsCompat.Type.statusBars())
        if (navigationBarsWereVisible) insetsController.show(WindowInsetsCompat.Type.navigationBars())
        else insetsController.hide(WindowInsetsCompat.Type.navigationBars())
        insetsController.systemBarsBehavior = priorSystemBarsBehavior
        activity.requestedOrientation = previousRequestedOrientation
        isFullscreen = false
    }

    fun goBack() { activeWebView()?.let { if (it.canGoBack()) it.goBack() } }
    fun goForward() { activeWebView()?.let { if (it.canGoForward()) it.goForward() } }
    fun reload() {
        val tab = activeTab() ?: return
        val alreadyLive = webViews.containsKey(tab.id)
        // A renderer-crashed/hibernated tab is recreated through the normal navigation path,
        // so HTTPS upgrade, Shields checks, document-start scripts and source context still apply.
        val view = ensureWebView(
            tab.id,
            loadInitialUrl = !alreadyLive,
            allowBlank = true
        ) ?: return
        if (alreadyLive) {
            val currentUrl = view.url
            if (currentUrl.isNullOrBlank() || currentUrl == "about:blank") {
                if (isWebUrl(tab.url)) {
                    navigationSourceUrls[tab.id] = pageUrls[tab.id]?.takeIf(::isWebUrl) ?: tab.url
                    loadNavigationWithShields(tab.id, view, tab.url, tab.isPrivate)
                }
            } else {
                view.reload()
            }
        }
        attachToHost()
    }
    fun stop() { activeWebView()?.stopLoading() }

    fun setReaderMode(enabled: Boolean) {
        val tabId = activeTabId
        if (tabId == -1) return
        if (enabled) readerModeTabs.add(tabId) else readerModeTabs.remove(tabId)
        readerModeActive = tabId in readerModeTabs
        activeWebView()?.evaluateJavascript(readerModeScript(enabled), null)
    }

    private fun readerModeScript(enabled: Boolean): String = if (enabled) {
        """(function(){var id='dhyra-reader-style';var old=document.getElementById(id);if(old)old.remove();if(!document.body)return; if(!document.body.hasAttribute('data-dhyra-reader-bg'))document.body.setAttribute('data-dhyra-reader-bg',document.body.style.background||'');var s=document.createElement('style');s.id=id;s.textContent='body{box-sizing:border-box!important;max-width:760px!important;margin:24px auto!important;padding:24px!important;font-family:Georgia,serif!important;font-size:19px!important;line-height:1.75!important;background:#fff!important;color:#222!important}nav,header,footer,aside,form,[role=navigation],[role=advertisement],video,iframe{display:none!important}article,main{display:block!important;max-width:100%!important}img{max-width:100%!important;height:auto!important}';document.head.appendChild(s);document.body.style.background='#fff';})();"""
    } else {
        """(function(){document.getElementById('dhyra-reader-style')?.remove();if(document.body){var bg=document.body.getAttribute('data-dhyra-reader-bg');if(bg!==null){document.body.style.background=bg;document.body.removeAttribute('data-dhyra-reader-bg');}}})();"""
    }

    fun printCurrentPage() {
        val webView = activeWebView() ?: return
        val manager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        runCatching {
            val adapter = webView.createPrintDocumentAdapter("dhyra-${System.currentTimeMillis()}")
            manager.print("dhyra page", adapter, PrintAttributes.Builder().build())
        }
    }

    fun closeTab(id: Int) {
        val closing = tabs.firstOrNull { it.id == id } ?: return
        val nextActive = DhyraTabManager.afterClose(tabs.map { it.id }, id, activeTabId) { child -> liveParentOf(child) }
        releaseTab(closing)
        tabs.removeAll { it.id == id }
        if (activeTabId == id) {
            if (nextActive != null && tabs.any { it.id == nextActive }) activate(nextActive) else activeTabId = -1
        }
        if (tabs.isEmpty()) createTab() else attachToHost()

        if (closing.isPrivate) clearSpaceProfileWhenSessionEnds()
        notifyTabsChanged()
    }

    /**
     * Closes every tab, or only the private/regular group, and always leaves a usable tab
     * behind so the UI never shows an empty or black screen. Every closed WebView is
     * stopped, wiped, removed from its parent and destroyed.
     */
    fun closeAllTabs(onlyPrivate: Boolean? = null) {
        val victims = tabs.filter { onlyPrivate == null || it.isPrivate == onlyPrivate }
        if (victims.isEmpty()) return
        if (isFullscreen) exitFullscreen()
        val originalOrder = tabs.map { it.id }
        val closedIds = victims.mapTo(mutableSetOf()) { it.id }
        victims.forEach { releaseTab(it) }
        tabs.removeAll { it.id in closedIds }
        if (victims.any { it.isPrivate }) clearSpaceProfileWhenSessionEnds()

        // Preserve the current tab when it survives; otherwise switch to the other group
        // instead of unexpectedly creating a new regular tab while SPACE tabs remain.
        val nextActiveId = DhyraTabManager.afterCloseAll(originalOrder, closedIds, activeTabId)
        if (nextActiveId != null && tabs.any { it.id == nextActiveId }) {
            if (activeTabId != nextActiveId) activate(nextActiveId)
            attachToHost()
            notifyTabsChanged()
        } else {
            activeTabId = -1
            createTab()
        }
    }

    /** Re-opens tabs closed by "Close all" (Undo). Pages load lazily; SPACE tabs are never restored. */
    fun restoreClosedTabs(entries: List<DhyraSessionTab>) {
        val valid = entries.filter { isWebUrl(it.url) }.takeLast(30)
        if (valid.isEmpty()) return
        // Drop the untouched blank tab that "Close all" created so Undo restores exactly what was closed.
        val untouched = tabs.singleOrNull()
            ?.takeIf { it.url == "about:blank" && !it.isPrivate && !webViews.containsKey(it.id) }
        if (untouched != null) {
            tabs.removeAll { it.id == untouched.id }
            lastActiveAt.remove(untouched.id)
            tabLifecycleStates.remove(untouched.id)
        }
        var lastId = -1
        valid.forEach { entry ->
            val url = HttpsUpgrade.upgrade(entry.url, httpsFirst)
            val id = nextId++
            val initialMode = if (entry.isDesktop) WebViewMode.DESKTOP else WebViewMode.MOBILE
            webViewModeManager.registerTab(id, initialMode)
            tabs.add(BrowserTab(id, url, entry.title.ifBlank { url }, 0, false, false, isDesktop = initialMode == WebViewMode.DESKTOP))
            pageUrls[id] = url
            lastActiveAt[id] = System.currentTimeMillis()
            tabLifecycleStates[id] = DhyraTabLifecycleState.HIBERNATING
            lastId = id
        }
        activate(lastId)
        attachToHost()
        notifyTabsChanged()
    }

    private fun releaseTab(tab: BrowserTab) {
        destroyWebView(tab.id)
        savedStates.remove(tab.id)
        lastActiveAt.remove(tab.id)
        tabLifecycleStates.remove(tab.id)
        blockedRequestCounts.remove(tab.id)
        popupTabIds.remove(tab.id)
        popupOpenerUrls.remove(tab.id)
        navigationSourceUrls.remove(tab.id)
        bypassMainFrameOnce.remove(tab.id)
        pendingBlockedNavigationTargets.remove(tab.id)
        blockedNavigationReasons.remove(tab.id)
        removeDocumentStartScript(tab.id)
        thumbnails.remove(tab.id)
        favicons.remove(tab.id)
        uaStale.remove(tab.id)
        rendererRecoveryPolicy.forgetTab(tab.id)
        pendingScrollRestore.remove(tab.id)
        pageUrls.remove(tab.id)
        readerModeTabs.remove(tab.id)
        translationConfigs.remove(tab.id)
        translationManagers.remove(tab.id)
        translationBridges.remove(tab.id)
        webViewModeManager.removeTab(tab.id)
        if (activeTabId == tab.id) {
            readerModeActive = false
            translationState = TranslationState()
        }
        // Per-site Shields preferences belong to regular browsing and must not be reset
        // merely because a SPACE session ended.
    }

    // ---- tab switcher previews ----

    fun thumbnailOf(id: Int): Bitmap? = thumbnails[id]
    fun faviconOf(id: Int): Bitmap? = favicons[id]

    /** Returns a recently observed regular-profile favicon for a URL's host, if available. */
    fun faviconForUrl(url: String): Bitmap? {
        // Read the snapshot state so Compose re-runs this lookup when a WebChromeClient icon arrives.
        faviconRevision
        val host = faviconHost(url) ?: return null
        return faviconsByHost[host]
            ?: tabs.firstOrNull { !it.isPrivate && faviconHost(it.url) == host }?.let { favicons[it.id] }
    }

    private fun rememberFavicon(url: String?, bitmap: Bitmap?) {
        if (bitmap == null) return
        val host = faviconHost(url) ?: return
        faviconsByHost[host] = compactFavicon(bitmap)
        faviconRevision++
    }

    /** Keep favicon memory predictable even when a site sends a large touch icon. */
    private fun compactFavicon(bitmap: Bitmap): Bitmap {
        val maxDimension = maxOf(bitmap.width, bitmap.height)
        if (maxDimension <= 128 || maxDimension <= 0) return bitmap
        val scale = 128f / maxDimension.toFloat()
        val width = (bitmap.width * scale).toInt().coerceAtLeast(1)
        val height = (bitmap.height * scale).toInt().coerceAtLeast(1)
        return runCatching { Bitmap.createScaledBitmap(bitmap, width, height, true) }.getOrDefault(bitmap)
    }

    private fun faviconHost(url: String?): String? = runCatching {
        Uri.parse(url.orEmpty()).host
            ?.lowercase(java.util.Locale.ROOT)
            ?.trimEnd('.')
            ?.removePrefix("www.")
            ?.takeIf(String::isNotBlank)
    }.getOrNull()

    /** Snapshots the visible page for the tab switcher. SPACE tabs never get a preview. */
    fun captureThumbnail() {
        val tab = activeTab() ?: return
        if (tab.isPrivate) return
        val view = webViews[tab.id] ?: return
        val width = view.width
        val height = view.height
        if (width <= 0 || height <= 0 || view.parent == null) return
        runCatching {
            val scale = THUMBNAIL_WIDTH_PX.toFloat() / width
            val bitmap = Bitmap.createBitmap(
                THUMBNAIL_WIDTH_PX,
                (height * scale).toInt().coerceAtLeast(1),
                Bitmap.Config.RGB_565
            )
            val canvas = Canvas(bitmap)
            canvas.drawColor(android.graphics.Color.WHITE)
            canvas.scale(scale, scale)
            view.draw(canvas)
            // Replaced bitmaps are left to the GC: Compose may still be drawing the old one.
            thumbnails[tab.id] = bitmap
            trimThumbnails()
        }
    }

    private fun trimThumbnails() {
        while (thumbnails.size > MAX_THUMBNAILS) {
            val victim = thumbnails.keys
                .filter { it != activeTabId }
                .minByOrNull { lastActiveAt[it] ?: Long.MIN_VALUE }
                ?: break
            thumbnails.remove(victim)
        }
    }

    // ---- find in page ----

    fun find(query: String) {
        val view = activeWebView() ?: return
        if (query.isBlank()) clearFind() else view.findAllAsync(query)
    }

    fun findNext(forward: Boolean) { activeWebView()?.findNext(forward) }

    fun clearFind() {
        activeWebView()?.clearMatches()
        findActiveMatch = 0
        findMatchCount = 0
    }

    fun attach(container: FrameLayout) {
        host = container
        attachToHost()
    }

    /** Releases [container] when its composable leaves; a newer container is left untouched. */
    fun detach(container: FrameLayout) {
        if (host !== container) return
        container.removeAllViews()
        host = null
    }

    private fun attachToHost() {
        val container = host ?: return
        val tab = activeTab()
        // A popup tab has a live WebView while its URL is still about:blank, so check the map first.
        val view = when {
            tab == null -> null
            webViews.containsKey(tab.id) -> webViews[tab.id]
            tab.url != "about:blank" -> ensureWebView(tab.id, loadInitialUrl = true)
            else -> null
        }
        if (view == null) {
            container.removeAllViews()
            return
        }
        if (view.parent !== container) {
            (view.parent as? ViewGroup)?.removeView(view)
            container.removeAllViews()
            container.addView(
                view,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }
    }

    /** Applies global preferences. Desktop is the default for future tabs; existing tabs keep their own mode. */
    fun applySettings(
        tracking: Boolean,
        popup: Boolean,
        desktop: Boolean,
        judolProtection: Boolean = true
    ) {
        trackingProtection = tracking
        popupBlocker = popup
        judolProtectionEnabled = judolProtection
        defaultDesktopMode = desktop
        webViews.forEach { (id, view) ->
            configureSettings(view, id, tabs.firstOrNull { it.id == id }?.isPrivate == true)
        }
    }

    fun setDesktopMode(tabId: Int, enabled: Boolean): Boolean {
        val index = tabs.indexOfFirst { it.id == tabId }
        if (index < 0) return false
        val tab = tabs[index]
        val mode = if (enabled) WebViewMode.DESKTOP else WebViewMode.MOBILE
        if (webViewModeManager.getCurrentMode(tabId) == mode) return true
        webViewModeManager.setMode(tabId, mode)
        tabs[index] = tab.copy(isDesktop = enabled)
        val view = webViews[tabId]
        if (view != null) {
            val applied = webViewModeManager.applyCurrentMode(view, tabId)
            if (!applied) {
                webViewModeManager.setMode(tabId, WebViewMode.MOBILE)
                tabs[index] = tab.copy(isDesktop = false)
                return false
            }
            pendingScrollRestore[tabId] = view.scrollY
            if (tabId == activeTabId) view.reload() else uaStale.add(tabId)
        }
        notifyTabsChanged()
        return true
    }

    private val pendingScrollRestore = mutableMapOf<Int, Int>()

    private fun prepareForNavigation(tabId: Int, targetUrl: String) {
        val current = tabs.firstOrNull { it.id == tabId }?.url
        if (current != null && current != targetUrl) {
            translationConfigs.remove(tabId)
            translationManagers[tabId]?.stopForNavigation()
            translationState = if (tabId == activeTabId) TranslationState() else translationState
        }
    }

    fun startTranslation(source: String, target: String, wifiOnly: Boolean = true): Boolean {
        val tab = activeTab() ?: return false
        val view = activeWebView() ?: return false
        if (!tab.url.startsWith("https://", ignoreCase = true)) {
            translationState = TranslationState(
                phase = TranslationPhase.ERROR,
                sourceLanguage = source,
                targetLanguage = target,
                message = "Page translation is available only on HTTPS pages."
            )
            return false
        }
        val bridge = translationBridges[tab.id]
        if (bridge == null) {
            translationState = TranslationState(
                phase = TranslationPhase.ERROR,
                sourceLanguage = source,
                targetLanguage = target,
                message = "This Android System WebView does not support the secure translation message API."
            )
            return false
        }
        val manager = translationManagers.getOrPut(tab.id) {
            DhyraTranslationManager(
                webView = view,
                bridge = bridge,
                translator = mlKitTranslator,
                scope = translationScope,
                scriptProvider = {
                    activity.assets.open("PageTranslation.js").bufferedReader().use { it.readText() }
                },
                onStateChanged = { next -> if (activeTabId == tab.id) translationState = next }
            )
        }
        translationConfigs[tab.id] = TranslationConfig(source, target, wifiOnly, tab.url)
        manager.start(source, target, wifiOnly)
        translationState = manager.state
        return true
    }

    fun pauseTranslation() {
        translationManagers[activeTabId]?.pause()
        translationState = translationManagers[activeTabId]?.state ?: translationState
    }

    fun resumeTranslation() {
        translationManagers[activeTabId]?.resume()
        translationState = translationManagers[activeTabId]?.state ?: translationState
    }

    fun restoreOriginalTranslation() {
        translationManagers[activeTabId]?.restoreOriginalText()
        translationConfigs.remove(activeTabId)
        translationState = translationManagers[activeTabId]?.state ?: TranslationState()
    }

    fun clearRegularData() {
        webViews.forEach { (id, view) ->
            if (tabs.firstOrNull { it.id == id }?.isPrivate != true) {
                // Cache/cookies/storage are cleared through the regular profile's
                // WebStorageCompat API below. WebView.clearCache(true) is application-wide
                // on some providers and could cross the named private-profile boundary.
                view.clearHistory()
                view.clearFormData()
            }
        }
        // CookieManager/WebStorage instances without a Profile are the regular default profile.
        // SPACE sessions use their own named profile and are never touched here.
        DhyraCookieManager().clearAll()
        DhyraCacheManager.clearRegularProfile()
    }

    /** Called by Activity.onTrimMemory; WebView work is performed on the main thread. */
    fun trimMemory(level: Int = ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
        if (destroyed) return
        val active = activeTabId
        val discardSnapshots = DhyraTabMemoryPolicy.shouldDiscardSavedState(level)
        if (DhyraTabMemoryPolicy.shouldHibernateInactiveTabs(level)) {
            webViews.keys.filter { it != active }.toList().forEach { id ->
                freezeTab(id, saveState = !discardSnapshots)
            }
        }
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            trimToLiveWebViewLimit(exceptId = active, discardSnapshots = discardSnapshots)
        }
        val snapshotLimit = DhyraTabMemoryPolicy.maxSavedStateSnapshots(currentLiveWebViewLimit(), level)
        trimSavedStateBundles(snapshotLimit)
        thumbnails.clear()
    }

    private fun currentLiveWebViewLimit(): Int {
        val memory = ActivityManager.MemoryInfo().also(activityManager::getMemoryInfo)
        return DhyraTabMemoryPolicy.maxLiveWebViews(
            totalMemoryBytes = memory.totalMem,
            availableMemoryBytes = memory.availMem,
            isLowRamDevice = activityManager.isLowRamDevice,
            lowMemory = memory.lowMemory,
            memoryClassMb = activityManager.memoryClass
        )
    }

    fun destroy() {
        if (destroyed) return
        destroyed = true
        if (isFullscreen) exitFullscreen()
        val hadPrivateTabs = tabs.any { it.isPrivate }
        webViews.keys.toList().forEach { id -> destroyWebView(id) }
        translationManagers.values.forEach { runCatching { it.destroy() } }
        translationManagers.clear()
        translationBridges.clear()
        translationConfigs.clear()
        translationScope.cancel()
        shieldsUpdateScope.cancel()
        rendererRecoveryPolicy.clear()
        mlKitTranslator.close()
        // SPACE sessions are never restored from a saved Activity state. Erase the
        // named profile once when the controller is torn down, not only when the final
        // tab is closed through an in-app action.
        webViewModeManager.run { tabs.map { it.id }.forEach(::removeTab) }
        webViews.clear()
        savedStates.clear()
        tabLifecycleStates.clear()
        thumbnails.clear()
        favicons.clear()
        faviconsByHost.clear()
        faviconRevision++
        uaStale.clear()
        pageUrls.clear()
        popupTabIds.clear()
        popupOpenerUrls.clear()
        navigationSourceUrls.clear()
        bypassMainFrameOnce.clear()
        pendingBlockedNavigationTargets.clear()
        blockedNavigationReasons.clear()
        documentStartScripts.keys.toList().forEach(::removeDocumentStartScript)
        navigationGenerations.clear()
        readerModeTabs.clear()
        readerModeActive = false
        // Never clear the regular/default profile when an Activity is recreated or the app exits.
        if (hadPrivateTabs) {
            spaceSiteShieldsOverrides.clear()
            clearSpaceProfileData()
        }
        tabs.clear()
        host?.removeAllViews()
        host = null
    }

    private fun ensureWebView(
        id: Int,
        loadInitialUrl: Boolean = false,
        allowBlank: Boolean = false
    ): WebView? {
        if (destroyed) return null
        webViews[id]?.let {
            lastActiveAt[id] = System.currentTimeMillis()
            return it
        }
        val tab = tabs.firstOrNull { it.id == id } ?: return null
        if (tab.url == "about:blank" && !allowBlank) return null

        tabLifecycleStates[id] = DhyraTabLifecycleState.RESTORING
        val view = buildWebView(id, tab.isPrivate) ?: run {
            tabLifecycleStates[id] = DhyraTabLifecycleState.CRASHED
            return null
        }
        if (hostResumed && id == activeTabId) view.onResume() else view.onPause()
        val saved = savedStates.remove(id)
        val restored = saved?.let { runCatching { view.restoreState(it) != null }.getOrDefault(false) } == true
        webViews[id] = view
        tabLifecycleStates[id] = if (id == activeTabId) DhyraTabLifecycleState.ACTIVE else DhyraTabLifecycleState.BACKGROUND
        lastActiveAt[id] = System.currentTimeMillis()
        if (loadInitialUrl && !restored && isWebUrl(tab.url)) {
            val sourceUrl = pageUrls[id]?.takeIf(::isWebUrl) ?: tab.url
            if (shouldBlockTopLevelNavigation(id, tab.url, sourcePageUrl = sourceUrl)) {
                showBlockedNavigation(id, tab.url)
            } else {
                navigationSourceUrls[id] = sourceUrl
                loadNavigationWithShields(id, view, tab.url, tab.isPrivate)
            }
        }
        trimToLiveWebViewLimit(exceptId = id)
        return view
    }

    private fun trimToLiveWebViewLimit(exceptId: Int, discardSnapshots: Boolean = false) {
        val limit = currentLiveWebViewLimit()
        while (webViews.size > limit) {
            val victim = DhyraTabMemoryPolicy.evictionOrder(
                tabIds = webViews.keys.toList(),
                activeTabId = exceptId,
                lastAccessedAt = lastActiveAt
            ).firstOrNull() ?: break
            freezeTab(victim, saveState = !discardSnapshots)
        }
        val snapshotLimit = if (discardSnapshots) 0 else currentLiveWebViewLimit() * 2
        trimSavedStateBundles(snapshotLimit)
    }

    private fun trimSavedStateBundles(maxSnapshots: Int) {
        val keepCount = maxSnapshots.coerceAtLeast(0)
        val oldestFirst = savedStates.keys.sortedBy { lastActiveAt[it] ?: Long.MIN_VALUE }
        oldestFirst.take((savedStates.size - keepCount).coerceAtLeast(0)).forEach(savedStates::remove)
    }

    private fun freezeTab(id: Int, saveState: Boolean = true) {
        val view = webViews.remove(id) ?: return
        removeDocumentStartScript(id)
        val translationWasActive = translationConfigs.containsKey(id)
        // A saved WebView Bundle can contain translated DOM text. Drop the translated
        // document and reload the original URL when this tab is restored, then re-run the
        // user's explicit translation request. This avoids persisting translated page state.
        translationManagers.remove(id)?.destroy()
        translationBridges.remove(id)?.remove()
        if (translationWasActive || !saveState) {
            savedStates.remove(id)
        } else {
            runCatching {
                val snapshot = Bundle()
                val history = view.saveState(snapshot)
                if (history != null && !snapshot.isEmpty) savedStates[id] = snapshot
                else savedStates.remove(id)
            }.onFailure { savedStates.remove(id) }
        }
        webViewController.release(view, clearHistory = false)
        tabLifecycleStates[id] = DhyraTabLifecycleState.HIBERNATING
    }

    private fun destroyWebView(id: Int) {
        removeDocumentStartScript(id)
        val manager = translationManagers.remove(id)
        manager?.destroy()
        translationBridges.remove(id)?.remove()
        val view = webViews.remove(id)
        if (view != null) {
            // Drop callbacks before destruction so an in-flight page cannot update dead tab state.
            webViewController.release(view, clearHistory = true)
        }
        tabLifecycleStates[id] = DhyraTabLifecycleState.DESTROYED
    }

    private fun clearSpaceProfileWhenSessionEnds() {
        if (tabs.any { it.isPrivate }) return
        spaceSiteShieldsOverrides.clear()
        clearSpaceProfileData()
    }

    /**
     * WebStorageCompat deletes the profile's HTTP cache, cookies, service workers and
     * JavaScript-readable storage. SPACE stays unavailable until its callback
     * confirms completion, preventing a new session from racing the cleanup.
     */
    private fun clearSpaceProfileData() {
        spaceProfile.clearBrowsingData()
    }

    private fun buildWebView(id: Int, isPrivate: Boolean): WebView? {
        val webView = try {
            dhyraEngine.createWebView(activity)
        } catch (error: Exception) {
            Log.e(TAG, "Unable to create WebView for tab $id", error)
            Toast.makeText(activity, localizePlainUiText(activity, "Unable to create a browser tab"), Toast.LENGTH_LONG).show()
            return null
        }
        if (isPrivate) {
            // Must be called immediately after construction, before settings, clients,
            // JavaScript, storage, or navigation access the WebView.
            if (!spaceProfile.attachTo(webView) || spaceProfile.cookieManager == null) {
                runCatching { webView.destroy() }
                return null
            }
        }
        return webView.apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            if (isPrivate) {
                // Avoid offering private form values to the Android Autofill service.
                importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
                isSaveEnabled = false
            }
            configureSettings(this, id, isPrivate)
            val translationBridge = TranslationBridge(this)
            if (translationBridge.install()) translationBridges[id] = translationBridge
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    // The Shields count is scoped to the current top-level page, not the whole tab lifetime.
                    blockedRequestCounts[id] = 0
                    shieldRevision++
                    if (favicon != null && tabs.firstOrNull { it.id == id }?.isPrivate != true) {
                        val compactIcon = compactFavicon(favicon)
                        favicons[id] = compactIcon
                        rememberFavicon(url ?: view?.url, compactIcon)
                    }
                    if (url != null) {
                        val isBlockedDocument = url.startsWith(BLOCKED_PAGE_BASE_URL)
                        val blockedTarget = if (isBlockedDocument) pendingBlockedNavigationTargets[id] else null
                        if (!isBlockedDocument) pendingBlockedNavigationTargets.remove(id)
                        val visibleUrl = blockedTarget ?: url
                        val translationConfig = translationConfigs[id]
                        if (translationConfig != null && translationConfig.pageUrl != visibleUrl) {
                            translationConfigs.remove(id)
                            translationManagers[id]?.stopForNavigation()
                        } else {
                            translationManagers[id]?.stopForNavigation()
                        }
                        pageUrls[id] = visibleUrl
                        updateTab(
                            id,
                            url = visibleUrl,
                            title = if (blockedTarget != null) "Blocked by DHYRA" else null,
                            loading = true,
                            progress = 5
                        )
                    }
                    if (id == activeTabId) attachToHost()
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    val actualUrl = url ?: view?.url ?: "about:blank"
                    val blockedTarget = if (actualUrl.startsWith(BLOCKED_PAGE_BASE_URL)) pendingBlockedNavigationTargets[id] else null
                    val finalUrl = blockedTarget ?: actualUrl
                    val current = updateTab(
                        id,
                        url = finalUrl,
                        title = if (blockedTarget != null) "Blocked by DHYRA" else view?.title?.takeIf { it.isNotBlank() } ?: finalUrl,
                        loading = false,
                        progress = 100
                    )
                    if (current != null) {
                        lastActiveAt[id] = System.currentTimeMillis()
                        if (blockedTarget != null) {
                            if (id == activeTabId) translationState = TranslationState()
                            onPageFinished(current)
                            notifyTabsChanged()
                            return
                        }
                        applyCosmeticFilters(id, view, finalUrl, isPrivate)
                        if (id in readerModeTabs) view?.evaluateJavascript(readerModeScript(true), null)
                        if (id == activeTabId) readerModeActive = id in readerModeTabs
                        pendingScrollRestore.remove(id)?.let { scrollY ->
                            view?.evaluateJavascript("window.scrollTo(0, $scrollY);", null)
                        }
                        translationConfigs[id]?.takeIf { it.pageUrl == finalUrl }?.let { config ->
                            if (translationManagers[id] == null) {
                                val bridge = translationBridges[id]
                                if (bridge != null && view != null) {
                                    translationManagers[id] = DhyraTranslationManager(
                                        webView = view,
                                        bridge = bridge,
                                        translator = mlKitTranslator,
                                        scope = translationScope,
                                        scriptProvider = { activity.assets.open("PageTranslation.js").bufferedReader().use { it.readText() } },
                                        onStateChanged = { next -> if (activeTabId == id) translationState = next }
                                    )
                                }
                            }
                            translationManagers[id]?.start(config.source, config.target, config.wifiOnly)
                        }
                        if (id == activeTabId) translationState = translationManagers[id]?.state ?: TranslationState()
                        onPageFinished(current)
                        notifyTabsChanged()
                    }
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        updateTab(id, loading = false)
                        if (error != null) {
                            Toast.makeText(activity, localizePlainUiText(activity, "Page failed to load. Check your connection or try HTTPS."), Toast.LENGTH_LONG).show()
                        }
                    }
                }

                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: android.net.http.SslError?) {
                    // Certificate failures are always cancelled. Never add an implicit bypass.
                    handler?.cancel()
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val scheme = uri.scheme?.lowercase()
                    val isMainFrame = request.isForMainFrame
                    val wasRedirect = request.isRedirect
                    val hasUserGesture = request.hasGesture

                    // The blocked-page actions are local navigation tokens, not external intents.
                    if (isMainFrame && scheme == "dhyra-shields") {
                        when (uri.host?.lowercase()) {
                            "continue" -> handleBlockedPageAction(id, "continue")
                            "whitelist" -> handleBlockedPageAction(id, "whitelist")
                        }
                        return true
                    }

                    val isAboutBlankBootstrap = scheme == "about" && uri.toString().equals("about:blank", ignoreCase = true)
                    if (isMainFrame && scheme !in setOf("http", "https") && !isAboutBlankBootstrap) {
                        // blob:, data:, file:, content:, and external intents are outside the
                        // HTTP(S) filter engine. Clear popup context so it cannot leak to a later load.
                        popupTabIds.remove(id)
                        popupOpenerUrls.remove(id)
                        navigationSourceUrls.remove(id)
                    }

                    if (isMainFrame && scheme in setOf("data", "javascript", "file", "content")) {
                        Toast.makeText(activity, localizePlainUiText(activity, "This top-level navigation was blocked"), Toast.LENGTH_SHORT).show()
                        return true
                    }

                    if (isMainFrame && scheme in setOf("http", "https")) {
                        val destination = if (scheme == "http" && httpsFirst) {
                            HttpsUpgrade.upgrade(uri.toString(), true)
                        } else uri.toString()
                        val popupNavigation = id in popupTabIds
                        val sourceUrl = if (popupNavigation) popupOpenerUrls[id] ?: pageUrls[id].orEmpty()
                            else pageUrls[id].orEmpty()
                        val policyPageUrl = sourceUrl.takeIf(::isWebUrl) ?: destination

                        if (shouldBlockTopLevelNavigation(
                                tabId = id,
                                destinationUrl = destination,
                                popup = popupNavigation,
                                sourcePageUrl = policyPageUrl
                            )) {
                            blockedRequestCounts.merge(id, 1, Int::plus)
                            scheduleShieldCounterUiUpdate(id)
                            popupTabIds.remove(id)
                            popupOpenerUrls.remove(id)
                            val reason = blockedNavigationReasons.remove(id) ?: when {
                                popupNavigation -> "A popup destination matched an active Shields rule."
                                wasRedirect -> "A redirect destination matched an active Shields rule."
                                !hasUserGesture -> "A navigation without a direct user gesture matched an active Shields rule."
                                else -> "This destination matched an active Shields rule."
                            }
                            showBlockedNavigation(id, destination, reason)
                            return true
                        }

                        // Capture the opener/source before pageUrls changes to the destination.
                        navigationSourceUrls[id] = policyPageUrl
                        prepareForNavigation(id, destination)
                        val currentTab = tabs.firstOrNull { it.id == id } ?: return true
                        val targetView = view ?: webViews[id] ?: return true
                        loadNavigationWithShields(id, targetView, destination, currentTab.isPrivate)
                        return true
                    }

                    if (scheme in setOf("http", "https", "about", "blob")) return false
                    // Non-HTTP schemes from subframes must not launch Android activities.
                    if (!isMainFrame) return true
                    return openExternal(uri)
                }

                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
                    // This callback runs away from the UI thread. It only reads concurrent tab
                    // context and the immutable matcher snapshot; no Compose state or disk I/O.
                    val uri = request.url
                    val url = uri.toString()
                    val isHttpDocument = uri.scheme.equals("http", ignoreCase = true) ||
                        uri.scheme.equals("https", ignoreCase = true)
                    val popupNavigation = request.isForMainFrame && isHttpDocument && popupTabIds.remove(id)

                    val sourcePageUrl = if (request.isForMainFrame) {
                        navigationSourceUrls.remove(id)?.takeIf(::isWebUrl)
                            ?: pageUrls[id]?.takeIf(::isWebUrl)
                            ?: url
                    } else pageUrls[id].orEmpty()

                    // Consume the one-shot override only for the exact destination and main frame.
                    if (request.isForMainFrame && bypassMainFrameOnce.remove(id, url)) {
                        pageUrls[id] = url
                        popupOpenerUrls.remove(id)
                        return null
                    }

                    // Opener context is used for popup/domain/third-party rules; the actual
                    // destination URL is passed separately for page-wide $document exceptions.
                    val openerUrl = if (popupNavigation) popupOpenerUrls.remove(id) else null
                    val filterPageUrl = ShieldsFilterEngine.filteringPageUrl(sourcePageUrl, openerUrl, popupNavigation)
                    if (request.isForMainFrame) pageUrls[id] = url
                    val siteFilterEnabled = siteShieldsEnabled(filterPageUrl, isPrivate)
                    val siteJudolEnabled = judolEnabledForSite(filterPageUrl, isPrivate)
                    if (!siteFilterEnabled && (!request.isForMainFrame || !siteJudolEnabled)) return null

                    val resourceType = ShieldsFilterEngine.classifyRequest(
                        url = url,
                        isMainFrame = request.isForMainFrame,
                        method = request.method,
                        headers = request.requestHeaders,
                        isPopup = popupNavigation
                    )
                    val blockedByFilter = siteFilterEnabled && shieldsFilterEngine.shouldBlock(
                        url = url,
                        pageUrl = filterPageUrl,
                        resourceType = resourceType,
                        documentUrl = if (request.isForMainFrame) url else filterPageUrl
                    )
                    // The heuristic is deliberately limited to top-level documents. It never
                    // guesses that a normal image/script/API request is gambling content.
                    val judolAssessment = if (request.isForMainFrame && siteJudolEnabled) {
                        judolIntelligence.evaluate(url)
                    } else null
                    val blockedByJudol = judolAssessment?.shouldBlock == true
                    if (blockedByFilter || blockedByJudol) {
                        blockedRequestCounts.merge(id, 1, Int::plus)
                        scheduleShieldCounterUiUpdate(id)
                        if (request.isForMainFrame) {
                            // Document/popup failures get a safe native-controlled interstitial.
                            val reason = if (blockedByJudol) {
                                "High-confidence gambling destination: ${judolAssessment?.summary() ?: "local heuristic match"}."
                            } else {
                                "This destination matched an active Shields network rule."
                            }
                            activity.runOnUiThread {
                                if (tabs.any { it.id == id }) showBlockedNavigation(id, url, reason)
                            }
                        }
                        return blockedResponse(resourceType)
                    }

                    return null
                }

                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    // Android may call this once for each WebView sharing the dead renderer.
                    // Only detach/destroy the exact instance delivered by this callback.
                    val failedView = view ?: webViews[id]
                    if (failedView != null) {
                        activity.runOnUiThread { handleRendererProcessGone(id, failedView, detail?.didCrash() == true) }
                    }
                    return true
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                    if (!isPrivate && icon != null) {
                        val compactIcon = compactFavicon(icon)
                        favicons[id] = compactIcon
                        rememberFavicon(view?.url ?: pageUrls[id], compactIcon)
                    }
                }

                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    updateTab(id, progress = newProgress, loading = newProgress < 100)
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                    if (!title.isNullOrBlank()) updateTab(id, title = title)
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    if (filePathCallback == null) return false
                    onFileChooser(filePathCallback, fileChooserParams)
                    return true
                }

                override fun onPermissionRequest(request: PermissionRequest?) {
                    if (request == null) return
                    if (!DhyraSecurityManager.canRequestSensitiveWebFeature(request.origin?.toString())) {
                        activity.runOnUiThread { runCatching { request.deny() } }
                        return
                    }
                    if (!com.dhyra.browser.core.tabs.SpaceSessionPolicy.allowDevicePermissions(isPrivate)) {
                        // Device permissions can leave durable OS/site traces. SPACE tabs deny
                        // camera, microphone and protected-media requests rather than persisting grants.
                        activity.runOnUiThread {
                            runCatching { request.deny() }
                            Toast.makeText(activity, localizePlainUiText(activity, "Device permissions are disabled in space."), Toast.LENGTH_LONG).show()
                        }
                    } else {
                        activity.runOnUiThread { onPermission(request) }
                    }
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    if (origin == null || callback == null) return
                    if (!DhyraSecurityManager.canRequestSensitiveWebFeature(origin)) {
                        activity.runOnUiThread { runCatching { callback.invoke(origin, false, false) } }
                        return
                    }
                    activity.runOnUiThread {
                        if (isPrivate) runCatching { callback.invoke(origin, false, false) }
                        else onGeolocation(origin, callback)
                    }
                }

                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (view == null) return
                    if (fullscreenView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    fullscreenView = view
                    fullscreenCallback = callback
                    previousRequestedOrientation = activity.requestedOrientation
                    activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    val decor = activity.window.decorView as? ViewGroup
                    if (decor != null) {
                        val currentInsets = ViewCompat.getRootWindowInsets(decor)
                        statusBarsWereVisible = currentInsets?.isVisible(WindowInsetsCompat.Type.statusBars()) ?: true
                        navigationBarsWereVisible = currentInsets?.isVisible(WindowInsetsCompat.Type.navigationBars()) ?: true
                        val insetsController = WindowInsetsControllerCompat(activity.window, decor)
                        priorSystemBarsBehavior = insetsController.systemBarsBehavior
                        (view.parent as? ViewGroup)?.removeView(view)
                        val container = FrameLayout(activity).apply {
                            setBackgroundColor(AndroidColor.BLACK)
                            addView(view, FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT
                            ))
                        }
                        fullscreenContainer = container
                        // The custom fullscreen view is a generic Android View (often a video
                        // SurfaceView), not the WebView that owns the page URL. Resolve the
                        // origin from this tab's navigation state instead of reading view.url.
                        val pageUrl = pageUrls[id]
                            ?: tabs.firstOrNull { it.id == id }?.url.orEmpty()
                        val origin = runCatching { Uri.parse(pageUrl).host }
                            .getOrNull()?.takeIf { it.isNotBlank() } ?: "Website"
                        val originIndicator = TextView(activity).apply {
                            text = "Fullscreen · $origin"
                            setTextColor(AndroidColor.WHITE)
                            textSize = 12f
                            contentDescription = "Fullscreen content from $origin. Press Back to exit."
                            setPadding(14, 9, 14, 9)
                            background = GradientDrawable().apply {
                                setColor(0xCC17151D.toInt())
                                cornerRadius = 999f
                                setStroke(1, 0x66FFFFFF)
                            }
                            alpha = 0f
                            elevation = 8f
                        }
                        container.addView(originIndicator, FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.WRAP_CONTENT,
                            FrameLayout.LayoutParams.WRAP_CONTENT,
                            Gravity.TOP or Gravity.START
                        ).apply { setMargins(18, 28, 18, 0) })
                        decor.addView(container, ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        ))
                        originIndicator.animate().alpha(1f).setDuration(160).withEndAction {
                            originIndicator.postDelayed({
                                if (isFullscreen && originIndicator.parent != null) {
                                    originIndicator.animate().alpha(0f).setDuration(260).withEndAction {
                                        (originIndicator.parent as? ViewGroup)?.removeView(originIndicator)
                                    }.start()
                                }
                            }, 2_600)
                        }.start()
                        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        insetsController.hide(WindowInsetsCompat.Type.systemBars())
                        isFullscreen = true
                    }
                }

                override fun onHideCustomView() { exitFullscreen() }

                override fun onCreateWindow(
                    view: WebView?,
                    isDialog: Boolean,
                    isUserGesture: Boolean,
                    resultMsg: android.os.Message?
                ): Boolean {
                    if (popupBlocker || !isUserGesture) return false
                    val newId = createTab("about:blank", isPrivate, parentId = id)
                    if (newId < 0) return false
                    val newView = ensureWebView(newId, allowBlank = true) ?: run {
                        closeTab(newId)
                        return false
                    }
                    // Mark this tab only until its first HTTP(S) main-frame request so
                    // ABP `$popup` rules do not apply to later manual navigation in the tab.
                    popupTabIds.add(newId)
                    popupOpenerUrls[newId] = view?.url ?: pageUrls[id].orEmpty()
                    val message = resultMsg ?: run {
                        closeTab(newId)
                        return false
                    }
                    val transport = message.obj as? WebView.WebViewTransport ?: run {
                        closeTab(newId)
                        return false
                    }
                    transport.webView = newView
                    message.sendToTarget()
                    attachToHost()
                    return true
                }

                override fun onCloseWindow(window: WebView?) {
                    val tabId = webViews.entries.firstOrNull { it.value == window }?.key
                    if (tabId != null) closeTab(tabId)
                }
            }

            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                if (!com.dhyra.browser.core.tabs.SpaceSessionPolicy.allowPersistentDownload(isPrivate)) {
                    // Android DownloadManager persists records and writes into shared Downloads.
                    // Refuse private-tab downloads rather than silently leaking private activity.
                    Toast.makeText(
                        activity,
                        localizePlainUiText(activity, "Downloads are disabled in space to avoid leaving a public download record."),
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    onDownloadRequest(DhyraDownloadRequest(url, userAgent, contentDisposition, mimeType))
                }
            })

            setFindListener { activeMatchOrdinal, numberOfMatches, _ ->
                if (id == activeTabId) {
                    findActiveMatch = activeMatchOrdinal
                    findMatchCount = numberOfMatches
                }
            }
        }
    }

    private fun handleRendererProcessGone(tabId: Int, failedView: WebView, didCrash: Boolean) {
        val isCurrentInstance = webViews[tabId] === failedView
        if (isCurrentInstance) {
            val lastKnownUrl = failedView.url?.takeIf(::isWebUrl)
                ?: pageUrls[tabId]?.takeIf(::isWebUrl)
                ?: tabs.firstOrNull { it.id == tabId }?.url?.takeIf(::isWebUrl)
            if (lastKnownUrl != null) updateTab(tabId, url = lastKnownUrl)
            webViews.remove(tabId)
            savedStates.remove(tabId)
            removeDocumentStartScript(tabId)
            translationManagers.remove(tabId)?.destroy()
            translationBridges.remove(tabId)?.remove()
            translationConfigs.remove(tabId)
            popupTabIds.remove(tabId)
            popupOpenerUrls.remove(tabId)
            navigationSourceUrls.remove(tabId)
            pendingScrollRestore.remove(tabId)
            if (activeTabId == tabId) host?.removeAllViews()
            webViewController.releaseAfterRendererGone(failedView)
            rendererCrashCount++
            tabLifecycleStates[tabId] = DhyraTabLifecycleState.CRASHED
            updateTab(
                tabId,
                loading = false,
                progress = 0,
                title = if (didCrash) "Page renderer crashed" else "Page renderer stopped"
            )
        } else {
            // A stale callback must never remove a newly-created WebView for the same tab.
            webViewController.releaseAfterRendererGone(failedView)
            return
        }

        val canRetry = !destroyed && tabs.any { it.id == tabId } &&
            tabId == activeTabId && hostResumed &&
            rendererRecoveryPolicy.allowAutomaticRecovery(tabId, SystemClock.elapsedRealtime())
        if (canRetry) {
            translationScope.launch {
                delay(RENDERER_RECOVERY_DELAY_MS)
                if (destroyed || tabs.none { it.id == tabId } || activeTabId != tabId || webViews.containsKey(tabId)) {
                    notifyTabsChanged()
                    return@launch
                }
                val replacement = ensureWebView(tabId, loadInitialUrl = true)
                attachToHost()
                if (replacement == null) {
                    Toast.makeText(activity, localizePlainUiText(activity, "The page renderer stopped. Tap Reload to try again."), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(activity, localizePlainUiText(activity, "Page restarted after renderer recovery."), Toast.LENGTH_SHORT).show()
                }
                notifyTabsChanged()
            }
        } else {
            if (activeTabId == tabId) {
                Toast.makeText(activity, localizePlainUiText(activity, "A page renderer stopped. Tap Reload to continue."), Toast.LENGTH_LONG).show()
            }
            notifyTabsChanged()
        }
    }

    private fun configureSettings(view: WebView, tabId: Int, isPrivate: Boolean) {
        val modeApplied = webViewController.configure(
            view = view,
            tabId = tabId,
            isPrivate = isPrivate,
            popupBlocker = popupBlocker,
            trackingProtection = trackingProtection,
            profileCookies = if (isPrivate) spaceProfile.cookieManager else null,
            onDesktopModeRejected = {
                val tabIndex = tabs.indexOfFirst { it.id == tabId }
                if (tabIndex >= 0 && tabs[tabIndex].isDesktop) {
                    tabs[tabIndex] = tabs[tabIndex].copy(isDesktop = false)
                }
                uaStale.remove(tabId)
            }
        )
        if (!modeApplied && tabs.any { it.id == tabId && it.isDesktop }) {
            Log.w(TAG, "Desktop mode was unavailable for tab $tabId; mobile rendering was restored.")
        }
    }

    private fun updateTab(
        id: Int,
        url: String? = null,
        title: String? = null,
        progress: Int? = null,
        loading: Boolean? = null
    ): BrowserTab? {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return null
        val old = tabs[index]
        val updated = old.copy(
            url = url ?: old.url,
            title = title ?: old.title,
            progress = progress ?: old.progress,
            loading = loading ?: old.loading
        )
        if (url != null) pageUrls[id] = url
        tabs[index] = updated
        return updated
    }

    /** External intents are restricted to browser-safe web URLs and standard contact links. */
    private fun openExternal(uri: Uri): Boolean {
        return try {
            if (uri.scheme.equals("intent", ignoreCase = true)) {
                val parsed = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME).apply {
                    action = Intent.ACTION_VIEW
                    component = null
                    selector = null
                    setPackage(null)
                    flags = 0
                    addCategory(Intent.CATEGORY_BROWSABLE)
                }
                val target = parsed.data
                when (target?.scheme?.lowercase()) {
                    "http", "https" -> navigate(target.toString())
                    "mailto", "tel" -> launchBrowsable(target)
                    else -> {
                        val fallback = parsed.getStringExtra("browser_fallback_url")
                        if (isSafeWebUrl(fallback)) navigate(fallback!!)
                        else Toast.makeText(activity, localizePlainUiText(activity, "This external link was blocked for safety"), Toast.LENGTH_LONG).show()
                    }
                }
                true
            } else if (uri.scheme.equals("mailto", true) || uri.scheme.equals("tel", true)) {
                launchBrowsable(uri)
                true
            } else {
                Toast.makeText(activity, localizePlainUiText(activity, "This link type is not supported by dhyra"), Toast.LENGTH_SHORT).show()
                true
            }
        } catch (_: Exception) {
            Toast.makeText(activity, localizePlainUiText(activity, "Unable to open this external link"), Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun launchBrowsable(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            component = null
            selector = null
            addCategory(Intent.CATEGORY_BROWSABLE)
        }
        activity.startActivity(intent)
    }

    private fun blockedResponse(type: ShieldsFilterEngine.ResourceType): WebResourceResponse {
        val mime = when (type) {
            ShieldsFilterEngine.ResourceType.SCRIPT -> "application/javascript"
            ShieldsFilterEngine.ResourceType.IMAGE -> "image/gif"
            ShieldsFilterEngine.ResourceType.STYLESHEET -> "text/css"
            ShieldsFilterEngine.ResourceType.FONT -> "font/woff2"
            ShieldsFilterEngine.ResourceType.MEDIA -> "application/octet-stream"
            else -> "text/plain"
        }
        val body = when (type) {
            ShieldsFilterEngine.ResourceType.SCRIPT -> EMPTY_SCRIPT
            ShieldsFilterEngine.ResourceType.IMAGE -> TRANSPARENT_GIF
            else -> ByteArray(0)
        }
        val noContent = type !in setOf(ShieldsFilterEngine.ResourceType.SCRIPT, ShieldsFilterEngine.ResourceType.IMAGE)
        return WebResourceResponse(
            mime,
            "UTF-8",
            if (noContent) 204 else 200,
            if (noContent) "No Content" else "OK",
            mapOf("Cache-Control" to "no-store", "X-dhyra-Blocked" to "1"),
            ByteArrayInputStream(body)
        )
    }

    private fun notifyTabsChanged() = onTabsChanged(tabs.toList())

    private fun isWebUrl(value: String): Boolean = com.dhyra.browser.core.security.DhyraSecurityManager.isHttpUrl(value)
    private fun isSafeWebUrl(value: String?): Boolean = com.dhyra.browser.core.security.DhyraSecurityManager.isHttpUrl(value)

    fun startConfirmedDownload(request: DhyraDownloadRequest) {
        val id = dhyraDownloadManager.enqueue(
            request.url,
            request.userAgent,
            request.contentDisposition,
            request.mimeType
        )
        if (id != null) Toast.makeText(activity, localizePlainUiText(activity, "Download started"), Toast.LENGTH_SHORT).show()
        else Toast.makeText(activity, localizePlainUiText(activity, "Unable to start this download"), Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val TAG = "DhyraBrowser"
        private const val RENDERER_RECOVERY_DELAY_MS = 350L
        private const val THUMBNAIL_WIDTH_PX = 360
        private const val MAX_THUMBNAILS = 16
        private const val SHIELDS_COUNTER_UI_INTERVAL_MS = 250L
        private const val BLOCKED_PAGE_BASE_URL = "https://dhyra-blocked.invalid/"
        private val EMPTY_SCRIPT = "/* blocked by dhyra Shields */".toByteArray(Charsets.UTF_8)
        private val TRANSPARENT_GIF = byteArrayOf(
            0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00,
            0x01, 0x00, 0x80.toByte(), 0x00, 0x00, 0x00, 0x00,
            0x00, 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0x21,
            0xF9.toByte(), 0x04, 0x01, 0x00, 0x00, 0x00, 0x00,
            0x2C, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01,
            0x00, 0x00, 0x02, 0x02, 0x44, 0x01, 0x00, 0x3B
        )
    }
}
