package com.dhyra.browser

import com.dhyra.browser.core.nav.BrowserAddressResolver
import com.dhyra.browser.core.network.HttpsUpgrade

/** Standalone JVM verification runner; no test framework dependency is required. */
object BrowserLogicChecks {
    @JvmStatic
    fun main(args: Array<String>) {
        BrowserAddressResolverTest().runChecks()
        HttpsUpgradeTest().runChecks()
        ShieldsFilterEngineTest().runChecks()
        ShieldsContentScriptTest().runChecks()
        JudolIntelligenceTest().runChecks()
        SmartSuggestTest().runChecks()
        BackPolicyTest().runChecks()
        UserAgentsTest().runChecks()
        TabSelectionTest().runChecks()
        SavedPagesManagerTest().runChecks()
        println("PASS: address resolution, HTTPS upgrade, Shields, judol intelligence, suggestions, back policy, user agents, tabs, history and bookmarks")
    }
}
