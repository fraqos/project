# Build instructions — dhyra 2.5.4

## ZIP-only GitHub Actions build (no local extraction)

1. Create or open a GitHub repository.
2. Add the supplied workflow file as `.github/workflows/build.yml` (GitHub discovers workflows only from this repository path).
3. Upload exactly one DHYRA project ZIP to the repository root. Do not extract the source ZIP on your computer and do not commit older Android project ZIPs alongside it.
4. Commit the workflow and ZIP. A push containing the ZIP starts the workflow; alternatively choose **Actions → dhyra Android CI (ZIP auto-build) → Run workflow**.
5. When the run succeeds, download the `dhyra-v2.5.4-build-*` artifact. It contains `dhyra-v2.5.4.apk`, `dhyra-source.zip` and `SHA256SUMS.txt`.

The runner validates the archive (including path traversal and symlink checks), unpacks it inside its temporary workspace, builds the Android app, validates the APK, and produces a clean source ZIP. The APK and source ZIP are then published as one GitHub Actions artifact. This avoids manual extraction and local Android SDK setup. GitHub's workflow-discovery rule still requires the YAML file to be committed separately at `.github/workflows/build.yml`; a YAML file inside the source archive alone cannot start a workflow.

The workflow currently targets the project toolchain: JDK 21, Gradle 9.5.1, Android Gradle Plugin 9.3.1, Android SDK Platform 37.1 and Build Tools 36.0.0. It generates and verifies the Gradle Wrapper within the extracted project root, then runs `checkDebugAarMetadata`, Kotlin compile, unit tests, `lintDebug` and `assembleDebug`.

## Optional release build

Manual workflow dispatch can build an unsigned release APK by setting `build_release=true`. Signing is optional and requires both `build_release=true` and `sign_release=true`, plus the following repository Actions secrets:

- `DHYRA_RELEASE_KEYSTORE_BASE64`
- `DHYRA_RELEASE_STORE_PASSWORD`
- `DHYRA_RELEASE_KEY_ALIAS`
- `DHYRA_RELEASE_KEY_PASSWORD`

Never commit keystores, passwords, `local.properties` or signing files into the source ZIP.

## Local build (optional)

If building locally, install JDK 21 and Android SDK Platform 37.1 / Build Tools 36.0.0. The incoming ZIP intentionally omits `gradle-wrapper.jar`; generate it with Gradle 9.5.1 at the project root, then run `./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug`.
