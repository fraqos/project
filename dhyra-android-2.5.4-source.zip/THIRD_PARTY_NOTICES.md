# Third-Party Notices

dhyra's direct dependencies in this build are listed below. Review current upstream license terms and include any required notices with distributed builds.

| Component | Purpose | License / notice |
|---|---|---|
| AndroidX Core / Activity / Lifecycle | Android platform integration | Apache License 2.0 |
| Jetpack Compose UI / Foundation / Material 3 | Declarative user interface | Apache License 2.0 |
| AndroidX DataStore | Preferences persistence | Apache License 2.0 |
| AndroidX WebKit | WebView compatibility APIs and secure message bridge | Apache License 2.0 |
| Google ML Kit Translate / Language ID | On-device page translation and language detection | Google ML Kit terms; models downloaded on demand |
| ZXing Core | QR-code generation | Apache License 2.0 |
| RE2/J 1.9 (`com.google.re2j:re2j`) | Linear-time regular expressions for filter rules | Go License (permissive; preserve upstream copyright/license/disclaimer notices; not copyleft) |
| Kotlin | Programming language and Gradle plugin | Apache License 2.0 |
| Android System WebView | Web content engine supplied by the device/vendor | Chromium and provider-specific notices apply |

Google Mobile Ads SDK is **not** a dependency in this build. This table lists direct dependencies visible in the app Gradle file; Gradle resolves transitive dependencies. Generate and inspect a complete dependency/license report before commercial distribution. No third-party source files are vendored into this archive.

Google ML Kit Translate and Language Identification versions used: `com.google.mlkit:translate:17.0.3` and `com.google.mlkit:language-id:17.0.6`. Translation language models are downloaded on demand from Google services.

## AndroidX AppCompat

This release adds `androidx.appcompat:appcompat:1.8.0` for AppCompatDelegate theme selection and per-app locale handling. It is distributed under the AndroidX/Apache License 2.0 terms. The app uses Compose Material Icons Outlined vector assets for its outlined UI icon treatment; it does not bundle a Material Symbols font file.


## Filter-list subscriptions

This build downloads the following filter subscriptions over HTTPS when automatic or manual refresh is run:

- EasyList: https://easylist.to/easylist/easylist.txt
- EasyPrivacy: https://easylist.to/easylist/easyprivacy.txt
- Fanboy’s Annoyance List: https://secure.fanboy.co.nz/fanboy-annoyance.txt
- ABPindo (Indonesian and Malay supplementary filter list): https://raw.githubusercontent.com/ABPindo/indonesianadblockrules/master/subscriptions/abpindo.txt
- ABPindo source repository: https://github.com/ABPindo/indonesianadblockrules
- ABPindo licence: dual-licensed under GPL version 3 or later, or Creative Commons Attribution-ShareAlike 3.0 or later, as stated by the upstream repository. Attribute the ABPindo authors and retain the upstream licence notice when redistributing list content.
- Maintainer project: https://github.com/easylist/easylist
- EasyList/EasyPrivacy licence: https://easylist.to/pages/licence.html
- Fanboy’s Annoyance List feed header identifies Creative Commons Attribution 3.0 (CC BY 3.0): https://creativecommons.org/licenses/by/3.0/

The EasyList repository states that its contents are dual-licensed under GPL version 3 or later, or Creative Commons Attribution-ShareAlike 3.0 Unported or later unless a file says otherwise. The EasyList authors must be attributed as the source. dhyra attributes the list maintainers here and downloads the subscriptions at runtime rather than embedding the complete lists in the APK. Review the upstream licence and current subscription terms before redistributing modified list data.

The Fanboy’s Annoyance List feed identifies its own licence as CC BY 3.0 and its maintainer as Fanboy. Attribute Fanboy/Ryan Brown and retain the upstream source link when describing or redistributing material from that list; verify the live feed header and licence before any redistributive packaging. dhyra downloads the feed at runtime and only compiles supported filter syntax.
