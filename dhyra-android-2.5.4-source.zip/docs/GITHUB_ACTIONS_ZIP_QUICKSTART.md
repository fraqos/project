# Build DHYRA from a ZIP with GitHub Actions (no local extraction)

The supplied workflow accepts one Android project ZIP committed to the repository root. It extracts the project only on the GitHub-hosted runner, performs checks/builds, and uploads an artifact containing the APK, a clean source ZIP, and SHA-256 checksums.

## First-time setup

1. Create an empty GitHub repository.
2. In GitHub, choose **Add file → Create new file** and name it `.github/workflows/build.yml`.
3. Copy the contents of the standalone `build.yml` supplied with this release into that file and commit it.
4. Choose **Add file → Upload files** and upload `dhyra-android-2.5.4-source.zip` to the repository root. Do not extract it.
5. Commit the ZIP. The `push` trigger finds the ZIP and starts the workflow.

The build workflow must be installed separately at `.github/workflows/build.yml`; GitHub does not discover workflow definitions nested inside a ZIP archive. This is the only required bootstrap file outside the source ZIP.

## Subsequent builds

Replace the root source ZIP with the updated ZIP and commit the change, or open **Actions → dhyra Android CI (ZIP auto-build) → Run workflow**.

The repository should contain exactly one valid DHYRA Android project ZIP. Old source ZIPs must be removed or moved outside the repository to avoid ambiguity.

## Download results

Open the successful workflow run, find the artifact named `dhyra-v2.5.4-build-<run-number>`, and download it. It contains:

- `dhyra-v2.5.4.apk` — debug APK for device testing.
- `dhyra-source.zip` — clean project source with the generated Gradle Wrapper JAR.
- `SHA256SUMS.txt` — checksums for all delivered files.

A successful CI run proves the automated build/test/lint gates passed on the hosted runner. It does not replace real-device QA, OAuth/provider testing, renderer-crash tests, Play policy review, or release signing.
