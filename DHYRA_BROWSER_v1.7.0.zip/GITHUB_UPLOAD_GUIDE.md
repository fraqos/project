# DHYRA Browser Android v1.7.0 — GitHub Actions

## Recommended: upload only the project ZIP

1. Keep a real workflow file at `.github/workflows/build.yml` in the GitHub repository. GitHub does not discover a workflow YAML stored inside a ZIP archive.
2. Upload `DHYRA_BROWSER_v1.7.0.zip` to the repository root. You do not need to unpack it on your phone.
3. The workflow at the repository root detects one ZIP, extracts it in the GitHub runner, prepares the Gradle wrapper if its JAR is absent, and builds the APK.
4. Open **Actions**, select **DHYRA BROWSER Android Build**, and inspect the run.
5. On success, download `DHYRA-BROWSER-v1.7.0-debug` from the run's **Artifacts** section.

If the repository already contains the project files at its root, the workflow builds them directly instead of searching for a ZIP. Do not keep multiple source ZIP files in the root; the ZIP mode intentionally requires exactly one archive to avoid extracting the wrong version.

## Build environment

- JDK 17
- Android SDK platform 35 and Build Tools 35.0.0
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21

The workflow uses the Gradle 8.7 distribution installed by the setup action. The source archive includes the Gradle launcher scripts and wrapper properties; when the wrapper JAR is missing, the workflow regenerates the standard wrapper using the installed Gradle before invoking it.
