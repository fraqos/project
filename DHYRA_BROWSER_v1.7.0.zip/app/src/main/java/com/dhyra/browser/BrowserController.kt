package com.dhyra.browser

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.PermissionRequest
import android.webkit.GeolocationPermissions
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import java.io.ByteArrayInputStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class BrowserTab(
    val id: Int,
    val url: String,
    val title: String,
    val progress: Int,
    val loading: Boolean,
    val isPrivate: Boolean
)

data class BrowserSnapshot(val tabs: List<BrowserTab> = emptyList(), val activeTabId: Int = -1)

class BrowserController(
    private val activity: Activity,
    private val onFileChooser: (ValueCallback<Array<Uri>>) -> Unit,
    private val onPermission: (PermissionRequest) -> Unit,
    private val onGeolocation: (String, GeolocationPermissions.Callback) -> Unit
) {
    private val tabs = mutableListOf<BrowserTab>()
    private val _snapshot = MutableStateFlow(BrowserSnapshot())
    val snapshot: StateFlow<BrowserSnapshot> = _snapshot.asStateFlow()
    private fun publishSnapshot() { _snapshot.value = BrowserSnapshot(tabs.toList(), activeTabId) }
    var activeTabId: Int = -1
        private set

    private val webViews = linkedMapOf<Int, WebView>()
    private var nextId = 1
    private var host: FrameLayout? = null
    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var savedSystemUiVisibility: Int = 0
    var isFullscreen by androidx.compose.runtime.mutableStateOf(false)
        private set

    var trackingProtection = true
    var popupBlocker = true
    var desktopMode = false
    var onPageFinished: (BrowserTab) -> Unit = {}

    fun activeTab(): BrowserTab? = tabs.firstOrNull { it.id == activeTabId }
    fun activeWebView(): WebView? = webViews[activeTabId]

    fun createTab(url: String = "about:blank", isPrivate: Boolean = false): Int {
        webViews[activeTabId]?.let { runCatching { it.onPause() } }
        val id = nextId++
        val tab = BrowserTab(id, url, "New tab", 0, false, isPrivate)
        tabs.add(tab)
        val view = buildWebView(id, isPrivate)
        webViews[id] = view
        activeTabId = id
        runCatching { view.onResume() }
        attachToHost()
        publishSnapshot()
        if (url != "about:blank") view.loadUrl(url)
        return id
    }

    /** Open a URL in a background tab while preserving the currently selected tab. */
    fun createBackgroundTab(url: String, isPrivate: Boolean = false): Int {
        val previous = activeTabId
        val created = createTab(url, isPrivate)
        if (previous != -1 && webViews.containsKey(previous)) selectTab(previous)
        return created
    }

    /** Duplicate a tab by opening its current URL in a new WebView. */
    fun duplicateTab(id: Int = activeTabId): Int {
        val source = tabs.firstOrNull { it.id == id } ?: return createTab()
        return createTab(source.url, source.isPrivate)
    }

    /** Close every tab and leave one clean regular tab available. */
    fun closeAllTabs() {
        val ids = tabs.map { it.id }
        ids.forEach { id ->
            val view = webViews.remove(id) ?: return@forEach
            (view.parent as? ViewGroup)?.removeView(view)
            runCatching { view.onPause() }
            runCatching { view.stopLoading() }
            runCatching { view.loadUrl("about:blank") }
            runCatching { view.destroy() }
        }
        tabs.clear()
        activeTabId = -1
        publishSnapshot()
        createTab()
    }

    fun selectTab(id: Int) {
        if (webViews.containsKey(id)) {
            if (activeTabId != id) webViews[activeTabId]?.let { runCatching { it.onPause() } }
            activeTabId = id
            webViews[id]?.let { runCatching { it.onResume() } }
            attachToHost()
            publishSnapshot()
        }
    }

    fun navigate(url: String) {
        val id = activeTabId
        val view = webViews[id]
        if (view == null) {
            createTab(url)
        } else {
            updateTab(id, url = url, loading = true, progress = 0)
            view.loadUrl(url)
        }
    }

    fun exitFullscreen() {
        val view = fullscreenView ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        fullscreenCallback?.onCustomViewHidden()
        fullscreenView = null
        fullscreenCallback = null
        activity.window.decorView.systemUiVisibility = savedSystemUiVisibility
        isFullscreen = false
    }

    fun goBack() { activeWebView()?.let { if (it.canGoBack()) it.goBack() } }
    fun goForward() { activeWebView()?.let { if (it.canGoForward()) it.goForward() } }
    fun reload() { activeWebView()?.reload() }
    fun stop() { activeWebView()?.stopLoading() }

    /** Pause timers and rendering while the Activity is backgrounded. */
    fun pause() {
        webViews.values.forEach { view -> runCatching { view.onPause() } }
        webViews.values.firstOrNull()?.let { runCatching { it.pauseTimers() } }
    }

    /** Resume all retained tabs when the Activity returns to the foreground. */
    fun resume() {
        webViews.values.forEach { view -> runCatching { view.onResume() } }
        webViews.values.firstOrNull()?.let { runCatching { it.resumeTimers() } }
    }

    fun closeTab(id: Int) {
        val view = webViews.remove(id)
        if (view != null) {
            (view.parent as? ViewGroup)?.removeView(view)
            runCatching { view.onPause() }
            runCatching { view.stopLoading() }
            if (tabs.firstOrNull { it.id == id }?.isPrivate == true) {
                runCatching { view.clearHistory() }
                runCatching { view.clearCache(true) }
                runCatching { view.clearFormData() }
            }
            runCatching { view.loadUrl("about:blank") }
            runCatching { view.destroy() }
        }
        tabs.removeAll { it.id == id }
        if (activeTabId == id) {
            activeTabId = tabs.lastOrNull()?.id ?: -1
            if (activeTabId == -1) createTab()
            webViews[activeTabId]?.let { runCatching { it.onResume() } }
            attachToHost()
        }
        publishSnapshot()
    }

    fun attach(container: FrameLayout) {
        host = container
        attachToHost()
    }

    private fun attachToHost() {
        val container = host ?: return
        val view = webViews[activeTabId]
        if (view == null) {
            container.removeAllViews()
            return
        }
        if (view.parent !== container) {
            (view.parent as? ViewGroup)?.removeView(view)
            container.removeAllViews()
            container.addView(
                view,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }
    }

    fun applySettings(tracking: Boolean, popup: Boolean, desktop: Boolean) {
        trackingProtection = tracking
        popupBlocker = popup
        desktopMode = desktop
        webViews.forEach { (id, view) ->
            configureSettings(view, tabs.firstOrNull { it.id == id }?.isPrivate == true)
        }
    }

    /** Clears the shared WebView profile. This also affects private tabs because
     * Android System WebView does not expose isolated cookie/storage profiles here. */
    fun clearAllBrowsingData() {
        webViews.values.forEach { view ->
            runCatching { view.clearCache(true) }
            runCatching { view.clearHistory() }
            runCatching { view.clearFormData() }
        }
        CookieManager.getInstance().removeAllCookies { CookieManager.getInstance().flush() }
        android.webkit.WebStorage.getInstance().deleteAllData()
    }

    fun destroy() {
        webViews.values.toList().forEach { view ->
            (view.parent as? ViewGroup)?.removeView(view)
            runCatching { view.onPause() }
            view.stopLoading()
            view.loadUrl("about:blank")
            view.destroy()
        }
        webViews.clear()
        tabs.clear()
        host?.removeAllViews()
        host = null
        exitFullscreen()
        publishSnapshot()
    }

    private fun buildWebView(id: Int, isPrivate: Boolean): WebView {
        return WebView(activity).apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            configureSettings(this, isPrivate)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    if (url != null) updateTab(id, url = url, loading = true, progress = 5)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    val finalUrl = url ?: view?.url ?: "about:blank"
                    val current = updateTab(
                        id,
                        url = finalUrl,
                        title = view?.title?.takeIf { it.isNotBlank() } ?: finalUrl,
                        loading = false,
                        progress = 100
                    )
                    if (current != null) this@BrowserController.onPageFinished(current)
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        updateTab(id, loading = false)
                    }
                }

                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: android.net.http.SslError?) {
                    // Never bypass certificate errors automatically.
                    handler?.cancel()
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val scheme = uri.scheme?.lowercase()
                    if (scheme == "javascript" || scheme == "file" || scheme == "content") return true
                    if (scheme == "about") return uri.toString() != "about:blank"
                    if (scheme in setOf("http", "https", "blob", "data")) return false
                    // Custom schemes in subframes are not allowed to launch external apps
                    // unless the navigation was directly initiated by a user gesture.
                    if (request.isForMainFrame.not() && request.hasGesture().not()) return true
                    return openExternal(uri)
                }

                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    if (!trackingProtection) return super.shouldInterceptRequest(view, request)
                    val uri = request?.url ?: return super.shouldInterceptRequest(view, request)
                    if (isKnownTracker(uri)) {
                        return WebResourceResponse(
                            "text/plain",
                            "UTF-8",
                            ByteArrayInputStream(ByteArray(0))
                        )
                    }
                    return super.shouldInterceptRequest(view, request)
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    updateTab(id, progress = newProgress, loading = newProgress < 100)
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                    if (!title.isNullOrBlank()) updateTab(id, title = title)
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    if (filePathCallback == null) return false
                    onFileChooser(filePathCallback)
                    return true
                }

                override fun onPermissionRequest(request: PermissionRequest?) {
                    if (request == null) return
                    activity.runOnUiThread { onPermission(request) }
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    if (origin == null || callback == null) return
                    activity.runOnUiThread { onGeolocation(origin, callback) }
                }

                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (view == null) return
                    if (fullscreenView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    fullscreenView = view
                    fullscreenCallback = callback
                    val decor = activity.window.decorView as? ViewGroup
                    if (decor != null) {
                        savedSystemUiVisibility = decor.systemUiVisibility
                        decor.addView(
                            view,
                            ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                        decor.systemUiVisibility = (
                            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_FULLSCREEN
                                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            )
                        isFullscreen = true
                    }
                }

                override fun onHideCustomView() {
                    exitFullscreen()
                }

                override fun onCreateWindow(
                    view: WebView?,
                    isDialog: Boolean,
                    isUserGesture: Boolean,
                    resultMsg: android.os.Message?
                ): Boolean {
                    if (popupBlocker) return false
                    val message = resultMsg ?: return false
                    val transport = message.obj as? WebView.WebViewTransport ?: return false
                    val newId = createTab("about:blank", isPrivate)
                    val newView = webViews[newId] ?: return false
                    transport.webView = newView
                    message.sendToTarget()
                    return true
                }

                override fun onCloseWindow(window: WebView?) {
                    val tabId = webViews.entries.firstOrNull { it.value == window }?.key
                    if (tabId != null) closeTab(tabId)
                }
            }

            setOnLongClickListener {
                val hit = hitTestResult
                val target = hit.extra
                val isLink = hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                    hit.type == WebView.HitTestResult.IMAGE_ANCHOR_TYPE
                if (isLink && !target.isNullOrBlank() &&
                    (target.startsWith("https://") || target.startsWith("http://"))) {
                    android.app.AlertDialog.Builder(activity)
                        .setTitle("Link options")
                        .setItems(arrayOf("Open in new tab", "Open in background tab", "Copy link")) { _, which ->
                            when (which) {
                                0 -> createTab(target, isPrivate)
                                1 -> createBackgroundTab(target, isPrivate)
                                2 -> {
                                    val clipboard = activity.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("URL", target))
                                    Toast.makeText(activity, "Link copied", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }.show()
                    true
                } else false
            }

            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                enqueueDownload(activity, url, userAgent, contentDisposition, mimeType)
            })
        }
    }

    private fun configureSettings(view: WebView, isPrivate: Boolean) {
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setGeolocationEnabled(true)
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = !popupBlocker
            setSupportMultipleWindows(true)
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = if (isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            safeBrowsingEnabled = true
            userAgentString = if (desktopMode) {
                WebSettings.getDefaultUserAgent(activity)
                    .replace("; wv", "")
                    .replace(" Version/4.0", "")
                    .replace(" Mobile", "")
            } else {
                WebSettings.getDefaultUserAgent(activity)
            }
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, !trackingProtection)
    }

    private fun updateTab(
        id: Int,
        url: String? = null,
        title: String? = null,
        progress: Int? = null,
        loading: Boolean? = null
    ): BrowserTab? {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return null
        val old = tabs[index]
        val updated = old.copy(
            url = url ?: old.url,
            title = title ?: old.title,
            progress = progress ?: old.progress,
            loading = loading ?: old.loading
        )
        tabs[index] = updated
        publishSnapshot()
        return updated
    }

    private fun openExternal(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return true
        return try {
            val intent = if (scheme == "intent") {
                val parsed = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                val fallback = parsed.getStringExtra("browser_fallback_url")
                parsed.component = null
                parsed.selector = null
                parsed.setPackage(null)
                parsed.action = Intent.ACTION_VIEW
                parsed.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                if (parsed.resolveActivity(activity.packageManager) == null) {
                    if (fallback != null && isSafeWebUrl(fallback)) {
                        webViews[activeTabId]?.loadUrl(fallback)
                    } else {
                        Toast.makeText(activity, "No compatible app found for this link", Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
                parsed
            } else {
                if (scheme !in setOf("mailto", "tel", "sms", "smsto", "mms", "geo", "market")) {
                    Toast.makeText(activity, "This link type is blocked for safety", Toast.LENGTH_SHORT).show()
                    return true
                }
                Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(activity.packageManager) != null) {
                activity.startActivity(intent)
            } else {
                Toast.makeText(activity, "No compatible app found for this link", Toast.LENGTH_SHORT).show()
            }
            true
        } catch (_: Exception) {
            Toast.makeText(activity, "Unable to open this link", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun isSafeWebUrl(value: String): Boolean {
        if (value.isBlank() || value.any { it.isWhitespace() }) return false
        val uri = Uri.parse(value)
        return uri.scheme?.lowercase() in setOf("http", "https") && !uri.host.isNullOrBlank()
    }

    private fun isKnownTracker(uri: Uri): Boolean {
        val host = uri.host?.lowercase().orEmpty()
        val blockedHosts = listOf(
            "doubleclick.net",
            "googletagmanager.com",
            "google-analytics.com",
            "connect.facebook.net",
            "hotjar.com",
            "segment.io",
            "segment.com",
            "ads-twitter.com",
            "adservice.google.com",
            "scorecardresearch.com",
            "quantserve.com"
        )
        val hostMatch = blockedHosts.any { host == it || host.endsWith(".$it") }
        val facebookHost = host == "facebook.com" || host.endsWith(".facebook.com")
        val facebookPixelPath = facebookHost && uri.path.orEmpty().startsWith("/tr")
        return hostMatch || facebookPixelPath
    }

    private fun enqueueDownload(
        context: Context,
        url: String,
        userAgent: String,
        contentDisposition: String,
        mimeType: String
    ) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                .setDescription("Downloaded by DHYRA Browser")
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", userAgent)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, contentDisposition, mimeType)
                )
            val cookie = CookieManager.getInstance().getCookie(url)
            if (!cookie.isNullOrBlank()) request.addRequestHeader("Cookie", cookie)
            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(context, "Unduhan dimulai", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(context, "Unduhan gagal dimulai", Toast.LENGTH_LONG).show()
        }
    }
}
