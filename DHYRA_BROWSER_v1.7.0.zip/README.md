# DHYRA Browser — Android v1.7.0

**A Beautiful, Powerful & Private Browsing Experience.**

DHYRA is an Android browser built with Kotlin, Jetpack Compose, Android System WebView, Preferences DataStore, and Android DownloadManager. This is an incremental development build based on the supplied v1.6.1 source archive. It keeps the existing Android/WebView architecture rather than pretending to provide a separate Chromium or Gecko engine.

## v1.7.0 changes

- Added a local Notes workspace with note creation, editing, debounced autosave, explicit save-failure feedback and retry, search, pinning, favorites, timestamps, delete confirmation, and sharing/export through Android's share sheet.
- Added a Privacy Center that exposes the protections actually wired to WebView, links to Android's app-permission settings, and clearly explains shared-profile private-tab limitations.
- Added Notes and Privacy entry points to the home screen and navigation drawer.
- Applied the configured homepage from the browser Home control.
- Hardened address-bar navigation: only valid HTTP/HTTPS URLs navigate directly; custom schemes typed into the address bar are treated as search text.
- Hardened external intent handling by stripping explicit components/packages and limiting custom URI schemes to supported user-facing actions.
- Blocked JavaScript, file, and content URL navigation through the WebView navigation callback; external custom-scheme links in subframes require a user gesture.
- Corrected tracker matching so Facebook pixel path matching is evaluated as a path, not as a hostname.
- Improved download rows with actual DownloadManager byte progress and guarded opening until a download completes; active/pending rows refresh while the screen is open.
- Added an original DHYRA launcher mark and disabled Android backup of browser data.
- Aligned app metadata and GitHub Actions build artifact names to v1.7.0.

## Retained functionality from earlier versions

- Multiple retained WebView tabs, tab search, duplicate/close actions, background tab creation, and URL-based regular-session restore.
- Back, forward, reload, stop, page find, long-press link actions, fullscreen custom views, file chooser, camera/microphone runtime permission handling, and geolocation permission callbacks.
- Local history and bookmarks stored in Preferences DataStore, searchable lists, and item removal.
- Search-engine selection for Google, Bing, DuckDuckGo, Yahoo, and Ecosia.
- Download handling through Android DownloadManager.
- Dark, light, and system theme selection, ambient palettes, configurable accent/font colors, and acrylic-like surfaces.

## Data and privacy behavior

- Notes, bookmarks, app history, preferences, and the saved regular-tab URL list are stored locally through Preferences DataStore.
- The session restore stores up to 30 HTTP/HTTPS URLs. It does not restore page scroll position, form state, or WebView back/forward stacks.
- Private tabs are excluded from the app's saved session and in-app browsing history.
- **Private tabs are not isolated profiles.** Android System WebView does not provide the separate cookie and website-storage profiles required for strong private-session isolation in this architecture. Private tabs can share cookies and storage with regular tabs.
- Clear browsing data clears the shared WebView cookies, cache, form data, website storage, and DHYRA in-app history. It can also affect private tabs.
- Tracker protection is a small built-in host/path deny-list and third-party-cookie restriction. It is not a full EasyList/uBlock-style ad-blocking engine and does not guarantee complete tracking prevention.
- WebView Safe Browsing is enabled through the platform setting. HTTPS status is inferred from the active URL; certificate errors are cancelled rather than bypassed.
- Camera, microphone, and location require Android runtime permission and an additional DHYRA per-request site confirmation. Site decisions are not persisted. There is no separate per-site permission editor in this version; Android app permissions can be revoked in system settings.

## Known limitations / not represented as completed

- No Gecko/Chromium engine integration, extension platform, full browser-profile isolation, site-specific permission dashboard, or comprehensive ad-blocking engine.
- Notes are plain text (up to 200 notes, 200 characters per title, and 20,000 characters per note body). Rich text, checklist blocks, categories/tags, import, and automatic file backup are not implemented. Notes can be shared/exported as text via the Android share sheet.
- Bookmark folders, bookmark import/export, favicon persistence, and drag-and-drop tab reordering are not implemented.
- DownloadManager controls the downloads. Reliable pause/resume/retry, download speed, and a persistent in-app download database are not provided by this build; the displayed byte progress/status is queried from Android DownloadManager.
- The startup intro animation, weather integration, wallpaper gallery, site autocomplete/suggestions, live tab thumbnails, and desktop browser extension support are not implemented.
- The UI is designed for Android phones and tablets using Compose responsive primitives; it is not a desktop browser build or an iOS app.

## Build configuration

- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- Gradle: 8.7
- compileSdk: 35
- targetSdk: 34
- minSdk: 26
- Java: 17
- app version: 1.7.0 (versionCode 11)

## Build locally

```bash
./gradlew testDebugUnitTest lintDebug :app:assembleDebug
```

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

The GitHub Actions workflow can build either a project extracted into the repository root or a single source ZIP in the repository root. If the ZIP does not include the Gradle wrapper JAR, the workflow generates it using Gradle 8.7 before running tests, lint, and the debug build.
