package com.dhyra.browser

import android.app.DownloadManager
import android.app.role.RoleManager
import android.os.Build
import android.provider.Settings
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.compose.foundation.isSystemInDarkTheme
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

private val Context.dhyraStore by preferencesDataStore(name = "dhyra_settings")
private val HOME_KEY = stringPreferencesKey("homepage")
private val ENGINE_KEY = stringPreferencesKey("search_engine")
private val THEME_KEY = stringPreferencesKey("theme")
private val TRANSPARENCY_KEY = floatPreferencesKey("glass_transparency")
private val TRACKING_KEY = booleanPreferencesKey("tracking_protection")
private val POPUP_KEY = booleanPreferencesKey("popup_blocker")
private val DESKTOP_KEY = booleanPreferencesKey("desktop_mode")
private val SESSION_KEY = stringPreferencesKey("session_json")
private val HISTORY_KEY = stringPreferencesKey("history_json")
private val BOOKMARKS_KEY = stringPreferencesKey("bookmarks_json")
private const val BTC_ADDRESS = "bc1qrdlrhldck8pz6mtcaths86htz3g3hjyhsa44q5"

private val Accent = Color(0xFF7657F6)
private val Cyan = Color(0xFF49C6D9)
private val LocalDhyraMuted = compositionLocalOf { Color(0xFF5B6577) }

private enum class Route { HOME, BROWSER, SETTINGS, TABS, BOOKMARKS, HISTORY, DOWNLOADS, SUPPORT, ABOUT }

private data class PreferencesState(
    val homepage: String = "https://www.google.com",
    val engine: String = "Brave",
    val theme: String = "System",
    val transparency: Float = .78f,
    val tracking: Boolean = true,
    val popup: Boolean = true,
    val desktop: Boolean = false,
)

private data class SavedPage(val title: String, val url: String, val timestamp: Long = System.currentTimeMillis())
private data class Shortcut(val label: String, val url: String, val symbol: String)

class MainActivity : ComponentActivity() {
    var pendingExternalUrl by mutableStateOf<String?>(null)
    var browserController: BrowserController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        acceptExternalIntent(intent)
        setContent { DhyraApplication() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        acceptExternalIntent(intent)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) browserController?.trimMemory()
    }

    private fun acceptExternalIntent(intent: Intent?) {
        if (intent == null) return
        pendingExternalUrl = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data?.takeIf {
                it.scheme.equals("http", true) || it.scheme.equals("https", true)
            }?.toString()
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_WEB_SEARCH -> intent.getStringExtra(android.app.SearchManager.QUERY)
            else -> null
        }?.takeIf { it.isNotBlank() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DhyraApplication() {
    val context = LocalContext.current
    val activity = context as MainActivity
    val scope = rememberCoroutineScope()

    var pendingFileChooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        pendingFileChooser?.onReceiveValue(uris.toTypedArray())
        pendingFileChooser = null
    }

    var pendingPermission by remember { mutableStateOf<PermissionRequest?>(null) }
    var showSitePermissionDialog by remember { mutableStateOf(false) }
    var pendingGeo by remember { mutableStateOf<Pair<String, GeolocationPermissions.Callback>?>(null) }
    var showGeoPermissionDialog by remember { mutableStateOf(false) }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val pending = pendingGeo
        if (pending != null) {
            val allowed = results.values.any { it }
            pending.second.invoke(pending.first, allowed, false)
        }
        pendingGeo = null
        showGeoPermissionDialog = false
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val request = pendingPermission
        if (request != null) {
            val granted = results.values.all { it }
            val supported = request.resources.filter {
                it == PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
                    it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
                    it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID
            }
            if (granted && supported.isNotEmpty()) runCatching { request.grant(supported.toTypedArray()) }
            else runCatching { request.deny() }
        }
        pendingPermission = null
        showSitePermissionDialog = false
    }

    val controller = remember(activity) {
        BrowserController(
            activity = activity,
            onFileChooser = { callback ->
                pendingFileChooser?.onReceiveValue(null)
                pendingFileChooser = callback
                filePicker.launch(arrayOf("*/*"))
            },
            onPermission = { request ->
                pendingPermission?.let { old -> runCatching { old.deny() } }
                pendingPermission = request
                showSitePermissionDialog = true
            },
            onGeolocation = { origin, callback ->
                pendingGeo?.second?.let { previous -> runCatching { previous.invoke(pendingGeo?.first.orEmpty(), false, false) } }
                pendingGeo = origin to callback
                showGeoPermissionDialog = true
            }
        )
    }

    val prefs by context.dhyraStore.data.collectAsState(
        initial = androidx.datastore.preferences.core.emptyPreferences()
    )
    val state = PreferencesState(
        homepage = prefs[HOME_KEY] ?: "https://www.google.com",
        engine = prefs[ENGINE_KEY] ?: "Brave",
        theme = prefs[THEME_KEY] ?: "System",
        transparency = prefs[TRANSPARENCY_KEY] ?: .78f,
        tracking = prefs[TRACKING_KEY] ?: true,
        popup = prefs[POPUP_KEY] ?: true,
        desktop = prefs[DESKTOP_KEY] ?: false
    )
    val historyRaw = prefs[HISTORY_KEY] ?: "[]"
    val bookmarksRaw = prefs[BOOKMARKS_KEY] ?: "[]"
    val history = remember(historyRaw) { decodeEntries(historyRaw) }
    val bookmarks = remember(bookmarksRaw) { decodeEntries(bookmarksRaw) }

    var route by remember { mutableStateOf(Route.HOME) }
    var address by remember { mutableStateOf("") }
    var findText by remember { mutableStateOf("") }
    var showFind by remember { mutableStateOf(false) }
    var showBrowserMenu by remember { mutableStateOf(false) }
    var refreshDownloads by remember { mutableIntStateOf(0) }

    val isDark = when (state.theme) {
        "Dark" -> true
        "Light" -> false
        else -> isSystemInDarkTheme()
    }
    val mutedText = if (isDark) Color(0xFF9BA8C0) else Color(0xFF5B6577)
    SideEffect {
        WindowInsetsControllerCompat(activity.window, activity.window.decorView).isAppearanceLightStatusBars = !isDark
        WindowInsetsControllerCompat(activity.window, activity.window.decorView).isAppearanceLightNavigationBars = !isDark
    }
    val colorScheme = if (isDark) darkColorScheme(
        primary = Color(0xFFB6A6FF),
        secondary = Color(0xFF67D6E5),
        background = Color(0xFF090D17),
        surface = Color(0xFF151B2A),
        surfaceVariant = Color(0xFF222A3C),
        onSurface = Color(0xFFEAF0FF)
    ) else lightColorScheme(
        primary = Accent,
        secondary = Color(0xFF168FA5),
        background = Color(0xFFF3F5FA),
        surface = Color.White,
        surfaceVariant = Color(0xFFE9ECF5),
        onSurface = Color(0xFF172033)
    )

    controller.onPageFinished = { tab ->
        if (!tab.isPrivate && (tab.url.startsWith("https://") || tab.url.startsWith("http://"))) {
            scope.launch {
                val currentRaw = context.dhyraStore.data.first()[HISTORY_KEY] ?: "[]"
                val current = decodeEntries(currentRaw)
                val updated = (listOf(SavedPage(tab.title, tab.url)) + current.filterNot { it.url == tab.url }).take(5000)
                context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(updated) }
            }
        }
    }
    controller.onTabsChanged = { snapshot ->
        val json = JSONArray()
        snapshot.filter { !it.isPrivate && (it.url.startsWith("https://") || it.url.startsWith("http://")) }
            .takeLast(30).forEach { tab ->
                json.put(JSONObject().put("url", tab.url).put("title", tab.title))
            }
        scope.launch { context.dhyraStore.edit { it[SESSION_KEY] = json.toString() } }
    }
    activity.browserController = controller

    LaunchedEffect(controller) {
        if (controller.tabs.isEmpty()) {
            val persistedSession = context.dhyraStore.data.first()[SESSION_KEY] ?: "[]"
            val restored = decodeSession(persistedSession)
            if (restored.isNotEmpty()) controller.restoreSession(restored) else controller.createTab()
        }
    }
    LaunchedEffect(state.tracking, state.popup, state.desktop) {
        controller.applySettings(state.tracking, state.popup, state.desktop)
    }
    DisposableEffect(controller) {
        onDispose {
            pendingFileChooser?.onReceiveValue(null)
            controller.destroy()
            activity.browserController = null
        }
    }

    fun saveValue(key: String, value: Any) {
        scope.launch {
            context.dhyraStore.edit { p ->
                when (value) {
                    is String -> p[stringPreferencesKey(key)] = value
                    is Float -> p[floatPreferencesKey(key)] = value
                    is Boolean -> p[booleanPreferencesKey(key)] = value
                }
            }
        }
    }

    fun openTarget(raw: String, newTab: Boolean = false, isPrivate: Boolean = false) {
        val target = resolveAddress(raw, state.engine)
        if (newTab || controller.activeTabId == -1) controller.createTab(target, isPrivate)
        else controller.navigate(target)
        address = target
        route = Route.BROWSER
    }

    LaunchedEffect(activity.pendingExternalUrl) {
        val incoming = activity.pendingExternalUrl
        if (!incoming.isNullOrBlank()) {
            activity.pendingExternalUrl = null
            openTarget(incoming, newTab = true)
        }
    }

    fun addBookmark() {
        val tab = controller.activeTab() ?: return
        if (!tab.url.startsWith("http")) return
        scope.launch {
            val latestRaw = context.dhyraStore.data.first()[BOOKMARKS_KEY] ?: "[]"
            val latest = decodeEntries(latestRaw).filterNot { it.url == tab.url }
            context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries((listOf(SavedPage(tab.title, tab.url)) + latest).take(500)) }
        }
    }

    BackHandler(enabled = controller.isFullscreen || route != Route.HOME || (route == Route.BROWSER && controller.activeWebView()?.canGoBack() == true)) {
        when {
            controller.isFullscreen -> controller.exitFullscreen()
            route == Route.BROWSER && controller.activeWebView()?.canGoBack() == true -> controller.goBack()
            route == Route.BROWSER -> route = Route.HOME
            else -> route = Route.HOME
        }
    }

    CompositionLocalProvider(LocalDhyraMuted provides mutedText) {
    MaterialTheme(colorScheme = colorScheme, typography = Typography()) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (route) {
                Route.HOME -> HomeScreen(
                    dark = isDark, transparency = state.transparency,
                    address = address, onAddressChange = { address = it },
                    onSearch = { openTarget(address) },
                    onShortcut = { openTarget(it, newTab = controller.tabs.isNotEmpty() && controller.activeTab()?.url != "about:blank") },
                    tabCount = controller.tabs.size,
                    onOpenTabs = { route = Route.TABS },
                    onSettings = { route = Route.SETTINGS },
                    onBookmarks = { route = Route.BOOKMARKS },
                    onHistory = { route = Route.HISTORY },
                    onDownloads = { route = Route.DOWNLOADS },
                    onSupport = { route = Route.SUPPORT }
                )
                Route.BROWSER -> {
                    val active = controller.activeTab()
                    LaunchedEffect(active?.id, active?.url) {
                        active?.url?.takeIf { it != "about:blank" }?.let { address = it }
                    }
                    Column(Modifier.fillMaxSize()) {
                        BrowserToolbar(
                            address = address,
                            onAddress = { address = it },
                            onGo = { openTarget(address) },
                            onHome = { address = state.homepage; controller.navigate(state.homepage) },
                            onMenu = { showBrowserMenu = true },
                            onShields = { route = Route.SETTINGS },
                            shieldCount = controller.totalBlockedRequestCount(),
                            loading = active?.loading == true,
                            progress = active?.progress ?: 0
                        )
                        if (showFind) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = findText, onValueChange = { findText = it; controller.activeWebView()?.findAllAsync(it) },
                                    modifier = Modifier.weight(1f), singleLine = true, label = { Text("Find in page") }
                                )
                                IconButton(onClick = { showFind = false; controller.activeWebView()?.clearMatches() }) { Icon(Icons.Default.Close, null) }
                            }
                        }
                        AndroidView(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            factory = { ctx -> android.widget.FrameLayout(ctx).apply { controller.attach(this) } },
                            update = { controller.attach(it) }
                        )
                        BrowserBottomBar(
                            canBack = controller.activeWebView()?.canGoBack() == true,
                            canForward = controller.activeWebView()?.canGoForward() == true,
                            onBack = { controller.goBack() },
                            onForward = { controller.goForward() },
                            onHome = { route = Route.HOME },
                            onTabs = { route = Route.TABS },
                            onReload = { controller.reload() }
                        )
                        DropdownMenu(expanded = showBrowserMenu, onDismissRequest = { showBrowserMenu = false }) {
                            DropdownMenuItem(text = { Text("New tab") }, leadingIcon = { Icon(Icons.Default.Add, null) }, onClick = {
                                showBrowserMenu = false; controller.createTab(); route = Route.HOME
                            })
                            DropdownMenuItem(text = { Text("New private tab") }, leadingIcon = { Icon(Icons.Default.VisibilityOff, null) }, onClick = {
                                showBrowserMenu = false; controller.createTab(isPrivate = true); route = Route.HOME
                            })
                            DropdownMenuItem(text = { Text("Add bookmark") }, leadingIcon = { Icon(Icons.Default.BookmarkAdd, null) }, onClick = {
                                showBrowserMenu = false; addBookmark()
                            })
                            DropdownMenuItem(text = { Text("Bookmarks") }, leadingIcon = { Icon(Icons.Default.Bookmarks, null) }, onClick = {
                                showBrowserMenu = false; route = Route.BOOKMARKS
                            })
                            DropdownMenuItem(text = { Text("History") }, leadingIcon = { Icon(Icons.Default.History, null) }, onClick = {
                                showBrowserMenu = false; route = Route.HISTORY
                            })
                            DropdownMenuItem(text = { Text("Downloads") }, leadingIcon = { Icon(Icons.Default.Download, null) }, onClick = {
                                showBrowserMenu = false; refreshDownloads++; route = Route.DOWNLOADS
                            })
                            DropdownMenuItem(text = { Text("Find in page") }, leadingIcon = { Icon(Icons.Default.Search, null) }, onClick = {
                                showBrowserMenu = false; showFind = true
                            })
                            DropdownMenuItem(text = { Text("Share page") }, leadingIcon = { Icon(Icons.Default.Share, null) }, onClick = {
                                showBrowserMenu = false
                                val share = Intent(Intent.ACTION_SEND).setType("text/plain")
                                    .putExtra(Intent.EXTRA_TEXT, controller.activeTab()?.url ?: "")
                                context.startActivity(Intent.createChooser(share, "Share page"))
                            })
                            DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(Icons.Default.Settings, null) }, onClick = {
                                showBrowserMenu = false; route = Route.SETTINGS
                            })
                        }
                    }
                }
                Route.TABS -> TabsScreen(controller, onBack = { route = Route.HOME }, onOpen = { route = Route.BROWSER }, onNew = {
                    controller.createTab(); route = Route.HOME
                })
                Route.SETTINGS -> SettingsScreen(state, onBack = { route = Route.HOME }, onSave = ::saveValue, onClear = {
                    controller.clearRegularData()
                    scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                }, onSetDefaultBrowser = { requestDefaultBrowserRole(activity) })
                Route.BOOKMARKS -> EntriesScreen("Bookmarks", bookmarks, onBack = { route = Route.HOME }, onOpen = {
                    openTarget(it, newTab = true)
                }, onDelete = { url ->
                    scope.launch {
                        val remaining = bookmarks.filterNot { it.url == url }
                        context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries(remaining) }
                    }
                })
                Route.HISTORY -> EntriesScreen("History", history, onBack = { route = Route.HOME }, onOpen = {
                    openTarget(it, newTab = true)
                }, onDelete = { url ->
                    scope.launch {
                        val remaining = history.filterNot { it.url == url }
                        context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(remaining) }
                    }
                }, onClearAll = {
                    scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                })
                Route.DOWNLOADS -> DownloadsScreen(onBack = { route = Route.HOME }, refreshKey = refreshDownloads)
                Route.SUPPORT -> SupportScreen(onBack = { route = Route.HOME })
                Route.ABOUT -> AboutScreen(onBack = { route = Route.HOME })
            }
        }
        if (showSitePermissionDialog && pendingPermission != null) {
            val request = pendingPermission
            val origin = request?.origin ?: "This website"
            val requestedResources = request?.resources?.joinToString { resource ->
                when (resource) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "camera"
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "microphone"
                    PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID -> "protected media / DRM"
                    else -> "unsupported resource"
                }
            } ?: "device resources"
            AlertDialog(
                onDismissRequest = {
                    runCatching { request?.deny() }
                    pendingPermission = null
                    showSitePermissionDialog = false
                },
                title = { Text("Allow site permission?") },
                text = { Text("$origin is requesting: $requestedResources. Only approve sites you trust.") },
                confirmButton = {
                    TextButton(onClick = {
                        val current = pendingPermission
                        val resources = current?.resources.orEmpty()
                        val runtimePermissions = buildList {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in resources) add(android.Manifest.permission.CAMERA)
                            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in resources) add(android.Manifest.permission.RECORD_AUDIO)
                        }
                        if (runtimePermissions.isNotEmpty()) {
                            permissionLauncher.launch(runtimePermissions.distinct().toTypedArray())
                        } else {
                            val supported = resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }
                            if (supported.isNotEmpty()) runCatching { current?.grant(supported.toTypedArray()) }
                            else runCatching { current?.deny() }
                            pendingPermission = null
                            showSitePermissionDialog = false
                        }
                    }) { Text("Allow") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        runCatching { request?.deny() }
                        pendingPermission = null
                        showSitePermissionDialog = false
                    }) { Text("Block") }
                }
            )
        }
        if (showGeoPermissionDialog && pendingGeo != null) {
            val (origin, callback) = pendingGeo!!
            AlertDialog(
                onDismissRequest = {
                    runCatching { callback.invoke(origin, false, false) }
                    pendingGeo = null
                    showGeoPermissionDialog = false
                },
                title = { Text("Allow location access?") },
                text = { Text("$origin is requesting your device location. This request is not saved for future visits.") },
                confirmButton = {
                    TextButton(onClick = {
                        val fineGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        val coarseGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        if (fineGranted || coarseGranted) {
                            runCatching { callback.invoke(origin, true, false) }
                            pendingGeo = null
                            showGeoPermissionDialog = false
                        } else {
                            locationLauncher.launch(arrayOf(
                                android.Manifest.permission.ACCESS_FINE_LOCATION,
                                android.Manifest.permission.ACCESS_COARSE_LOCATION
                            ))
                        }
                    }) { Text("Allow once") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        runCatching { callback.invoke(origin, false, false) }
                        pendingGeo = null
                        showGeoPermissionDialog = false
                    }) { Text("Block") }
                }
            )
        }
    }
    }
}

@Composable
private fun HomeScreen(
    dark: Boolean,
    transparency: Float,
    address: String,
    onAddressChange: (String) -> Unit,
    onSearch: () -> Unit,
    onShortcut: (String) -> Unit,
    tabCount: Int,
    onOpenTabs: () -> Unit,
    onSettings: () -> Unit,
    onBookmarks: () -> Unit,
    onHistory: () -> Unit,
    onDownloads: () -> Unit,
    onSupport: () -> Unit
) {
    val shortcuts = listOf(
        Shortcut("Google", "https://www.google.com", "G"),
        Shortcut("YouTube", "https://m.youtube.com", "▶"),
        Shortcut("GitHub", "https://github.com", "⌘"),
        Shortcut("DuckDuckGo", "https://duckduckgo.com", "D"),
        Shortcut("Wikipedia", "https://wikipedia.org", "W"),
        Shortcut("Brave Search", "https://search.brave.com", "B"),
        Shortcut("Bing", "https://www.bing.com", "b"),
        Shortcut("Reddit", "https://www.reddit.com", "r"),
        Shortcut("Telegram", "https://web.telegram.org", "➤")
    )

    val cardColor = MaterialTheme.colorScheme.surface.copy(
        alpha = transparency.coerceIn(0.55f, 1f)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    if (dark) {
                        listOf(
                            Color(0xFF0B1220),
                            Color(0xFF101A2B),
                            Color(0xFF090D17)
                        )
                    } else {
                        listOf(
                            Color(0xFFF7F8FC),
                            Color(0xFFEEF1F8),
                            Color(0xFFF8F9FC)
                        )
                    }
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        // Header: compact brand identity and primary controls.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, bottom = 22.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(39.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(Brush.linearGradient(listOf(Accent, Cyan))),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Public,
                    contentDescription = "DHYRA",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "DHYRA",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "BROWSER",
                    fontSize = 9.sp,
                    color = LocalDhyraMuted.current,
                    letterSpacing = 2.4.sp
                )
            }

            IconButton(onClick = onOpenTabs) {
                BadgedBox(
                    badge = {
                        if (tabCount > 0) Badge { Text(tabCount.toString()) }
                    }
                ) {
                    Icon(Icons.Default.Tab, contentDescription = "Tabs")
                }
            }

            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Tune, contentDescription = "Settings")
            }
        }

        // Short welcome message keeps the home screen visually light.
        Text(
            text = "Browse freely.",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.5).sp
        )
        Text(
            text = "A calmer way to explore the web.",
            color = LocalDhyraMuted.current,
            fontSize = 12.sp
        )

        Spacer(Modifier.height(17.dp))

        // Search and address field.
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 54.dp),
            shape = RoundedCornerShape(18.dp),
            color = cardColor,
            shadowElevation = 3.dp
        ) {
            Row(
                modifier = Modifier.padding(start = 14.dp, end = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = Accent,
                    modifier = Modifier.size(21.dp)
                )
                Spacer(Modifier.width(8.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = onAddressChange,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 52.dp),
                    placeholder = {
                        Text("Search or enter address", fontSize = 13.sp)
                    },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { onSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent
                    )
                )

                IconButton(
                    onClick = onSearch,
                    modifier = Modifier
                        .size(39.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .background(Accent)
                ) {
                    Icon(
                        Icons.Default.ArrowForward,
                        contentDescription = "Search",
                        tint = Color.White,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(22.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "QUICK ACCESS",
                color = LocalDhyraMuted.current,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "Your favourite sites",
                color = LocalDhyraMuted.current,
                fontSize = 10.sp
            )
        }

        Spacer(Modifier.height(10.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            gridItems(shortcuts) { item ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onShortcut(item.url) },
                    shape = RoundedCornerShape(16.dp),
                    color = cardColor,
                    shadowElevation = 1.dp
                ) {
                    Column(
                        modifier = Modifier.padding(
                            horizontal = 5.dp,
                            vertical = 11.dp
                        ),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(37.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            Accent.copy(alpha = 0.15f),
                                            Cyan.copy(alpha = 0.18f)
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = item.symbol,
                                color = Accent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }

                        Spacer(Modifier.height(6.dp))

                        Text(
                            text = item.label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Frequently used library actions.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 5.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickAction(
                Icons.Default.Bookmarks,
                "Saved",
                onBookmarks,
                Modifier.weight(1f)
            )
            QuickAction(
                Icons.Default.History,
                "History",
                onHistory,
                Modifier.weight(1f)
            )
            QuickAction(
                Icons.Default.Download,
                "Downloads",
                onDownloads,
                Modifier.weight(1f)
            )
        }

        // Small support entry; intentionally secondary to browsing.
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp)
                .clickable(onClick = onSupport),
            shape = RoundedCornerShape(15.dp),
            color = cardColor
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.FavoriteBorder,
                    contentDescription = null,
                    tint = Accent,
                    modifier = Modifier.size(19.dp)
                )
                Spacer(Modifier.width(9.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Support DHYRA",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "Help us keep improving",
                        color = LocalDhyraMuted.current,
                        fontSize = 9.sp
                    )
                }
                Icon(
                    Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = LocalDhyraMuted.current,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun QuickAction(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit, modifier: Modifier) {
    Surface(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(15.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(19.dp))
            Spacer(Modifier.height(4.dp))
            Text(text, fontSize = 10.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun BrowserToolbar(
    address: String, onAddress: (String) -> Unit, onGo: () -> Unit,
    onHome: () -> Unit, onMenu: () -> Unit, onShields: () -> Unit, shieldCount: Int,
    loading: Boolean, progress: Int
) {
    Column {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onHome) { Icon(Icons.Default.Home, "Home", tint = Accent) }
            Surface(Modifier.weight(1f), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Row(Modifier.padding(start = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (address.startsWith("https://")) Icons.Default.Lock else Icons.Default.Language, null, tint = if (address.startsWith("https://")) Color(0xFF24A36A) else LocalDhyraMuted.current, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    OutlinedTextField(
                        value = address, onValueChange = onAddress, modifier = Modifier.weight(1f),
                        singleLine = true, placeholder = { Text("Search or URL", fontSize = 12.sp) },
                        textStyle = MaterialTheme.typography.bodySmall,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { onGo() }),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent, focusedContainerColor = Color.Transparent
                        )
                    )
                    IconButton(onClick = onGo) { Icon(Icons.Default.ArrowForward, null, tint = Accent) }
                }
            }
            IconButton(onClick = onShields) {
                BadgedBox(badge = { if (shieldCount > 0) Badge { Text(shieldCount.coerceAtMost(999).toString()) } }) {
                    Icon(Icons.Default.Shield, "Shields", tint = Accent)
                }
            }
            IconButton(onClick = onMenu) { Icon(Icons.Default.MoreVert, "Menu") }
        }
        if (loading) LinearProgressIndicator(
            progress = { (progress.coerceIn(0, 100) / 100f) },
            modifier = Modifier.fillMaxWidth().height(2.dp), color = Accent, trackColor = Color.Transparent
        )
    }
}

@Composable
private fun BrowserBottomBar(
    canBack: Boolean, canForward: Boolean, onBack: () -> Unit, onForward: () -> Unit,
    onHome: () -> Unit, onTabs: () -> Unit, onReload: () -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 12.dp) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().height(55.dp).padding(horizontal = 13.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, enabled = canBack) { Icon(Icons.Default.ArrowBack, "Back") }
            IconButton(onClick = onForward, enabled = canForward) { Icon(Icons.Default.ArrowForward, "Forward") }
            IconButton(onClick = onHome) { Icon(Icons.Default.Home, "Home", tint = Accent) }
            IconButton(onClick = onReload) { Icon(Icons.Default.Refresh, "Reload") }
            IconButton(onClick = onTabs) { Icon(Icons.Default.Tab, "Tabs") }
        }
    }
}

@Composable
private fun TabsScreen(controller: BrowserController, onBack: () -> Unit, onOpen: () -> Unit, onNew: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Tabs (${controller.tabs.size})", Modifier.weight(1f), fontSize = 21.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = onNew) { Icon(Icons.Default.Add, "New tab", tint = Accent) }
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(controller.tabs, key = { it.id }) { tab ->
                Surface(
                    modifier = Modifier.fillMaxWidth().clickable { controller.selectTab(tab.id); onOpen() },
                    shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface
                ) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (tab.isPrivate) Icons.Default.VisibilityOff else Icons.Default.Language, null, tint = Accent)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tab.title.ifBlank { "New tab" }, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(tab.url, color = LocalDhyraMuted.current, fontSize = 11.sp, maxLines = 1)
                            if (tab.loading) LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                        }
                        IconButton(onClick = { controller.closeTab(tab.id) }) { Icon(Icons.Default.Close, "Close tab") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    prefs: PreferencesState, onBack: () -> Unit,
    onSave: (String, Any) -> Unit, onClear: () -> Unit, onSetDefaultBrowser: () -> Unit
) {
    var homepage by remember(prefs.homepage) { mutableStateOf(prefs.homepage) }
    var engine by remember(prefs.engine) { mutableStateOf(prefs.engine) }
    var theme by remember(prefs.theme) { mutableStateOf(prefs.theme) }
    var transparency by remember(prefs.transparency) { mutableFloatStateOf(prefs.transparency) }
    var engineExpanded by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                Column {
                    Text("Settings Center", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("Customize your browsing", color = LocalDhyraMuted.current, fontSize = 11.sp)
                }
            }
        }
        item {
            SettingsCard("APPEARANCE", Icons.Default.Palette) {
                Text("Theme mode", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("Light", "Dark", "System").forEach { mode ->
                        FilterChip(selected = theme == mode, onClick = { theme = mode; onSave("theme", mode) }, label = { Text(mode) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Glass transparency", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Text("${(transparency * 100).toInt()}%", color = Accent, fontWeight = FontWeight.Bold)
                }
                Slider(value = transparency, onValueChange = { transparency = it }, valueRange = .2f..1f, onValueChangeFinished = { onSave("glass_transparency", transparency) })
            }
        }
        item {
            SettingsCard("SEARCH & HOMEPAGE", Icons.Default.Search) {
                Text("Default search engine", fontWeight = FontWeight.SemiBold)
                Box {
                    OutlinedButton(onClick = { engineExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(engine, Modifier.weight(1f)); Icon(Icons.Default.ExpandMore, null)
                    }
                    DropdownMenu(engineExpanded, { engineExpanded = false }) {
                        listOf("Brave", "DuckDuckGo", "Google", "Bing", "Ecosia", "Startpage", "Qwant").forEach { choice ->
                            DropdownMenuItem(text = { Text(choice) }, onClick = { engine = choice; engineExpanded = false; onSave("search_engine", choice) })
                        }
                    }
                }
                Text("Homepage URL", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(homepage, { homepage = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("https://example.com") })
                Button(onClick = {
                    val normalized = normalizeHomepage(homepage)
                    homepage = normalized
                    onSave("homepage", normalized)
                }, modifier = Modifier.fillMaxWidth()) { Text("Save homepage") }
            }
        }
        item {
            SettingsCard("PRIVACY & SECURITY", Icons.Default.Shield) {
                PreferenceSwitch("Basic tracker blocking", "Blocks a small set of known ad/tracker hosts", prefs.tracking) { onSave("tracking_protection", it) }
                HorizontalDivider()
                PreferenceSwitch("Popup blocker", "Blocks new windows unless you turn this off", prefs.popup) { onSave("popup_blocker", it) }
                HorizontalDivider()
                PreferenceSwitch("Desktop site", "Request desktop user agent", prefs.desktop) { onSave("desktop_mode", it) }
                HorizontalDivider()
                Text("HTTPS-first is always enabled. Cleartext HTTP is disabled by network policy; DHYRA does not automatically downgrade to an insecure connection.", color = LocalDhyraMuted.current, fontSize = 10.sp)
                OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.DeleteSweep, null); Spacer(Modifier.width(7.dp)); Text("Clear cookies, cache & history")
                }
                Text("Tracker blocking is a lightweight built-in host list, not a full Adblock Plus / uBlock filter engine.", color = LocalDhyraMuted.current, fontSize = 10.sp)
                Text("Private tabs still share Android WebView cookies while open. When the last private tab closes, DHYRA clears shared cookies and WebStorage; this can sign you out of regular tabs.", color = LocalDhyraMuted.current, fontSize = 10.sp)
            }
        }
        item {
            SettingsCard("DEFAULT BROWSER", Icons.Default.Public) {
                Text("Set DHYRA as your device browser", fontWeight = FontWeight.SemiBold)
                OutlinedButton(onClick = onSetDefaultBrowser, modifier = Modifier.fillMaxWidth()) { Text("Choose default browser") }
            }
        }
        item {
            SettingsCard("ABOUT", Icons.Default.Info) {
                Text("DHYRA Browser 1.4.1", fontWeight = FontWeight.Bold)
                Text("Android browser powered by Android System WebView (Chromium-based).", color = LocalDhyraMuted.current, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(21.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Accent, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(title, color = LocalDhyraMuted.current, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
            }
            content()
        }
    }
}

@Composable
private fun PreferenceSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = LocalDhyraMuted.current, fontSize = 10.sp)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun EntriesScreen(
    title: String, entries: List<SavedPage>, onBack: () -> Unit,
    onOpen: (String) -> Unit, onDelete: (String) -> Unit, onClearAll: (() -> Unit)? = null
) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text(title, Modifier.weight(1f), fontSize = 21.sp, fontWeight = FontWeight.Bold)
            if (onClearAll != null) TextButton(onClick = onClearAll) { Text("Clear") }
        }
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nothing here yet", color = LocalDhyraMuted.current) }
        } else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries, key = { it.url }) { entry ->
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.clickable { onOpen(entry.url) }.padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, null, tint = Accent)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(entry.url, color = LocalDhyraMuted.current, fontSize = 10.sp, maxLines = 1)
                            if (title == "History") Text(DateFormat.getDateTimeInstance().format(Date(entry.timestamp)), color = LocalDhyraMuted.current, fontSize = 9.sp)
                        }
                        IconButton(onClick = { onDelete(entry.url) }) { Icon(Icons.Default.DeleteOutline, "Remove") }
                    }
                }
            }
        }
    }
}

@Composable
private fun DownloadsScreen(onBack: () -> Unit, refreshKey: Int) {
    val context = LocalContext.current
    var rows by remember { mutableStateOf(emptyList<DownloadRow>()) }
    fun load() {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = manager.query(DownloadManager.Query())
        val result = mutableListOf<DownloadRow>()
        cursor?.use { c ->
            val idCol = c.getColumnIndex(DownloadManager.COLUMN_ID)
            val titleCol = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
            val statusCol = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val totalCol = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val soFarCol = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val status = c.getInt(statusCol)
                val title = c.getString(titleCol) ?: "Download"
                val total = c.getLong(totalCol)
                val soFar = c.getLong(soFarCol)
                result += DownloadRow(id, title, statusLabel(status), total, soFar)
            }
        }
        rows = result
    }
    LaunchedEffect(refreshKey) { load() }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Downloads", Modifier.weight(1f), fontSize = 21.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = { load() }) { Icon(Icons.Default.Refresh, "Refresh") }
        }
        if (rows.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No downloads yet", color = LocalDhyraMuted.current) }
        else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(rows, key = { it.id }) { row ->
                Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.InsertDriveFile, null, tint = Accent)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(row.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text("${row.status} • ${formatBytes(row.downloaded)} / ${if (row.total > 0) formatBytes(row.total) else "—"}", color = LocalDhyraMuted.current, fontSize = 10.sp)
                        }
                        IconButton(onClick = {
                            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            runCatching {
                                val uri = manager.getUriForDownloadedFile(row.id)
                                if (uri != null) {
                                    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, context.contentResolver.getType(uri))
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    context.startActivity(intent)
                                }
                            }
                        }) { Icon(Icons.Default.OpenInNew, "Open") }
                        IconButton(onClick = {
                            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(row.id)
                            load()
                        }) { Icon(Icons.Default.DeleteOutline, "Delete") }
                    }
                }
            }
        }
    }
}

private data class DownloadRow(val id: Long, val title: String, val status: String, val total: Long, val downloaded: Long)

private fun statusLabel(status: Int): String = when (status) {
    DownloadManager.STATUS_PENDING -> "Pending"
    DownloadManager.STATUS_RUNNING -> "Downloading"
    DownloadManager.STATUS_PAUSED -> "Paused"
    DownloadManager.STATUS_SUCCESSFUL -> "Completed"
    DownloadManager.STATUS_FAILED -> "Failed"
    else -> "Unknown"
}

private fun formatBytes(value: Long): String {
    if (value < 1024) return "$value B"
    if (value < 1024 * 1024) return "%.1f KB".format(value / 1024f)
    return "%.1f MB".format(value / (1024f * 1024f))
}

@Composable
private fun SupportScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val qr = remember { makeQr("bitcoin:$BTC_ADDRESS") }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
        Icon(Icons.Default.Favorite, null, tint = Accent, modifier = Modifier.size(34.dp))
        Text("Support DHYRA", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Contribute voluntarily to support future development.", color = LocalDhyraMuted.current)
        Surface(shape = RoundedCornerShape(22.dp), color = Color.White, shadowElevation = 3.dp) {
            Image(qr.asImageBitmap(), null, Modifier.padding(13.dp).size(216.dp))
        }
        Text(BTC_ADDRESS, fontSize = 11.sp)
        Button(onClick = {
            clipboard.setText(AnnotatedString(BTC_ADDRESS))
            android.widget.Toast.makeText(context, "Bitcoin address copied", android.widget.Toast.LENGTH_SHORT).show()
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(7.dp)); Text("Copy address") }
        OutlinedButton(onClick = {
            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("bitcoin:$BTC_ADDRESS"))) }
                .onFailure { android.widget.Toast.makeText(context, "No compatible wallet found", android.widget.Toast.LENGTH_SHORT).show() }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AccountBalanceWallet, null); Spacer(Modifier.width(7.dp)); Text("Open Bitcoin wallet") }
        Text("Verify the address and Bitcoin network before sending.", color = LocalDhyraMuted.current, fontSize = 10.sp)
    }
}

@Composable
private fun AboutScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
        Spacer(Modifier.height(50.dp))
        Box(Modifier.size(82.dp).clip(RoundedCornerShape(27.dp)).background(Brush.linearGradient(listOf(Accent, Cyan))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Public, null, tint = Color.White, modifier = Modifier.size(46.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("DHYRA BROWSER", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        Text("Version 1.4.1", color = LocalDhyraMuted.current)
        Spacer(Modifier.height(18.dp))
        Text("An elegant Android browser powered by Android System WebView.", color = LocalDhyraMuted.current)
    }
}

private fun makeQr(payload: String): Bitmap {
    val matrix = com.google.zxing.qrcode.QRCodeWriter().encode(payload, com.google.zxing.BarcodeFormat.QR_CODE, 560, 560)
    return Bitmap.createBitmap(560, 560, Bitmap.Config.ARGB_8888).also { bmp ->
        for (x in 0 until 560) for (y in 0 until 560) {
            bmp.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
}

private fun resolveAddress(input: String, engine: String): String =
    BrowserAddressResolver.resolve(input, engine)

private fun normalizeHomepage(value: String): String = BrowserAddressResolver.normalizeHomepage(value)

private fun decodeSession(raw: String): List<Pair<String, String>> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val item = array.optJSONObject(index) ?: return@mapNotNull null
        val url = item.optString("url")
        if (url.startsWith("https://", true) || url.startsWith("http://", true)) {
            url to item.optString("title", url)
        } else null
    }
}.getOrDefault(emptyList())

private fun requestDefaultBrowserRole(activity: MainActivity) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val manager = activity.getSystemService(RoleManager::class.java)
            if (manager != null && manager.isRoleAvailable(RoleManager.ROLE_BROWSER)) {
                activity.startActivity(manager.createRequestRoleIntent(RoleManager.ROLE_BROWSER))
            } else {
                activity.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            }
        } else {
            activity.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        }
    } catch (_: Exception) {
        runCatching { activity.startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
}

private fun decodeEntries(raw: String): List<SavedPage> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val obj = array.optJSONObject(index) ?: return@mapNotNull null
        val url = obj.optString("url")
        if (url.isBlank()) null else SavedPage(
            title = obj.optString("title", url),
            url = url,
            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
        )
    }
}.getOrDefault(emptyList())

private fun encodeEntries(entries: List<SavedPage>): String {
    val array = JSONArray()
    entries.forEach { entry ->
        array.put(JSONObject().put("title", entry.title).put("url", entry.url).put("timestamp", entry.timestamp))
    }
    return array.toString()
}
