# Integration notes

Required dependencies (use versions compatible with your project):
```kotlin
implementation("androidx.datastore:datastore-preferences:1.1.1")
implementation("com.google.zxing:core:3.5.3")
implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
implementation("androidx.compose.material:material-icons-extended")
implementation("androidx.compose.material3:material3")
```
Enable `buildConfig = true` if AboutScreen reads `BuildConfig`.

The previous Phase 5 navigation draft assumed certain Phase 4 class signatures. Those must be aligned against your actual project before expecting a successful build. This archive does not claim a verified build.
