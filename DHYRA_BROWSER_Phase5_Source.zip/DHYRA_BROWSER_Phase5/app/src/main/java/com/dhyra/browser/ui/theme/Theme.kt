package com.dhyra.browser.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import com.dhyra.browser.data.prefs.ThemeMode

@Composable
fun DhyraTheme(themeMode: ThemeMode = ThemeMode.SYSTEM, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val scheme = if (dark) darkColorScheme(
        primary = DhyraBlue,
        background = DhyraDarkBackground,
        surface = DhyraDarkBackground
    ) else lightColorScheme(
        primary = DhyraBlue,
        background = DhyraLightBackground,
        surface = DhyraLightBackground
    )
    MaterialTheme(colorScheme = scheme, typography = DhyraTypography, content = content)
}
