package com.dhyra.browser.ui.theme

import androidx.compose.ui.graphics.Color

val DhyraBlue = Color(0xFF4F7DFF)
val DhyraLightBackground = Color(0xFFF5F7FC)
val DhyraDarkBackground = Color(0xFF10131B)
val DhyraGlassWhite = Color(0xFFFFFFFF)
