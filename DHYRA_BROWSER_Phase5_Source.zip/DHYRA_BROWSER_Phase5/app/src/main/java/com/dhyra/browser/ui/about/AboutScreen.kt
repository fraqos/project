package com.dhyra.browser.ui.about

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AboutScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("About DHYRA BROWSER", style = MaterialTheme.typography.headlineSmall)
        Text("A browser project focused on privacy, speed, and a clean interface.")
        Text("Application ID: com.dhyra.browser")
    }
}
