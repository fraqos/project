package com.dhyra.browser.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dhyraDataStore by preferencesDataStore(name = "dhyra_settings")

enum class ThemeMode(val storageValue: String, val label: String) {
    LIGHT("light", "Light"), DARK("dark", "Dark"), SYSTEM("system", "System");
    companion object {
        fun from(value: String?) = entries.firstOrNull { it.storageValue == value } ?: SYSTEM
    }
}

enum class SearchEngine(val storageValue: String, val label: String, val searchUrl: String) {
    GOOGLE("google", "Google", "https://www.google.com/search?q="),
    BING("bing", "Bing", "https://www.bing.com/search?q="),
    DUCKDUCKGO("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q="),
    BRAVE("brave", "Brave", "https://search.brave.com/search?q=");
    companion object {
        fun from(value: String?) = entries.firstOrNull { it.storageValue == value } ?: GOOGLE
    }
}

data class DhyraSettings(
    val searchEngine: SearchEngine = SearchEngine.GOOGLE,
    val homepage: String = "https://www.google.com",
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val glassTransparency: Float = 0.75f,
    val trackingProtection: Boolean = true,
    val popupBlocker: Boolean = true,
    val desktopMode: Boolean = false
)

class SettingsDataStore(private val context: Context) {
    private object Keys {
        val searchEngine = stringPreferencesKey("search_engine")
        val homepage = stringPreferencesKey("homepage")
        val theme = stringPreferencesKey("theme")
        val glassTransparency = floatPreferencesKey("glass_transparency")
        val trackingProtection = booleanPreferencesKey("tracking_protection")
        val popupBlocker = booleanPreferencesKey("popup_blocker")
        val desktopMode = booleanPreferencesKey("desktop_mode")
    }

    val settings: Flow<DhyraSettings> = context.dhyraDataStore.data.map { p ->
        DhyraSettings(
            searchEngine = SearchEngine.from(p[Keys.searchEngine]),
            homepage = normalizeHomepage(p[Keys.homepage] ?: "https://www.google.com"),
            themeMode = ThemeMode.from(p[Keys.theme]),
            glassTransparency = (p[Keys.glassTransparency] ?: 0.75f).coerceIn(0.2f, 1f),
            trackingProtection = p[Keys.trackingProtection] ?: true,
            popupBlocker = p[Keys.popupBlocker] ?: true,
            desktopMode = p[Keys.desktopMode] ?: false
        )
    }

    suspend fun setSearchEngine(value: SearchEngine) = context.dhyraDataStore.edit { it[Keys.searchEngine] = value.storageValue }
    suspend fun setHomepage(value: String) = context.dhyraDataStore.edit { it[Keys.homepage] = normalizeHomepage(value) }
    suspend fun setTheme(value: ThemeMode) = context.dhyraDataStore.edit { it[Keys.theme] = value.storageValue }
    suspend fun setGlassTransparency(value: Float) = context.dhyraDataStore.edit { it[Keys.glassTransparency] = value.coerceIn(0.2f, 1f) }
    suspend fun setTrackingProtection(value: Boolean) = context.dhyraDataStore.edit { it[Keys.trackingProtection] = value }
    suspend fun setPopupBlocker(value: Boolean) = context.dhyraDataStore.edit { it[Keys.popupBlocker] = value }
    suspend fun setDesktopMode(value: Boolean) = context.dhyraDataStore.edit { it[Keys.desktopMode] = value }

    private fun normalizeHomepage(raw: String): String {
        val value = raw.trim()
        if (value.isBlank()) return "https://www.google.com"
        val candidate = if ("://" in value) value else "https://$value"
        return runCatching {
            val uri = android.net.Uri.parse(candidate)
            if (uri.scheme in listOf("http", "https") && !uri.host.isNullOrBlank()) candidate
            else "https://www.google.com"
        }.getOrDefault("https://www.google.com")
    }
}
