package com.dhyra.browser.ui.theme

import androidx.compose.material3.Typography

val DhyraTypography = Typography()
