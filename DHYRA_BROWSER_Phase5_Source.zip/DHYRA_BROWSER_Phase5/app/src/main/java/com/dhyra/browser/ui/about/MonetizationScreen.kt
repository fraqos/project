package com.dhyra.browser.ui.about

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun MonetizationScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("Monetization Info", style = MaterialTheme.typography.headlineSmall)
        Text("The app may be supported by advertising placements and voluntary Bitcoin contributions.")
        Text("No paid subscription is represented in this screen.")
    }
}
