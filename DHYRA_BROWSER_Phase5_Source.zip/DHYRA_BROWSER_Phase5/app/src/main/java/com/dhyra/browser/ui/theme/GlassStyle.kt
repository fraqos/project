package com.dhyra.browser.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

fun Modifier.dhyraGlass(transparency: Float, shape: RoundedCornerShape = RoundedCornerShape(20.dp)): Modifier =
    clip(shape).background(Color.White.copy(alpha = transparency.coerceIn(0.2f, 1f)))
