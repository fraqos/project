package com.dhyra.browser.ui.support

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

private const val BTC_ADDRESS = "bc1qrdlrhldck8pz6mtcaths86htz3g3hjyhsa44q5"

private fun createQr(payload: String, size: Int = 720): Bitmap {
    val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, size, size)
    return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).also { bitmap ->
        for (x in 0 until size) for (y in 0 until size) {
            bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
}

@Composable
fun SupportDhyraScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val qr = remember { createQr("bitcoin:$BTC_ADDRESS") }
    var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) { TextButton(onClick = onBack) { Text("← Back") } }
        Text("Support DHYRA BROWSER", style = MaterialTheme.typography.headlineSmall)
        Text("Jika aplikasi ini membantu, kamu bisa mendukung pengembang secara sukarela.")
        Image(qr.asImageBitmap(), contentDescription = "Bitcoin QR code", modifier = Modifier.size(230.dp))
        Text(BTC_ADDRESS, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { clipboard.setText(AnnotatedString(BTC_ADDRESS)); message = "Alamat disalin" }) { Text("Copy address") }
            OutlinedButton(onClick = {
                runCatching {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("bitcoin:$BTC_ADDRESS")))
                }.onFailure { message = "Wallet Bitcoin yang kompatibel tidak ditemukan" }
            }) { Text("Open wallet") }
        }
        Text("Pastikan alamat dan jaringan Bitcoin benar sebelum mengirim.")
        if (message.isNotBlank()) Text(message)
    }
}
