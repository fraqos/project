# DHYRA BROWSER — Phase 5 source package

This archive packages the Phase 5 Settings Center, preferences, theme, support/Bitcoin QR, About/Monetization, and privacy-cleaner source files.

## Important
This is a **Phase 5 source package**, not a verified complete Android Studio project. The navigation/ViewModel integration depends on the exact Phase 1–4 source APIs, which were not included in this chat. No Gradle build/device test has been run.

## Suggested placement
Copy the files under `app/src/main/java/com/dhyra/browser/` into the matching package paths in your project. Review `integration-notes.md` before replacing existing files.

## Dependencies
See `integration-notes.md` for the needed Gradle dependencies.
