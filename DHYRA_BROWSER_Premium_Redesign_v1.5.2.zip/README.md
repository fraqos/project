# DHYRA Browser — iOS Edition v1.5.2

A compact Android browser built with Kotlin, Jetpack Compose, and Android System WebView. This edition refreshes the browser surface with an iOS/Safari-inspired visual language while retaining Android-native behavior.

## UI and interaction updates

- Compact, pinned address capsule at the top of the browsing screen (48–54 dp target height), with connection indicator, editable URL/search field, reload/stop control, menu, and a 2 dp loading indicator.
- Floating acrylic-style bottom navigation with Back, Forward, Home, tab count, and More actions.
- Reusable `FrostedSurface` for translucent top and bottom browser chrome. It uses low-cost translucent layers and highlights rather than live backdrop blur to avoid unnecessary frame cost on mid-range phones.
- Reduced home, tab switcher, and settings spacing with smaller radii and more consistent type scale.
- Edge-only right-swipe opens the drawer; the Material 3 modal drawer drag gesture closes it while open. The explicit menu button remains available.
- Persistent custom accent and font colors, with RGB sliders and six-digit HEX input in Settings.
- Automatic text contrast can be enabled or disabled. When enabled, text color is selected from the resolved light/dark canvas luminance.
- Glass opacity preference is applied to the address capsule and bottom browser controls.

## Browser architecture

- `BrowserController` owns the WebView instances and publishes immutable tab snapshots via `StateFlow`.
- Tabs are retained when switching and destroyed when closed. WebViews are paused/resumed with the Activity lifecycle to reduce background work.
- JavaScript, DOM storage, safe browsing, download handling, file chooser, runtime camera/microphone permissions, and geolocation permission callbacks are wired through the controller.
- Android Back navigates browser history first and returns to the home screen when the active WebView has no history.

## Existing feature limits

- Tracking protection is a small built-in host list, not a full EasyList/uBlock-style ad-blocking engine.
- WebView private tabs are not isolated browser profiles. Android System WebView shares process-level cookie and storage infrastructure; the UI does not claim full Safari-grade private isolation.
- Drawer opening listens only within a 24 dp strip on the left edge and only after horizontal touch slop; horizontal WebView gestures elsewhere are left to the page. While the drawer is open, the modal drawer handles the closing gesture.
- Acrylic surfaces are translucent but do not perform true behind-the-surface Gaussian blur.
- Tab previews are lightweight placeholders rather than live page thumbnails.

## Build configuration

- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- Gradle: 8.7
- compileSdk: 35
- Java: 17
- app version: 1.5.2 (versionCode 6)

The GitHub Actions workflow supports either a project already extracted into the repository root or exactly one source ZIP in the repository root. If the Gradle wrapper JAR is missing from an uploaded ZIP, the workflow regenerates it using the installed Gradle 8.7 before building.

## Build

```bash
gradle --version
gradle :app:assembleDebug
```

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

For GitHub Actions, place the project ZIP at the repository root and keep `.github/workflows/build.yml` in the repository. GitHub does not discover workflow files nested inside an uploaded ZIP; at least the workflow itself must be present at `.github/workflows/build.yml` in the repository.
