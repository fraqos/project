package com.dhyra.browser.ui.theme

import androidx.compose.ui.graphics.Color

data class MoodPreset(
    val name: String,
    val shortName: String,
    val accent: Color,
    val canvasTop: Color,
    val canvasBottom: Color
) {
    companion object {
        val all = listOf(
            MoodPreset("Morning Mist", "Mist", Color(0xFF557A91), Color(0xFFF5F7FA), Color(0xFFE8EDF2)),
            MoodPreset("Warm Sand", "Sand", Color(0xFF9B795E), Color(0xFFF8F5F0), Color(0xFFECE5DA)),
            MoodPreset("Sage Calm", "Sage", Color(0xFF5D806C), Color(0xFFF2F6F2), Color(0xFFE3ECE4)),
            MoodPreset("Midnight Air", "Night", Color(0xFF9C9AE0), Color(0xFF101722), Color(0xFF1D2939))
        )

        fun fromName(name: String): MoodPreset = all.firstOrNull { it.name == name } ?: all.first()
    }
}
