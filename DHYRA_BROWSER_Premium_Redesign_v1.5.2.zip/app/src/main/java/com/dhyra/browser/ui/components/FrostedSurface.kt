package com.dhyra.browser.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Lightweight acrylic surface. Uses translucent layers and highlights without an expensive
 * per-frame backdrop blur, keeping scrolling smooth on mid-range Android devices. */
@Composable
fun FrostedSurface(
    modifier: Modifier = Modifier,
    radius: Dp = 18.dp,
    dark: Boolean = false,
    opacity: Float = .90f,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    val strength = opacity.coerceIn(.35f, 1f)
    val fill = if (dark) {
        listOf(Color(0xFF202B3B).copy(alpha = strength), Color(0xFF111A28).copy(alpha = strength))
    } else {
        listOf(Color.White.copy(alpha = strength), Color(0xFFF4F6FA).copy(alpha = strength))
    }
    Box(
        modifier = modifier
            .shadow(7.dp, shape, clip = false)
            .clip(shape)
            .background(Brush.verticalGradient(fill))
            .border(
                BorderStroke(1.dp, if (dark) Color.White.copy(alpha = .14f) else Color.White.copy(alpha = .86f)),
                shape
            ),
        contentAlignment = Alignment.Center,
        content = {
            Box(
                Modifier.fillMaxWidth().height(1.dp).align(Alignment.TopCenter)
                    .background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = if (dark) .18f else .72f), Color.Transparent)))
            )
            content()
        }
    )
}
