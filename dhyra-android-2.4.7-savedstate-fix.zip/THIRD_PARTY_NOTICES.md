# Third-Party Notices

dhyra's direct dependencies in this build are listed below. Review current upstream license terms and include any required notices with distributed builds.

| Component | Purpose | License / notice |
|---|---|---|
| AndroidX Core / Activity / Lifecycle | Android platform integration | Apache License 2.0 |
| Jetpack Compose UI / Foundation / Material 3 | Declarative user interface | Apache License 2.0 |
| AndroidX DataStore | Preferences persistence | Apache License 2.0 |
| AndroidX WebKit | WebView compatibility APIs and secure message bridge | Apache License 2.0 |
| Google ML Kit Translate / Language ID | On-device page translation and language detection | Google ML Kit terms; models downloaded on demand |
| ZXing Core | QR-code generation | Apache License 2.0 |
| Kotlin | Programming language and Gradle plugin | Apache License 2.0 |
| Android System WebView | Web content engine supplied by the device/vendor | Chromium and provider-specific notices apply |

Google Mobile Ads SDK is **not** a dependency in this build. This table lists direct dependencies visible in the app Gradle file; Gradle resolves transitive dependencies. Generate and inspect a complete dependency/license report before commercial distribution. No third-party source files are vendored into this archive.

Google ML Kit Translate and Language Identification versions used: `com.google.mlkit:translate:17.0.3` and `com.google.mlkit:language-id:17.0.6`. Translation language models are downloaded on demand from Google services.

## AndroidX AppCompat

This release adds `androidx.appcompat:appcompat:1.8.0` for AppCompatDelegate theme selection and per-app locale handling. It is distributed under the AndroidX/Apache License 2.0 terms. The app uses Compose Material Icons Outlined vector assets for its outlined UI icon treatment; it does not bundle a Material Symbols font file.
