# dhyra 2.4.6 branding integration

The current icon artwork is based on the user-supplied D/globe/orbit emblem. The rectangular blue image background was removed; the logo art is stored as transparent PNG.

- `drawable-nodpi/dhyra_brand_art_transparent.png`: shared Compose/About artwork.
- `drawable-<density>/dhyra_splash_logo.png`: transparent Android 12+ splash art, with restrained safe-area occupancy.
- `drawable-<density>/dhyra_launcher_foreground.png`: adaptive icon foreground, scaled down within Android's safe zone.
- `drawable-nodpi/dhyra_launcher_monochrome.png`: Android themed-icon monochrome layer.
- `mipmap-<density>/ic_launcher*.png`: legacy icon with a calm flat field and a smaller emblem.

The splash screen still has a theme-matched surface color; only the logo's old blue rectangular background was removed. This allows the transparent logo to work in both light and dark startup surfaces.
