# dhyra v2.4.7 implementation status

## Implemented in source

- Native Compose homepage contains only search/address entry, speed dial and recently visited. Weather and news feed sections/repository are removed.
- Speed dial rotates through the requested six flat color pairs; dark mode uses separate high-contrast pairs. Recently visited rows are deduplicated by normalized host and shown in one card.
- Settings uses grouped cards and one outlined Compose icon style; Theme offers Light, Dark and System default. Accent is `#7F77DD`.
- App language choices are System default, English and Bahasa Indonesia. AppCompatDelegate persists the selected locale and recreates the activity; native Compose text and Toasts use the local resource catalogue.
- User-provided D/globe/orbit artwork is converted to transparent PNGs for startup/splash/About and safely scaled for adaptive/legacy launcher artwork.
- WebView remains Android System WebView. Inactive tabs receive `onPause()`, selected tabs resume, regular browsing uses `LOAD_DEFAULT`, `space` uses `LOAD_NO_CACHE`, DOM storage remains enabled, and deprecated Web SQL Database is disabled.

## Explicit limitations

- The homepage is native Compose, not an HTML/CSS page loaded in WebView. Locale selection therefore updates Compose resources directly; no JavaScript interface or homepage JSON injection is required.
- Only English and Bahasa Indonesia are currently localized. Other locales must not be offered until their complete `values-<language>` string resources and tests are added.
- Icons are Compose Material Icons Outlined vector assets for consistent outlined styling; this project does not bundle a Material Symbols font file.
- There is no separate Baseline Profile generation/benchmark module in this source. Do not claim baseline-profile gains. A WebView instance is not created on a background thread because WebView construction/use is UI-thread-bound; no speculative preloader is enabled.
- Android DownloadManager still owns transfer lifecycle; in-app pause/resume/speed prediction are not claimed.
- Full Android Gradle compilation, lint and device tests must run on GitHub Actions/Android tooling; source/static checks do not prove APK success.
