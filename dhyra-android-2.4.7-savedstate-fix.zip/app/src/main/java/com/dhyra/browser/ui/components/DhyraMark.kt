package com.dhyra.browser.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Canonical transparent dhyra emblem shared by startup and About surfaces. */
@Composable
internal fun DhyraMark(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    framed: Boolean = false
) {
    Box(
        modifier = modifier
            .size(size)
            .then(
                if (framed) Modifier
                    .clip(RoundedCornerShape(size * 0.28f))
                    .background(androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant)
                else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = com.dhyra.browser.R.drawable.dhyra_brand_art_transparent),
            contentDescription = null,
            modifier = Modifier.size(size),
            contentScale = ContentScale.Fit
        )
    }
}
