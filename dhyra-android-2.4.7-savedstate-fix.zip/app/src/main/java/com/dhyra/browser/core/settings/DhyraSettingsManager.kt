package com.dhyra.browser.core.settings

import com.dhyra.browser.core.search.CustomSearchEngine
import com.dhyra.browser.core.search.SearchEngineManager

/** Central defaults and validation for user-facing dhyra preferences. */
object DhyraSettingsManager {
    const val DEFAULT_SEARCH_ENGINE = SearchEngineManager.GOOGLE
    const val DEFAULT_THEME = "System default"
    const val DEFAULT_APP_LANGUAGE = "system"
    val supportedThemes = setOf("Light", "Dark", "System default")
    val supportedAppLanguages = setOf("system", "en", "id")

    fun normalizeSearchEngine(value: String?, custom: List<CustomSearchEngine> = emptyList()): String =
        value?.takeIf { it in SearchEngineManager.builtInEngines || custom.any { engine -> engine.name == it } || it == SearchEngineManager.CUSTOM }
            ?: DEFAULT_SEARCH_ENGINE

    /** Normalizes old stored values to the current three-option theme selector. */
    fun normalizeTheme(value: String?): String = when (value) {
        "Light" -> "Light"
        "Dark", "AMOLED" -> "Dark"
        "System", "System default", "Dynamic", null -> DEFAULT_THEME
        else -> DEFAULT_THEME
    }

    fun normalizeAppLanguage(value: String?): String = when (value?.lowercase()) {
        "en" -> "en"
        "id" -> "id"
        else -> DEFAULT_APP_LANGUAGE
    }

}
