package com.dhyra.browser.core.engine

import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.ViewGroup
import com.dhyra.browser.core.network.WebViewModeManager
import com.dhyra.browser.core.storage.DhyraCookieManager

/** Applies dhyra's common security/rendering policy and owns deterministic WebView teardown. */
class DhyraWebViewController(
    private val modeManager: WebViewModeManager
) {
    fun configure(
        view: WebView,
        tabId: Int,
        isPrivate: Boolean,
        popupBlocker: Boolean,
        trackingProtection: Boolean,
        profileCookies: CookieManager?,
        onDesktopModeRejected: () -> Unit
    ): Boolean {
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            // Web SQL Database is deprecated; DOM storage remains enabled for modern sites.
            databaseEnabled = false
            setGeolocationEnabled(!isPrivate)
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = !popupBlocker
            setSupportMultipleWindows(true)
            setSupportZoom(true)
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            allowFileAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            // Android system document pickers return content:// URIs after an explicit user grant.
            // Top-level content:// navigation remains blocked by BrowserController.
            allowContentAccess = true
            // Follow browser defaults: media with sound requires an explicit user gesture.
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = if (isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            safeBrowsingEnabled = true
        }

        val modeApplied = modeManager.applyCurrentMode(view, tabId)
        if (!modeApplied) {
            modeManager.enableMobileMode(view, tabId)
            onDesktopModeRejected()
        }
        val cookies = if (isPrivate) {
            // A private WebView must never silently inherit the default profile's cookies.
            DhyraCookieManager(requireNotNull(profileCookies) {
                "Private WebView configuration requires its named profile CookieManager."
            })
        } else {
            DhyraCookieManager(profileCookies ?: CookieManager.getInstance())
        }
        cookies.configureThirdPartyCookies(view, enabled = !isPrivate && !trackingProtection)
        return modeApplied
    }

    /** Detaches callbacks and the parent before destroy, reducing stale renderer references. */
    fun release(view: WebView, clearHistory: Boolean) {
        runCatching { view.onPause() }
        runCatching { view.stopLoading() }
        if (clearHistory) runCatching { view.clearHistory() }
        runCatching { view.webChromeClient = WebChromeClient() }
        runCatching { view.webViewClient = WebViewClient() }
        runCatching { (view.parent as? ViewGroup)?.removeView(view) }
        runCatching { view.removeAllViews() }
        runCatching { view.destroy() }
    }
}
