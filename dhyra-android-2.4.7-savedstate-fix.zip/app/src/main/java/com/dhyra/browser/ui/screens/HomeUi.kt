@file:OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class
)

package com.dhyra.browser.ui.screens

import com.dhyra.browser.*
import com.dhyra.browser.ui.theme.*
import com.dhyra.browser.ui.components.*

import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import com.dhyra.browser.R
import java.util.Locale

/**
 * Compact native start page: search, speed dial and recently visited only.
 * The home screen in this project is Compose (not an HTML document in WebView).
 */
@Composable
internal fun HomePage(
    isPrivate: Boolean,
    searchEngine: String,
    searchEngineOptions: List<String>,
    onSearchEngine: (String) -> Unit,
    speedDial: List<Shortcut>,
    recent: List<SavedPage>,
    onOpenOmnibox: () -> Unit,
    onSite: (String) -> Unit,
    onRemoveSite: (Shortcut) -> Unit,
    onSaveShortcut: (Shortcut?, Shortcut) -> Unit,
    onRecent: (String) -> Unit,
    tabCount: Int,
    onTabs: () -> Unit,
    onMenu: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val isDark = cs.background.luminance() < 0.5f
    var editingShortcut by remember { mutableStateOf<Shortcut?>(null) }
    var addingShortcut by remember { mutableStateOf(false) }
    var engineMenuExpanded by remember { mutableStateOf(false) }
    val uniqueRecent = remember(recent) { dedupeRecentByDomain(recent) }

    Column(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .statusBarsPadding()
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .height(52.dp),
            shape = RoundedCornerShape(999.dp),
            color = cs.surface,
            border = BorderStroke(0.5.dp, cs.outlineVariant)
        ) {
            Row(
                Modifier.fillMaxSize().padding(start = 16.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    Modifier.weight(1f).fillMaxHeight().clickable(onClick = onOpenOmnibox),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = null,
                        tint = cs.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = stringResource(R.string.search_or_enter_address),
                        fontSize = 15.sp,
                        lineHeight = 21.sp,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Box {
                    TextButton(
                        onClick = { engineMenuExpanded = true },
                        modifier = Modifier.height(48.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text(searchEngine, fontSize = 13.sp, maxLines = 1)
                        Icon(Icons.Outlined.ExpandMore, contentDescription = stringResource(R.string.choose_search_engine))
                    }
                    DropdownMenu(
                        expanded = engineMenuExpanded,
                        onDismissRequest = { engineMenuExpanded = false }
                    ) {
                        searchEngineOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    onSearchEngine(option)
                                    engineMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(top = 12.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Column {
                SectionLabel(stringResource(R.string.speed_dial))
                if (speedDial.isEmpty() && !isPrivate) {
                    Text(
                        text = stringResource(R.string.add_favourite_websites),
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        color = cs.onSurfaceVariant
                    )
                }
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val columns = (maxWidth / 92.dp).toInt().coerceIn(3, 6)
                    val gap = 8.dp
                    val tileWidth = (maxWidth - gap * (columns - 1)) / columns
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        maxItemsInEachRow = columns,
                        horizontalArrangement = Arrangement.spacedBy(gap),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        speedDial.take(8).forEachIndexed { index, site ->
                            SpeedDialTile(
                                site = site,
                                index = index,
                                isDark = isDark,
                                modifier = Modifier.width(tileWidth),
                                onClick = { onSite(site.url) },
                                onLongClick = { if (!isPrivate) editingShortcut = site }
                            )
                        }
                        if (!isPrivate && speedDial.size < 8) {
                            AddSpeedDialTile(
                                modifier = Modifier.width(tileWidth),
                                index = speedDial.size,
                                isDark = isDark,
                                onClick = { addingShortcut = true }
                            )
                        }
                    }
                }
            }

            Column {
                SectionLabel(stringResource(R.string.recently_visited))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = cs.surface,
                    border = BorderStroke(0.5.dp, cs.outlineVariant)
                ) {
                    if (uniqueRecent.isEmpty()) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Outlined.History,
                                contentDescription = null,
                                tint = cs.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = stringResource(if (isPrivate) R.string.space_has_no_recent_sites else R.string.no_recently_visited),
                                color = cs.onSurfaceVariant,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }
                    } else {
                        Column {
                            uniqueRecent.take(5).forEachIndexed { index, entry ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 56.dp)
                                        .clickable { onRecent(entry.url) }
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val accent = SPEED_DIAL_PALETTE[index % SPEED_DIAL_PALETTE.size].forMode(isDark)
                                    Box(
                                        Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(accent.background),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            monogramOf(entry.title.ifBlank { siteLabelOf(entry.url) }),
                                            color = accent.foreground,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            text = entry.title.ifBlank { siteLabelOf(entry.url) },
                                            fontSize = 14.sp,
                                            lineHeight = 19.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = cs.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = siteLabelOf(entry.url),
                                            fontSize = 12.sp,
                                            lineHeight = 16.sp,
                                            color = cs.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Icon(
                                        Icons.Outlined.ChevronRight,
                                        contentDescription = null,
                                        tint = cs.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                if (index < minOf(uniqueRecent.size, 5) - 1) {
                                    HorizontalDivider(
                                        modifier = Modifier.padding(start = 62.dp, end = 14.dp),
                                        thickness = 0.5.dp,
                                        color = cs.outlineVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        BottomNav(
            canBack = false,
            canForward = false,
            onBack = {},
            onForward = {},
            onHome = {},
            onTabs = onTabs,
            tabCount = tabCount,
            onMenu = onMenu
        )
    }

    if (addingShortcut || editingShortcut != null) {
        val original = editingShortcut
        var label by remember(original, addingShortcut) { mutableStateOf(original?.label.orEmpty()) }
        var url by remember(original, addingShortcut) { mutableStateOf(original?.url.orEmpty()) }
        var validationError by remember(original, addingShortcut) { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { addingShortcut = false; editingShortcut = null },
            containerColor = cs.surface,
            title = { Text(stringResource(if (original == null) R.string.add_shortcut else R.string.edit_shortcut)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = it.take(28); validationError = null },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text(stringResource(R.string.name)) }
                    )
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it; validationError = null },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        isError = validationError != null,
                        label = { Text(stringResource(R.string.website_url)) },
                        placeholder = { Text("https://example.com") }
                    )
                    validationError?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
                    Text(stringResource(R.string.long_press_shortcut), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val trimmedUrl = url.trim()
                    val candidate = if (trimmedUrl.contains("://")) trimmedUrl else "https://$trimmedUrl"
                    when {
                        label.isBlank() -> validationError = "Enter a name for this shortcut."
                        !com.dhyra.browser.core.nav.DhyraNavigationManager.isHttpUrl(candidate) -> validationError = "Enter a valid HTTP or HTTPS website URL."
                        speedDial.any { it.url.equals(candidate, ignoreCase = true) && it.url != original?.url } -> validationError = "That website is already in your speed dial."
                        else -> {
                            onSaveShortcut(original, Shortcut(label.trim(), candidate))
                            addingShortcut = false
                            editingShortcut = null
                        }
                    }
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = {
                Row {
                    if (original != null) TextButton(onClick = {
                        onRemoveSite(original)
                        editingShortcut = null
                    }) { Text(stringResource(R.string.remove), color = cs.error) }
                    TextButton(onClick = { addingShortcut = false; editingShortcut = null }) { Text(stringResource(R.string.cancel)) }
                }
            }
        )
    }
}

private data class SpeedDialSwatch(val background: Color, val foreground: Color) {
    fun forMode(dark: Boolean): SpeedDialSwatch = if (!dark) this else when (this) {
        SPEED_DIAL_PALETTE[0] -> SpeedDialSwatch(Color(0xFF21364B), Color(0xFFD8EAFB))
        SPEED_DIAL_PALETTE[1] -> SpeedDialSwatch(Color(0xFF432D29), Color(0xFFF6D5CA))
        SPEED_DIAL_PALETTE[2] -> SpeedDialSwatch(Color(0xFF34342F), Color(0xFFE7E4D9))
        SPEED_DIAL_PALETTE[3] -> SpeedDialSwatch(Color(0xFF302C54), Color(0xFFE1DEFF))
        SPEED_DIAL_PALETTE[4] -> SpeedDialSwatch(Color(0xFF1E4038), Color(0xFFCBEFE2))
        else -> SpeedDialSwatch(Color(0xFF472D39), Color(0xFFF5D3DF))
    }
}

private val SPEED_DIAL_PALETTE = listOf(
    SpeedDialSwatch(Color(0xFFE6F1FB), Color(0xFF0C447C)),
    SpeedDialSwatch(Color(0xFFFAECE7), Color(0xFF712B13)),
    SpeedDialSwatch(Color(0xFFF1EFE8), Color(0xFF444441)),
    SpeedDialSwatch(Color(0xFFEEEDFE), Color(0xFF3C3489)),
    SpeedDialSwatch(Color(0xFFE1F5EE), Color(0xFF085041)),
    SpeedDialSwatch(Color(0xFFFBEAF0), Color(0xFF72243E))
)

@Composable
private fun AddSpeedDialTile(modifier: Modifier, index: Int, isDark: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val swatch = SPEED_DIAL_PALETTE[index % SPEED_DIAL_PALETTE.size].forMode(isDark)
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(swatch.background),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.Add, contentDescription = stringResource(R.string.add_website_shortcut), tint = swatch.foreground)
        }
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.add), fontSize = 12.sp, lineHeight = 17.sp, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun SpeedDialTile(
    site: Shortcut,
    index: Int,
    isDark: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val swatch = SPEED_DIAL_PALETTE[index % SPEED_DIAL_PALETTE.size].forMode(isDark)
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(swatch.background),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = monogramOf(site.label),
                fontSize = 22.sp,
                lineHeight = 28.sp,
                fontWeight = FontWeight.Medium,
                color = swatch.foreground
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = site.label,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            color = cs.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

private fun dedupeRecentByDomain(entries: List<SavedPage>): List<SavedPage> {
    val seen = HashSet<String>()
    return entries.filter { entry ->
        val host = runCatching { Uri.parse(entry.url).host }
            .getOrNull()
            ?.lowercase(Locale.ROOT)
            ?.trimEnd('.')
        val normalizedHost = host?.let {
            var value = it
            listOf("www.", "m.", "mobile.").forEach { prefix ->
                if (value.startsWith(prefix)) value = value.removePrefix(prefix)
            }
            value
        }
        val key = normalizedHost?.takeIf { it.isNotBlank() }
            ?: entry.url.trim().lowercase(Locale.ROOT)
        seen.add(key)
    }
}

@Composable
internal fun SectionLabel(text: String) {
    Text(
        text = text,
        modifier = Modifier.padding(bottom = 8.dp),
        fontSize = 13.sp,
        lineHeight = 18.sp,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
