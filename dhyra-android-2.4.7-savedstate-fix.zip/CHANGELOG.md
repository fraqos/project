# Changelog

## 2.4.7 — Compose saved-state compile fix

- Fixed the Kotlin compilation error caused by referencing `savedInstanceState` inside the top-level `DhyraApplication()` composable.
- `MainActivity.onCreate()` now passes `isColdLaunch = savedInstanceState == null` into the Compose root; the startup reveal uses that explicit parameter.
- Added source-contract regression checks for Activity-to-Compose saved-state flow and absence of out-of-scope Bundle references.
- CI now runs `:app:compileDebugKotlin` as a dedicated step before unit tests, lint and APK assembly.
- Updated to versionCode 25 / versionName 2.4.7.

## 2.4.6 — homepage, Settings, language and transparent branding

- Rebuilt homepage as a minimal native Compose surface: search/address, speed dial and recently visited only.
- Removed weather/news homepage cards and the associated feed repository.
- Added six rotating flat speed-dial color pairs, dark variants, 54dp tiles and host-based recent-visit deduplication.
- Added three explicit theme choices: Light, Dark and System default, applied via AppCompatDelegate.
- Added searchable app-language choices: System default, English and Bahasa Indonesia. Added locale configuration and resource catalogues; native Compose text and Toasts use the active app locale.
- Replaced logo image assets with the user-provided D/globe/orbit mark on transparent canvases. Reduced adaptive icon/splash occupancy and added a monochrome launcher layer.
- Aligned Settings sections, row touch targets, outlined icons, card borders and accent `#7F77DD`.
- Updated to versionCode 24 / versionName 2.4.6.
- Updated CI to generate Gradle Wrapper in the actual Android project root and accept any source ZIP filename.

## 2.4.5 and earlier

See repository history for previous browser engine, tab management, translation, download and security changes.
