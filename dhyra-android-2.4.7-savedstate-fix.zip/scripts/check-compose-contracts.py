#!/usr/bin/env python3
"""Source-contract checks for dhyra 2.4.7 Kotlin fix, UI, locale, branding and CI integration."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    file = ROOT / path
    if not file.is_file():
        raise SystemExit(f"Required source file is missing: {path}")
    return file.read_text(encoding="utf-8")

main = read("app/src/main/java/com/dhyra/browser/MainActivity.kt")
models = read("app/src/main/java/com/dhyra/browser/UiModels.kt")
home = read("app/src/main/java/com/dhyra/browser/ui/screens/HomeUi.kt")
settings = read("app/src/main/java/com/dhyra/browser/ui/screens/ScreensUi.kt")
settings_manager = read("app/src/main/java/com/dhyra/browser/core/settings/DhyraSettingsManager.kt")
theme = read("app/src/main/java/com/dhyra/browser/ui/theme/Theme.kt")
webview_policy = read("app/src/main/java/com/dhyra/browser/core/engine/DhyraWebViewController.kt")
controller = read("app/src/main/java/com/dhyra/browser/BrowserController.kt")
mark = read("app/src/main/java/com/dhyra/browser/ui/components/DhyraMark.kt")
build = read("app/build.gradle.kts")
manifest = read("app/src/main/AndroidManifest.xml")
workflow = read(".github/workflows/build.yml")
strings_en = read("app/src/main/res/values-en/strings.xml")
strings_default = read("app/src/main/res/values/strings.xml")
strings_id = read("app/src/main/res/values-id/strings.xml")
locale_config = read("app/src/main/res/xml/locales_config.xml")
localized_text = read("app/src/main/java/com/dhyra/browser/ui/localization/LocalizedUiText.kt")
resolver_tests = read("app/src/test/java/com/dhyra/browser/BrowserAddressResolverTest.kt")

def xml(path: str):
    return ET.parse(ROOT / path).getroot()

checks = {
    "saved instance state is passed from Activity into Compose explicitly": (
        "val isColdLaunch = savedInstanceState == null" in main
        and "DhyraApplication(isColdLaunch = isColdLaunch)" in main
        and "private fun DhyraApplication(isColdLaunch: Boolean)" in main
        and "if (isColdLaunch)" in main
    ),
    "Composable body does not reference Activity savedInstanceState out of scope": (
        "if (savedInstanceState == null)" not in main
        and main.count("savedInstanceState") == 3
    ),
    "theme unit tests assert the current Light Dark and System default values": all(
        value in resolver_tests for value in (
            'normalizeTheme(null) == "System default"',
            'normalizeTheme("System") == "System default"',
            'normalizeTheme("Light") == "Light"',
            'normalizeTheme("Dark") == "Dark"',
        )
    ),
    "obsolete homepage RSS repository is not referenced by JVM tests": "HomeFeedRepository" not in resolver_tests,
    "homepage is native Compose and contains the three expected sections": all(
        item in home for item in ("R.string.search_or_enter_address", "R.string.speed_dial", "R.string.recently_visited")
    ),
    "weather/news UI and feed service have been removed": (
        "weather" not in home.lower() and "news" not in home.lower()
        and not (ROOT / "app/src/main/java/com/dhyra/browser/core/home/HomeFeedRepository.kt").exists()
        and "HomeFeedRepository" not in main
    ),
    "recently visited deduplicates by normalized domain": all(
        value in home for value in ("dedupeRecentByDomain(recent)", "Uri.parse(entry.url).host", "www.", "removePrefix(prefix)")
    ),
    "recently visited is rendered in one single bordered card with row dividers": all(
        value in home for value in ("RoundedCornerShape(12.dp)", "BorderStroke(0.5.dp", "HorizontalDivider(", "uniqueRecent.take(5)")
    ),
    "six speed dial colors and labels are flat and rotated sequentially": all(
        value in home for value in (
            "0xFFE6F1FB", "0xFF0C447C", "0xFFFAECE7", "0xFF712B13",
            "0xFFF1EFE8", "0xFF444441", "0xFFEEEDFE", "0xFF3C3489",
            "0xFFE1F5EE", "0xFF085041", "0xFFFBEAF0", "0xFF72243E",
            "SPEED_DIAL_PALETTE[index % SPEED_DIAL_PALETTE.size]", ".size(54.dp)"
        )
    ),
    "speed dial dark colors use a separate high-contrast variant": "fun forMode(dark: Boolean)" in home and "Color(0xFF21364B)" in home,
    "homepage vertical rhythm and horizontal margins are 16/24dp": "padding(horizontal = 16.dp)" in home and "Arrangement.spacedBy(24.dp)" in home,
    "theme selector contains only Light, Dark and System default": 'THEME_OPTIONS = listOf("Light", "Dark", "System default")' in models,
    "theme normalization migrates previous System and AMOLED values": all(
        value in settings_manager for value in ('"Light" -> "Light"', '"Dark", "AMOLED" -> "Dark"', '"System", "System default"')
    ),
    "native theme invokes AppCompatDelegate for all three choices": all(
        value in main for value in ("AppCompatDelegate.setDefaultNightMode", "MODE_NIGHT_NO", "MODE_NIGHT_YES", "MODE_NIGHT_FOLLOW_SYSTEM")
    ),
    "Compose theme uses explicit Light Dark and system fallback": '"Light" -> false' in theme and '"Dark" -> true' in theme and 'isSystemInDarkTheme()' in theme,
    "Settings app language picker offers system English and Indonesian with search": all(
        value in settings for value in ("AppLanguageDialog", '"system" to stringResource', '"en" to stringResource', '"id" to stringResource', "R.string.search_languages")
    ),
    "application locale is set and auto-persisted via AppCompatDelegate": all(
        value in main for value in ("AppCompatDelegate.setApplicationLocales", "LocaleListCompat.forLanguageTags", 'key == "app_language"')
    ),
    "AppCompatActivity uses the backward-compatible locale storage service": "AppCompatActivity" in main and "AppLocalesMetadataHolderService" in manifest and "autoStoreLocales" in manifest,
    "supported language configuration is explicit": 'android:localeConfig="@xml/locales_config"' in manifest and '<locale android:name="en"' in locale_config and '<locale android:name="id"' in locale_config,
    "English and Indonesian string resource files are present": 'name="search_or_enter_address"' in strings_en and 'name="search_or_enter_address"' in strings_id and 'name="settings"' in strings_id and 'name="app_name">dhyra<' in strings_default,
    "Compose Text surfaces resolve localized Android resources": "localizeUiText(text)" in read("app/src/main/java/com/dhyra/browser/LocalizedText.kt") and "localizeUiText(text)" in read("app/src/main/java/com/dhyra/browser/ui/screens/LocalizedText.kt") and "localizeUiText(text)" in read("app/src/main/java/com/dhyra/browser/ui/components/LocalizedText.kt") and "localizePlainUiText" in main,
    "all private-mode user-facing labels keep space lowercase": not re.search(r'"[^"\\n]*\\b(?:SPACE|Space)\\b[^"\\n]*"', main + settings + home + read("app/src/main/java/com/dhyra/browser/ui/screens/TabsUi.kt") + read("app/src/main/java/com/dhyra/browser/ui/components/SheetsUi.kt")),
    "Settings sections are grouped into subtle cards": all(
        value in settings for value in ("private fun SettingsGroup", "RoundedCornerShape(12.dp)", "BorderStroke(0.5.dp", "padding(top = 24.dp")
    ),
    "Settings uses one outline icon style and unified violet accent": all(
        value in settings for value in ("Icons.Outlined.Download", "Icons.Outlined.Search", "SettingsAccent = Color(0xFF7F77DD)", "tint = SettingsAccent")
    ),
    "Download manager row has no sticky pressed/selected indication": "indication = null" in settings and "MutableInteractionSource()" in settings,
    "theme is in General and language is a searchable Languages dialog": 'SettingRow(Icons.Outlined.Brightness6, "Theme"' in settings and "AppLanguageDialog(" in settings and 'SettingsGroup("Languages"' in settings,
    "logo is loaded from transparent PNG for startup": "dhyra_brand_art_transparent" in mark and "DhyraMark(size = 64.dp)" in main,
    "launcher art is transparent and density-aware": all(
        (ROOT / f"app/src/main/res/drawable-{density}/dhyra_launcher_foreground.png").is_file()
        for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi")
    ) and "<monochrome android:drawable=\"@drawable/dhyra_launcher_monochrome\"" in read("app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml"),
    "splash art is transparent and density-aware in day and night resources": all(
        (ROOT / f"app/src/main/res/drawable-{density}/dhyra_splash_logo.png").is_file()
        for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi")
    ) and all("@drawable/dhyra_splash_logo" in read(f"app/src/main/res/{folder}/styles.xml") for folder in ("values-v31", "values-night-v31")),
    "app uses the user logo as canonical About artwork": "dhyra_brand_art_transparent" in settings and "ContentScale.Fit" in settings,
    "one violet value is shared by native theme and Android resources": "BrandViolet = Color(0xFF7F77DD)" in theme and "#7F77DD" in read("app/src/main/res/values/colors.xml") and "#7F77DD" in read("app/src/main/res/values-night/colors.xml"),
    "WebView uses normal cache and disables deprecated Web SQL Database": "cacheMode = if (isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT" in webview_policy and "databaseEnabled = false" in webview_policy and "domStorageEnabled = true" in webview_policy,
    "inactive WebView tabs receive onPause and selected tab resumes": "webViews[previousId]?.onPause()" in controller and "selected?.onResume()" in controller,
    "activity hardware acceleration remains enabled": 'android:hardwareAccelerated="true"' in manifest,
    "app version and build artifact are synchronized": 'versionName = "2.4.7"' in build and 'versionCode = 25' in build and "dhyra-v2.4.7.apk" in workflow,
    "release version omits debug suffix and shrinker remains enabled": 'versionNameSuffix = ""' in build and 'versionNameSuffix = "-debug"' in build and 'isMinifyEnabled = true' in build and 'isShrinkResources = true' in build,
    "Gradle wrapper is generated in real extracted project root": "Generate and verify Gradle Wrapper in the real dhyra project" in workflow and "gradle --no-daemon --stacktrace wrapper" in workflow and "TEMP_WRAPPER_DIR" not in workflow,
    "workflow accepts arbitrary source ZIP names and manual dispatch": "'*.zip'" in workflow and "'**/*.zip'" in workflow and "workflow_dispatch:" in workflow,
    "workflow extracts ZIP safely and finds Android root": all(
        value in workflow for value in ("zipfile.ZipFile", "archive_has_android_root", "AndroidManifest.xml", "Unsafe ZIP entry")
    ),
    "CI explicitly compiles Kotlin before tests lint and APK": all(task in workflow for task in (":app:compileDebugKotlin", "testDebugUnitTest", "lintDebug", "assembleDebug")),
    "workflow uploads APK source archive and checksums": all(
        value in workflow for value in ("dhyra-source.zip", "SHA256SUMS.txt", "actions/upload-artifact@v7.0.2", "if-no-files-found: error")
    ),
    "release signing remains opt-in and secret-backed": all(
        value in workflow for value in ("DHYRA_RELEASE_KEYSTORE_BASE64", "DHYRA_RELEASE_STORE_PASSWORD", "DHYRA_RELEASE_KEY_ALIAS", "DHYRA_RELEASE_KEY_PASSWORD")
    ) and "DHYRA_RELEASE_STORE_FILE" in build,
}

# Verify XML documents parse, plus the theme/splash resources refer to existing colors.
xml_files = [
    "app/src/main/AndroidManifest.xml",
    "app/src/main/res/values/strings.xml",
    "app/src/main/res/values-en/strings.xml",
    "app/src/main/res/values-id/strings.xml",
    "app/src/main/res/values-en/strings.xml",
    "app/src/main/res/xml/locales_config.xml",
    "app/src/main/res/values/styles.xml",
    "app/src/main/res/values-night/styles.xml",
    "app/src/main/res/values-v31/styles.xml",
    "app/src/main/res/values-night-v31/styles.xml",
    "app/src/main/res/values-v27/styles.xml",
    "app/src/main/res/values-v28/styles.xml",
    "app/src/main/res/values-night-v27/styles.xml",
    "app/src/main/res/values-night-v28/styles.xml",
]
for path in xml_files:
    try:
        xml(path)
        checks[f"XML parses: {path}"] = True
    except ET.ParseError as error:
        checks[f"XML parses: {path}"] = False
        print(f"XML parse error in {path}: {error}", file=sys.stderr)

# Keep the same resource keys in the shipped English and Indonesian catalogues.
try:
    resource_sets = []
    for folder in ("values", "values-en", "values-id"):
        resource_sets.append({item.attrib["name"] for item in xml(f"app/src/main/res/{folder}/strings.xml").findall("string")})
    checks["string resource key parity across default/en/id"] = resource_sets[0] == resource_sets[1] == resource_sets[2]
except (KeyError, ET.ParseError):
    checks["string resource key parity across default/en/id"] = False

# PNG color type 6 is RGBA, so the outer image canvas really is transparent.
for relative in (
    "app/src/main/res/drawable-nodpi/dhyra_brand_art_transparent.png",
    "app/src/main/res/drawable-nodpi/dhyra_launcher_monochrome.png",
    "app/src/main/res/drawable-xxxhdpi/dhyra_launcher_foreground.png",
    "app/src/main/res/drawable-xxxhdpi/dhyra_splash_logo.png",
):
    file = ROOT / relative
    data = file.read_bytes() if file.is_file() else b""
    checks[f"transparent PNG asset: {relative}"] = len(data) > 32 and data[:8] == b"\x89PNG\r\n\x1a\n" and data[25] == 6

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(("PASS" if passed else "FAIL") + ": " + name)
if failed:
    print("Source contract validation failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
print(f"All {len(checks)} source contract checks passed.")
