package com.dhyra.browser

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.lifecycleScope
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.net.URLEncoder

private val android.content.Context.dataStore by preferencesDataStore(name = "dhyra_settings")
private const val BTC = "bc1qrdlrhldck8pz6mtcaths86htz3g3hjyhsa44q5"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DhyraApp() }
    }
}

private enum class Screen { BROWSER, SETTINGS, SUPPORT, ABOUT }

@Composable
private fun DhyraApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs by context.dataStore.data.map { p ->
        BrowserPrefs(
            homepage = p[stringPreferencesKey("homepage")] ?: "https://www.google.com",
            engine = p[stringPreferencesKey("search_engine")] ?: "Google",
            theme = p[stringPreferencesKey("theme")] ?: "System",
            transparency = p[floatPreferencesKey("glass_transparency")] ?: 0.75f,
            tracking = p[booleanPreferencesKey("tracking_protection")] ?: true,
            popup = p[booleanPreferencesKey("popup_blocker")] ?: true,
            desktop = p[booleanPreferencesKey("desktop_mode")] ?: false
        )
    }.collectAsState(initial = BrowserPrefs())

    var screen by remember { mutableStateOf(Screen.BROWSER) }
    var address by remember { mutableStateOf(prefs.homepage) }
    var currentUrl by remember { mutableStateOf(prefs.homepage) }
    var pageTitle by remember { mutableStateOf("DHYRA BROWSER") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var pageLoading by remember { mutableStateOf(false) }
    var reloadKey by remember { mutableIntStateOf(0) }
    var showMenu by remember { mutableStateOf(false) }
    var showFind by remember { mutableStateOf(false) }
    var findText by remember { mutableStateOf("") }
    var dark by remember { mutableStateOf(false) }

    LaunchedEffect(prefs.theme) {
        dark = when (prefs.theme) {
            "Dark" -> true
            "Light" -> false
            else -> false
        }
    }
    LaunchedEffect(prefs.homepage) {
        if (currentUrl.isBlank()) { address = prefs.homepage; currentUrl = prefs.homepage }
    }

    BackHandler(enabled = screen != Screen.BROWSER || (webViewRef?.canGoBack() == true)) {
        if (screen != Screen.BROWSER) screen = Screen.BROWSER else webViewRef?.goBack()
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFF82A5FF), background = Color(0xFF10131B), surface = Color(0xFF191E29))
                  else lightColorScheme(primary = Color(0xFF4169E1), background = Color(0xFFF4F6FB), surface = Color.White)) {
        Surface(Modifier.fillMaxSize()) {
            when (screen) {
                Screen.BROWSER -> Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = address, onValueChange = { address = it }, modifier = Modifier.weight(1f),
                            singleLine = true, placeholder = { Text("Cari atau masukkan alamat") },
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                            keyboardActions = KeyboardActions(onGo = { currentUrl = normalize(address, prefs.engine); address = currentUrl; reloadKey++ })
                        )
                        IconButton(onClick = { currentUrl = normalize(address, prefs.engine); address = currentUrl; reloadKey++ }) { Icon(Icons.Default.Search, "Go") }
                        Box {
                            IconButton(onClick = { showMenu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                            DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                                DropdownMenuItem(text = { Text("Settings") }, onClick = { showMenu = false; screen = Screen.SETTINGS })
                                DropdownMenuItem(text = { Text("Support DHYRA") }, onClick = { showMenu = false; screen = Screen.SUPPORT })
                                DropdownMenuItem(text = { Text("About") }, onClick = { showMenu = false; screen = Screen.ABOUT })
                                DropdownMenuItem(text = { Text("Find in page") }, onClick = { showMenu = false; showFind = true })
                                DropdownMenuItem(text = { Text("Share page") }, onClick = {
                                    showMenu = false
                                    runCatching {
                                        context.startActivity(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, currentUrl).let { Intent.createChooser(it, "Share page") })
                                    }
                                })
                            }
                        }
                    }
                    if (showFind) Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(findText, { findText = it; webViewRef?.findAllAsync(it) }, Modifier.weight(1f), singleLine = true, label = { Text("Find") })
                        IconButton(onClick = { showFind = false; webViewRef?.clearMatches() }) { Icon(Icons.Default.Close, "Close") }
                    }
                    if (pageLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    key(reloadKey) {
                        AndroidView(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = true
                                    settings.javaScriptCanOpenWindowsAutomatically = !prefs.popup
                                    settings.setSupportMultipleWindows(!prefs.popup)
                                    settings.userAgentString = if (prefs.desktop) settings.userAgentString.replace("Mobile", "X11") else settings.userAgentString
                                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, !prefs.tracking)
                                    webViewClient = object : WebViewClient() {
                                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                            pageLoading = true
                                            if (url != null) { currentUrl = url; address = url }
                                        }
                                        override fun onPageFinished(view: WebView?, url: String?) {
                                            pageLoading = false
                                            pageTitle = view?.title ?: "DHYRA BROWSER"
                                            if (url != null) { currentUrl = url; address = url }
                                        }
                                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                            val u = request?.url ?: return false
                                            if (u.scheme !in listOf("http", "https")) {
                                                runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, u)) }
                                                return true
                                            }
                                            return false
                                        }
                                    }
                                    webChromeClient = WebChromeClient()
                                    setDownloadListener(DownloadListener { url, userAgent, disposition, mime, _ ->
                                        val req = android.app.DownloadManager.Request(Uri.parse(url))
                                            .setTitle(disposition.ifBlank { "Download" })
                                            .setMimeType(mime)
                                            .addRequestHeader("User-Agent", userAgent)
                                            .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                        runCatching {
                                            val dm = ctx.getSystemService(android.content.Context.DOWNLOAD_SERVICE) as android.app.DownloadManager
                                            dm.enqueue(req)
                                            Toast.makeText(ctx, "Download dimulai", Toast.LENGTH_SHORT).show()
                                        }.onFailure { Toast.makeText(ctx, "Download gagal dimulai", Toast.LENGTH_SHORT).show() }
                                    })
                                    loadUrl(currentUrl)
                                }
                            },
                            update = { webViewRef = it }
                        )
                    }
                    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        IconButton(onClick = { webViewRef?.goBack() }) { Icon(Icons.Default.ArrowBack, "Back") }
                        IconButton(onClick = { webViewRef?.goForward() }) { Icon(Icons.Default.ArrowForward, "Forward") }
                        IconButton(onClick = { webViewRef?.reload() }) { Icon(Icons.Default.Refresh, "Refresh") }
                        IconButton(onClick = { currentUrl = prefs.homepage; address = currentUrl; reloadKey++ }) { Icon(Icons.Default.Home, "Home") }
                        IconButton(onClick = { screen = Screen.SETTINGS }) { Icon(Icons.Default.Settings, "Settings") }
                    }
                }
                Screen.SETTINGS -> SettingsPage(prefs, onBack = { screen = Screen.BROWSER }, onSave = { key, value ->
                    scope.launch { context.dataStore.edit { p ->
                        when (key) {
                            "homepage" -> p[stringPreferencesKey(key)] = value as String
                            "search_engine" -> p[stringPreferencesKey(key)] = value as String
                            "theme" -> p[stringPreferencesKey(key)] = value as String
                            "glass_transparency" -> p[floatPreferencesKey(key)] = value as Float
                            "tracking_protection" -> p[booleanPreferencesKey(key)] = value as Boolean
                            "popup_blocker" -> p[booleanPreferencesKey(key)] = value as Boolean
                            "desktop_mode" -> p[booleanPreferencesKey(key)] = value as Boolean
                        }
                    } }
                }, onClear = {
                    webViewRef?.clearCache(true); webViewRef?.clearHistory()
                    CookieManager.getInstance().removeAllCookies(null)
                    android.webkit.WebStorage.getInstance().deleteAllData()
                    Toast.makeText(context, "Data penjelajahan dibersihkan", Toast.LENGTH_SHORT).show()
                })
                Screen.SUPPORT -> SupportPage(onBack = { screen = Screen.BROWSER })
                Screen.ABOUT -> SimplePage("About DHYRA BROWSER", "Browser Android dengan antarmuka sederhana dan kontrol privasi.", onBack = { screen = Screen.BROWSER })
            }
        }
    }
}

private data class BrowserPrefs(
    val homepage: String = "https://www.google.com",
    val engine: String = "Google",
    val theme: String = "System",
    val transparency: Float = 0.75f,
    val tracking: Boolean = true,
    val popup: Boolean = true,
    val desktop: Boolean = false
)

private fun normalize(input: String, engine: String): String {
    val value = input.trim()
    if (value.isBlank()) return "https://www.google.com"
    if (value.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))) return value
    if (value.contains(".") && !value.contains(" ")) return "https://$value"
    val base = when (engine) {
        "Bing" -> "https://www.bing.com/search?q="
        "DuckDuckGo" -> "https://duckduckgo.com/?q="
        "Brave" -> "https://search.brave.com/search?q="
        else -> "https://www.google.com/search?q="
    }
    return base + URLEncoder.encode(value, "UTF-8")
}

@Composable
private fun SettingsPage(p: BrowserPrefs, onBack: () -> Unit, onSave: (String, Any) -> Unit, onClear: () -> Unit) {
    var home by remember(p.homepage) { mutableStateOf(p.homepage) }
    var engine by remember(p.engine) { mutableStateOf(p.engine) }
    var theme by remember(p.theme) { mutableStateOf(p.theme) }
    var transparency by remember(p.transparency) { mutableFloatStateOf(p.transparency) }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { TextButton(onClick = onBack) { Text("← Kembali") }; Text("Settings Center", style = MaterialTheme.typography.headlineSmall) }
        item {
            Text("Appearance", style = MaterialTheme.typography.titleMedium)
            Text("Theme")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Light", "Dark", "System").forEach { item -> FilterChip(selected = theme == item, onClick = { theme = item; onSave("theme", item) }, label = { Text(item) }) }
            }
            Text("Glass transparency: ${(transparency * 100).toInt()}%")
            Slider(value = transparency, onValueChange = { transparency = it }, valueRange = 0.2f..1f, onValueChangeFinished = { onSave("glass_transparency", transparency) })
        }
        item {
            Text("Search", style = MaterialTheme.typography.titleMedium)
            Text("Search engine")
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }) { Text(engine) }
                DropdownMenu(expanded, { expanded = false }) {
                    listOf("Google", "Bing", "DuckDuckGo", "Brave").forEach { e -> DropdownMenuItem(text = { Text(e) }, onClick = { engine = e; expanded = false; onSave("search_engine", e) }) }
                }
            }
            OutlinedTextField(home, { home = it }, Modifier.fillMaxWidth(), label = { Text("Homepage URL") }, singleLine = true)
            Button(onClick = { onSave("homepage", if (home.startsWith("http")) home else "https://$home") }) { Text("Save homepage") }
        }
        item {
            Text("Privacy", style = MaterialTheme.typography.titleMedium)
            SettingSwitch("Tracking protection (basic third-party cookie restriction)", p.tracking) { onSave("tracking_protection", it) }
            SettingSwitch("Popup blocker", p.popup) { onSave("popup_blocker", it) }
            SettingSwitch("Desktop mode", p.desktop) { onSave("desktop_mode", it) }
            OutlinedButton(onClick = onClear) { Text("Clear browsing data") }
        }
    }
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

@Composable
private fun SupportPage(onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val bitmap = remember { makeQr("bitcoin:$BTC") }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth()) { TextButton(onClick = onBack) { Text("← Kembali") } }
        Text("Support DHYRA BROWSER", style = MaterialTheme.typography.headlineSmall)
        Text("Dukungan sukarela melalui Bitcoin")
        Image(bitmap.asImageBitmap(), null, Modifier.size(230.dp))
        Text(BTC, style = MaterialTheme.typography.bodySmall)
        Button(onClick = { clipboard.setText(AnnotatedString(BTC)); Toast.makeText(context, "Alamat disalin", Toast.LENGTH_SHORT).show() }) { Text("Copy Bitcoin address") }
        OutlinedButton(onClick = {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("bitcoin:$BTC"))
            runCatching { context.startActivity(intent) }.onFailure { Toast.makeText(context, "Wallet Bitcoin tidak ditemukan", Toast.LENGTH_SHORT).show() }
        }) { Text("Open Bitcoin wallet") }
        Text("Periksa alamat dan jaringan sebelum mengirim.")
    }
}

private fun makeQr(payload: String): Bitmap {
    val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 640, 640)
    return Bitmap.createBitmap(640, 640, Bitmap.Config.ARGB_8888).also { b ->
        for (x in 0 until 640) for (y in 0 until 640) b.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    }
}

@Composable
private fun SimplePage(title: String, body: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("← Kembali") }
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Text(body)
        Text("DHYRA BROWSER • 1.0.0")
    }
}
