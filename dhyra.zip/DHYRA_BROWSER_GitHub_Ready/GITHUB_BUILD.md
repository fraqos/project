# Cara build APK lewat GitHub Actions

1. Buat repository GitHub baru (mis. `dhyra-browser`).
2. Upload seluruh isi folder project ini ke root repository, termasuk folder `.github`.
3. Pastikan branch bernama `main`.
4. Buka tab **Actions**. Jika diminta, aktifkan workflow.
5. Pilih **Build DHYRA BROWSER APK** lalu klik **Run workflow**. Workflow juga berjalan otomatis setiap push ke `main`.
6. Setelah status hijau, buka run yang selesai, lalu unduh artifact **DHYRA-BROWSER-debug-apk**.

APK yang dihasilkan adalah debug APK untuk pengujian/instalasi. Untuk rilis publik, perlu konfigurasi signing release tersendiri.

Catatan: source ini adalah rekonstruksi project mandiri yang berisi browser WebView, Settings, DataStore, pilihan tema/search engine, kontrol privasi dasar, download manager, dan halaman dukungan Bitcoin. Build belum dijalankan di lingkungan ini; jika GitHub menemukan error kompilasi, kirim log Actions agar dapat diperbaiki.
