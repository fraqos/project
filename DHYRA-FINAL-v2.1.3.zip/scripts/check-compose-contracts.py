#!/usr/bin/env python3
"""Static regression checks for Compose Material 3 and Kotlin visibility APIs."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sheet_path = ROOT / "app/src/main/java/com/dhyra/browser/ui/components/TranslationSheet.kt"
controller_path = ROOT / "app/src/main/java/com/dhyra/browser/BrowserController.kt"
models_path = ROOT / "app/src/main/java/com/dhyra/browser/UiModels.kt"
sheet = sheet_path.read_text(encoding="utf-8")
controller = controller_path.read_text(encoding="utf-8")
models = models_path.read_text(encoding="utf-8")

checks = {
    "Material3 ExposedDropdownMenu extension import":
        "import androidx.compose.material3.ExposedDropdownMenu\n" in sheet,
    "Material3 anchor type import":
        "import androidx.compose.material3.ExposedDropdownMenuAnchorType\n" in sheet,
    "Both read-only anchors declare PrimaryNotEditable":
        sheet.count("menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable)") == 2,
    "Both menus use the scope extension unqualified":
        len(re.findall(r"^\s*ExposedDropdownMenu\s*\(", sheet, flags=re.MULTILINE)) == 2,
    "No invalid fully-qualified top-level menu calls remain":
        "androidx.compose.material3.ExposedDropdownMenu(" not in sheet,
    "Dropdown menu calls remain inside TranslationSheet composable":
        "@Composable\ninternal fun TranslationSheet(" in sheet,
    "restoreSession is not a public API":
        re.search(r"^\s*internal fun restoreSession\(entries: List<SessionTab>\)", controller, re.MULTILINE) is not None
        and re.search(r"^\s*public?\s*fun restoreSession\(", controller, re.MULTILINE) is None,
    "SessionTab remains internal":
        re.search(r"^internal data class SessionTab\b", models, re.MULTILINE) is not None,
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(("PASS" if passed else "FAIL") + ": " + name)
if failed:
    print("Compose/Kotlin source contract validation failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
print(f"All {len(checks)} source contract checks passed.")
