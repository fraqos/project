package com.dhyra.browser.core.translation

import android.net.Uri
import android.webkit.WebView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Coordinates one page's translation lifecycle. One manager is created per live WebView tab. */
class TranslationManager(
    private val webView: WebView,
    private val bridge: TranslationBridge,
    private val translator: MLKitTranslator,
    private val scope: CoroutineScope,
    private val scriptProvider: () -> String,
    private val onStateChanged: (TranslationState) -> Unit
) {
    private val preparationMutex = Mutex()
    private val queue = TranslationQueue(
        scope = scope,
        translateText = { text, source, target -> translator.translate(text, source, target, wifiOnly) }
    )

    @Volatile private var active = false
    @Volatile private var paused = false
    @Volatile private var userPaused = false
    @Volatile private var tabInactive = false
    @Volatile private var hostPaused = false
    private var sourceLanguage = "auto"
    private var targetLanguage = "id"
    private var wifiOnly = true
    private var detectedSourceLanguage: String? = null
    private var pendingBatches = 0
    private var translatedSegments = 0
    private var failedSegments = 0
    private var scanComplete = false
    private var scanTruncated = false
    private var sessionToken = ""
    private var generation = 0L

    @Volatile var state: TranslationState = TranslationState()
        private set

    fun start(source: String, target: String, requireWifi: Boolean = true) {
        if (!isSecureHttpPage(webView.url)) {
            publish(
                TranslationState(
                    phase = TranslationPhase.ERROR,
                    sourceLanguage = source,
                    targetLanguage = target,
                    message = "Page translation requires an HTTPS website."
                )
            )
            return
        }
        if (source == target) {
            publish(TranslationState(phase = TranslationPhase.ERROR, message = "Choose different source and target languages."))
            return
        }

        generation += 1
        val runGeneration = generation
        sourceLanguage = source
        targetLanguage = target
        wifiOnly = requireWifi
        detectedSourceLanguage = null
        pendingBatches = 0
        translatedSegments = 0
        failedSegments = 0
        scanComplete = false
        scanTruncated = false
        sessionToken = UUID.randomUUID().toString().replace("-", "")
        val runSessionToken = sessionToken
        active = true
        userPaused = false
        paused = tabInactive || hostPaused
        queue.clearPending()
        if (paused) queue.pause() else queue.resume()
        bridge.setHandler(TranslationBridge.MessageHandler { message, reply ->
            handleBridgeMessage(message, runGeneration, runSessionToken, reply)
        })
        publish(
            TranslationState(
                phase = if (source == "auto") TranslationPhase.READY else TranslationPhase.DOWNLOADING_MODEL,
                sourceLanguage = source,
                targetLanguage = target,
                message = if (source == "auto") "Detecting the page language when text is available." else "Preparing the on-device language model…"
            )
        )

        scope.launch {
            try {
                if (source != "auto") translator.prepare(source, target, requireWifi)
                if (!isCurrent(runGeneration)) return@launch
                val sourceJs = JSONObject.quote(source)
                val targetJs = JSONObject.quote(target)
                val script = withContext(Dispatchers.IO) { scriptProvider() }
                val tokenJs = JSONObject.quote(runSessionToken)
                val command = "window.__DhyraPageTranslation && window.__DhyraPageTranslation.startTranslation($sourceJs,$targetJs,$tokenJs);"
                withContext(Dispatchers.Main.immediate) {
                    if (isCurrent(runGeneration)) {
                        webView.evaluateJavascript("$script\n$command", null)
                        if (paused) webView.evaluateJavascript("window.__DhyraPageTranslation?.pauseTranslation();", null)
                    }
                }
                if (source != "auto") publish(currentState(TranslationPhase.READY, "Translation is ready."))
            } catch (error: Exception) {
                if (isCurrent(runGeneration)) {
                    active = false
                    bridge.setHandler(null)
                    publish(currentState(TranslationPhase.ERROR, error.message ?: "Could not prepare the translation model."))
                }
            }
        }
    }

    /** User-requested pause survives tab switches and Activity lifecycle transitions. */
    fun pause() {
        userPaused = true
        reconcilePauseState("Translation paused by you.")
    }

    fun resume() {
        userPaused = false
        reconcilePauseState("Translation resumed.")
    }

    fun onTabInactive() {
        tabInactive = true
        reconcilePauseState("Translation paused while this tab is in the background.")
    }

    fun onTabActive() {
        tabInactive = false
        reconcilePauseState("Translation resumed for this tab.")
    }

    fun onHostPaused() {
        hostPaused = true
        reconcilePauseState("Translation paused while DHYRA is in the background.")
    }

    fun onHostResumed() {
        hostPaused = false
        reconcilePauseState("Translation resumed.")
    }

    private fun reconcilePauseState(message: String) {
        if (!active) return
        val shouldPause = userPaused || tabInactive || hostPaused
        if (paused == shouldPause) return
        paused = shouldPause
        if (shouldPause) {
            queue.pause()
            webView.evaluateJavascript("window.__DhyraPageTranslation?.pauseTranslation();", null)
            publish(currentState(TranslationPhase.PAUSED, message))
        } else {
            queue.resume()
            webView.evaluateJavascript("window.__DhyraPageTranslation?.resumeTranslation();", null)
            publish(currentState(if (pendingBatches > 0) TranslationPhase.TRANSLATING else TranslationPhase.READY, message))
        }
    }

    fun restoreOriginalText() {
        generation++ // Responses from already-running ML Kit Tasks are discarded.
        active = false
        paused = false
        userPaused = false
        queue.pause()
        queue.clearPending()
        bridge.setHandler(null)
        webView.evaluateJavascript("window.__DhyraPageTranslation?.restoreOriginalText();", null)
        detectedSourceLanguage = null
        pendingBatches = 0
        scanComplete = false
        scanTruncated = false
        sessionToken = ""
        publish(TranslationState(phase = TranslationPhase.IDLE, message = "Original page text restored."))
    }

    fun stopForNavigation() {
        generation++
        active = false
        paused = false
        userPaused = false
        queue.pause()
        queue.clearPending()
        bridge.setHandler(null)
        webView.evaluateJavascript("window.__DhyraPageTranslation?.destroyTranslationEngine();", null)
        pendingBatches = 0
        scanComplete = false
        scanTruncated = false
        sessionToken = ""
        publish(TranslationState())
    }

    fun destroy() {
        generation++
        active = false
        paused = false
        userPaused = false
        bridge.setHandler(null)
        queue.close()
        runCatching { webView.evaluateJavascript("window.__DhyraPageTranslation?.destroyTranslationEngine();", null) }
        bridge.remove()
        publish(TranslationState())
    }

    private fun handleBridgeMessage(
        message: TranslationBridgeMessage,
        requestGeneration: Long,
        expectedSessionToken: String,
        reply: (String) -> Unit
    ) {
        if (!isCurrent(requestGeneration) || message.sessionToken != expectedSessionToken) {
            val requestId = (message as? TranslationBridgeMessage.Batch)?.value?.requestId
            reply(errorResponse("Translation session is no longer active.", requestId))
            return
        }
        when (message) {
            is TranslationBridgeMessage.ScanComplete -> {
                scanComplete = true
                scanTruncated = message.truncated
                failedSegments = maxOf(failedSegments, message.failedSegments)
                val completionMessage = if (scanTruncated) {
                    "Page scan completed. Some content was skipped to protect memory and responsiveness."
                } else {
                    "Page scan completed."
                }
                publish(currentState(if (pendingBatches == 0) TranslationPhase.COMPLETED else TranslationPhase.TRANSLATING, completionMessage))
                reply(JSONObject().put("type", "ack").put("status", "complete").toString())
            }
            is TranslationBridgeMessage.Batch -> {
                val incoming = message.value
                if (incoming.targetLanguage != targetLanguage || incoming.sourceLanguage != sourceLanguage) {
                    reply(errorResponse("Translation language settings do not match the active session.", incoming.requestId))
                    return
                }
                pendingBatches++
                publish(currentState(TranslationPhase.TRANSLATING, "Translating page content…"))
                scope.launch {
                    try {
                        val resolvedSource = preparationMutex.withLock {
                            val detected = if (sourceLanguage == "auto") {
                                detectedSourceLanguage ?: translator.identifyLanguage(
                                    incoming.items.joinToString(" ") { it.text }.take(1_200)
                                )?.also { detectedSourceLanguage = it }
                            } else sourceLanguage
                            if (!detected.isNullOrBlank()) {
                                if (sourceLanguage == "auto") {
                                    publish(currentState(TranslationPhase.DOWNLOADING_MODEL, "Preparing ${detected.uppercase()} language model…"))
                                }
                                translator.prepare(detected, targetLanguage, wifiOnly)
                            }
                            detected
                        }

                        if (resolvedSource.isNullOrBlank()) {
                            pendingBatches = (pendingBatches - 1).coerceAtLeast(0)
                            reply(errorResponse("The page language could not be identified. Choose a source language manually.", incoming.requestId))
                            publish(currentState(if (scanComplete && pendingBatches == 0) TranslationPhase.COMPLETED else TranslationPhase.TRANSLATING, "Language not detected."))
                            return@launch
                        }
                        if (!isCurrent(requestGeneration)) return@launch
                        val batch = incoming.copy(sourceLanguage = resolvedSource)
                        val submitted = queue.submit(
                            batch,
                            isCurrent = { isCurrent(requestGeneration) }
                        ) { result ->
                            // Queue work is performed off the UI thread. Mutate manager/UI state
                            // only on the WebView thread and discard late results after navigation.
                            webView.post {
                                if (!isCurrent(requestGeneration)) return@post
                                pendingBatches = (pendingBatches - 1).coerceAtLeast(0)
                                translatedSegments += result.translations.size
                                failedSegments += result.failedIds.size
                                reply(result.toJson())
                                val phase = if (scanComplete && pendingBatches == 0) TranslationPhase.COMPLETED else TranslationPhase.TRANSLATING
                                publish(currentState(phase, if (phase == TranslationPhase.COMPLETED) "Page translation completed." else "Translating page content…"))
                            }
                        }
                        if (!submitted) {
                            pendingBatches = (pendingBatches - 1).coerceAtLeast(0)
                            reply(errorResponse(
                                "Translation queue is full. Please wait and try again.",
                                incoming.requestId,
                                retryable = true
                            ))
                            publish(currentState(TranslationPhase.ERROR, "Too much page content is queued. Please retry."))
                        }
                    } catch (error: Exception) {
                        if (!isCurrent(requestGeneration)) return@launch
                        pendingBatches = (pendingBatches - 1).coerceAtLeast(0)
                        reply(errorResponse(error.message ?: "Translation failed.", incoming.requestId))
                        publish(currentState(TranslationPhase.ERROR, error.message ?: "Translation failed."))
                    }
                }
            }
        }
    }

    private fun TranslationBatchResult.toJson(): String {
        val items = JSONArray()
        translations.forEach { (id, translated) ->
            items.put(JSONObject().put("id", id).put("text", translated))
        }
        val failed = JSONArray()
        failedIds.forEach(failed::put)
        return JSONObject()
            .put("type", "batch_result")
            .put("requestId", requestId)
            .put("batchId", batchId)
            .put("translations", items)
            .put("failedIds", failed)
            .put("error", error)
            .toString()
    }

    private fun currentState(phase: TranslationPhase, message: String?): TranslationState = TranslationState(
        phase = phase,
        sourceLanguage = sourceLanguage,
        targetLanguage = targetLanguage,
        translatedSegments = translatedSegments,
        failedSegments = failedSegments,
        pendingBatches = pendingBatches,
        contentLimited = scanTruncated,
        message = message
    )

    private fun publish(value: TranslationState) {
        state = value
        webView.post { onStateChanged(value) }
    }

    private fun isCurrent(candidate: Long): Boolean = active && generation == candidate

    private fun errorResponse(
        message: String,
        requestId: String? = null,
        retryable: Boolean = false
    ): String = JSONObject().apply {
        put("type", "error")
        put("message", message)
        put("retryable", retryable)
        if (!requestId.isNullOrBlank()) put("requestId", requestId)
    }.toString()

    private fun isSecureHttpPage(url: String?): Boolean {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        return uri.scheme.equals("https", true) && !uri.host.isNullOrBlank()
    }
}
