# DHYRA Browser — Manual QA Checklist

Run on at least one Android 14+ phone, one Android 16 device/emulator, and one tablet/foldable window size. Also test at least two Android System WebView provider versions where possible.

## Build and startup
- [ ] Install debug APK from CI.
- [ ] Cold start and warm start do not crash.
- [ ] App opens a usable start page.
- [ ] External HTTP/HTTPS intent opens in DHYRA.
- [ ] App survives Activity recreation and process death for regular tabs.

## Address bar and navigation
- [ ] Address bar remains above WebView on every screen size.
- [ ] Omnibox focus does not jump/resize the page unexpectedly.
- [ ] URL and search input resolve correctly.
- [ ] Autocomplete uses local history/bookmark data.
- [ ] Back/forward/reload/stop work.
- [ ] HTTPS-first and TLS certificate cancellation work; invalid certificates are never bypassed.
- [ ] Redirects, JavaScript and viewport rendering work on representative sites.

## Tabs and lifecycle
- [ ] Open, switch, close, duplicate/restore flows behave as implemented.
- [ ] Swipe between tabs does not conflict with page horizontal gestures.
- [ ] Tab switcher adapts to compact and expanded windows.
- [ ] 5, 10 and 20 tab sessions do not leak WebViews or freeze the UI.
- [ ] Background/foreground lifecycle pauses/resumes visible WebView safely.
- [ ] Renderer crash recovery returns to a usable state.

## Private profile isolation — P0
- [ ] Confirm the test WebView provider supports MULTI_PROFILE and DELETE_BROWSING_DATA.
- [ ] Open a regular site and set a regular-profile test cookie and localStorage key.
- [ ] Open a private tab for the same origin; verify regular cookie and localStorage values are absent.
- [ ] Set distinct private cookie and localStorage key; verify regular tab cannot read them.
- [ ] Open multiple private tabs and verify they share the private session profile.
- [ ] Close one private tab; remaining private tabs continue to work.
- [ ] Close the final private tab; close and reopen private mode; verify private cookie, cache and localStorage are gone.
- [ ] Verify regular cookies/cache/localStorage and login remain intact after private cleanup.
- [ ] Kill the app with private tabs open, relaunch, and verify private profile is cleared before new private browsing is enabled.
- [ ] On unsupported WebView provider, private mode remains disabled and never falls back to regular profile.
- [ ] Verify private downloads are refused with a clear explanation.
- [ ] Verify bookmark and speed-dial actions are blocked from private tabs and do not write the URL to regular DataStore.
- [ ] Verify per-site Shields toggles in private tabs do not alter the same site's regular-profile setting.
- [ ] Verify Android Autofill and view-state saving are disabled for private WebViews.
- [ ] Verify on-device ML Kit translation in a private HTTPS tab: language model download, tab-scoped restore, and no URL or page text sent to an external translation website.

## Website permissions
- [ ] Camera and microphone prompt shows requesting origin and resource.
- [ ] Deny and grant flows both work.
- [ ] Android runtime permission denial is handled safely.
- [ ] Geolocation prompt shows origin; denial is propagated.
- [ ] File picker respects MIME type and single/multiple mode.
- [ ] Pending permissions/file chooser are cancelled when Activity is disposed.

## Shields and privacy
- [ ] Known blocklist test hosts/paths are intercepted.
- [ ] Non-matching resources continue to load.
- [ ] Per-site Shields toggle affects only that site's setting.
- [ ] Request counts reset for a new main-frame page and count only observed intercepted requests.
- [ ] UI does not claim byte savings.
- [ ] Clear regular browsing data does not clear private profile data.
- [ ] Third-party cookies are blocked when protection is enabled.

## History, bookmarks, downloads
- [ ] Private pages are not saved to regular history or restored session JSON.
- [ ] Bookmark add/delete/import/export round-trips valid JSON.
- [ ] History/bookmark search works with URL and title.
- [ ] Downloads show current status/progress and system completion notification.
- [ ] Download list refresh pauses outside the visible lifecycle and slows while idle.
- [ ] Completed supported files open through a content URI permission grant.

## UI and accessibility
- [ ] Light, dark, dynamic and AMOLED themes cover dialogs/sheets/cards.
- [ ] AMOLED internal surfaces remain black/near black.
- [ ] Speed dial and tab grid adapt from phone to tablet.
- [ ] TalkBack labels and reading order are useful.
- [ ] Text scaling reaches 200% without clipping critical controls.
- [ ] Minimum touch areas are 48 dp.
- [ ] Reduced-motion/system animation scale does not make navigation unusable.

## Release checks
- [ ] `testDebugUnitTest` passes on CI.
- [ ] `lintDebug` passes with `abortOnError=true`.
- [ ] `assembleDebug` output installs and launches.
- [ ] Release AAB is signed through CI secrets and validated.
- [ ] Privacy policy, data safety, target API, store listing and third-party notices are reviewed.

## Tab group close regression checks (2.1.3)

- [ ] Open regular and private tabs; close all regular tabs and confirm the last private tab becomes active without creating a blank regular tab.
- [ ] Repeat in the opposite direction; closing all private tabs returns to an existing regular tab.
- [ ] Close all regular tabs and use Undo; verify restored regular tabs are available and the last restored tab becomes active.
- [ ] Tap Close All in Private; cancel the confirmation and verify no tabs are removed.
- [ ] Confirm Close All in Private; verify every private tab closes and no Undo action is offered.
- [ ] Start Close All with a tab search active; verify search clears and all tabs in the selected group animate and close.
- [ ] While the close cascade runs, verify tab selection, individual close gestures, mode switching and New Tab cannot race the operation.
- [ ] Repeat with 1, 8, 20 and 50 tabs; verify no stale active ID, blank screen, freeze or crash.
