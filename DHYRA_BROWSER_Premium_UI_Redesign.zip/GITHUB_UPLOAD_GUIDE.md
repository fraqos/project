# Upload DHYRA BROWSER 1.3.0 to GitHub

1. Create a new GitHub repository named `dhyra-browser`.
2. Extract this ZIP.
3. Upload **the contents inside** the extracted folder to the repository root. Do not upload an extra parent folder.
4. Verify these are visible at the top level:
   - `settings.gradle.kts`
   - `build.gradle.kts`
   - `gradle.properties`
   - `gradle/wrapper/gradle-wrapper.properties`
   - `gradlew`
   - `app/`
   - `.github/workflows/build.yml`
5. Open the repository's **Actions** tab.
6. Choose **DHYRA BROWSER - Build Android APK**.
7. Press **Run workflow**. Builds also start automatically on pushes to `main` or `master`.
8. After the run succeeds, open it and download `DHYRA-BROWSER-v1.3.0-debug` under **Artifacts**.
9. Extract that artifact to obtain `app-debug.apk`.

The workflow installs JDK 17, Android SDK platform/build-tools 35 and Gradle 8.7, checks key project files, builds `:app:assembleDebug`, and uploads APK plus build diagnostics.

The ZIP contains a Gradle launcher script and wrapper properties. The GitHub workflow invokes Gradle 8.7 directly via the setup action, so it does not depend on a separately bundled `gradle-wrapper.jar`.
