# dhyra — Android browser 2.5.1

dhyra is an Android browser built with Kotlin, Jetpack Compose Material 3 and the Android System WebView supplied by the device. Websites are rendered by the real WebView engine; dhyra does not simulate websites and does not bundle Chromium. This project builds an Android application for phones, foldables and tablets. Desktop-site mode requests a desktop version of a website; it is not a Windows/macOS/Linux browser.

![DHYRA browser brand artwork](docs/assets/dhyra-brand-reference.png)

## Project status

Release source version: **2.5.1** (versionCode 29). This Shields update builds on the v2.4.9 UI/localization release, which replaced the old blue rectangular logo backdrop with the user-supplied transparent D/globe/orbit emblem, uses a restrained adaptive launcher scale, keeps the native homepage to search + speed dial + recently visited, removes weather/news from that homepage, deduplicates recent visits by normalized host, adds explicit Light/Dark/System default choices with in-place Compose color transitions, and adds per-app English/Bahasa Indonesia/System default language selection through AppCompat locales. Existing browser data, bookmarks and tab/session logic are retained.

This is an engineering build candidate, **not yet production-certified**. The source has received privacy, lifecycle, UI and CI improvements described below. The current authoring environment does not include an Android SDK or a usable Gradle installation, and the archive intentionally omits `gradle-wrapper.jar`; therefore a full Android Gradle build, Android Lint, APK creation, emulator run and real-device QA have not been claimed. The source-contract, Node.js, XML and workflow-configuration checks listed in `docs/BUILD_VERIFICATION.md` have been run. Run the included GitHub Actions workflow to perform the Android build gates.

## 2.4.9 UI/UX and performance baseline

The native browser UI uses one outlined icon family in browser controls, tab overview, omnibox and overflow menu. The overflow menu pins Settings outside its scrollable action list. Settings rows have standard press feedback and switches use a single parent toggle interaction. Theme changes are rendered in Compose without AppCompat night-mode Activity recreation; shared surface and brand colors transition over 180 ms. Homepage speed dial and recent rows show cached regular-profile favicons when available, with a bounded 64-host cache scaled to 128px maximum dimension. CI keeps a dedicated `:app:compileDebugKotlin` gate before unit tests, lint and APK assembly.

## 2.5.1 Shields update

Shields loads a bundled starter snapshot plus four fixed HTTPS subscriptions: EasyList for ads, EasyPrivacy for tracking, Fanboy’s Annoyance List for supported social/overlay/cookie annoyances, and ABPindo for Indonesian/Malay sites. ABPindo is a regional supplement to EasyList, not a replacement. The Fanboy list is compiled and served by its maintainer; dhyra does not download a template containing unresolved `%include` directives. Automatic refresh is attempted every four days on unmetered connections, and manual refresh is available from the Shields sheet. A successful list refresh builds an immutable replacement engine on `Dispatchers.IO` and publishes the snapshot for request-callback threads only after each list has passed validation/storage; failed lists retain their previous last-known-good copy.

The matcher supports an indexed subset of Adblock Plus network filters (host/path anchors, wildcards, separators, resource types, first/third-party heuristics, `domain=`, exceptions, `$important` and `$badfilter`) plus common CSS cosmetic selectors, including ID shorthand and child combinators. Domain-specific cosmetic selectors are prioritized, generated CSS is valid and capped at 64 KiB per page, and blocked-request UI updates are coalesced to reduce recomposition during bursts. Unsupported directives are skipped and surfaced as an implementation limitation rather than guessed. See [Shields limitations and filter support](#shields-and-filter-list-support).

The workflow also runs `scripts/validate-ci-config.py` before installing the toolchain to verify that Gradle, AGP, Kotlin, JDK, compile SDK, Build Tools, wrapper checksum, and APK artifact naming remain aligned with the source project. It clears `dist/` before staging APKs to prevent stale artifacts.

## Toolchain

| Component | Version |
|---|---|
| Kotlin / Compose compiler plugin | 2.4.21 |
| Android Gradle Plugin | 9.3.1 |
| Gradle | 9.5.1 |
| JDK | 21 in CI (17 minimum) |
| compileSdk / targetSdk / minSdk | 37.1 / 36 / 26 |
| Compose BOM | 2026.11.01 |
| Activity Compose | 1.13.0 |
| Lifecycle runtime | 2.10.0 |
| Core KTX | 1.19.0 |
| AppCompat | 1.8.0 |
| Preferences DataStore | 1.2.1 |
| AndroidX WebKit | 1.17.1 |
| ML Kit Translate | 17.0.3 |
| ML Kit Language ID | 17.0.6 |
| Web rendering | Android System WebView |
| UI | Jetpack Compose Material 3 |
| QR encoding | ZXing Core 3.5.3 |

The application targets API 36. Google Play requires new apps and app updates to target Android 16 / API 36 or higher from 31 August 2026. This API target does not mean that all Android 16 behavior or device compatibility has been validated; compatibility QA is still required. See [Google Play target API requirements](https://developer.android.com/google/play/requirements/target-sdk). The compile SDK is 37.1 specifically because Compose BOM 2026.11.01 / Compose 1.13.0 declares that requirement; compile SDK and target SDK serve different purposes.

Kotlin uses the typed `compilerOptions` DSL with `JvmTarget.JVM_17`, aligned with Java `sourceCompatibility` and `targetCompatibility`. The obsolete `kotlinOptions { jvmTarget = "17" }` block is not used.

## Architecture today

Detailed notes: [architecture](docs/ARCHITECTURE.md), [`space` privacy model](docs/SPACE_PRIVACY.md), [implementation status](docs/IMPLEMENTATION_STATUS.md), and [build instructions](BUILD_INSTRUCTIONS.md).

```text
app/src/main/java/com/dhyra/browser/
├── MainActivity.kt                 # Activity, Compose root, preferences and app routing
├── BrowserController.kt            # WebView sessions, tab lifecycle and browser callbacks
├── UiModels.kt                     # Preferences, lightweight data models and JSON codecs
├── core/
│   ├── localization/               # Compose text bridge and Android per-app locale resources
│   ├── downloads/                  # Android DownloadManager integration and file policy
│   ├── engine/                     # DhyraEngine facade and WebView lifecycle/security policy
│   ├── nav/                        # Address resolution and navigation policy
│   ├── network/                    # HTTPS-first, headers and per-tab desktop/mobile mode
│   ├── search/                     # Search provider registry and custom HTTPS templates
│   ├── security/                   # URL validation and WebView permission resource policy
│   ├── settings/                   # Centralized preference defaults/validation
│   ├── shields/                    # Indexed ABP-subset engine + filter-list manager
│   ├── storage/                    # Cookie/cache adapters and history/bookmark list operations
│   ├── suggest/                    # Local history/bookmark suggestions
│   ├── tabs/                       # Tab selection, session persistence and SPACE profiles
│   └── translation/                # Provider contract, ML Kit, bounded queue and secure bridge
└── ui/
    ├── components/                 # Omnibox, quick menu, sheets and controls
    ├── screens/                    # Home, browser, tabs, settings and library screens
    └── theme/                      # Material 3 themes and shared design tokens
```

Theme has three explicit choices (Light, Dark, System default). App language supports English, Bahasa Indonesia, and System default; locale changes use AppCompatDelegate and are automatically applied to the Activity. The full native text catalog is included for the two shipped languages. Adding another language requires providing another `values-<tag>/strings.xml` catalogue and adding its tag to `res/xml/locales_config.xml`.

The codebase is not yet a fully separated multi-module MVVM/Room/DI architecture. `MainActivity.kt`, `BrowserController.kt` and `UiModels.kt` remain relatively large; further extraction and a safe migration from JSON DataStore to Room are planned rather than being claimed complete. Existing JSON history/bookmark/session data is retained to avoid destructive migration.

## Implemented behavior in this source

- Material 3 UI foundation with three explicit theme choices: Light, Dark and System default. Theme changes animate Compose color tokens in place and do not recreate the Activity or attached WebViews. Legacy Dynamic/System values migrate to System default and AMOLED migrates to Dark; explicit Light remains Light without clearing browser data.
- Address bar is fixed at the top. There is no setting or layout path to move it to the bottom. Fullscreen media hides browser chrome instead of relocating it.
- Homepage is a compact native Compose start page containing only the address/search bar, speed dial and recently visited. Speed-dial swatches rotate through six fixed flat color pairs with a dark palette variant. Recently visited rows are deduplicated by normalized host and rendered in one bordered card. There is no weather or news section on the homepage. This source does not load an HTML/CSS homepage into WebView; the start page is Compose.
- Tab overview uses a compact adaptive grid, search for larger tab sets, title/favicon/preview where available, `space` markers, close gestures, Undo for normal group-close and explicit confirmation for irreversible `space` group-close. Closing one group keeps the other group’s active tab instead of creating an unnecessary blank tab.
- Google is the first-run search engine. Built-in Google, Bing, DuckDuckGo, Yahoo, Ecosia, Startpage, Qwant and Brave templates are available. Users can add, edit, delete and select multiple custom providers; templates require a valid HTTPS URL and exactly one `%s` or legacy `{query}` placeholder. Search input is URL-encoded and invalid providers fail back to Google.
- URL/search resolution validates HTTP(S) hosts and rejects user-info credentials before top-level navigation. Domain names, localhost aliases, `.local` hostnames, IPv4 and bracketed IPv6 literals (including ports) are treated as addresses; a bare single word remains a search query. Non-HTTP schemes are sent to search rather than opened in WebView.
- Local suggestions, grouped-by-date history, history/bookmark search, bookmark add/edit/delete and JSON import/export, loading, back/forward/reload, copy/share and horizontal tab switching.
- Home speed-dial shortcuts can be added, edited and removed (up to the existing eight-tile limit); `space` does not persist shortcut changes.
- Per-tab Mobile/Desktop rendering mode uses the installed WebView user agent and preserves its Chromium version token. Desktop mode sends a Linux X11 UA; the site can still choose a responsive/mobile layout, and changing UA does not create desktop operating-system capabilities.
- On-device page translation uses Google ML Kit Translate and Language Identification. Language models are downloaded on demand (Wi-Fi-only by default), then text is translated locally. DOM extraction uses TreeWalker and replaces only eligible TextNode values; it does not rewrite `innerHTML` or replace page elements. Batches, retries, tracked nodes and cache are bounded; page scripts that mutate text remain authoritative, and partially failed segments remain in the source language.
- WebView lifecycle is forwarded from Activity pause/resume; inactive tabs are saved in memory and destroyed when over the live-WebView limit; renderer crash recovery remains enabled.
- **`space` is feature-gated.** It uses a named AndroidX WebKit profile only when runtime WebView supports both `MULTI_PROFILE` and `DELETE_BROWSING_DATA`. dhyra assigns the profile before using each `space` WebView and clears profile data at startup, when the final SPACE tab closes and when its controller is destroyed. If support/cleanup is missing, `space` tabs are disabled rather than silently using regular storage. Downloads, bookmarks, speed-dial additions and device permissions are blocked in `space` to avoid persistent traces. `space` does not make the user anonymous to websites or network operators.
- HTTPS-first for browser-initiated main-frame navigation, cancellation of TLS certificate errors, mixed-content restrictions, Safe Browsing, file access restrictions, DNT/GPC on browser-initiated top-level requests and third-party cookie controls.
- Indexed Shields interception with supported Adblock Plus network rules, resource-type/domain/third-party scopes, important rules, exceptions, generic patterns, cosmetic CSS and bounded filter-list subscriptions. Normal and `space` per-site overrides are held separately; request-thread interception reads concurrent URL/override state instead of Compose snapshots. The app does not invent a byte-savings figure; transferred bytes are not measured.
- Downloads use Android `DownloadManager`, with a pre-download confirmation showing filename, true source host, MIME/format, storage destination and an executable/APK warning; the list displays status/progress, supports cancellation/removal and opens completed files. Android `DownloadManager` does not expose app-controlled pause/resume, precise per-second speed or remaining-time controls in this implementation. `space` downloads are blocked.
- Quick actions include find-in-page, per-tab desktop-site mode, on-device translation, CSS reader presentation, share, print/PDF and QR.
- Optional release signing can be enabled at manual workflow dispatch. The keystore is decoded from GitHub Secrets into the runner's temporary directory; no keystore or password is stored in source. The release APK and AAB are produced only when signing secrets are provided; otherwise the optional release APK is unsigned.
- **AdMob and monetization are removed**: no Ads SDK dependency, application metadata, initialization, ad component, placement or affiliate tagging.

## Privacy model and limitations

`space` profile isolation is attempted only when the installed WebView provider advertises both required features. The `space` profile is cleared through the profile-specific `WebStorageCompat.deleteBrowsingData` API; runtime support and behavior still require tests on physical devices and multiple WebView provider versions. If profile attachment fails at runtime, dhyra disables `space` tabs rather than using the default profile. The `space` session is not backed up or restored. `space` downloads and device permission requests (camera, microphone, protected media and geolocation) are refused. This is a real profile boundary offered by AndroidX WebKit, not a separate operating-system user or Chromium process sandbox.

Shields is an Android System WebView-compatible filter engine implementing a documented subset of Adblock Plus syntax, not a full EasyList/uBlock engine. Unsupported directives (including regular-expression matching, redirects, scriptlets, `removeparam`, CSP and procedural cosmetic rules) are skipped rather than approximated. Counts describe only requests observed and intercepted by WebView callbacks. Bytes saved are not measured.

HTTPS-first applies to browser-initiated main-frame navigation. It does not guarantee HTTPS for links or redirects handled internally by every website. DNT/GPC headers are only attached to browser-initiated top-level requests; they are not guaranteed on all subresources. These headers are requests for privacy, not enforcement against sites.

Reader Mode remains a CSS presentation mode, not an article extraction engine. Translation uses on-device ML Kit models after download; model downloads require network access, and supported languages are limited by ML Kit. The JS bridge is installed through AndroidX WebMessageListener, restricted to HTTPS origins, main-frame messages, a per-session token, bounded payloads and a translation-only protocol; it does not use a general-purpose `@JavascriptInterface` on untrusted pages. Translation is best-effort: complex canvases, shadow DOM, cross-origin frames, inaccessible closed components, and text rendered as images are not translated. Very large pages may be partially scanned to bound memory; the UI reports when this happens. The DOM API also cannot guarantee that a hostile page script will not race with page text changes.

Desktop-mode UA switching preserves the current WebView Chromium version where a `Chrome/<version>` token is available. The CSS viewport is the layout coordinate space selected by the page/UA; the visual viewport is the currently visible/scaled portion. Pages that force a device-width viewport or render content in canvas/remote frames may not show desktop layout even with a desktop UA. The feature requests a desktop variant; it cannot force server-side layout or desktop-only operating-system features. DoH entries are provider presets only and do not route WebView DNS through a custom DoH transport. Anti-fingerprinting and WebRTC leak protection are not complete.

## Shields and filter-list support

Shields includes an indexed Adblock Plus subset for host/path patterns, anchors, `*` wildcards, `^` separators, request resource types including first-document `$popup`, `third-party`, `domain=`, `$important`, exceptions, `badfilter`, and supported CSS element-hiding selectors. Cosmetic rules are indexed by domain so page completion does not scan the entire subscription. It combines a bundled starter list with EasyList, EasyPrivacy, Fanboy’s Annoyance List and ABPindo HTTPS subscriptions. ABPindo adds regional Indonesian/Malay coverage. Automatic refresh is attempted every four days on unmetered connections; users can refresh manually from the Shields sheet. `$important` block rules take precedence over ordinary exceptions, and `$badfilter` signatures normalize option ordering while preserving case-sensitive patterns. Downloads are size-limited, checked for an Adblock Plus header and a minimum plausible rule count, stored atomically, and retained at the last known-good version if a refresh fails. The immutable filter-engine snapshot is published through a volatile reference for WebView request callbacks; filter-list updates do not send visited page URLs.

The parser deliberately skips unsupported features such as regular-expression filters, redirects, scriptlets, `removeparam`, CSP modifiers, and procedural cosmetic syntax. `$popup` is applied only to the first HTTP(S) document request created by `WebChromeClient.onCreateWindow`, using the opener page as the filter context; popup requests that WebView does not surface cannot be intercepted. Ping and WebSocket classification is best-effort when the provider exposes the request headers; this is not a WebRTC blocker. First/third-party detection uses a curated common-suffix heuristic rather than the full Public Suffix List, so uncommon suffixes may be classified imperfectly. Android System WebView interception does not expose all browser-internal, `javascript:`, `blob:`, redirect-follow-up, or every service-worker request path. CSS cosmetic filters may also be constrained by CSP, shadow DOM and dynamic site rendering. This is a stronger supported WebView filter subset, but it is not a full uBlock/Brave/Firefox extension engine and has not been benchmarked against those products.

## Build locally

Requirements: JDK 17 or newer (CI uses JDK 21), Android SDK Platform 37.1, accepted SDK licenses and Gradle 9.5.1. AGP 9.3.1 selects the compatible Build Tools version because the app does not pin `buildToolsVersion`. The source ZIP intentionally omits `gradle-wrapper.jar`; CI generates the standard Gradle Wrapper in the actual project root before using `./gradlew`. For Android Studio sync, generate the wrapper from the project root with a local Gradle 9.5.1 installation.

From the project root:

```bash
./gradlew --version
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

The canonical workflow is `.github/workflows/build.yml`. Keep only this dhyra workflow active.

The workflow supports:

1. **Source at repository root (recommended):** commit the extracted project contents, including `settings.gradle.kts`, `app/`, `gradle/` and `.github/workflows/build.yml`.
2. **One ZIP at repository root:** keep the workflow committed separately under `.github/workflows/build.yml` and commit exactly one dhyra `.zip` at repository root. The workflow safely validates and extracts it into a temporary directory. No manual extraction is required for CI.

The workflow first validates the translation DOM tests and Compose/source contracts, then sets up JDK 21, Android SDK Platform 37.1 and Gradle 9.5.1. It locates the project at repository root or safely extracts exactly one Android project ZIP. The standard Gradle Wrapper is generated in the real extracted project root (which already contains `settings.gradle.kts` and `build.gradle.kts`), then the pinned Gradle distribution checksum is verified by the wrapper. It runs `:app:checkDebugAarMetadata`, `testDebugUnitTest`, `lintDebug` and `assembleDebug`, validates APK manifest/DEX entries, creates a clean source ZIP and SHA-256 sums, and uploads artifacts. Optional release APK/AAB build is available through `workflow_dispatch`; release signing is opt-in via GitHub Secrets.

## Documentation

- `BUILD_INSTRUCTIONS.md` — local build and GitHub Actions setup.
- `docs/AUDIT_AND_CHANGELOG.md` — source audit and engineering changes.
- `docs/IMPLEMENTATION_STATUS.md` — current implemented state and limitations.
- `docs/MANUAL_TEST_CHECKLIST.md` — physical-device QA plan.
- `docs/UI_UX_OVERHAUL.md` — Compose design system and layout behavior.
- `docs/BUILD_VERIFICATION.md` — checks performed and build verification boundary.
- `docs/GITHUB_UPLOAD_GUIDE.md` — canonical workflow setup.
- `THIRD_PARTY_NOTICES.md` — direct dependency notices.

## License

No project-level license file was present in the supplied source archive. Do not assume the project is open source or redistribute it under a license without the owner's decision.


## 2.4.6 — calm homepage, app locales and transparent user logo

- Reworked the native Compose homepage to contain only the address/search bar, a six-color rotating speed dial and a single recently-visited card. Weather and news homepage sections and their feed repository were removed.
- Recently visited entries are deduplicated by normalized host (including common `www.`, `m.` and `mobile.` prefixes). Speed-dial tiles use 54dp flat-color icons, 16dp corners, 12sp labels and a restrained dark-mode palette.
- Added exactly three explicit theme modes: Light, Dark and System default. The stored value is normalized from legacy System/AMOLED settings and rendered by the Compose theme without Activity recreation; legacy Light remains Light.
- Added searchable app-language choices for System default, English and Bahasa Indonesia. AppCompatDelegate locale storage/recreation is enabled; native Compose text and Toasts resolve through Android `values`, `values-en` and `values-id` resources. Additional languages require a complete resource catalogue.
- Replaced the previous icon artwork with the supplied D/globe/orbit emblem after removing its rectangular blue image background. Adaptive launcher artwork is kept within the safe area; splash/startup/About use transparent PNG artwork.
- Settings categories follow General, Privacy and security, Languages, Downloads, Notifications, Advanced and About. Settings controls retain the common outlined vector icon family, 0.5dp card borders and theme-provided violet accent with accessible light/dark variants.
- App version updated to 2.4.6 / versionCode 24. CI now generates the standard Gradle Wrapper in the real extracted project root instead of a temporary empty build.


## 2.2.2 compile correction

- Corrected `MainActivity.kt` permission grant handling: `DhyraPermissionManager.supportedResources()` already returns `Array<String>`, so that array is passed directly to `PermissionRequest.grant()` without an invalid `toTypedArray()` call. The separate `List<String>` path for protected-media resources still uses `toTypedArray()` correctly.
- Removed default argument values from both `MLKitTranslator` overrides (`prepare` and `translate`). The `TranslationProvider` interface remains the single owner of `wifiOnly = true`, so callers retain the default behavior.
- CI artifact names and app metadata now use version 2.2.2 / versionCode 16.


## 2.4.2 — focused brand and tab-motion update (previous release)

- Removed the five requested appearance/motion options from Settings while retaining existing browser preferences and saved homepage layout data for continuity.
- Standardized the violet accent to `#8067F0` in launcher artwork and Compose light/dark/dynamic schemes.
- Refined single-tab exit and Close All stagger with keyed lazy-grid placement animation for remaining cards.
- The D monogram startup reveal runs briefly on each initialized app launch.
- Updated app version to 2.4.2 / versionCode 20.

## 2.4.1 — D monogram and motion refinement

- Launcher foreground, monochrome, legacy and Compose artwork now use only a geometric capital D; the former spider artwork is removed. Obsidian is used for the launcher surface and electric violet is the single brand accent.
- The startup identity appears on every app launch as a short D-only fade/scale reveal. The previous first-run-only and user-disable logic is removed.
- Settings no longer exposes UI Styles, Homepage Layout, Reduce Motion, Animation Intensity or Disable Startup Animation. Old UI-style/motion preference records are cleaned on initialization; saved homepage layout data remains compatible and continues to render as before.
- The theme now exposes System and Dark only; legacy preferences migrate safely to those modes with the stable dhyra violet action/brand accent.
- Tab cards animate out before their tab is removed. Keyed lazy-grid items animate into their new positions; close-all uses a bounded stagger so it remains quick even with many tabs. Swipe-to-close and private-tab confirmation remain available.
- Version updated to 2.4.1 / versionCode 19 (superseded by 2.4.2).

## 2.4.0 — spider identity and product redesign pass

- The app label and visible brand are `dhyra` in lowercase. The original eight-legged geometric spider emblem is supplied as Android vector artwork and a Compose mark; launcher foreground, monochrome, legacy and splash resources use the new obsidian/violet direction.
- UI Style System includes Glassmorphism, Swiss Editorial, Minimalism, Bento Grid, Liquid Glass, Material You, Hand-Drawn, Bauhaus, Aurora Gradient and Manga Color. Style selection is persistent and affects colour scheme, shape geometry and selected typography treatment. It is not yet ten entirely different screen/navigation implementations.
- Homepage layout presets persist across restarts and adjust available sections and ordering. Freeform widget add/remove/reorder/resize, custom image backgrounds and independently configurable widget sizes are not part of this release.
- Custom search-engine CRUD is stored in Preferences DataStore. HTTPS templates accept exactly one `%s` or `{query}` placeholder, custom names are checked against built-ins/duplicates, and terms are URL-encoded before navigation.
- News uses category RSS feeds, search, source labels, publication dates, duplicate suppression, loading/error/retry states. Google News RSS is an unofficial endpoint without a published service SLA. Weather remains opt-in and uses Open-Meteo after Android location permission; there is no IP-geolocation fallback.
- Downloads require confirmation and show source host/format/destination. Android DownloadManager still controls transfer mechanics: no in-app pause/resume or fully accurate speed/remaining-time display is claimed.
- Tab and screen transitions use saved motion intensity/reduced-motion preferences. The first-launch intro can be disabled. Android does not expose a safe way for this app to delay process shutdown for a cinematic closing animation, so no blocking exit animation is implemented.
- The rendering backend remains Android System WebView. See `docs/IMPLEMENTATION_STATUS.md` for security, localization, privacy and device-test gaps.

## Recent CI compile fix (2.4.0)

The fullscreen origin indicator uses the current tab URL (`pageUrls` with the tab model as fallback). The custom fullscreen callback receives a generic Android `View`, so it must not read `view.url`; that property belongs to `WebView`.


## 2.4.4 — navigation, theme, SPACE and release hardening

- Corrected local address detection for `localhost`, local aliases, IPv4, IPv6 and explicit ports while keeping unqualified single words as search queries.
- Made Shields exceptions authoritative over matching block rules regardless of list order.
- Restricted theme choices to System and Dark; old Dynamic/Light values fall back to System and AMOLED maps to Dark.
- Renamed user-facing private-session controls to SPACE while preserving internal state compatibility.
- Added the supplied 3D DHYRA artwork to About and kept the compact geometric monogram for small/launcher-safe contexts.
- Added optional protected release signing and signed AAB packaging to the GitHub Actions workflow.
- Added JVM regression coverage and SPACE/architecture documentation; a full Android Gradle build remains pending a hosted Android CI run.


## 2.4.5 — official DHYRA logo integration

- The user-supplied 640×640 PNG is now the canonical artwork across the Android launcher, Android 12+ splash, homepage logo, startup intro and About page.
- Adaptive and legacy launcher icon assets are generated from the same image without stretching. The About image uses fit scaling and is not cropped.
- The version is 2.4.5 / versionCode 23.
