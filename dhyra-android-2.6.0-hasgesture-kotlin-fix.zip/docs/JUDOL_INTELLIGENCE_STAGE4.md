# DHYRA 2.5.4 — Stage 4: local Judol Intelligence

## Scope

This detector is a conservative navigation guard for top-level HTTP(S) documents and popup destinations. It is not a general page classifier, URL reputation service, DNS filter, VPN, or guarantee that all gambling advertisements are removed. Network subresources remain under the ABP matcher and cosmetic destination hints.

## Decision order

1. Reject malformed, overlong, non-HTTP(S), IP-literal, and hostless inputs from heuristic scoring (fail open).
2. Match the local allowlist first; an allow entry overrides both the bundled local blocklist and heuristic signals.
3. Match the local exact-domain blocklist (exact hostname and its subdomains, with a label boundary).
4. Score hostname tokens and known compound terms. Ambiguous single words carry low weight.
5. URL path/query terms contribute at most 12 review points and can never independently satisfy the block decision.
6. Automatic heuristic blocking requires a strong hostname anchor and score >= 85. REVIEW results are diagnostic only and do not block.

## Local lists

- `app/src/main/assets/judol_domains.txt`: one verified hostname per line; `||host^` shorthand is accepted.
- `app/src/main/assets/judol_allowlist.txt`: one trusted hostname per line.
- Blank lines and `!` / `#` comments are ignored. URL/path expressions, wildcard entries, IP literals, and malformed domain names are rejected.
- Subdomains match by a dot-delimited suffix; `evil-example.test` does not match `example.test`.
- The shipped files intentionally contain no live domain entries because DHYRA has not been supplied a vetted dataset. Populate them only from a source you have reviewed and are entitled to redistribute.

## Privacy and limitations

All scoring is on-device and the detector does not issue DNS, HTTP, or analytics requests. It sees only the destination URL passed by the browser. It cannot inspect page body text, hidden redirects in every script, opaque service-worker traffic, or every navigation path exposed by Chromium. The current integration is deliberately limited to top-level HTTP(S) navigation and popup main-frame requests.

The detector is heuristic, not trained or benchmarked. No precision/recall numbers are claimed. Before lowering the threshold or populating the blocklist, build a labelled dataset containing confirmed gambling domains, news/education pages, brands, software terms, and neutral sites. Report precision and recall separately; do not tune only for recall.

## Tests

`JudolIntelligenceTest.kt` covers compound high-confidence labels, ambiguous terms, path-only contexts, local allow/block precedence, IDN normalization, malformed URLs, and suffix lookalikes. CI runs these through `testDebugUnitTest`; the standalone JVM runner also exposes `runChecks()`.
