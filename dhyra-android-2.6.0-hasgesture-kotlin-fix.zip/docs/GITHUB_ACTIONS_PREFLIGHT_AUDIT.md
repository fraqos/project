# GitHub Actions preflight audit — dhyra 2.6.0

## Changes made before first use

- Corrected the invalid `actions/download-artifact@v7.0.2` reference to the published `v8.0.2` release. `upload-artifact@v7.0.2` remains valid.
- Qualified app-only Gradle tasks (`:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug`, and release tasks) so they cannot resolve to the wrong module.
- Pinned the hosted build runner to `ubuntu-24.04` instead of the moving `ubuntu-latest` alias.
- Kept Android SDK Platform `37.1` aligned with `compileSdk { version = release(37) { minorApiLevel = 1 } }`, and Build Tools `36.0.0` aligned with the configured AGP toolchain.
- Removed the workflow file itself from the push path filter. Adding the workflow before the ZIP therefore does not trigger a doomed build with no project source. A commit containing the ZIP triggers the job; workflow-only changes can be run manually with **Run workflow**.
- Kept the Gradle 9.5.1 distribution checksum pin and added verification of the generated Wrapper JAR before using `./gradlew`.
- Kept the Macrobenchmark job opt-in and restricted it to a self-hosted Linux runner with an authorized physical Android 14+ device.
- Kept repository token permission at `contents: read`; the workflow only uploads build artifacts and does not push commits, publish releases, or deploy anything.

## Static checks performed

- YAML parsed as YAML 1.2; both `build` and optional `macrobenchmark` jobs were found.
- Every inline Bash `run:` block passed `bash -n`.
- The source-project ZIP locator was executed in a temporary mock GitHub workspace; it safely extracted the uploaded ZIP and copied the exact active workflow into the project.
- After simulated extraction, all 99 source contract checks passed and the CI toolchain validator passed.
- Python scripts passed `py_compile`; translation JavaScript passed `node --check`; both translation regression scripts passed.
- The standalone workflow and `.github/workflows/build.yml` embedded in this source ZIP are byte-identical.
- The source ZIP passed CRC/integrity checking.

## Not verified in this environment

The Android Gradle build, Android Lint, APK packaging, and actual artifact upload were not executed here because this environment has no Android SDK and no usable installed Gradle distribution. Those steps require GitHub Actions to download Gradle, Android SDK packages, Gradle plugins, and Maven dependencies. Consequently, no one can truthfully guarantee a successful first hosted run before the workflow has actually run in the target repository. If a build step fails, download `dhyra-build-diagnostics-*` from that same run and inspect the failing Gradle task/log.

## Required first-run repository layout

```text
repository-root/
├── .github/
│   └── workflows/
│       └── build.yml
└── dhyra-android-2.6.0-ci-reviewed.zip
```

Keep exactly one Android project ZIP in the repository. Do not put old DHYRA source ZIPs beside the one being built.
## Follow-up correction — `BuildType with name 'release' not found`

The GitHub log is consistent with the invalid lookup in `benchmark/build.gradle.kts`, not with the app module: `:app` explicitly declares `release`, but the separate `com.android.test` module did not declare a `release` build type before calling `initWith(getByName("release"))`. The test module now defines its own `benchmark` instrumentation build type directly, so it no longer performs a missing release lookup. The target app's `:app:benchmark` build type still inherits from the app's real `release` type and remains non-debuggable/profileable.

The `androidx.benchmark` Gradle plugin was removed from the Macrobenchmark test module and root plugin classpath. That Gradle plugin configures Microbenchmark modules; DHYRA's `com.android.test` module uses the Macrobenchmark library dependency `androidx.benchmark:benchmark-macro-junit4:1.5.0`.

The workflow now runs `./gradlew help` after wrapper bootstrap and before task-specific builds. This forces project configuration to complete early and reports configuration errors before the compile/test steps. `scripts/validate-ci-config.py` also guards against reintroducing the invalid release lookup or Microbenchmark plugin.
