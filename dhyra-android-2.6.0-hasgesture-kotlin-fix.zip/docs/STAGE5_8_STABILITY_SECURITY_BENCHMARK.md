# DHYRA 2.6.0 — Tahap 5–8 Engineering Notes

## Stage 5: renderer stability and recovery

`BrowserController` handles `WebViewClient.onRenderProcessGone` per callback instance. The failed WebView is detached and destroyed; no `saveState`, `reload`, or navigation is attempted on the dead object. The controller clears translation/document-start references and retains the last known HTTP(S) tab URL. The active foreground tab receives a bounded automatic recreation attempt, routed through `ensureWebView(loadInitialUrl = true)` so the normal HTTPS upgrade, Shields checks and document-start setup run again. An explicit user Reload remains available after the automatic retry budget is exhausted.

Android may deliver `onRenderProcessGone` for multiple WebViews sharing the renderer process. Each callback cleans only its own WebView; other callbacks for the other affected instances perform their own cleanup. This prevents a callback for one tab from destroying a newly-created WebView for the same tab ID.

## Stage 6: multi-tab and RAM management

`DhyraTabMemoryPolicy` returns a target cap of 1 for low-RAM/low-headroom devices, 2 for ordinary devices, and 3 only when total RAM, available RAM and app memory class all show high headroom. Inactive tabs are hibernated in LRU order; the active tab is never selected as a victim. Under critical memory pressure or background process pressure, large WebView `Bundle` snapshots are dropped and tabs fall back to their last URL when restored.

`saveState`/`restoreState` are best-effort navigation snapshots, not full JavaScript heap/session restoration. Cookies, local storage and the dedicated SPACE profile are managed separately. `TRIM_MEMORY_UI_HIDDEN` hibernates inactive tabs; critical/background pressure can discard snapshots so tabs reload from their last known URL.

## Stage 7: security hardening

The current WebView policy disables file URL access and file-to-file/universal file access, disallows mixed content, enables Safe Browsing, disables automatic script-created windows, restricts external top-level navigation, cancels SSL certificate errors, and keeps HTTP cleartext disabled by Network Security Config. Sensitive Web permissions are now denied unless their origin is HTTPS or loopback HTTP (for local development); user and Android runtime permission flows still apply. SPACE sessions continue to deny device permissions and persistent downloads.

No certificate bypass, arbitrary `addJavascriptInterface`, global file access, or auto-grant of camera/microphone is introduced. OAuth providers may still reject embedded WebView; use Custom Tabs or the provider's supported native authentication flow where required.

## Stage 8: performance diagnostics and benchmark

Debug builds attach an Activity `FrameMetrics` listener. It records frame durations, counts frames above the current display refresh budget, and counts dropped metric reports. It does not record URLs, page content, cookies or typed text. The percentage is a window-level approximation, not WebView-only jank attribution.

The optional `:benchmark` AndroidX Macrobenchmark module measures cold and warm Activity startup and frame timing during home-screen swipes. Run the matching benchmark build variant on a physical Android 14+ device:

```bash
./gradlew :benchmark:connectedBenchmarkAndroidTest
```

The normal GitHub-hosted CI job compiles the Macrobenchmark instrumentation APK and runs app tests/lint/APK packaging. If `run_macrobenchmark=true` is selected in `workflow_dispatch`, a separate job runs on a self-hosted runner labeled `android-physical` with exactly one authorized physical Android 14+ device attached. A GitHub-hosted emulator is deliberately not used for performance claims. A passing compile/unit-test job is not a substitute for device-level benchmark results. Each benchmark case requests 30 iterations. Report median/P90/P95 alongside device model, Android version, refresh rate, RAM and WebView provider version; rerun the suite after a cool-down and compare runs to identify thermal or network variance.

## Risks and verification

- Renderer recovery cannot preserve renderer memory, in-flight form submissions, active media playback or transient JavaScript state.
- Renderer processes can be shared; the OS decides which WebViews share a process.
- Memory classes and `availMem` are heuristics, not precise per-WebView memory accounting.
- A `Bundle` can still be large; dropping it trades page-state fidelity for lower memory usage.
- Activity `FrameMetrics` include Compose/toolbars/system drawing, not solely the WebView renderer.
- Macrobenchmark output is device-specific; a single physical device cannot represent all low-end hardware or thermal behavior.
- Run full CI, then test renderer crash (`chrome://crash`) on a dedicated debug device, multi-tab switching, Activity background/foreground, permission prompts, TLS error cases, OAuth, file upload, downloads, and video fullscreen before release.

## Gradle configuration correction (CI build-type failure)

The `:app` application module declares its own `release` build type and its `benchmark` app variant inherits from that release type. The separate `:benchmark` module applies `com.android.test`; its instrumentation build types are independent and must not assume that the app module's `release` type exists in the test module.

The instrumentation module now defines its own `benchmark` build type directly (`isDebuggable = true`, debug signing, and release fallback). The invalid `initWith(getByName("release"))` lookup has been removed. The `androidx.benchmark` Gradle plugin was also removed from this Macrobenchmark module: that plugin is for Microbenchmark build configuration; DHYRA uses the `benchmark-macro-junit4` library for Macrobenchmark. The app target remains the non-debuggable, profileable `:app:benchmark` variant.

CI preflight now rejects reintroduction of a release lookup or Microbenchmark plugin in the `:benchmark` module.
