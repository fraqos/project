# DHYRA 2.6.0 — Kotlin `WebResourceRequest.hasGesture()` compilation fix

## Root cause

`android.webkit.WebResourceRequest.hasGesture()` is declared by Android as a Java interface method:

```java
boolean hasGesture();
```

It is not a JavaBean accessor (`getX()` or `isX()`), so Kotlin must invoke it with parentheses. The previous source used `request.hasGesture`, which Kotlin reports as `Function invocation 'hasGesture()' expected`.

## Source correction

In `app/src/main/java/com/dhyra/browser/BrowserController.kt`:

```kotlin
val hasUserGesture = request.hasGesture()
```

The adjacent `request.isRedirect` and `request.isForMainFrame` accesses remain unchanged: they map to Java Boolean `is...()` methods and are valid Kotlin synthetic-property access.

## Regression protection

`scripts/check-compose-contracts.py` now asserts exactly one `request.hasGesture()` invocation and rejects the old property-style expression. The Stage 3 API documentation explains the Kotlin/Java distinction.

## API levels

- `WebResourceRequest.hasGesture()` — API 21.
- `WebResourceRequest.isRedirect()` — API 24.
- DHYRA `minSdk` — API 26.

Both methods are therefore available for all supported DHYRA devices.

## Validation performed

- Kotlin/JVM interoperability fixture compiled against a Java interface with the exact three method signatures (`hasGesture()`, `isRedirect()`, `isForMainFrame()`).
- 100 source-contract checks passed.
- CI configuration preflight passed.
- Both JavaScript regression test scripts passed.
- Remaining `hasGesture` source search shows the corrected invocation only.

A full Android Gradle compile was not run in this environment because there is no Android SDK installed and the source ZIP does not contain `gradle-wrapper.jar`; the GitHub Actions workflow generates the wrapper in CI before running Gradle tasks.
