# DHYRA Shields — Stage 2 (network filter core)

This note describes the Stage 2 source changes in the DHYRA 2.5.3 working tree. It is not a claim that an Android APK has been built or device-tested.

## What changed

- Kept the existing `ShieldsFilterEngine` public API and the `BrowserController` integration point.
- Added bounded regular-expression network filters through RE2/J 1.9. Regex patterns are limited to 512 characters and 1,024 accepted rules. A regex must contain a mandatory literal that can be indexed; unindexable patterns are skipped instead of forcing a full regex scan for every request.
- Corrected `@@...$document`: it is a page-level exception evaluated against the current filtering page URL, not a resource-type test for an individual request.
- Merged repeated `domain=` options into one include/exclude scope so later options do not silently erase earlier domains.
- Kept exception precedence independent of list order and retained `$important` precedence.
- Stopped inferring `XMLHTTPREQUEST` from HTTP `POST`/`PUT`/`PATCH` alone. Traditional HTML form submissions can use those methods. `Sec-Fetch-Dest: empty` is used when present; other cases fall back to Accept and URL-path hints, then `OTHER`.

## Current supported network subset

The parser supports the syntax already implemented by the engine plus the Stage 2 additions:

- `||host^`, host/path filters, `*`, `^`, start/end anchors;
- `@@` network exceptions;
- resource options such as `script`, `image`, `stylesheet`, `subdocument`, `xmlhttprequest`, `font`, `media`, `object`, `ping`, `websocket`, `popup`, and their supported negations;
- `third-party`, `~third-party`, `domain=`, `match-case`, `important`, `badfilter`;
- bounded slash-delimited regex patterns using RE2/J;
- page-wide `@@...$document` exceptions. `$document`, `$elemhide`, `$generichide`, and `$genericblock` are exception-only modifiers; on blocking rules they have no effect, as in ABP.

This is not a full Adblock Plus or uBlock Origin parser. Unsupported directives such as redirect resources, scriptlets, `removeparam`, CSP modifiers, procedural cosmetic rules, and other unsupported options are deliberately skipped rather than approximated. Exception rules using only `$elemhide`, `$generichide`, or `$genericblock` are skipped by the network parser so they cannot accidentally whitelist network requests; cosmetic handling is deferred to a later stage. A combined `$document` exception remains a page-level network exception.

## Regex safety and compatibility

RE2/J avoids catastrophic backtracking by using a linear-time matching design. It is not a drop-in replacement for Java/PCRE regex syntax: constructs unsupported by RE2/J are rejected at compile time. DHYRA also requires an indexable mandatory literal, so a valid RE2/J expression can still be skipped if the matcher cannot safely narrow its candidate set. This is intentional: the engine must not run an unbounded list of regexes for each request.

Dependency: `com.google.re2j:re2j:1.9`. The project notice records the Go License; retain upstream copyright, license, and disclaimer notices when redistributing.

## Request classification and WebView hook

The existing hook is in `BrowserController`'s `WebViewClient.shouldInterceptRequest`. It already calls `ShieldsFilterEngine.classifyRequest(...)`, then `shouldBlock(...)`, returns a synthetic blocked response for matched requests, and returns `null` to let WebView continue otherwise. The original three-argument `shouldBlock(...)` API remains available; the controller uses a four-argument overload so the popup opener can remain the `$domain`/`$third-party` policy context while `$document` is checked against the actual popup destination. This prevents an opener's document exception from silently allowlisting a popup.

The request callback is not a UI-thread callback. Keep its work bounded and in-memory: no Compose state access, database queries, disk reads, list downloads, or long-running regex compilation inside it. The current engine is published as an immutable snapshot and the controller uses concurrent per-tab context.

Android System WebView does not pass an explicit resource-type enum to `shouldInterceptRequest`. Classification is best-effort:

1. `isForMainFrame` gives the strongest signal for a document.
2. `Sec-Fetch-Dest` is preferred when present (`script`, `image`, `style`, `iframe`, `empty`, etc.).
3. `Accept` and common URL extensions are fallback hints.
4. HTTP method alone is not enough to call a request XHR; an HTML form can POST. Unknown requests remain `OTHER`.

Consequently, resource-specific rules can miss some requests when a WebView version omits Fetch Metadata and the URL/Accept headers are ambiguous. Generic URL/domain rules can still match those requests.

The Android WebView callback has important coverage limits: it is invoked on a non-UI thread; for redirects it is called for the initial resource URL rather than every subsequent redirect URL; and it is not invoked for several non-network schemes/resources such as `javascript:`, `blob:`, and certain local asset/file URLs. It does not expose request bodies. The current per-tab context also represents the top-level page, not a reliable per-iframe document context, so `$document` exceptions for individual nested iframes are not fully modeled yet. Navigation/popup/redirect policy and document-start cosmetic injection are separate layers and are intentionally left for later stages.

## Third-party classification limitation

The current engine still uses a small hard-coded suffix approximation for registrable domains. It is **not** a complete Public Suffix List and does not correctly cover every country-code, private, wildcard, or exception suffix. Therefore `$third-party` and the `isThirdParty` helper remain best-effort. Do not advertise exact first-party/third-party classification until a versioned local PSL is integrated and tested.

## Verification

Run on a machine with the project Gradle wrapper, required Android SDK/Build Tools, and network access to resolve Maven dependencies:

```bash
./gradlew :app:compileDebugKotlin
./gradlew :app:compileDebugUnitTestKotlin
./gradlew :app:testDebugUnitTest
./gradlew :app:lintDebug
./gradlew :app:assembleDebug
```

The source-only CI preflight can be run with:

```bash
python3 scripts/validate-ci-config.py
```

For Stage 2, check that the new regression tests pass for document exceptions, repeated domain scopes, regex matching, unindexable regex rejection, and POST classification. Measure matcher P50/P95/P99 separately from full WebView callback latency; no performance number is claimed by this source change.
