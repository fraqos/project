# dhyra v2.6.0 implementation status

## Implemented in source

- Stage 4 adds local Judol Intelligence for high-confidence top-level HTTP(S) destinations. It combines exact user-managed block/allow domain entries with conservative hostname scoring; URL path/query words alone can never trigger an automatic block. Ambiguous terms such as `slot`, `toto`, `scatter`, and `RTP` are not sufficient by themselves. The Shields sheet exposes a persistent toggle. The default domain and allowlist files contain instructions only, not invented live domains.
- GitHub Actions supports ZIP-only project input: exactly one valid project ZIP is safely unpacked on the runner, compiled/tested/linted, APK validated, and a clean source ZIP plus SHA-256 checksums are uploaded. The workflow must be installed separately under `.github/workflows/build.yml`; no local extraction is required.


- Native Compose homepage contains only search/address entry, speed dial and recently visited. Weather and news feed sections/repository are removed.
- Speed dial rotates through the requested six flat color pairs; dark mode uses separate high-contrast pairs. Recently visited rows are deduplicated by normalized host and shown in one card.
- Settings uses grouped cards and one outlined Compose icon style. Theme offers Light, Dark and System default; palette transitions run inside Compose without recreating the Activity or WebViews. Brand accent is `#6F68C8` in light mode and `#AAA4FF` in dark mode.
- App language choices are System default, English and Bahasa Indonesia. AppCompatDelegate persists the selected app locale and applies the compatible locale configuration; native Compose text and Toasts use the local resource catalogue. Locale recreation remains separate from theme changes, which do not recreate the Activity.
- User-provided D/globe/orbit artwork is converted to transparent PNGs for startup/splash/About and safely scaled for adaptive/legacy launcher artwork.
- Homepage speed dial and recently visited rows show cached regular-profile favicons when available. The cache keeps at most 64 normalized hosts and scales site icons to a maximum dimension of 128px.
- Browser controls, tab overview, omnibox and overflow menu consistently use outlined Compose Material icons. Settings stays pinned at the bottom of the overflow menu and remains visible while action rows scroll.
- Settings groups follow General, Privacy and security, Languages, Downloads, Notifications, Advanced and About. Rows use default press feedback and switches have a single parent toggle handler.
- WebView remains Android System WebView. Inactive tabs receive `onPause()`, selected tabs resume, regular browsing uses `LOAD_DEFAULT`, `space` uses `LOAD_NO_CACHE`, DOM storage remains enabled, and deprecated Web SQL Database is disabled.
- Shields now uses an indexed Adblock Plus syntax subset: host/path patterns, anchors, wildcards, separators, exceptions, `$important`, `$badfilter`, supported request-type options including `$popup`, `third-party`, `domain=` and bounded CSS cosmetic selectors. Domain-scoped cosmetic rules are indexed by domain rather than scanned across the complete list on every page finish. Popup rules are applied to the first HTTP(S) document request created through `WebChromeClient.onCreateWindow`, using the opener page as the filter context for third-party/domain conditions.
- The bundled starter rules are combined with four HTTPS subscriptions: EasyList, EasyPrivacy, Fanboy’s Annoyance List and ABPindo (regional Indonesian/Malay coverage). Downloads have connection/read timeouts, a 10 MiB per-list cap, header/minimum-rule validation, private app storage and atomic replacement. Automatic refresh is attempted every four days on an unmetered connection; manual refresh is available from Shields. A failed refresh leaves the last known-good list active. The compiled filter snapshot is safely published for WebView request-callback threads.

## Explicit limitations

- The homepage is native Compose, not an HTML/CSS page loaded in WebView. Locale selection therefore updates Compose resources directly; no JavaScript interface or homepage JSON injection is required.
- Only English and Bahasa Indonesia are currently localized. Other locales must not be offered until their complete `values-<language>` string resources and tests are added.
- Icons are Compose Material Icons Outlined vector assets for consistent outlined styling; this project does not bundle a Material Symbols font file.
- There is no Baseline Profile generation module, so do not claim baseline-profile gains. A separate AndroidX Macrobenchmark module measures cold/warm Activity startup and home-window frame timing. A WebView instance is not created on a background thread because WebView construction/use is UI-thread-bound; no speculative preloader is enabled.
- Android DownloadManager still owns transfer lifecycle; in-app pause/resume/speed prediction are not claimed.
- Full Android Gradle compilation, lint and device tests must run on GitHub Actions/Android tooling; source/static checks do not prove APK success.
- The parser is a deliberate Adblock Plus subset, not a full uBlock Origin/Brave/Firefox filter engine. Regular-expression filters, redirects, scriptlets, `removeparam`, CSP modifiers and procedural cosmetic rules are not supported and are skipped. `$popup` is limited to the first HTTP(S) main-frame request created through `WebChromeClient.onCreateWindow`; it cannot cover popup mechanisms that WebView does not surface through that callback. Ping and WebSocket request headers are classified only if a WebView provider exposes them to the callback; WebRTC interception is not implemented. Third-party classification uses a curated common-suffix heuristic, not a complete Public Suffix List.
- Android System WebView's `shouldInterceptRequest` does not expose every request path: `javascript:`, `blob:`, provider-internal assets, redirect follow-up requests and some service-worker paths are outside or not consistently visible to the callback. CSS cosmetic injection can also be affected by CSP, shadow DOM and site-specific dynamic rendering. The current filter set is not a complete browser extension engine and has not been benchmarked against Brave Shields or Firefox extensions; do not claim parity or superiority without real-world compatibility and performance benchmarks.


## 2.6.0 stages 5–8

- Renderer recovery is per-WebView instance. The failed WebView is detached/destroyed and the active tab receives up to two automatic retries in a two-minute window; manual Reload recreates through standard navigation/HTTPS/Shield checks.
- Live WebView count is adaptive (1 low-RAM, 2 ordinary, 3 high-headroom) and inactive tabs are evicted by LRU. WebView saved-state Bundles are bounded to at most twice the live cap and dropped under critical/background trim pressure.
- Sensitive Web permission requests are restricted to HTTPS and loopback HTTP origins. SSL errors remain cancel-only; file access, mixed content and cleartext networking remain restricted.
- Debug builds measure Activity-level FrameMetrics locally. Optional AndroidX Macrobenchmark tests cover cold/warm startup and home swipe frame timing; physical-device execution is opt-in from workflow_dispatch and requires the `android-physical` self-hosted runner label. No physical-device benchmark numbers are claimed.
