# DHYRA 2.5.3 — Shields Stage 3: cosmetic filtering and navigation protection

This document describes the Stage 3 working-tree implementation. It is not a claim that all Chromium/uBlock Origin behavior is available through Android System WebView.

## Scope

Stage 3 adds three related protections:

1. Page cosmetic filtering at document start where the installed WebView provider supports it, with a `onPageFinished` fallback.
2. Destination-based hiding for anchors, iframe elements and image elements using host hints derived from the native request matcher.
3. Native top-level navigation and popup checks, including a DHYRA-controlled blocked page with **Continue once** and a session-only site whitelist action.

The native `ShieldsFilterEngine` remains authoritative for requests and navigation. JavaScript only hides DOM elements; it does not decide whether a network request is allowed.

## Document-start injection

`BrowserController` compiles the page-specific CSS and destination host hints on `Dispatchers.Default`. It then switches to the main thread to register the script and start the app-initiated navigation. The registration is feature-gated:

```kotlin
if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
    scriptHandler = WebViewCompat.addDocumentStartJavaScript(
        webView,
        script,
        setOf("*")
    )
}
```

The project currently declares AndroidX WebKit `1.17.1`. The method was added in AndroidX WebKit 1.9.0, but availability also depends on the installed WebView provider; AndroidX library version alone does not guarantee that the runtime feature is supported. Always check `WebViewFeature.isFeatureSupported` at runtime.

The wildcard origin registration is used so the DOM-only script can run inside eligible child frames. Before doing any work, the script checks that the top frame matches the expected page host or that the child frame referrer belongs to that top-page host. It exposes no Android JavaScript interface and performs no fetch, XHR, beacon, cookie, or storage operation.

Document-start scripts execute before the page's JavaScript and can delay document loading while the script runs. The generated content script is bounded, but it is not free: the base script is roughly 10 KiB before page CSS, and cosmetic CSS may add up to 64 KiB plus four bounded host lists. The registration uses `*`, so eligible frames receive the script before it self-restricts by top-frame/referrer context. Profile parsing and navigation time on low-end devices; do not assume the injection is performance-neutral. On providers without `DOCUMENT_START_SCRIPT`, or when registration fails, `onPageFinished` uses `evaluateJavascript` to update the current document. That fallback cannot prevent the initial cosmetic flash.

`ScriptHandler.remove()` removes a registration for subsequent page loads; it does not retroactively undo code already run in the current document. The current document is updated through the script's in-page controller.

## Cosmetic filtering and dynamic DOM

The script applies page cosmetic selectors through a `<style>` element. The selector rules already come from the filter engine's bounded CSS output (maximum 64 KiB/page and a bounded selector count). CSS does the actual hiding; JavaScript does not repeatedly rewrite inline styles.

Dynamic content handling:

- A `MutationObserver` watches `childList`, subtree additions, and `href`, `src`, `srcset`, and `target` attribute changes. Images use `currentSrc` where available so selected `srcset` candidates can be checked.
- Added roots are queued and processed through `requestAnimationFrame` (or a 16 ms timeout fallback).
- Each frame processes at most 12 queued roots and 200 descendant elements across active TreeWalkers.
- Open shadow roots are observed when encountered.
- Closed shadow roots cannot be inspected by page-world JavaScript.

The 200-element frame budget limits the amount of scanning per animation frame; it is not a universal performance guarantee. Sites that continuously mutate huge DOM trees can still create ongoing work. Device profiling remains required.

## Destination-based ad element hiding

The engine exports four separate, bounded host lists:

- document destinations for ordinary `<a href>` navigation;
- popup destinations for anchors with a non-empty browsing target other than `_self`, `_top` or `_parent` (including `_blank` and named targets);
- subdocument destinations for `<iframe src>`;
- image destinations for `<img src>`.

This separation prevents a `$script`-only rule from causing an ordinary link to be hidden, prevents a `$popup`-only rule from hiding a same-tab link, and prevents an `$image`-only rule from hiding an anchor to the same host. Host hints are only emitted when the native matcher blocks a representative root URL for that page and resource type.

To avoid over-hiding, only host-wide domain rules are exported. Generic URL rules, path-only rules, IPv6 literals, and other patterns that cannot safely be reduced to a host remain native-only. Candidate inspection is limited to 8,192 host keys and each DOM hint list is limited to 128 hosts. A filter list with more matching hosts can therefore have destinations that are blocked at request time but not hidden pre-click in the DOM.

For a detected destination, the content script marks the link, iframe or image with `data-dhyra-shields-hidden`. For anchors and images it may hide a nearby `DIV`, `ASIDE`, `SECTION` or `LI`, but only within four ancestor levels and only when its measured size and text/link counts are within conservative bounds. It stops at structural elements such as `BODY`, `MAIN`, `ARTICLE`, `NAV`, `FORM`, `HEADER` and `FOOTER`. This is intended to hide common ad cards/banners without hiding large content sections.

The detector does not depend on generated CSS class names. It will not reliably detect an overlay that has no anchor, iframe or image destination (for example a canvas-only ad, CSS background image, or a click handler that changes `location` without a link). Ineligible or inaccessible frames remain protected by native request filtering where WebView exposes the request.

## Navigation, redirects and popups

Top-level HTTP(S) navigation is checked against `DOCUMENT` rules; the first navigation in a popup tab is checked as `POPUP` using the opener page as the `$domain`/`$third-party` policy context. The actual target URL remains the document URL for `$document` exceptions.

`shouldOverrideUrlLoading(WebView, WebResourceRequest)` uses the Kotlin synthetic Boolean property `request.isRedirect` (Java `isRedirect()`) and the explicit method call `request.hasGesture()` for the block-page reason. `isRedirect()` was added in API 24 and `hasGesture()` in API 21; this app's minSdk is 26. `hasGesture()` is not a JavaBean `getX`/`isX` accessor, so Kotlin must invoke it with parentheses. Request matching in `shouldInterceptRequest` remains a second line of defence for main-frame and subresource requests that reach that callback.

Popup behavior:

- `javaScriptCanOpenWindowsAutomatically` is always `false`, so script-created windows without a user gesture are denied by WebView.
- `setSupportMultipleWindows(true)` enables the app to receive eligible new-window requests through `WebChromeClient.onCreateWindow`.
- `onCreateWindow` rejects the request if DHYRA's popup blocker is enabled or `isUserGesture` is false.
- When popup blocking is disabled, the first HTTP(S) document in a gesture-created popup is still checked against `$popup` rules and can show the blocked page.

The blocked page is generated locally with escaped destination/reason text. Its buttons use the private `dhyra-shields://` scheme, which `WebViewClient` consumes; no JavaScript-to-native bridge is exposed. **Continue once** bypasses the exact blocked destination once. **Whitelist sementara (sesi ini)** sets the destination host's Shields override off for the current controller/session and then continues. The whitelist is in-memory and is not persisted across process restarts.

`shouldOverrideUrlLoading` is not called for every navigation (including app-issued `loadUrl` and POST navigations). It can see page-initiated link/JavaScript navigation and HTTP redirects. For allowed page-initiated HTTP(S) main-frame navigations, this implementation deliberately cancels the callback request and reissues it through the app navigation path so it can register the page-specific document-start script and apply privacy headers before the new document begins. Android's API guidance normally says to return `false` instead of reloading the same URL; this deliberate restart is a compatibility trade-off inherited from DHYRA's header/navigation path and must be tested for history, POST/form behavior, duplicate navigation and latency. POST is not covered by this callback and remains subject to request-interception limitations. `shouldInterceptRequest` is the complementary request hook, but Android documents that for a redirect chain it is called only for the initial resource URL. Do not treat these hooks as a perfect Chromium network interception API.

## Verification

Run from the Android project root:

```bash
./gradlew :app:compileDebugKotlin
./gradlew :app:compileDebugUnitTestKotlin
./gradlew :app:testDebugUnitTest
./gradlew :app:lintDebug
./gradlew :app:assembleDebug
```

Then test on at least one device with a current Android System WebView and one older supported provider:

1. Confirm `WebViewFeature.isFeatureSupported(DOCUMENT_START_SCRIPT)` and compare supported/unsupported behavior.
2. Load a local fixture with CSS selectors, a dynamically inserted anchor, iframe, image, and an open shadow root.
3. Verify host-type separation: document-only host hides anchors, subdocument-only host hides iframes, image-only host hides images, and script-only host hides none of those elements.
4. Verify a link to a blocked host displays the local blocked page; Continue once permits only the exact target once; session whitelist permits the host for the current session.
5. Test redirect chains, meta refresh, `location` navigation, `window.open` with and without a click, and `target="_blank"`.
6. Confirm normal forms/login, CAPTCHA, checkout/payment, news article links and common website navigation are not hidden by destination hints.
7. Record scroll frame timing and CPU while loading a mutation-heavy SPA. Compare the same page with Shields on/off.

## Known limitations and risks

- No full uBlock Origin scriptlet, procedural cosmetic, redirect-resource, CSP or removeparam implementation is included.
- Host-hint export is bounded; path/generic rules still block requests natively but do not necessarily hide their DOM link before click.
- Closed shadow roots and frame contexts whose referrer is withheld cannot be inspected by this script. Open shadow roots are traversed for destination links, but page cosmetic CSS selectors do not pierce shadow-root boundaries.
- Pure canvas/background-image/click-handler overlays without a matching anchor/iframe/image destination are outside the current DOM detector. `<img>` selection checks `currentSrc`/`src`; CSS backgrounds and standalone `<source>` nodes are not independently classified.
- `shouldInterceptRequest` does not expose POST bodies and is not a universal interception point for every WebView resource/redirect.
- Whitelist is session-only; it is not persisted.
- The injected controller marker and DOM attribute are visible to page scripts; cosmetic detection is not a security boundary and sites can evade or remove it. Native request and navigation matching remain authoritative.
- Runtime behavior must be tested with actual Android System WebView providers. JVM/source checks cannot prove document-start availability, WebView navigation ordering or real device jank.
