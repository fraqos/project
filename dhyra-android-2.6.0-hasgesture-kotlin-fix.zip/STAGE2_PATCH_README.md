# DHYRA 2.5.3 — Stage 2 source patch

This archive contains only the files changed for Stage 2. Extract it into the root of the existing DHYRA project and allow the files to overwrite their matching paths.

## Changed files

- `app/build.gradle.kts` — adds `com.google.re2j:re2j:1.9`.
- `app/src/main/java/com/dhyra/browser/core/shields/ShieldsFilterEngine.kt` — bounded RE2/J matching, corrected `$document` page exceptions, safe handling of cosmetic-only exceptions, merged repeated `domain=` scopes, conservative resource classification, and a backward-compatible overload separating popup policy context from the actual document URL.
- `app/src/main/java/com/dhyra/browser/BrowserController.kt` — passes the actual destination page separately for `$document` evaluation during the first popup request while keeping the opener context for `$domain`/`$third-party` rules.
- `app/src/test/java/com/dhyra/browser/ShieldsFilterEngineTest.kt` — regression coverage; `runChecks()` calls all 29 `@Test` methods.
- `THIRD_PARTY_NOTICES.md` — records RE2/J and the Go License notice.
- `CHANGELOG.md` — Stage 2 summary.
- `docs/SHIELDS_STAGE2.md` — supported subset, WebView hook behavior/limits, third-party suffix limitation and verification commands.

## Build and verify

Run from the project root on a machine with the required JDK, Android SDK/Build Tools, Gradle wrapper and Maven Central access:

```bash
./gradlew :app:compileDebugKotlin
./gradlew :app:compileDebugUnitTestKotlin
./gradlew :app:testDebugUnitTest
./gradlew :app:lintDebug
./gradlew :app:assembleDebug
```

The source tree used to make this patch did not contain `gradle-wrapper.jar`, and this execution environment did not have Gradle or Android SDK installed or working Maven DNS. Therefore no successful Android build/APK is claimed. A local Kotlin matcher runner passed using a temporary RE2/J API stub; that validates matcher/test logic and Kotlin compilation only, not the actual RE2/J runtime or Android packaging.
