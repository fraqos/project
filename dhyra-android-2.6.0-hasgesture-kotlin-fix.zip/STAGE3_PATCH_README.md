# DHYRA 2.5.3 — Stage 3 source patch

This patch applies Stage 3 on top of the supplied DHYRA 2.5.3 Stage 2 tree.

## Apply

1. Back up the current project.
2. Extract this ZIP into the project root, preserving the `app/`, `scripts/`, and `docs/` paths.
3. Allow file replacement for the listed Kotlin source/test files and checker script.
4. Run the Gradle verification tasks in `docs/SHIELDS_STAGE3.md` from the Android project root.

This archive contains source and documentation only; it is not a signed APK.

## Main additions

- Document-start, provider-gated local content script and page-finished fallback.
- MutationObserver/RAF batching with bounded DOM traversal and open-shadow-root observation.
- Resource-typed destination hints for document, popup, subdocument and image elements.
- Native top-level navigation checks, blocked interstitial, continue-once and session-only whitelist.
- Regression tests and Stage 3 verification notes.

The patch is a working-tree update. Full Android Gradle test, lint and APK build must be run on a machine with the configured JDK, Android SDK and Gradle distribution available.
