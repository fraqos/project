package com.dhyra.browser.core.performance

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.FrameMetrics
import android.view.Window
import com.dhyra.browser.BuildConfig
import java.util.concurrent.atomic.AtomicLong

/**
 * Debug-only, local frame timing diagnostics. It records durations only—never URLs, page text,
 * cookies, form values or user input. FrameMetrics covers the Activity window, not WebView alone.
 */
class DhyraFrameMetricsMonitor(private val activity: Activity) {
    private val handler = Handler(Looper.getMainLooper())
    private val frameCount = AtomicLong()
    private val slowFrameCount = AtomicLong()
    private val droppedReports = AtomicLong()
    private val totalDurationNanos = AtomicLong()
    private val maxDurationNanos = AtomicLong()
    @Volatile private var running = false

    private val frameListener = Window.OnFrameMetricsAvailableListener { _, metrics, dropped ->
        val duration = runCatching { metrics.getMetric(FrameMetrics.TOTAL_DURATION) }.getOrDefault(0L)
        val refreshRate = activity.window.decorView.display?.refreshRate?.takeIf { it > 0f } ?: 60f
        val frameBudget = (1_000_000_000.0 / refreshRate).toLong()
        frameCount.incrementAndGet()
        droppedReports.addAndGet(dropped.toLong().coerceAtLeast(0L))
        totalDurationNanos.addAndGet(duration.coerceAtLeast(0L))
        if (duration > frameBudget) slowFrameCount.incrementAndGet()
        updateMax(maxDurationNanos, duration)
    }

    fun start() {
        if (!BuildConfig.DEBUG || running) return
        running = true
        runCatching { activity.window.addOnFrameMetricsAvailableListener(frameListener, handler) }
            .onFailure { Log.w(TAG, "Frame metrics could not be enabled", it); running = false }
    }

    fun stop() {
        if (!running) return
        running = false
        runCatching { activity.window.removeOnFrameMetricsAvailableListener(frameListener) }
        val result = snapshot()
        if (result.frames > 0L) {
            Log.i(
                TAG,
                "frames=${result.frames}, slow=${result.slowFrames} " +
                    "(${"%.2f".format(java.util.Locale.ROOT, result.slowFramePercent)}%), " +
                    "droppedReports=${result.droppedReports}, " +
                    "avgMs=${"%.2f".format(java.util.Locale.ROOT, result.averageFrameDurationMillis)}, " +
                    "maxMs=${"%.2f".format(java.util.Locale.ROOT, result.maxFrameDurationMillis)}"
            )
        }
    }

    fun snapshot(): FrameMetricsSnapshot {
        val frames = frameCount.get()
        val slow = slowFrameCount.get()
        return FrameMetricsSnapshot(
            frames = frames,
            slowFrames = slow,
            slowFramePercent = if (frames == 0L) 0.0 else slow * 100.0 / frames,
            droppedReports = droppedReports.get(),
            averageFrameDurationMillis = if (frames == 0L) 0.0 else totalDurationNanos.get() / frames / 1_000_000.0,
            maxFrameDurationMillis = maxDurationNanos.get() / 1_000_000.0
        )
    }

    private fun updateMax(target: AtomicLong, candidate: Long) {
        while (true) {
            val current = target.get()
            if (candidate <= current || target.compareAndSet(current, candidate)) return
        }
    }

    companion object {
        private const val TAG = "DhyraFrameMetrics"
    }
}

data class FrameMetricsSnapshot(
    val frames: Long,
    val slowFrames: Long,
    val slowFramePercent: Double,
    val droppedReports: Long,
    val averageFrameDurationMillis: Double,
    val maxFrameDurationMillis: Double
)
