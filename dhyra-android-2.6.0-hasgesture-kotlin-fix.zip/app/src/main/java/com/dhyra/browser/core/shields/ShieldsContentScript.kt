package com.dhyra.browser.core.shields

/**
 * Builds a local-only WebView content script. The script has no native bridge and performs
 * no network/storage access. It only applies filter CSS and marks elements whose destination
 * host is already blocked by the native network matcher.
 */
object ShieldsContentScript {
    const val MAX_DESTINATION_HOSTS = 128

    fun build(
        expectedPageUrl: String,
        cosmeticCss: String,
        blockedDocumentHosts: Collection<String>,
        blockedPopupHosts: Collection<String> = emptyList(),
        blockedSubdocumentHosts: Collection<String> = emptyList(),
        blockedImageHosts: Collection<String> = emptyList()
    ): String {
        val expectedHost = runCatching { java.net.URI(expectedPageUrl).host?.lowercase() }.getOrNull().orEmpty()
        val cssLiteral = jsString(cosmeticCss.take(64 * 1024))
        fun hostList(hosts: Collection<String>): String = hosts.asSequence()
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() && it.length <= 253 && it.matches(Regex("[a-z0-9.-]+")) }
            .distinct()
            .take(MAX_DESTINATION_HOSTS)
            .joinToString(prefix = "[", postfix = "]") { jsString(it) }
        val documentHosts = hostList(blockedDocumentHosts)
        val popupHosts = hostList(blockedPopupHosts)
        val subdocumentHosts = hostList(blockedSubdocumentHosts)
        val imageHosts = hostList(blockedImageHosts)

        return """
            (function () {
              'use strict';
              var expectedHost = ${jsString(expectedHost)};
              var nextCss = $cssLiteral;
              var nextDocumentHosts = $documentHosts;
              var nextPopupHosts = $popupHosts;
              var nextSubdocumentHosts = $subdocumentHosts;
              var nextImageHosts = $imageHosts;

              // A handler is registered for all origins so cross-origin frames can inspect
              // blocked link destinations. Restrict execution to the target top document or
              // frames whose referrer belongs to that top document. No native object is exposed.
              var mainFrame = false;
              try { mainFrame = window.top === window; } catch (_) { return; }
              var contextHost = '';
              if (mainFrame) {
                contextHost = String(location.hostname || '').toLowerCase();
              } else {
                try { contextHost = String(new URL(document.referrer).hostname || '').toLowerCase(); }
                catch (_) { return; }
              }
              if (!expectedHost || !(contextHost === expectedHost || contextHost.endsWith('.' + expectedHost))) return;
              if (!/^https?:$/i.test(location.protocol)) return;

              var existing = window.__dhyraShieldsController;
              if (existing && typeof existing.update === 'function') {
                existing.update(nextCss, nextDocumentHosts, nextPopupHosts, nextSubdocumentHosts, nextImageHosts, mainFrame);
                return;
              }
              if (!nextCss && nextDocumentHosts.length === 0 && nextPopupHosts.length === 0 &&
                  nextSubdocumentHosts.length === 0 && nextImageHosts.length === 0) return;

              var hiddenAttribute = 'data-dhyra-shields-hidden';
              var cosmeticStyleId = 'dhyra-shields-cosmetic';
              var targetStyleId = 'dhyra-shields-target-style';
              var blockedDocumentHosts = [];
              var blockedPopupHosts = [];
              var blockedSubdocumentHosts = [];
              var blockedImageHosts = [];
              var pending = [];
              var pendingWalkers = [];
              var frameScheduled = false;
              var observedRoots = typeof WeakSet === 'function' ? new WeakSet() : null;
              var observer = typeof MutationObserver === 'function' ? new MutationObserver(onMutations) : null;

              function setStyle(id, css) {
                var style = document.getElementById(id);
                if (!css) {
                  if (style && style.parentNode) style.parentNode.removeChild(style);
                  return;
                }
                if (!style) {
                  var parent = document.head || document.documentElement;
                  if (!parent) {
                    document.addEventListener('DOMContentLoaded', function () { setStyle(id, css); }, { once: true });
                    return;
                  }
                  style = document.createElement('style');
                  style.id = id;
                  style.type = 'text/css';
                  parent.appendChild(style);
                }
                if (style.textContent !== css) style.textContent = css;
              }

              function isBlockedTarget(raw, candidates) {
                if (!raw || !candidates || candidates.length === 0) return false;
                try {
                  var url = new URL(raw, document.baseURI || location.href);
                  if (url.protocol !== 'http:' && url.protocol !== 'https:') return false;
                  var host = String(url.hostname || '').toLowerCase();
                  for (var i = 0; i < candidates.length; i++) {
                    var blocked = candidates[i];
                    if (host === blocked || host.endsWith('.' + blocked)) return true;
                  }
                } catch (_) {}
                return false;
              }

              function containerFor(element) {
                var current = element;
                var viewportWidth = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0, 320);
                var viewportHeight = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0, 240);
                var viewportArea = viewportWidth * viewportHeight;
                for (var depth = 0; current && depth < 4; depth++, current = current.parentElement) {
                  var tag = String(current.tagName || '').toUpperCase();
                  if (tag === 'BODY' || tag === 'HTML' || tag === 'MAIN' || tag === 'ARTICLE' ||
                      tag === 'NAV' || tag === 'FORM' || tag === 'HEADER' || tag === 'FOOTER') break;
                  if (tag !== 'DIV' && tag !== 'ASIDE' && tag !== 'SECTION' && tag !== 'LI') continue;
                  var rect;
                  try { rect = current.getBoundingClientRect(); } catch (_) { continue; }
                  var area = Math.max(0, rect.width) * Math.max(0, rect.height);
                  if (rect.width >= 48 && rect.height >= 24 && area <= viewportArea * 0.45 &&
                      rect.width <= viewportWidth * 0.95 && rect.height <= viewportHeight * 0.85) {
                    var textLength = String(current.textContent || '').trim().length;
                    var linkCount = 0;
                    try { linkCount = current.querySelectorAll('a[href]').length; } catch (_) {}
                    if (textLength <= 1600 && linkCount <= 10) return current;
                  }
                }
                return element;
              }

              function hideElement(element, chooseContainer) {
                if (!element || !element.setAttribute) return;
                var target = chooseContainer ? containerFor(element) : element;
                if (!target.hasAttribute(hiddenAttribute)) target.setAttribute(hiddenAttribute, '1');
              }

              function inspect(element) {
                if (!element || element.nodeType !== 1) return;
                var tag = String(element.tagName || '').toUpperCase();
                if (tag === 'A') {
                  var targetName = String(element.getAttribute('target') || '').trim().toLowerCase();
                  var opensPopup = targetName !== '' && targetName !== '_self' &&
                    targetName !== '_top' && targetName !== '_parent';
                  var anchorHosts = opensPopup ? blockedDocumentHosts.concat(blockedPopupHosts) : blockedDocumentHosts;
                  if (isBlockedTarget(element.getAttribute('href'), anchorHosts)) hideElement(element, true);
                } else if (tag === 'IFRAME' && isBlockedTarget(element.getAttribute('src'), blockedSubdocumentHosts)) {
                  hideElement(element, false);
                } else if (tag === 'IMG' && isBlockedTarget(element.currentSrc || element.getAttribute('src'), blockedImageHosts)) {
                  hideElement(element, true);
                }
                // Observe open shadow roots when the page exposes them. Closed roots cannot be inspected.
                try {
                  if (element.shadowRoot) observeRoot(element.shadowRoot, true);
                } catch (_) {}
              }

              function enqueueRoot(root) {
                if (!root) return;
                if (pending.length >= 1800) pending.splice(0, 300);
                pending.push(root);
                requestFlush();
              }

              function requestFlush() {
                if (frameScheduled) return;
                frameScheduled = true;
                var raf = window.requestAnimationFrame || function (callback) { return window.setTimeout(callback, 16); };
                raf(flush);
              }

              function schedule(node) {
                enqueueRoot(node);
              }

              function flush() {
                frameScheduled = false;
                // Bound both subtree setup and total element work per frame. A large SPA
                // insertion is spread over several frames rather than scanned in one task.
                var roots = 0;
                while (pending.length && roots < 12) {
                  var root = pending.shift();
                  if (root && root.nodeType === 1) inspect(root);
                  try {
                    var walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
                    pendingWalkers.push(walker);
                  } catch (_) {}
                  roots++;
                }
                var budget = 200;
                while (budget > 0 && pendingWalkers.length) {
                  var currentWalker = pendingWalkers[0];
                  var node = currentWalker.nextNode();
                  if (!node) {
                    pendingWalkers.shift();
                    continue;
                  }
                  inspect(node);
                  budget--;
                }
                if (pending.length || pendingWalkers.length) requestFlush();
              }

              function onMutations(records) {
                for (var i = 0; i < records.length; i++) {
                  var record = records[i];
                  if (record.type === 'attributes') {
                    schedule(record.target);
                  } else {
                    for (var j = 0; j < record.addedNodes.length; j++) schedule(record.addedNodes[j]);
                  }
                }
              }

              function observeRoot(root, shouldScan) {
                if (!observer || !root) return;
                try {
                  if (observedRoots && observedRoots.has(root)) return;
                  observer.observe(root, {
                    childList: true,
                    subtree: true,
                    attributes: true,
                    attributeFilter: ['href', 'src', 'target', 'srcset']
                  });
                  if (observedRoots) observedRoots.add(root);
                  if (shouldScan) schedule(root);
                } catch (_) {}
              }

              function update(css, documentHosts, popupHosts, subdocumentHosts, imageHosts, isMainFrame) {
                blockedDocumentHosts = Array.isArray(documentHosts) ? documentHosts.slice(0, ${MAX_DESTINATION_HOSTS}) : [];
                blockedPopupHosts = Array.isArray(popupHosts) ? popupHosts.slice(0, ${MAX_DESTINATION_HOSTS}) : [];
                blockedSubdocumentHosts = Array.isArray(subdocumentHosts) ? subdocumentHosts.slice(0, ${MAX_DESTINATION_HOSTS}) : [];
                blockedImageHosts = Array.isArray(imageHosts) ? imageHosts.slice(0, ${MAX_DESTINATION_HOSTS}) : [];
                // Cosmetic selectors belong to the main document. Destination matching is
                // also used in eligible child frames, so install its tiny marker style there too.
                if (isMainFrame) setStyle(cosmeticStyleId, css);
                setStyle(targetStyleId,
                  '[' + hiddenAttribute + '="1"]{display:none!important;visibility:hidden!important}');
                // Clear prior markings before evaluating a refreshed filter snapshot.
                try {
                  var marked = document.querySelectorAll('[' + hiddenAttribute + '="1"]');
                  for (var i = 0; i < marked.length && i < 1000; i++) marked[i].removeAttribute(hiddenAttribute);
                } catch (_) {}
                schedule(document.documentElement);
              }

              var api = { update: update };
              try {
                Object.defineProperty(window, '__dhyraShieldsController', {
                  value: api, configurable: true, enumerable: false, writable: false
                });
              } catch (_) { window.__dhyraShieldsController = api; }

              if (observer) {
                if (document.documentElement) observeRoot(document.documentElement, false);
                else document.addEventListener('DOMContentLoaded', function () {
                  if (document.documentElement) observeRoot(document.documentElement, false);
                  schedule(document.documentElement);
                }, { once: true });
              }
              update(nextCss, nextDocumentHosts, nextPopupHosts, nextSubdocumentHosts, nextImageHosts, mainFrame);
            })();
        """.trimIndent()
    }

    private fun jsString(value: String): String = buildString(value.length + 2) {
        append('"')
        value.forEach { char ->
            when (char) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\b' -> append("\\b")
                '\u000C' -> append("\\f")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (char.code < 0x20 || char == '\u2028' || char == '\u2029') {
                    append("\\u%04x".format(char.code))
                } else append(char)
            }
        }
        append('"')
    }
}
