package com.dhyra.browser.core.security

import java.net.URI

/** Shared URL trust policy for browser-initiated navigation and privileged page features. */
object DhyraSecurityManager {
    fun isHttpUrl(value: String?): Boolean {
        if (value.isNullOrBlank()) return false
        return runCatching {
            val uri = URI(value)
            uri.scheme?.lowercase() in setOf("http", "https") &&
                !uri.host.isNullOrBlank() && uri.userInfo.isNullOrBlank()
        }.getOrDefault(false)
    }

    fun isHttpsUrl(value: String?): Boolean =
        isHttpUrl(value) && value!!.startsWith("https://", ignoreCase = true)

    fun canUseSecurePageTranslation(value: String?): Boolean = isHttpsUrl(value)

    /**
     * Camera/microphone/geolocation grants are accepted only for secure origins. Loopback HTTP
     * is allowed for local development; arbitrary cleartext origins are not.
     */
    fun canRequestSensitiveWebFeature(origin: String?): Boolean {
        if (origin.isNullOrBlank()) return false
        return runCatching {
            val uri = URI(origin)
            val scheme = uri.scheme?.lowercase() ?: return@runCatching false
            val host = uri.host?.lowercase()?.trimEnd('.') ?: return@runCatching false
            if (uri.userInfo != null || host.isBlank()) return@runCatching false
            scheme == "https" || (scheme == "http" && host in LOOPBACK_HOSTS)
        }.getOrDefault(false)
    }

    private val LOOPBACK_HOSTS = setOf("localhost", "127.0.0.1", "::1", "[::1]")
}
