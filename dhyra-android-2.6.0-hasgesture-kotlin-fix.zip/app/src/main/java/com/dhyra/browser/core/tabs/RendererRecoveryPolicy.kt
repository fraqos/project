package com.dhyra.browser.core.tabs

/**
 * Prevents renderer-crash reload loops. At most [maxAutomaticRecoveries] are attempted per tab
 * during [windowMillis]; explicit user reloads are not restricted by this policy.
 */
class RendererRecoveryPolicy(
    private val maxAutomaticRecoveries: Int = 2,
    private val windowMillis: Long = 120_000L
) {
    private val attemptsByTab = mutableMapOf<Int, ArrayDeque<Long>>()

    @Synchronized
    fun allowAutomaticRecovery(tabId: Int, nowMillis: Long): Boolean {
        val attempts = attemptsByTab.getOrPut(tabId) { ArrayDeque() }
        while (attempts.isNotEmpty() && nowMillis - attempts.first() >= windowMillis) {
            attempts.removeFirst()
        }
        if (attempts.size >= maxAutomaticRecoveries) return false
        attempts.add(nowMillis)
        return true
    }

    @Synchronized
    fun forgetTab(tabId: Int) {
        attemptsByTab.remove(tabId)
    }

    @Synchronized
    fun clear() {
        attemptsByTab.clear()
    }
}
