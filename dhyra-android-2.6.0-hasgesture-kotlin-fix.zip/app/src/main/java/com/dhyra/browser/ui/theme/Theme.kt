package com.dhyra.browser.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One restrained violet brand accent with accessible light/dark contrast. */
private val LightBrandViolet = Color(0xFF6F68C8)
private val DarkBrandViolet = Color(0xFFAAA4FF)
private val LightPrimaryContainer = Color(0xFFECEAFF)
private val DarkPrimaryContainer = Color(0xFF302D55)

/** SPACE tabs use a quiet, dark violet surface to remain distinct without visual noise. */
internal val SpaceTint = Color(0xFF252039)
internal val SpaceText = Color(0xFFE0D9FF)

private val DhyraTypography = Typography(
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 15.sp, fontWeight = FontWeight.Medium)
)

@Composable
internal fun DhyraTheme(
    themeMode: String,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        "Light" -> false
        "Dark" -> true
        else -> androidx.compose.foundation.isSystemInDarkTheme()
    }

    val targetScheme = if (isDark) {
        darkColorScheme(
            primary = DarkBrandViolet,
            onPrimary = Color(0xFF171322),
            primaryContainer = DarkPrimaryContainer,
            onPrimaryContainer = Color(0xFFEAE7FF),
            secondary = DarkBrandViolet,
            onSecondary = Color(0xFF171322),
            tertiary = DarkBrandViolet,
            onTertiary = Color(0xFF171322),
            background = Color(0xFF101116),
            onBackground = Color(0xFFF1F0F7),
            surface = Color(0xFF171820),
            onSurface = Color(0xFFF1F0F7),
            surfaceVariant = Color(0xFF242631),
            onSurfaceVariant = Color(0xFFB9BAC7),
            outline = Color(0xFF555765),
            outlineVariant = Color(0xFF343541),
            error = Color(0xFFFFB4AB),
            onError = Color(0xFF690005),
            surfaceContainerLowest = Color(0xFF101116),
            surfaceContainerLow = Color(0xFF191B24),
            surfaceContainer = Color(0xFF1D1F29),
            surfaceContainerHigh = Color(0xFF252731),
            surfaceContainerHighest = Color(0xFF2B2D37)
        )
    } else {
        lightColorScheme(
            primary = LightBrandViolet,
            onPrimary = Color.White,
            primaryContainer = LightPrimaryContainer,
            onPrimaryContainer = Color(0xFF29264C),
            secondary = LightBrandViolet,
            onSecondary = Color.White,
            tertiary = LightBrandViolet,
            onTertiary = Color.White,
            background = Color(0xFFF7F7FA),
            onBackground = Color(0xFF191922),
            surface = Color(0xFFFFFFFF),
            onSurface = Color(0xFF191922),
            surfaceVariant = Color(0xFFEFEEF4),
            onSurfaceVariant = Color(0xFF626373),
            outline = Color(0xFFD3D2DD),
            outlineVariant = Color(0xFFE2E1E9),
            error = Color(0xFFBA1A1A),
            onError = Color.White,
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = Color(0xFFF8F7FB),
            surfaceContainer = Color(0xFFF1F0F6),
            surfaceContainerHigh = Color(0xFFECEBF2),
            surfaceContainerHighest = Color(0xFFE6E5ED)
        )
    }

    // Animate only the shared surface/brand tokens. This changes Compose colors in place and
    // deliberately avoids AppCompat night-mode recreation, which would tear down WebViews.
    val primary = animateColorAsState(targetScheme.primary, tween(180, easing = FastOutSlowInEasing), label = "themePrimary").value
    val onPrimary = animateColorAsState(targetScheme.onPrimary, tween(180, easing = FastOutSlowInEasing), label = "themeOnPrimary").value
    val primaryContainer = animateColorAsState(targetScheme.primaryContainer, tween(180, easing = FastOutSlowInEasing), label = "themePrimaryContainer").value
    val onPrimaryContainer = animateColorAsState(targetScheme.onPrimaryContainer, tween(180, easing = FastOutSlowInEasing), label = "themeOnPrimaryContainer").value
    val secondary = animateColorAsState(targetScheme.secondary, tween(180, easing = FastOutSlowInEasing), label = "themeSecondary").value
    val onSecondary = animateColorAsState(targetScheme.onSecondary, tween(180, easing = FastOutSlowInEasing), label = "themeOnSecondary").value
    val tertiary = animateColorAsState(targetScheme.tertiary, tween(180, easing = FastOutSlowInEasing), label = "themeTertiary").value
    val onTertiary = animateColorAsState(targetScheme.onTertiary, tween(180, easing = FastOutSlowInEasing), label = "themeOnTertiary").value
    val error = animateColorAsState(targetScheme.error, tween(180, easing = FastOutSlowInEasing), label = "themeError").value
    val onError = animateColorAsState(targetScheme.onError, tween(180, easing = FastOutSlowInEasing), label = "themeOnError").value
    val background = animateColorAsState(targetScheme.background, tween(180, easing = FastOutSlowInEasing), label = "themeBackground").value
    val onBackground = animateColorAsState(targetScheme.onBackground, tween(180, easing = FastOutSlowInEasing), label = "themeOnBackground").value
    val surface = animateColorAsState(targetScheme.surface, tween(180, easing = FastOutSlowInEasing), label = "themeSurface").value
    val onSurface = animateColorAsState(targetScheme.onSurface, tween(180, easing = FastOutSlowInEasing), label = "themeOnSurface").value
    val surfaceVariant = animateColorAsState(targetScheme.surfaceVariant, tween(180, easing = FastOutSlowInEasing), label = "themeSurfaceVariant").value
    val onSurfaceVariant = animateColorAsState(targetScheme.onSurfaceVariant, tween(180, easing = FastOutSlowInEasing), label = "themeOnSurfaceVariant").value
    val outline = animateColorAsState(targetScheme.outline, tween(180, easing = FastOutSlowInEasing), label = "themeOutline").value
    val outlineVariant = animateColorAsState(targetScheme.outlineVariant, tween(180, easing = FastOutSlowInEasing), label = "themeOutlineVariant").value
    val surfaceContainerLowest = animateColorAsState(targetScheme.surfaceContainerLowest, tween(180, easing = FastOutSlowInEasing), label = "themeSurfaceContainerLowest").value
    val surfaceContainerLow = animateColorAsState(targetScheme.surfaceContainerLow, tween(180, easing = FastOutSlowInEasing), label = "themeSurfaceContainerLow").value
    val surfaceContainer = animateColorAsState(targetScheme.surfaceContainer, tween(180, easing = FastOutSlowInEasing), label = "themeSurfaceContainer").value
    val surfaceContainerHigh = animateColorAsState(targetScheme.surfaceContainerHigh, tween(180, easing = FastOutSlowInEasing), label = "themeSurfaceContainerHigh").value
    val surfaceContainerHighest = animateColorAsState(targetScheme.surfaceContainerHighest, tween(180, easing = FastOutSlowInEasing), label = "themeSurfaceContainerHighest").value

    val scheme = targetScheme.copy(
        primary = primary,
        onPrimary = onPrimary,
        primaryContainer = primaryContainer,
        onPrimaryContainer = onPrimaryContainer,
        secondary = secondary,
        onSecondary = onSecondary,
        tertiary = tertiary,
        onTertiary = onTertiary,
        error = error,
        onError = onError,
        background = background,
        onBackground = onBackground,
        surface = surface,
        onSurface = onSurface,
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = onSurfaceVariant,
        outline = outline,
        outlineVariant = outlineVariant,
        surfaceContainerLowest = surfaceContainerLowest,
        surfaceContainerLow = surfaceContainerLow,
        surfaceContainer = surfaceContainer,
        surfaceContainerHigh = surfaceContainerHigh,
        surfaceContainerHighest = surfaceContainerHighest
    )

    val shapes = Shapes(
        extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
        small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        medium = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        large = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(24.dp)
    )

    MaterialTheme(colorScheme = scheme, typography = DhyraTypography, shapes = shapes, content = content)
}
