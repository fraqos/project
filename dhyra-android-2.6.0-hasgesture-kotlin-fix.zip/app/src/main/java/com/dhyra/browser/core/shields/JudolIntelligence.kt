package com.dhyra.browser.core.shields

import java.net.IDN
import java.net.URI
import java.util.Locale

/**
 * Conservative, on-device detector for high-confidence gambling destinations.
 *
 * This is intentionally not a general-purpose content classifier. It evaluates only the URL
 * supplied by the browser, never sends it anywhere, and never blocks from ambiguous path words
 * alone. Exact local block/allow domains take precedence over the heuristic.
 */
class JudolIntelligence(
    blockedDomainRules: Collection<String> = emptyList(),
    allowedDomainRules: Collection<String> = emptyList(),
    private val blockThreshold: Int = DEFAULT_BLOCK_THRESHOLD
) {
    enum class Verdict { ALLOW, REVIEW, BLOCK }

    data class Assessment(
        val host: String?,
        val score: Int,
        val verdict: Verdict,
        val signals: List<String>,
        val exactListMatch: Boolean = false
    ) {
        val shouldBlock: Boolean get() = verdict == Verdict.BLOCK
        fun summary(): String = when (verdict) {
            Verdict.ALLOW -> "No high-confidence gambling signal"
            Verdict.REVIEW -> "Low-confidence gambling-like signals (not blocked)"
            Verdict.BLOCK -> if (exactListMatch) "Matched local gambling-domain list" else "High-confidence gambling-domain score ($score)"
        }
    }

    private val blockedDomains = normalizeRules(blockedDomainRules)
    private val allowedDomains = normalizeRules(allowedDomainRules)

    val blockedDomainCount: Int get() = blockedDomains.size
    val allowedDomainCount: Int get() = allowedDomains.size

    fun evaluate(rawUrl: String): Assessment {
        if (rawUrl.isBlank() || rawUrl.length > MAX_URL_LENGTH) return neutral(null)
        val uri = runCatching { URI(rawUrl) }.getOrNull() ?: return neutral(null)
        val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return neutral(null)
        if (scheme != "http" && scheme != "https") return neutral(null)

        val host = normalizeHost(uri.host ?: authorityHost(uri.rawAuthority)) ?: return neutral(null)
        if (matchesDomain(host, allowedDomains)) {
            return Assessment(host, 0, Verdict.ALLOW, listOf("local-allowlist"), exactListMatch = true)
        }
        if (matchesDomain(host, blockedDomains)) {
            return Assessment(host, 100, Verdict.BLOCK, listOf("local-blocklist"), exactListMatch = true)
        }

        val labels = host.split('.').filter(String::isNotBlank)
        val compactLabels = labels.map { it.filter(Char::isLetterOrDigit) }
        fun token(word: String): Boolean = labels.any { label ->
            label.split(Regex("[^a-z0-9]+" )).any { it == word }
        }
        fun compound(value: String): Boolean = compactLabels.any { it.contains(value) }
        fun has(word: String): Boolean = token(word) || when (word) {
            "judi" -> compound("judionline") || compound("judicasino") || compound("judislot")
            "togel" -> compound("togelonline")
            "slot" -> compound("slotgacor") || compound("slotonline") || compound("slotmaxwin")
            "gacor" -> compound("slotgacor") || compound("maxwingacor")
            "maxwin" -> compound("slotmaxwin") || compound("maxwingacor")
            "casino" -> compound("casinoonline")
            "poker" -> compound("pokeronline")
            else -> false
        }

        var score = 0
        val signals = ArrayList<String>(8)
        fun add(condition: Boolean, points: Int, name: String) {
            if (condition) {
                score += points
                signals += "$name(+$points)"
            }
        }

        val judi = has("judi")
        val togel = has("togel")
        val slot = has("slot")
        val gacor = has("gacor")
        val maxwin = has("maxwin")
        val casino = has("casino")
        val poker = has("poker")
        val online = token("online") || compound("online")

        add(judi, 55, "judi")
        add(togel, 50, "togel")
        add(casino, 35, "casino")
        add(poker, 25, "poker")
        add(slot, 8, "slot-ambiguous")
        add(gacor, 28, "gacor")
        add(maxwin, 48, "maxwin")
        add(online, 15, "online")
        add(has("jackpot"), 12, "jackpot")
        add(has("bet") && (judi || togel || casino || poker || slot), 8, "bet-context")

        // Compound terms carry more weight than ambiguous words seen in normal software/content.
        add(slot && gacor, 50, "slot-gacor-combination")
        add(slot && online, 65, "slot-online-combination")
        add(judi && online, 45, "judi-online-combination")
        add(togel && online, 45, "togel-online-combination")
        add(casino && online, 40, "casino-online-combination")
        add(maxwin && gacor, 20, "maxwin-gacor-combination")

        val path = (uri.rawPath.orEmpty() + "?" + uri.rawQuery.orEmpty()).lowercase(Locale.ROOT)
        val pathSignals = listOf("slot", "togel", "maxwin", "gacor", "casino", "deposit", "withdraw", "bonus")
            .filter { path.contains(it) }
        // URL path/query context can raise REVIEW but never independently produce BLOCK.
        val pathScore = minOf(12, pathSignals.size * 3)
        if (pathScore > 0) {
            score += pathScore
            signals += "url-context(+$pathScore)"
        }

        val hasDomainAnchor = judi || togel || casino || poker || (slot && (gacor || online || maxwin)) || (maxwin && gacor)
        val verdict = when {
            hasDomainAnchor && score >= blockThreshold -> Verdict.BLOCK
            score >= REVIEW_THRESHOLD -> Verdict.REVIEW
            else -> Verdict.ALLOW
        }
        return Assessment(host, score, verdict, signals)
    }

    private fun neutral(host: String?) = Assessment(host, 0, Verdict.ALLOW, emptyList())

    private fun normalizeRules(lines: Collection<String>): Set<String> = lines.asSequence()
        .mapNotNull(::parseDomainRule)
        .toSet()

    private fun parseDomainRule(raw: String): String? {
        var value = raw.trim()
        if (value.isEmpty() || value.startsWith("!") || value.startsWith("#")) return null
        if (value.startsWith("||")) value = value.removePrefix("||")
        if (value.endsWith('^')) value = value.dropLast(1)
        if (value.contains("://") || value.contains('/') || value.contains('*') || value.contains('@')) return null
        return normalizeHost(value)
    }

    private fun normalizeHost(raw: String?): String? {
        if (raw.isNullOrBlank() || raw.length > 253) return null
        val trimmed = raw.trim().trimEnd('.').lowercase(Locale.ROOT)
        if (trimmed.isEmpty() || trimmed.startsWith('[') || trimmed.contains(':')) return null
        val ascii = runCatching { IDN.toASCII(trimmed, IDN.USE_STD3_ASCII_RULES).lowercase(Locale.ROOT) }.getOrNull()
            ?: return null
        if (ascii.length > 253 || ascii.split('.').any { label ->
                label.isEmpty() || label.length > 63 || label.startsWith('-') || label.endsWith('-')
            }) return null
        if (ascii.none { it == '.' }) return null
        if (ascii.matches(Regex("[0-9.]+"))) return null
        return ascii
    }

    private fun authorityHost(authority: String?): String? {
        if (authority.isNullOrBlank()) return null
        val withoutUserInfo = authority.substringAfterLast('@')
        if (withoutUserInfo.startsWith("[")) return null // IP literals are not heuristically classified.
        val host = if (withoutUserInfo.count { it == ':' } == 1 && withoutUserInfo.substringAfterLast(':').all(Char::isDigit)) {
            withoutUserInfo.substringBeforeLast(':')
        } else withoutUserInfo
        return host.takeIf { it.isNotBlank() }
    }

    private fun matchesDomain(host: String, rules: Set<String>): Boolean {
        if (rules.isEmpty()) return false
        // Check only the host itself and its dot-delimited suffixes. This keeps lookup cost
        // proportional to the number of hostname labels, not the number of list entries.
        var start = 0
        while (start < host.length) {
            if (host.substring(start) in rules) return true
            val separator = host.indexOf('.', start)
            if (separator < 0) break
            start = separator + 1
        }
        return false
    }

    companion object {
        const val DEFAULT_BLOCK_THRESHOLD = 85
        const val REVIEW_THRESHOLD = 30
        private const val MAX_URL_LENGTH = 8_192
    }
}
