@file:OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser.ui.components

import com.dhyra.browser.*
import com.dhyra.browser.ui.theme.*
import com.dhyra.browser.ui.screens.*

import androidx.compose.foundation.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Main menu. The top row holds the quick controls, including the Desktop site toggle with a
 * clear On/Off label; everything else is a clean list below it.
 */
@Composable
internal fun MenuSheet(
    inPage: Boolean,
    isPrivate: Boolean,
    desktop: Boolean,
    readerMode: Boolean,
    onDismiss: () -> Unit,
    onToggleDesktop: () -> Unit,
    onNewTab: () -> Unit,
    onNewPrivate: () -> Unit,
    onFind: () -> Unit,
    onTranslate: () -> Unit,
    onReader: () -> Unit,
    onPrint: () -> Unit,
    onQr: () -> Unit,
    onBurnPrivate: () -> Unit,
    onBookmark: () -> Unit,
    onShare: () -> Unit,
    onAddSpeedDial: () -> Unit,
    onBookmarks: () -> Unit,
    onHistory: () -> Unit,
    onDownloads: () -> Unit,
    onSettings: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val sheetState = rememberModalBottomSheetState()
    fun pick(action: () -> Unit) {
        onDismiss()
        action()
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = cs.surface) {
        Column(Modifier.fillMaxWidth().heightIn(max = 720.dp).padding(bottom = 8.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickTile(
                    icon = Icons.Outlined.DesktopWindows,
                    label = if (desktop) "Desktop: On" else "Desktop: Off",
                    active = desktop,
                    enabled = true,
                    modifier = Modifier.weight(1f),
                    onClick = { pick(onToggleDesktop) }
                )
                QuickTile(
                    icon = Icons.Outlined.VisibilityOff,
                    label = "space",
                    active = false,
                    enabled = true,
                    modifier = Modifier.weight(1f),
                    onClick = { pick(onNewPrivate) }
                )
                QuickTile(
                    icon = Icons.Outlined.BookmarkAdd,
                    label = "Bookmark",
                    active = false,
                    enabled = inPage && !isPrivate,
                    modifier = Modifier.weight(1f),
                    onClick = { pick(onBookmark) }
                )
            }
            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                color = cs.outlineVariant
            )
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 460.dp),
                contentPadding = PaddingValues(bottom = 4.dp)
            ) {
                item { MenuRow(Icons.Outlined.Add, "New tab") { pick(onNewTab) } }
                if (!isPrivate) {
                    item { MenuRow(Icons.Outlined.Bookmarks, "Bookmarks") { pick(onBookmarks) } }
                    item { MenuRow(Icons.Outlined.History, "History") { pick(onHistory) } }
                    item { MenuRow(Icons.Outlined.Download, "Downloads") { pick(onDownloads) } }
                }
                if (inPage) {
                    item { MenuRow(Icons.Outlined.FindInPage, "Find in page") { pick(onFind) } }
                    item { MenuRow(Icons.Outlined.Translate, "Translate page") { pick(onTranslate) } }
                    item { MenuRow(Icons.Outlined.MenuBook, if (readerMode) "Exit reader mode" else "Reader mode") { pick(onReader) } }
                    item { MenuRow(Icons.Outlined.Print, "Print / Save as PDF") { pick(onPrint) } }
                    item { MenuRow(Icons.Outlined.QrCode2, "Share QR code") { pick(onQr) } }
                    if (!isPrivate) item { MenuRow(Icons.Outlined.Apps, "Add to speed dial") { pick(onAddSpeedDial) } }
                    item { MenuRow(Icons.Outlined.Share, "Share page") { pick(onShare) } }
                }
                if (isPrivate) item { MenuRow(Icons.Outlined.LocalFireDepartment, "Burn space session") { pick(onBurnPrivate) } }
            }
            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                color = cs.outlineVariant
            )
            // Keep Settings outside the scrolling action list so it remains visible on short screens.
            MenuRow(Icons.Outlined.Settings, "Settings", emphasized = true) { pick(onSettings) }
        }
    }
}

@Composable
private fun QuickTile(
    icon: ImageVector,
    label: String,
    active: Boolean,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val tint = (if (active) cs.primary else cs.onSurface).copy(alpha = if (enabled) 1f else 0.34f)
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(if (active) cs.primary.copy(alpha = 0.2f) else cs.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            lineHeight = 16.sp,
            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
            textAlign = TextAlign.Center,
            color = tint,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun MenuRow(
    icon: ImageVector,
    text: String,
    emphasized: Boolean = false,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp),
        shape = RoundedCornerShape(12.dp),
        color = if (emphasized) cs.primaryContainer.copy(alpha = 0.48f) else androidx.compose.ui.graphics.Color.Transparent
    ) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).heightIn(min = 52.dp).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = if (emphasized) cs.primary else cs.onSurfaceVariant, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(16.dp))
            Text(
                text = text,
                fontSize = 15.sp,
                lineHeight = 21.sp,
                fontWeight = if (emphasized) FontWeight.SemiBold else FontWeight.Normal,
                color = cs.onSurface
            )
        }
    }
}

/** Privacy controls for the open page: how much was blocked and the two global switches. */
@Composable
internal fun ShieldsSheet(
    siteLabel: String,
    blocked: Int,
    tracking: Boolean,
    shieldsEnabled: Boolean,
    popup: Boolean,
    judolProtection: Boolean,
    judolBlockedDomainCount: Int,
    judolAllowedDomainCount: Int,
    networkRuleCount: Int,
    cosmeticRuleCount: Int,
    lastUpdated: String,
    updateRunning: Boolean,
    updateMessage: String,
    onDismiss: () -> Unit,
    onSiteShieldsChange: (Boolean) -> Unit,
    onUpdateLists: () -> Unit,
    onSave: (String, Any) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val sheetState = rememberModalBottomSheetState()
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = cs.surface) {
        Column(
            Modifier.fillMaxWidth().heightIn(max = 760.dp).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)
        ) {
            Row(
                Modifier.padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Outlined.Shield, contentDescription = null, tint = cs.primary)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Shields", fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                    Text(
                        text = siteLabel,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                shape = RoundedCornerShape(18.dp),
                color = cs.surfaceVariant
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text(
                        text = blocked.toString(),
                        fontSize = 30.sp,
                        lineHeight = 38.sp,
                        fontWeight = FontWeight.Light,
                        color = cs.primary
                    )
                    Text(
                        text = if (blocked > 0) "requests blocked on this page" else "Nothing blocked on this page yet",
                        fontSize = 14.sp,
                        lineHeight = 21.sp,
                        color = cs.onSurfaceVariant
                    )
                }
            }
            SwitchRow(
                icon = Icons.Outlined.Shield,
                title = "Shields on this site",
                subtitle = "Override the global tracker setting for this website",
                checked = shieldsEnabled,
                onChange = onSiteShieldsChange
            )
            SwitchRow(
                icon = Icons.Outlined.Shield,
                title = "Block trackers & ads globally",
                subtitle = "Uses global, privacy, annoyance and Indonesian regional lists",
                checked = tracking
            ) { onSave("tracking_protection", it) }
            SwitchRow(
                icon = Icons.Outlined.Shield,
                title = "Block high-confidence gambling sites",
                subtitle = "Local-only domain scoring and your confirmed domain list",
                checked = judolProtection
            ) { onSave("judol_protection", it) }
            Text(
                text = "Local judol list: $judolBlockedDomainCount block domains · $judolAllowedDomainCount allow domains",
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp),
                fontSize = 12.sp,
                color = cs.onSurfaceVariant
            )
            SwitchRow(
                icon = Icons.Outlined.VisibilityOff,
                title = "Block pop-ups",
                subtitle = "Stops pop-up windows from opening",
                checked = popup
            ) { onSave("popup_blocker", it) }
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
                shape = RoundedCornerShape(14.dp),
                color = cs.surfaceVariant.copy(alpha = 0.55f),
                border = BorderStroke(0.5.dp, cs.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Text("Protection lists", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                    Text(
                        text = "$networkRuleCount network rules · $cosmeticRuleCount cosmetic rules",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant
                    )
                    Text("EasyList · EasyPrivacy · Fanboy Annoyance · ABPindo", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    Text("Last updated: $lastUpdated", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    Text(updateMessage, fontSize = 12.sp, color = cs.onSurfaceVariant)
                    OutlinedButton(
                        onClick = onUpdateLists,
                        enabled = !updateRunning,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
                    ) {
                        if (updateRunning) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Updating lists…")
                        } else {
                            Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Update protection lists")
                        }
                    }
                }
            }
            Text(
                text = "dhyra blocks supported network filter rules and cosmetic selectors in Android System WebView. Some service-worker, redirect, scriptlet and browser-internal requests are outside WebView interception.",
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                fontSize = 12.sp,
                lineHeight = 18.sp,
                color = cs.onSurfaceVariant
            )
        }
    }
}
