package com.dhyra.browser.core.tabs

/** Lifecycle labels used by diagnostics and policy tests; WebView references remain in BrowserController. */
enum class DhyraTabLifecycleState {
    ACTIVE,
    BACKGROUND,
    HIBERNATING,
    RESTORING,
    CRASHED,
    DESTROYED
}

/** Device-aware policy for limiting simultaneously live WebViews. */
object DhyraTabMemoryPolicy {
    private const val MIB = 1024L * 1024L
    private const val GIB = 1024L * MIB

    /**
     * Returns a conservative live-WebView cap. A WebView renderer can consume substantially
     * more memory than the Java object, so this intentionally targets 1–3 live instances.
     */
    fun maxLiveWebViews(
        totalMemoryBytes: Long,
        availableMemoryBytes: Long,
        isLowRamDevice: Boolean,
        lowMemory: Boolean,
        memoryClassMb: Int
    ): Int {
        if (isLowRamDevice || lowMemory || memoryClassMb < 192 || availableMemoryBytes < 384L * MIB) {
            return 1
        }
        val highHeadroom = totalMemoryBytes >= 8L * GIB &&
            availableMemoryBytes >= 2L * GIB && memoryClassMb >= 384
        return if (highHeadroom) 3 else 2
    }

    /** Least-recently-used inactive tabs, oldest first. Active tab is never a victim. */
    fun evictionOrder(
        tabIds: List<Int>,
        activeTabId: Int,
        lastAccessedAt: Map<Int, Long>
    ): List<Int> = tabIds
        .asSequence()
        .filter { it != activeTabId }
        .distinct()
        .sortedWith(compareBy<Int> { lastAccessedAt[it] ?: Long.MIN_VALUE }.thenBy { it })
        .toList()

    /** Drop saved WebView Bundles only under meaningful memory pressure/backgrounding. */
    fun shouldDiscardSavedState(trimLevel: Int): Boolean =
        trimLevel >= 15 && trimLevel < 20 || trimLevel >= 40

    /** Maximum in-memory navigation Bundles; snapshots are a cache, not authoritative state. */
    fun maxSavedStateSnapshots(liveWebViewLimit: Int, trimLevel: Int): Int = when {
        shouldDiscardSavedState(trimLevel) -> 0
        shouldHibernateInactiveTabs(trimLevel) -> liveWebViewLimit.coerceIn(1, 3)
        else -> (liveWebViewLimit.coerceIn(1, 3) * 2)
    }

    /** When the app is no longer visible, hibernate all inactive WebViews. */
    fun shouldHibernateInactiveTabs(trimLevel: Int): Boolean = trimLevel >= 20
}
