package com.dhyra.browser.core.shields

import java.net.URI
import java.util.Locale
import com.google.re2j.Pattern as LinearTimePattern

/**
 * Lightweight Adblock Plus-compatible subset for Android System WebView.
 *
 * Supported network syntax:
 * - ||host^ and ||host/path patterns
 * - |start and end| anchors, * wildcards and ^ separator tokens
 * - @@ exceptions (exceptions always win)
 * - subdocument/popup/script/image/stylesheet/font/media/xmlhttprequest/object/ping/websocket
 *   resource options, their ~ exclusions, third-party/~third-party, domain=, match-case,
 *   important, and page-wide @@...$document exceptions
 * - indexed regular expressions through RE2/J (bounded subset; unsupported/unindexable regex is skipped)
 * - Common cosmetic rules: domain##selector, domain#@#selector and generic ##selector
 *
 * It deliberately skips unsupported directives (redirect, scriptlets, removeparam,
 * CSP, procedural cosmetic syntax, etc.) instead of guessing. It is not a full uBlock parser.
 */
class ShieldsFilterEngine(rules: Collection<String>) {
    enum class ResourceType {
        DOCUMENT, SUBDOCUMENT, POPUP, SCRIPT, IMAGE, STYLESHEET, FONT, MEDIA,
        XMLHTTPREQUEST, OBJECT, PING, WEBSOCKET, OTHER
    }

    data class Stats(
        val networkRules: Int,
        val cosmeticRules: Int,
        val skippedRules: Int
    )

    /** Host-only DOM hints, separated so an image-only rule cannot hide an ordinary link. */
    data class DestinationHostHints(
        val documentHosts: List<String>,
        val popupHosts: List<String>,
        val subdocumentHosts: List<String>,
        val imageHosts: List<String>
    ) {
        fun hasAnyHostHints(): Boolean =
            documentHosts.isNotEmpty() || popupHosts.isNotEmpty() ||
                subdocumentHosts.isNotEmpty() || imageHosts.isNotEmpty()

        companion object {
            val EMPTY = DestinationHostHints(emptyList(), emptyList(), emptyList(), emptyList())
        }
    }

    private data class DomainScope(
        val included: Set<String>,
        val excluded: Set<String>
    ) {
        fun matches(host: String): Boolean {
            if (excluded.any { domainMatches(host, it) }) return false
            return included.isEmpty() || included.any { domainMatches(host, it) }
        }
    }

    private data class NetworkRule(
        val host: String?,
        val pattern: String,
        val anchorStart: Boolean,
        val anchorEnd: Boolean,
        val exception: Boolean,
        val includedTypes: Set<ResourceType>,
        val excludedTypes: Set<ResourceType>,
        val thirdParty: Boolean?,
        val domainScope: DomainScope?,
        val matchCase: Boolean,
        val important: Boolean,
        val documentException: Boolean,
        val regex: LinearTimePattern? = null
    ) {
        fun matches(
            requestHost: String,
            pageHost: String,
            hostPathAndQuery: String,
            fullUrl: String,
            type: ResourceType,
            isThirdParty: Boolean
        ): Boolean {
            if (includedTypes.isNotEmpty() && type !in includedTypes) return false
            if (type in excludedTypes) return false
            if (thirdParty != null && thirdParty != isThirdParty) return false
            if (domainScope != null && !domainScope.matches(pageHost)) return false

            val candidate = if (host != null) {
                if (!domainMatches(requestHost, host)) return false
                if (pattern.isEmpty()) return true
                hostPathAndQuery
            } else {
                fullUrl
            }
            return if (regex != null) regex.matcher(fullUrl).find()
            else globMatches(pattern, candidate, anchorStart, anchorEnd, matchCase)
        }
    }

    private data class CosmeticRule(
        val includedDomains: Set<String>,
        val excludedDomains: Set<String>,
        val selector: String,
        val exception: Boolean
    ) {
        fun applies(host: String): Boolean {
            if (excludedDomains.any { domainMatches(host, it) }) return false
            return includedDomains.isEmpty() || includedDomains.any { domainMatches(host, it) }
        }
    }

    private val rulesByHost: Map<String, List<NetworkRule>>
    private val genericByThreeCharKey: Map<Long, List<NetworkRule>>
    private val genericByFourCharKey: Map<Long, List<NetworkRule>>
    private val genericRegexByThreeCharKey: Map<Long, List<NetworkRule>>
    private val genericRegexByFourCharKey: Map<Long, List<NetworkRule>>
    private val genericCosmeticRules: List<CosmeticRule>
    private val cosmeticByDomain: Map<String, List<CosmeticRule>>
    private val destinationHostCache = java.util.concurrent.ConcurrentHashMap<String, DestinationHostHints>()
    private var regexRulesSeen: Int = 0
    val stats: Stats
    val ruleCount: Int get() = stats.networkRules
    val cosmeticRuleCount: Int get() = stats.cosmeticRules

    init {
        val network = ArrayList<NetworkRule>(minOf(rules.size, MAX_NETWORK_RULES))
        val cosmetic = ArrayList<CosmeticRule>()
        var skipped = 0
        val badFilters = rules.asSequence()
            .mapNotNull(::badFilterSignature)
            .toHashSet()

        for (raw in rules) {
            if (network.size >= MAX_NETWORK_RULES && cosmetic.size >= MAX_COSMETIC_RULES) {
                skipped++
                continue
            }
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("!") || line.startsWith("[") || line.startsWith("# ")) continue

            val cosmeticRule = parseCosmeticRule(line)
            if (cosmeticRule != null) {
                if (cosmetic.size < MAX_COSMETIC_RULES) cosmetic += cosmeticRule else skipped++
                continue
            }
            if (line.contains("##") || line.contains("#@#") || line.contains("#$#") || line.contains("#?#")) {
                skipped++
                continue
            }
            if (badFilterSignature(line) != null || network.size >= MAX_NETWORK_RULES) continue
            val parsed = parseNetworkRule(line)
            if (parsed == null || ruleSignature(line) in badFilters ||
                (parsed.host == null && parsed.regex == null && literalIndexKey(parsed.pattern) == null)
            ) {
                skipped++
                continue
            }
            network += parsed
        }

        rulesByHost = network.filter { it.host != null }.groupBy { it.host!! }
        val genericRules = network.filter { it.host == null }
        genericByThreeCharKey = genericRules.mapNotNull { rule ->
            if (rule.regex != null) null else literalIndexKey(rule.pattern)?.takeIf { it.first == 3 }?.let { it.second to rule }
        }.groupBy({ it.first }, { it.second })
        genericByFourCharKey = genericRules.mapNotNull { rule ->
            if (rule.regex != null) null else literalIndexKey(rule.pattern)?.takeIf { it.first == 4 }?.let { it.second to rule }
        }.groupBy({ it.first }, { it.second })
        val regexRules = genericRules.filter { it.regex != null }
        genericRegexByThreeCharKey = regexRules.mapNotNull { rule ->
            regexIndexKey(rule.pattern)?.takeIf { it.first == 3 }?.let { it.second to rule }
        }.groupBy({ it.first }, { it.second })
        genericRegexByFourCharKey = regexRules.mapNotNull { rule ->
            regexIndexKey(rule.pattern)?.takeIf { it.first == 4 }?.let { it.second to rule }
        }.groupBy({ it.first }, { it.second })
        genericCosmeticRules = cosmetic.filter { it.includedDomains.isEmpty() }
        cosmeticByDomain = cosmetic.filter { it.includedDomains.isNotEmpty() }
            .flatMap { rule -> rule.includedDomains.map { it to rule } }
            .groupBy({ it.first }, { it.second })
        stats = Stats(network.size, cosmetic.size, skipped)
    }

    fun shouldBlock(
        url: String,
        pageUrl: String,
        resourceType: ResourceType = ResourceType.OTHER
    ): Boolean = shouldBlock(url, pageUrl, resourceType, pageUrl)

    /**
     * `pageUrl` is the policy context used by `$domain` and `$third-party` (the opener for the
     * first popup document). `documentUrl` is the actual page being loaded and is used only for
     * page-wide `@@...$document` exceptions, so an opener exception cannot whitelist a popup.
     */
    fun shouldBlock(
        url: String,
        pageUrl: String,
        resourceType: ResourceType,
        documentUrl: String
    ): Boolean {
        // Bound parsing and matching work for adversarially long resource URLs. Fail open rather than
        // spending unbounded CPU on a malformed or unusually large URL.
        if (url.length > MAX_URL_LENGTH || pageUrl.length > MAX_URL_LENGTH) return false
        val requestUri = runCatching { URI(url) }.getOrNull() ?: return false
        val pageUri = runCatching { URI(pageUrl) }.getOrNull() ?: return false
        val requestScheme = requestUri.scheme?.lowercase(Locale.ROOT) ?: return false
        if (requestScheme != "http" && requestScheme != "https") return false
        val requestHost = normalizeHost(requestUri.host) ?: return false
        val pageHost = normalizeHost(pageUri.host) ?: return false
        val isThirdParty = registrableDomain(requestHost) != registrableDomain(pageHost)
        val normalizedUrl = if (url.length <= MAX_URL_LENGTH) url else url.take(MAX_URL_LENGTH)

        // ABP @@...$document is a page-level exception, not a DOCUMENT resource filter.
        // During the first popup request, policy context is the opener but documentUrl is the popup.
        if (isDocumentException(documentUrl)) return false

        val hostPathAndQuery = hostPathAndQuery(requestUri)
        val candidates = indexedCandidates(requestHost, normalizedUrl)

        var hasException = false
        var hasRegularBlock = false
        var hasImportantBlock = false
        for (rule in candidates) {
            // $document exceptions are handled against the page URL above, never against an
            // arbitrary subresource that happens to share their URL pattern.
            if (rule.documentException) continue
            if (!rule.matches(requestHost, pageHost, hostPathAndQuery, normalizedUrl, resourceType, isThirdParty)) continue
            when {
                rule.exception -> hasException = true
                rule.important -> hasImportantBlock = true
                else -> hasRegularBlock = true
            }
        }
        // ABP exceptions override regular blocking rules independent of line order,
        // but `$important` rules deliberately cannot be whitelisted by a normal exception.
        return hasImportantBlock || (hasRegularBlock && !hasException)
    }

    private fun isDocumentException(documentUrl: String): Boolean {
        if (documentUrl.length > MAX_URL_LENGTH) return false
        val documentUri = runCatching { URI(documentUrl) }.getOrNull() ?: return false
        val scheme = documentUri.scheme?.lowercase(Locale.ROOT) ?: return false
        if (scheme != "http" && scheme != "https") return false
        val documentHost = normalizeHost(documentUri.host) ?: return false
        val candidates = indexedCandidates(documentHost, documentUrl)
        val path = hostPathAndQuery(documentUri)
        return candidates.any { rule ->
            rule.documentException && rule.matches(
                requestHost = documentHost,
                pageHost = documentHost,
                hostPathAndQuery = path,
                fullUrl = documentUrl,
                type = ResourceType.DOCUMENT,
                isThirdParty = false
            )
        }
    }

    private fun hostPathAndQuery(uri: URI): String = buildString {
        append(uri.rawPath.orEmpty().ifEmpty { "/" })
        uri.rawQuery?.let { append('?').append(it) }
    }

    /** Host-suffix plus mandatory-literal indexes; this keeps request matching off list scans. */
    private fun indexedCandidates(requestHost: String, url: String): LinkedHashSet<NetworkRule> {
        val candidates = LinkedHashSet<NetworkRule>()
        var current = requestHost
        while (current.isNotEmpty()) {
            candidates.addAll(rulesByHost[current].orEmpty())
            val dot = current.indexOf('.')
            if (dot < 0) break
            current = current.substring(dot + 1)
        }
        val normalized = url.lowercase(Locale.ROOT)
        addIndexedCandidates(normalized, GENERIC_MIN_INDEX_LENGTH, genericByThreeCharKey, candidates)
        addIndexedCandidates(normalized, GENERIC_INDEX_LENGTH, genericByFourCharKey, candidates)
        addIndexedCandidates(normalized, GENERIC_MIN_INDEX_LENGTH, genericRegexByThreeCharKey, candidates)
        addIndexedCandidates(normalized, GENERIC_INDEX_LENGTH, genericRegexByFourCharKey, candidates)
        return candidates
    }

    private fun addIndexedCandidates(
        text: String,
        keyLength: Int,
        index: Map<Long, List<NetworkRule>>,
        target: MutableSet<NetworkRule>
    ) {
        if (index.isEmpty() || text.length < keyLength) return
        val seenKeys = HashSet<Long>()
        for (position in 0..text.length - keyLength) {
            val key = packChars(text, position, keyLength)
            if (seenKeys.add(key)) target.addAll(index[key].orEmpty())
        }
    }

    /** CSS selectors from supported EasyList-style cosmetic rules for the current page. */
    fun cosmeticCssFor(pageUrl: String): String {
        val host = runCatching { URI(pageUrl).host }.getOrNull()?.let(::normalizeHost) ?: return ""
        val hidden = LinkedHashSet<String>()
        val exceptions = HashSet<String>()
        val pageRules = LinkedHashSet<CosmeticRule>()
        // Site-specific rules are inserted first so a long global list cannot consume the
        // per-page selector budget before rules written for this exact site or its parents.
        var current = host
        while (current.isNotEmpty()) {
            pageRules.addAll(cosmeticByDomain[current].orEmpty())
            val dot = current.indexOf('.')
            if (dot < 0) break
            current = current.substring(dot + 1)
        }
        pageRules.addAll(genericCosmeticRules)
        for (rule in pageRules) {
            if (!rule.applies(host)) continue
            if (rule.exception) exceptions += rule.selector else hidden += rule.selector
        }
        if (hidden.isEmpty()) return ""
        val declaration = "{display:none!important;visibility:hidden!important}"
        val selectors = StringBuilder(minOf(MAX_COSMETIC_CSS_BYTES, hidden.size * 24))
        var added = 0
        for (selector in hidden) {
            if (selector in exceptions || added >= MAX_COSMETIC_SELECTORS_PER_PAGE) continue
            val extra = selector.length + if (added == 0) 0 else 2
            if (selectors.length + extra + declaration.length > MAX_COSMETIC_CSS_BYTES) break
            if (added > 0) selectors.append(",\n")
            selectors.append(selector)
            added++
        }
        if (added == 0) return ""
        // A comma-separated selector group shares one declaration block. Keeping the CSS valid
        // is important: malformed concatenated rules would silently disable all cosmetic hiding.
        return selectors.append(declaration).toString()
    }

    /**
     * Returns bounded host-only DOM hints derived from the native matcher. Each element class
     * uses only the matching resource types, preventing an image-only rule from hiding an
     * ordinary anchor or a script-only rule from hiding an iframe. This is a cosmetic hint only;
     * native request/navigation matching remains authoritative.
     *
     * Generic and path-only rules are not exported because reducing them to a host would
     * over-hide unrelated links. Candidate inspection is capped for large subscriptions.
     */
    fun blockedDestinationHintsFor(
        pageUrl: String,
        maxHostsPerType: Int = ShieldsContentScript.MAX_DESTINATION_HOSTS
    ): DestinationHostHints {
        val limit = maxHostsPerType.coerceIn(0, ShieldsContentScript.MAX_DESTINATION_HOSTS)
        if (limit == 0 || pageUrl.length > MAX_URL_LENGTH) return DestinationHostHints.EMPTY
        runCatching { URI(pageUrl).host }.getOrNull()?.let(::normalizeHost)
            ?: return DestinationHostHints.EMPTY
        if (isDocumentException(pageUrl)) return DestinationHostHints.EMPTY
        destinationHostCache[pageUrl]?.let { cached ->
            return DestinationHostHints(
                cached.documentHosts.take(limit),
                cached.popupHosts.take(limit),
                cached.subdocumentHosts.take(limit),
                cached.imageHosts.take(limit)
            )
        }

        val documents = LinkedHashSet<String>()
        val popups = LinkedHashSet<String>()
        val subdocuments = LinkedHashSet<String>()
        val images = LinkedHashSet<String>()
        var inspected = 0
        for (host in rulesByHost.keys) {
            if (inspected++ >= MAX_SCRIPT_DESTINATION_CANDIDATES) break
            // Domain-host rules only. Path-only, generic and IPv6 patterns stay native-only.
            if (':' in host) continue
            val destination = "https://$host/"
            if (documents.size < limit && shouldBlock(
                    destination, pageUrl, ResourceType.DOCUMENT, destination
                )) {
                documents += host
            }
            if (popups.size < limit && shouldBlock(
                    destination, pageUrl, ResourceType.POPUP, destination
                )) {
                popups += host
            }
            if (subdocuments.size < limit && shouldBlock(
                    destination, pageUrl, ResourceType.SUBDOCUMENT, pageUrl
                )) {
                subdocuments += host
            }
            if (images.size < limit && shouldBlock(
                    destination, pageUrl, ResourceType.IMAGE, pageUrl
                )) {
                images += host
            }
            if (documents.size >= limit && popups.size >= limit &&
                subdocuments.size >= limit && images.size >= limit
            ) break
        }

        val snapshot = DestinationHostHints(
            documents.toList(), popups.toList(), subdocuments.toList(), images.toList()
        )
        if (destinationHostCache.size >= MAX_DESTINATION_HOST_CACHE_ENTRIES) destinationHostCache.clear()
        destinationHostCache.putIfAbsent(pageUrl, snapshot)
        return destinationHostCache[pageUrl] ?: snapshot
    }

    /** Backwards-compatible document-only host projection for existing diagnostics/tests. */
    fun blockedDestinationHostsFor(
        pageUrl: String,
        maxHosts: Int = ShieldsContentScript.MAX_DESTINATION_HOSTS
    ): List<String> = blockedDestinationHintsFor(pageUrl, maxHosts).documentHosts

    private fun parseNetworkRule(raw: String): NetworkRule? {
        var value = raw.trim()
        if (value.startsWith("@@")) value = value.substring(2)
        val exception = raw.trim().startsWith("@@")
        if (value.isEmpty()) return null

        val optionSeparator = optionSeparator(value)
        val patternPart = if (optionSeparator >= 0) value.substring(0, optionSeparator) else value
        val optionPart = if (optionSeparator >= 0) value.substring(optionSeparator + 1) else ""
        if (patternPart.isEmpty()) return null
        val options = parseOptions(optionPart, exception) ?: return null
        val regex = if (patternPart.length > 2 && patternPart.startsWith('/') && patternPart.endsWith('/')) {
            if (patternPart.length > MAX_REGEX_PATTERN_LENGTH || regexRulesSeen >= MAX_REGEX_RULES) return null
            val expression = patternPart.substring(1, patternPart.length - 1)
            // A mandatory literal lets us use the same URL index as glob rules. Regex patterns
            // without such a literal, or with unsafe alternatives/groups for this index, are
            // skipped rather than forcing every request through a broad regex scan.
            if (regexIndexKey(expression) == null) return null
            val flags = if (options.matchCase) 0 else LinearTimePattern.CASE_INSENSITIVE
            runCatching { LinearTimePattern.compile(expression, flags) }.getOrNull() ?: return null
        } else null
        if (regex != null) regexRulesSeen++

        if (patternPart.startsWith("||")) {
            val body = patternPart.substring(2)
            val hostEnd = body.indexOfFirst { it == '/' || it == '^' || it == '*' || it == '?' || it == '|' }
            val hostToken = if (hostEnd < 0) body else body.substring(0, hostEnd)
            val tail = if (hostEnd < 0) "" else body.substring(hostEnd)
            val host = hostToken.removePrefix("*.").lowercase(Locale.ROOT).trimEnd('.')
            if (!validFilterHost(host)) return null
            return NetworkRule(
                host = host,
                pattern = tail,
                anchorStart = true,
                anchorEnd = false,
                exception = exception,
                includedTypes = options.includedTypes,
                excludedTypes = options.excludedTypes,
                thirdParty = options.thirdParty,
                domainScope = options.domainScope,
                matchCase = options.matchCase,
                important = options.important,
                documentException = options.documentException
            )
        }

        var pattern = if (regex != null) patternPart.substring(1, patternPart.length - 1) else patternPart
        val anchorStart = regex == null && pattern.startsWith('|')
        val anchorEnd = regex == null && pattern.endsWith('|')
        if (anchorStart) pattern = pattern.drop(1)
        if (anchorEnd && pattern.isNotEmpty()) pattern = pattern.dropLast(1)
        if (pattern.isEmpty() || pattern.length > MAX_PATTERN_LENGTH) return null
        return NetworkRule(
            host = null,
            pattern = pattern,
            anchorStart = anchorStart,
            anchorEnd = anchorEnd,
            exception = exception,
            includedTypes = options.includedTypes,
            excludedTypes = options.excludedTypes,
            thirdParty = options.thirdParty,
            domainScope = options.domainScope,
            matchCase = options.matchCase,
            important = options.important,
            documentException = options.documentException,
            regex = regex
        )
    }

    private data class ParsedOptions(
        val includedTypes: Set<ResourceType>,
        val excludedTypes: Set<ResourceType>,
        val thirdParty: Boolean?,
        val domainScope: DomainScope?,
        val matchCase: Boolean,
        val important: Boolean,
        val documentException: Boolean
    )

    private fun parseOptions(raw: String, exception: Boolean): ParsedOptions? {
        if (raw.isBlank()) return ParsedOptions(emptySet(), emptySet(), null, null, false, false, false)
        val included = LinkedHashSet<ResourceType>()
        val excluded = LinkedHashSet<ResourceType>()
        var thirdParty: Boolean? = null
        val includedDomains = LinkedHashSet<String>()
        val excludedDomains = LinkedHashSet<String>()
        var matchCase = false
        var important = false
        var documentException = false
        var hasCosmeticOnlyModifier = false
        for (optionRaw in raw.split(',')) {
            val option = optionRaw.trim().lowercase(Locale.ROOT)
            if (option.isEmpty()) continue
            when {
                option == "third-party" -> thirdParty = true
                option == "~third-party" -> thirdParty = false
                option == "match-case" -> matchCase = true
                option == "important" -> important = true
                option == "all" -> Unit
                option.startsWith("domain=") -> {
                    val parsed = parseDomainScope(option.substringAfter('=')) ?: return null
                    includedDomains += parsed.included
                    excludedDomains += parsed.excluded
                }
                // These are exception-only modifiers. On blocking rules ABP says they have
                // no effect; for the network parser, only an exception `$document` changes
                // network behavior. Cosmetic-only exceptions must not become network allows.
                option == "document" -> documentException = exception
                option == "elemhide" || option == "generichide" || option == "genericblock" -> {
                    if (exception) hasCosmeticOnlyModifier = true
                }
                option == "badfilter" -> return null
                option == "~document" -> return null
                option.startsWith("~") -> {
                    val type = resourceType(option.substring(1)) ?: return null
                    excluded += type
                }
                else -> {
                    val type = resourceType(option) ?: return null
                    included += type
                }
            }
        }
        // This stage does not implement cosmetic-only exception effects. Preserve a combined
        // page-wide document exception, but skip cosmetic-only rules so they cannot whitelist
        // network requests by accident.
        if (exception && hasCosmeticOnlyModifier && !documentException) return null
        val domainScope = if (includedDomains.isNotEmpty() || excludedDomains.isNotEmpty()) {
            DomainScope(includedDomains, excludedDomains)
        } else null
        return ParsedOptions(included, excluded, thirdParty, domainScope, matchCase, important, documentException)
    }

    private fun resourceType(value: String): ResourceType? = when (value) {
        "document" -> ResourceType.DOCUMENT
        "subdocument" -> ResourceType.SUBDOCUMENT
        "popup" -> ResourceType.POPUP
        "script" -> ResourceType.SCRIPT
        "image" -> ResourceType.IMAGE
        "stylesheet" -> ResourceType.STYLESHEET
        "font" -> ResourceType.FONT
        "media" -> ResourceType.MEDIA
        "xmlhttprequest" -> ResourceType.XMLHTTPREQUEST
        "object", "object-subrequest" -> ResourceType.OBJECT
        "ping" -> ResourceType.PING
        "websocket" -> ResourceType.WEBSOCKET
        "other" -> ResourceType.OTHER
        else -> null
    }

    private fun parseDomainScope(value: String): DomainScope? {
        val included = LinkedHashSet<String>()
        val excluded = LinkedHashSet<String>()
        for (entryRaw in value.split('|')) {
            val entry = entryRaw.trim().lowercase(Locale.ROOT)
            if (entry.isEmpty()) continue
            val excludedEntry = entry.startsWith('~')
            val domain = (if (excludedEntry) entry.substring(1) else entry).trimStart('.')
            if (!validFilterHost(domain)) return null
            if (excludedEntry) excluded += domain else included += domain
        }
        return DomainScope(included, excluded)
    }

    private fun parseCosmeticRule(line: String): CosmeticRule? {
        val exceptionIndex = line.indexOf("#@#")
        val hideIndex = line.indexOf("##")
        val isException = exceptionIndex >= 0 && (hideIndex < 0 || exceptionIndex < hideIndex)
        val markerIndex = if (isException) exceptionIndex else hideIndex
        if (markerIndex < 0) return null
        val markerLength = if (isException) 3 else 2
        val domainPart = line.substring(0, markerIndex)
        val selector = line.substring(markerIndex + markerLength).trim()
        if (!isSafeSelector(selector)) return null
        val included = LinkedHashSet<String>()
        val excluded = LinkedHashSet<String>()
        for (entryRaw in domainPart.split(',')) {
            val entry = entryRaw.trim().lowercase(Locale.ROOT)
            if (entry.isEmpty()) continue
            val isExcluded = entry.startsWith('~')
            val domain = (if (isExcluded) entry.substring(1) else entry).trimStart('.')
            if (!validFilterHost(domain)) return null
            if (isExcluded) excluded += domain else included += domain
        }
        return CosmeticRule(included, excluded, selector, isException)
    }

    private fun isSafeSelector(selector: String): Boolean =
        selector.isNotBlank() && selector.length <= MAX_SELECTOR_LENGTH &&
            selector.none { it == '{' || it == '}' || it == '<' || it == '\n' || it == '\r' || it == '\u0000' } &&
            !selector.contains("+js", ignoreCase = true)

    private fun badFilterSignature(line: String): String? {
        val value = line.trim()
        val hasExceptionPrefix = value.startsWith("@@")
        val normalizedValue = if (hasExceptionPrefix) value.substring(2) else value
        val separator = optionSeparator(normalizedValue)
        if (separator < 0) return null
        val options = normalizedValue.substring(separator + 1).split(',').map { it.trim() }
        if (options.none { it.equals("badfilter", ignoreCase = true) }) return null
        return ruleSignature(value)
    }

    /** Canonicalize option order so ABP badfilter disables the same rule regardless of spacing/order. */
    private fun ruleSignature(line: String): String {
        val value = line.trim()
        val prefix = if (value.startsWith("@@")) "@@" else ""
        val normalizedValue = if (prefix.isNotEmpty()) value.substring(2) else value
        val separator = optionSeparator(normalizedValue)
        if (separator < 0) return value.lowercase(Locale.ROOT)
        val patternRaw = prefix + normalizedValue.substring(0, separator).trim()
        val options = normalizedValue.substring(separator + 1).split(',')
            .map { it.trim().lowercase(Locale.ROOT) }
            .filter { it.isNotEmpty() && it != "badfilter" }
            .sorted()
        val pattern = if ("match-case" in options) patternRaw else patternRaw.lowercase(Locale.ROOT)
        return if (options.isEmpty()) pattern else "$pattern\$${options.joinToString(",")}"
    }

    /** A trailing slash closes a bare regex; a `$` inside that regex is not an option delimiter. */
    private fun optionSeparator(value: String): Int =
        if (value.startsWith('/') && value.endsWith('/')) -1 else value.lastIndexOf('$')

    private fun literalIndexKey(pattern: String): Pair<Int, Long>? {
        val chunks = pattern.split('*', '^', '|')
        val best = chunks.maxByOrNull { it.length }?.trim().orEmpty()
        if (best.length < GENERIC_MIN_INDEX_LENGTH) return null
        val length = minOf(GENERIC_INDEX_LENGTH, best.length)
        return length to packChars(best.lowercase(Locale.ROOT), best.length - length, length)
    }

    /**
     * Extract a guaranteed literal index from a regex without interpreting optional groups as
     * mandatory. Alternatives at top level are skipped because a single literal would miss a
     * valid alternative. This deliberately favors correctness over accepting every regex.
     */
    private fun regexIndexKey(expression: String): Pair<Int, Long>? {
        var best = ""
        val run = StringBuilder()
        var inClass = false
        var groupDepth = 0
        var index = 0

        fun flush() {
            if (run.length > best.length) best = run.toString()
            run.setLength(0)
        }

        while (index < expression.length) {
            val char = expression[index]
            if (char == '\\' && index + 1 < expression.length) {
                val escaped = expression[index + 1]
                if (groupDepth == 0 && !inClass && escaped !in "dDsSwWpPbBAzZGQEk") {
                    run.append(escaped)
                } else {
                    flush()
                }
                index += 2
                continue
            }
            if (inClass) {
                if (char == ']') inClass = false
                index++
                continue
            }
            when (char) {
                '[' -> { flush(); inClass = true }
                '(' -> { flush(); groupDepth++ }
                ')' -> { flush(); groupDepth = (groupDepth - 1).coerceAtLeast(0) }
                '|' -> {
                    flush()
                    if (groupDepth == 0) return null
                }
                '*', '?' -> {
                    // The immediately preceding atom may occur zero times. Drop its last
                    // literal character from the index candidate before flushing the rest.
                    if (groupDepth == 0 && run.isNotEmpty()) run.setLength(run.length - 1)
                    flush()
                }
                '{' -> {
                    val quantifier = expression.substring(index + 1).substringBefore('}')
                    if (groupDepth == 0 && quantifier.startsWith('0') && run.isNotEmpty()) {
                        run.setLength(run.length - 1)
                    }
                    flush()
                }
                '.', '^', '$', '+', '}' -> flush()
                else -> if (groupDepth == 0) run.append(char) else flush()
            }
            index++
        }
        flush()
        if (best.length < GENERIC_MIN_INDEX_LENGTH) return null
        val length = minOf(GENERIC_INDEX_LENGTH, best.length)
        return length to packChars(best.lowercase(Locale.ROOT), best.length - length, length)
    }

    /** Pack 3/4 UTF-16 code units into a primitive Long key without allocating substrings. */
    private fun packChars(value: CharSequence, start: Int, length: Int): Long {
        var packed = 0L
        for (offset in 0 until length) {
            packed = (packed shl 16) or value[start + offset].lowercaseChar().code.toLong()
        }
        return packed
    }

    private fun validFilterHost(host: String): Boolean = host.isNotBlank() && host.length <= 253 &&
        host.all { it.isLetterOrDigit() || it == '.' || it == '-' } &&
        !host.startsWith('.') && !host.endsWith('.') && ".." !in host

    private fun normalizeHost(host: String?): String? = host?.lowercase(Locale.ROOT)?.trimEnd('.')
        ?.takeIf { it.isNotBlank() }

    // This suffix set is intentionally only a temporary best-effort approximation. It is not
    // the Public Suffix List and must not be treated as authoritative for uncommon/private suffixes.
    private fun registrableDomain(host: String): String {
        if (host.isBlank() || host.startsWith('[') || host.matches(Regex("\\d{1,3}(\\.\\d{1,3}){3}"))) return host
        val labels = host.split('.')
        if (labels.size <= 2) return host
        val suffix = labels.takeLast(2).joinToString(".")
        val count = if (suffix in TWO_PART_PUBLIC_SUFFIXES && labels.size >= 3) 3 else 2
        return labels.takeLast(count).joinToString(".")
    }

    companion object {
        private const val MAX_NETWORK_RULES = 220_000
        private const val MAX_COSMETIC_RULES = 80_000
        private const val MAX_COSMETIC_SELECTORS_PER_PAGE = 700
        private const val MAX_COSMETIC_CSS_BYTES = 64 * 1024
        private const val MAX_SELECTOR_LENGTH = 600
        private const val MAX_PATTERN_LENGTH = 2_048
        private const val MAX_REGEX_PATTERN_LENGTH = 512
        private const val MAX_REGEX_RULES = 1_024
        private const val MAX_URL_LENGTH = 8_192
        private const val MAX_SCRIPT_DESTINATION_CANDIDATES = 8_192
        private const val MAX_DESTINATION_HOST_CACHE_ENTRIES = 128
        private const val GENERIC_INDEX_LENGTH = 4
        private const val GENERIC_MIN_INDEX_LENGTH = 3
        // Small fallback set, not a complete PSL. Stage 2 deliberately avoids claiming exact
        // first/third-party classification until a versioned, locally bundled PSL is integrated.
        private val TWO_PART_PUBLIC_SUFFIXES = setOf(
            "co.uk", "org.uk", "gov.uk", "ac.uk", "com.au", "net.au", "org.au", "co.jp",
            "co.id", "or.id", "ac.id", "go.id", "com.br", "com.cn", "com.hk", "com.sg",
            "com.tw", "co.nz", "co.za", "com.mx", "com.tr", "com.my", "com.ph", "com.ar"
        )

        /**
         * A popup's first destination must be evaluated in the context of the page that opened it.
         * Later navigation is evaluated against the popup tab's own current page URL.
         */
        fun filteringPageUrl(destinationPageUrl: String, openerPageUrl: String?, isPopupNavigation: Boolean): String {
            if (!isPopupNavigation || openerPageUrl.isNullOrBlank()) return destinationPageUrl
            val scheme = runCatching { URI(openerPageUrl).scheme?.lowercase(Locale.ROOT) }.getOrNull()
            return if (scheme == "http" || scheme == "https") openerPageUrl else destinationPageUrl
        }

        /** Resource type inference from the WebView request headers and URL. */
        @Suppress("UNUSED_PARAMETER") // HTTP method alone cannot distinguish a form POST from fetch/XHR.
        fun classifyRequest(
            url: String,
            isMainFrame: Boolean,
            method: String,
            headers: Map<String, String>,
            isPopup: Boolean = false
        ): ResourceType {
            if (isMainFrame) return if (isPopup) ResourceType.POPUP else ResourceType.DOCUMENT
            fun header(name: String): String = headers.entries.firstOrNull { it.key.equals(name, true) }?.value.orEmpty().lowercase(Locale.ROOT)
            // Best-effort classification only: Android System WebView does not guarantee that
            // every ping or WebSocket handshake is surfaced to shouldInterceptRequest.
            if (header("Upgrade") == "websocket" || header("Sec-WebSocket-Key").isNotEmpty()) {
                return ResourceType.WEBSOCKET
            }
            if (header("Ping-From").isNotEmpty() || header("Ping-To").isNotEmpty()) {
                return ResourceType.PING
            }
            val destination = header("Sec-Fetch-Dest")
            when (destination) {
                "document" -> return ResourceType.DOCUMENT
                "iframe", "frame" -> return ResourceType.SUBDOCUMENT
                "script" -> return ResourceType.SCRIPT
                "image" -> return ResourceType.IMAGE
                "style" -> return ResourceType.STYLESHEET
                "font" -> return ResourceType.FONT
                "audio", "video", "track" -> return ResourceType.MEDIA
                "object", "embed" -> return ResourceType.OBJECT
                // Fetch/XHR expose an empty destination. `no-cors` fetch requests can also
                // use `empty`, so do not require the mode to be exactly `cors`.
                "empty" -> return ResourceType.XMLHTTPREQUEST
            }
            val accept = header("Accept")
            val path = runCatching { URI(url).path.orEmpty().lowercase(Locale.ROOT) }.getOrDefault("")
            return when {
                accept.contains("text/html") -> ResourceType.SUBDOCUMENT
                accept.contains("text/css") || path.endsWith(".css") -> ResourceType.STYLESHEET
                accept.contains("image/") || path.endsWithAny(".png", ".jpg", ".jpeg", ".gif", ".webp", ".avif", ".svg", ".ico") -> ResourceType.IMAGE
                accept.contains("javascript") || path.endsWithAny(".js", ".mjs", ".cjs") -> ResourceType.SCRIPT
                accept.contains("font/") || path.endsWithAny(".woff", ".woff2", ".ttf", ".otf", ".eot") -> ResourceType.FONT
                accept.contains("audio/") || accept.contains("video/") || path.endsWithAny(".mp4", ".webm", ".mp3", ".m4a", ".ogg", ".m3u8", ".mpd") -> ResourceType.MEDIA
                else -> ResourceType.OTHER
            }
        }

        fun isThirdParty(requestUrl: String, pageUrl: String): Boolean {
            val requestHost = runCatching { URI(requestUrl).host }.getOrNull()?.lowercase(Locale.ROOT) ?: return false
            val pageHost = runCatching { URI(pageUrl).host }.getOrNull()?.lowercase(Locale.ROOT) ?: return false
            fun site(host: String): String {
                if (host.startsWith('[') || host.matches(Regex("\\d{1,3}(\\.\\d{1,3}){3}"))) return host
                val labels = host.trimEnd('.').split('.')
                if (labels.size <= 2) return host
                val suffix = labels.takeLast(2).joinToString(".")
                return labels.takeLast(if (suffix in TWO_PART_PUBLIC_SUFFIXES && labels.size >= 3) 3 else 2).joinToString(".")
            }
            return site(requestHost) != site(pageHost)
        }

        private fun globMatches(pattern: String, text: String, anchorStart: Boolean, anchorEnd: Boolean, matchCase: Boolean): Boolean {
            if (anchorStart) return globAt(pattern, text, 0, anchorEnd, matchCase)
            for (start in 0..text.length) {
                if (globAt(pattern, text, start, anchorEnd, matchCase)) return true
            }
            return false
        }

        /** Greedy wildcard matcher with one backtracking star; '^' is an ABP separator token. */
        private fun globAt(pattern: String, text: String, start: Int, anchorEnd: Boolean, matchCase: Boolean): Boolean {
            var p = 0
            var t = start
            var lastStar = -1
            var starText = -1
            while (true) {
                // Unanchored filters match as soon as their pattern is consumed; an explicit
                // trailing | requires the rest of the URL to be consumed by the pattern.
                if (p >= pattern.length) {
                    if (!anchorEnd || t == text.length) return true
                    if (lastStar >= 0) {
                        p = lastStar + 1
                        starText++
                        t = starText
                        continue
                    }
                    return false
                }
                if (t >= text.length) {
                    if (pattern[p] == '*') {
                        p++
                        continue
                    }
                    if (pattern[p] == '^' && p == pattern.lastIndex) return true
                    if (lastStar >= 0) {
                        p = lastStar + 1
                        starText++
                        t = starText
                        continue
                    }
                    return false
                }
                if (tokenMatches(pattern[p], text[t], matchCase)) {
                    p++
                    t++
                } else if (pattern[p] == '*') {
                    lastStar = p++
                    starText = t
                } else if (lastStar >= 0) {
                    p = lastStar + 1
                    starText++
                    t = starText
                } else {
                    return false
                }
            }
        }

        private fun tokenMatches(patternChar: Char, textChar: Char, matchCase: Boolean): Boolean = when (patternChar) {
            '*' -> false
            '^' -> textChar.isAbpSeparator()
            else -> if (matchCase) patternChar == textChar else patternChar.lowercaseChar() == textChar.lowercaseChar()
        }

        private fun Char.isAbpSeparator(): Boolean = !(isLetterOrDigit() || this == '_' || this == '-' || this == '.' || this == '%')
        private fun String.endsWithAny(vararg suffixes: String): Boolean = suffixes.any(::endsWith)
        private fun domainMatches(host: String, domain: String): Boolean = host == domain || host.endsWith(".$domain")
    }
}
