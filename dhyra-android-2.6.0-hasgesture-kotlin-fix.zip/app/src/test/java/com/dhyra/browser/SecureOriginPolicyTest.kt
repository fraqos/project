package com.dhyra.browser

import com.dhyra.browser.core.security.DhyraSecurityManager
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SecureOriginPolicyTest {
    @Test fun secureWebOriginsCanRequestSensitiveFeatures() {
        assertTrue(DhyraSecurityManager.canRequestSensitiveWebFeature("https://example.com"))
    }

    @Test fun onlyLoopbackHttpIsAllowedForDevelopment() {
        assertTrue(DhyraSecurityManager.canRequestSensitiveWebFeature("http://localhost:8080"))
        assertTrue(DhyraSecurityManager.canRequestSensitiveWebFeature("http://127.0.0.1:3000"))
        assertTrue(DhyraSecurityManager.canRequestSensitiveWebFeature("http://[::1]:3000"))
        assertFalse(DhyraSecurityManager.canRequestSensitiveWebFeature("http://example.com"))
    }

    @Test fun malformedAndCredentialedOriginsAreRejected() {
        assertFalse(DhyraSecurityManager.canRequestSensitiveWebFeature(null))
        assertFalse(DhyraSecurityManager.canRequestSensitiveWebFeature("not a url"))
        assertFalse(DhyraSecurityManager.canRequestSensitiveWebFeature("https://user:pass@example.com"))
        assertFalse(DhyraSecurityManager.canRequestSensitiveWebFeature("file:///tmp/page.html"))
    }

    fun runChecks() {
        secureWebOriginsCanRequestSensitiveFeatures()
        onlyLoopbackHttpIsAllowedForDevelopment()
        malformedAndCredentialedOriginsAreRejected()
    }
}
