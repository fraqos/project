package com.dhyra.browser

import com.dhyra.browser.core.tabs.RendererRecoveryPolicy
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RendererRecoveryPolicyTest {
    @Test fun permitsOnlyConfiguredAutomaticRetriesWithinWindow() {
        val policy = RendererRecoveryPolicy(maxAutomaticRecoveries = 2, windowMillis = 60_000)
        assertTrue(policy.allowAutomaticRecovery(7, 1_000))
        assertTrue(policy.allowAutomaticRecovery(7, 2_000))
        assertFalse(policy.allowAutomaticRecovery(7, 3_000))
        assertTrue(policy.allowAutomaticRecovery(7, 62_000))
    }

    @Test fun tabsHaveIndependentRecoveryBudgets() {
        val policy = RendererRecoveryPolicy(maxAutomaticRecoveries = 1, windowMillis = 60_000)
        assertTrue(policy.allowAutomaticRecovery(1, 1_000))
        assertTrue(policy.allowAutomaticRecovery(2, 1_000))
        assertFalse(policy.allowAutomaticRecovery(1, 1_001))
    }

    @Test fun closedTabCanBeForgotten() {
        val policy = RendererRecoveryPolicy(maxAutomaticRecoveries = 1, windowMillis = 60_000)
        assertTrue(policy.allowAutomaticRecovery(5, 1_000))
        policy.forgetTab(5)
        assertTrue(policy.allowAutomaticRecovery(5, 1_001))
    }

    fun runChecks() {
        permitsOnlyConfiguredAutomaticRetriesWithinWindow()
        tabsHaveIndependentRecoveryBudgets()
        closedTabCanBeForgotten()
    }
}
