package com.dhyra.browser

import com.dhyra.browser.core.tabs.DhyraTabMemoryPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TabMemoryPolicyTest {
    @Test fun lowRamDevicesKeepOneLiveWebView() {
        assertEquals(1, DhyraTabMemoryPolicy.maxLiveWebViews(
            totalMemoryBytes = 2L * 1024 * 1024 * 1024,
            availableMemoryBytes = 900L * 1024 * 1024,
            isLowRamDevice = true,
            lowMemory = false,
            memoryClassMb = 256
        ))
    }

    @Test fun normalDevicesKeepTwoLiveWebViews() {
        assertEquals(2, DhyraTabMemoryPolicy.maxLiveWebViews(
            totalMemoryBytes = 6L * 1024 * 1024 * 1024,
            availableMemoryBytes = 900L * 1024 * 1024,
            isLowRamDevice = false,
            lowMemory = false,
            memoryClassMb = 256
        ))
    }

    @Test fun highHeadroomDevicesMayKeepThreeLiveWebViews() {
        assertEquals(3, DhyraTabMemoryPolicy.maxLiveWebViews(
            totalMemoryBytes = 12L * 1024 * 1024 * 1024,
            availableMemoryBytes = 3L * 1024 * 1024 * 1024,
            isLowRamDevice = false,
            lowMemory = false,
            memoryClassMb = 512
        ))
    }

    @Test fun activeTabIsNeverAnEvictionCandidateAndOthersAreLru() {
        assertEquals(
            listOf(2, 3, 1),
            DhyraTabMemoryPolicy.evictionOrder(
                tabIds = listOf(1, 2, 3, 4),
                activeTabId = 4,
                lastAccessedAt = mapOf(1 to 30L, 2 to 10L, 3 to 20L, 4 to 1L)
            )
        )
    }

    @Test fun savedStateCacheIsBoundedAndDroppedUnderPressure() {
        assertEquals(6, DhyraTabMemoryPolicy.maxSavedStateSnapshots(3, 0))
        assertEquals(2, DhyraTabMemoryPolicy.maxSavedStateSnapshots(2, 20))
        assertEquals(0, DhyraTabMemoryPolicy.maxSavedStateSnapshots(2, 40))
    }

    @Test fun backgroundAndCriticalTrimPoliciesAreConservative() {
        assertFalse(DhyraTabMemoryPolicy.shouldDiscardSavedState(10))
        assertTrue(DhyraTabMemoryPolicy.shouldDiscardSavedState(15))
        assertFalse(DhyraTabMemoryPolicy.shouldDiscardSavedState(20))
        assertTrue(DhyraTabMemoryPolicy.shouldDiscardSavedState(40))
        assertFalse(DhyraTabMemoryPolicy.shouldHibernateInactiveTabs(15))
        assertTrue(DhyraTabMemoryPolicy.shouldHibernateInactiveTabs(20))
    }

    fun runChecks() {
        lowRamDevicesKeepOneLiveWebView()
        normalDevicesKeepTwoLiveWebViews()
        highHeadroomDevicesMayKeepThreeLiveWebViews()
        activeTabIsNeverAnEvictionCandidateAndOthersAreLru()
        savedStateCacheIsBoundedAndDroppedUnderPressure()
        backgroundAndCriticalTrimPoliciesAreConservative()
    }
}
