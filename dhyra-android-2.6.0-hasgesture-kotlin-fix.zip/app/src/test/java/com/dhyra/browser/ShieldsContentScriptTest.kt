package com.dhyra.browser

import com.dhyra.browser.core.shields.ShieldsContentScript
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ShieldsContentScriptTest {
    @Test
    fun scriptCarriesOnlyLocalRulesAndNoNativeBridgeOrNetworkCalls() {
        val script = ShieldsContentScript.build(
            expectedPageUrl = "https://publisher.test/article",
            cosmeticCss = ".ad-box{display:none!important}",
            blockedDocumentHosts = listOf("casino.test", "slot.test"),
            blockedPopupHosts = listOf("popup-only.test"),
            blockedSubdocumentHosts = listOf("frame-ad.test"),
            blockedImageHosts = listOf("image-ad.test")
        )
        assertTrue(script.contains("publisher.test"))
        assertTrue(script.contains("casino.test"))
        assertTrue(script.contains("popup-only.test"))
        assertTrue(script.contains("frame-ad.test"))
        assertTrue(script.contains("opensPopup"))
        assertTrue(script.contains("targetName !== '_self'"))
        assertTrue(script.contains("element.currentSrc || element.getAttribute('src')"))
        assertTrue(script.contains("'srcset'"))
        assertTrue(script.contains("image-ad.test"))
        assertTrue(script.contains("MutationObserver"))
        assertTrue(script.contains("requestAnimationFrame"))
        assertTrue(script.contains("document.createTreeWalker"))
        assertTrue(script.contains("data-dhyra-shields-hidden"))
        assertTrue(script.contains("setStyle(targetStyleId"))
        assertFalse(script.contains("addJavascriptInterface"))
        assertFalse(script.contains("fetch("))
        assertFalse(script.contains("XMLHttpRequest"))
        assertFalse(script.contains("sendBeacon"))
    }

    @Test
    fun scriptEscapesUntrustedCssAndLimitsDestinationHosts() {
        val script = ShieldsContentScript.build(
            expectedPageUrl = "https://publisher.test/",
            cosmeticCss = "x{content:\"quoted\"}\\n</script>",
            blockedDocumentHosts = (1..200).map { "host-$it.test" }
        )
        assertTrue(script.contains("\\\"quoted\\\""))
        assertTrue(script.contains("host-128.test"))
        assertFalse(script.contains("host-129.test"))
    }
    fun runChecks() {
        scriptCarriesOnlyLocalRulesAndNoNativeBridgeOrNetworkCalls()
        scriptEscapesUntrustedCssAndLimitsDestinationHosts()
    }

    @Test
    fun junitSuite() = runChecks()

}
