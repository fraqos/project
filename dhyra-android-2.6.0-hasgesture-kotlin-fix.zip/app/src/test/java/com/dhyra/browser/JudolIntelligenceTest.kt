package com.dhyra.browser

import com.dhyra.browser.core.shields.JudolIntelligence
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class JudolIntelligenceTest {
    private val detector = JudolIntelligence()

    @Test
    fun blocksHighConfidenceCompoundGamblingDomains() {
        assertEquals(JudolIntelligence.Verdict.BLOCK, detector.evaluate("https://slot-gacor.example/").verdict)
        assertEquals(JudolIntelligence.Verdict.BLOCK, detector.evaluate("https://judionline.example/promo").verdict)
        assertEquals(JudolIntelligence.Verdict.BLOCK, detector.evaluate("https://togelonline.example/").verdict)
        assertEquals(JudolIntelligence.Verdict.BLOCK, detector.evaluate("https://casinoonline.example/").verdict)
    }

    @Test
    fun ambiguousTermsDoNotBlockLegitimateDestinations() {
        val urls = listOf(
            "https://docs.example/slot-ram/",
            "https://analytics.example/scatter-plot/",
            "https://news.example/berita/judi-online/",
            "https://brand-toto.example/about/",
            "https://developer.example/rtp-protocol/",
            "https://game.example/slot/"
        )
        urls.forEach { url -> assertFalse("Unexpected block for $url", detector.evaluate(url).shouldBlock) }
    }

    @Test
    fun singleWeakDomainTermsOnlyRequestReview() {
        assertEquals(JudolIntelligence.Verdict.REVIEW, detector.evaluate("https://maxwin.example/").verdict)
        assertEquals(JudolIntelligence.Verdict.REVIEW, detector.evaluate("https://casino.example/").verdict)
        assertEquals(JudolIntelligence.Verdict.ALLOW, detector.evaluate("https://slot.example/").verdict)
        assertEquals(JudolIntelligence.Verdict.ALLOW, detector.evaluate("https://gacor.example/").verdict)
    }

    @Test
    fun urlPathAloneCannotCauseAutomaticBlock() {
        val assessment = detector.evaluate("https://publisher.example/judi-online/slot-gacor?promo=maxwin")
        assertFalse(assessment.shouldBlock)
        assertTrue(assessment.score < JudolIntelligence.DEFAULT_BLOCK_THRESHOLD)
    }

    @Test
    fun exactBlocklistMatchesOnlyDomainAndItsSubdomains() {
        val custom = JudolIntelligence(blockedDomainRules = listOf("! comment", "||confirmed.example^", "bad/path", "https://invalid.example/"))
        assertTrue(custom.evaluate("https://confirmed.example/").shouldBlock)
        assertTrue(custom.evaluate("https://sub.confirmed.example/path").shouldBlock)
        assertFalse(custom.evaluate("https://notconfirmed.example/").shouldBlock)
        assertEquals(1, custom.blockedDomainCount)
    }

    @Test
    fun allowlistOverridesHeuristicsAndExactBlocklist() {
        val custom = JudolIntelligence(
            blockedDomainRules = listOf("casinoonline.example"),
            allowedDomainRules = listOf("publisher.example", "casinoonline.example")
        )
        assertEquals(JudolIntelligence.Verdict.ALLOW, custom.evaluate("https://casinoonline.example/").verdict)
        assertEquals(JudolIntelligence.Verdict.ALLOW, custom.evaluate("https://sub.publisher.example/").verdict)
        assertFalse(custom.evaluate("https://notpublisher.example/").shouldBlock)
    }

    @Test
    fun parserAcceptsIdnDomainsAndRejectsInvalidHosts() {
        val custom = JudolIntelligence(blockedDomainRules = listOf("münchen.example"))
        assertTrue(custom.evaluate("https://xn--mnchen-3ya.example/").shouldBlock)
        assertFalse(detector.evaluate("https://localhost/").shouldBlock)
        assertFalse(detector.evaluate("file:///data/local/tmp/page.html").shouldBlock)
        assertFalse(detector.evaluate("not a url").shouldBlock)
        assertFalse(detector.evaluate("https://" + "a".repeat(9_000) + ".example/").shouldBlock)
    }

    @Test
    fun suffixLookalikesDoNotMatchCuratedDomainEntries() {
        val custom = JudolIntelligence(blockedDomainRules = listOf("casino.example"))
        assertTrue(custom.evaluate("https://ads.casino.example/").shouldBlock)
        assertFalse(custom.evaluate("https://casino.example.attacker.test/").shouldBlock)
    }

    fun runChecks() {
        blocksHighConfidenceCompoundGamblingDomains()
        ambiguousTermsDoNotBlockLegitimateDestinations()
        singleWeakDomainTermsOnlyRequestReview()
        urlPathAloneCannotCauseAutomaticBlock()
        exactBlocklistMatchesOnlyDomainAndItsSubdomains()
        allowlistOverridesHeuristicsAndExactBlocklist()
        parserAcceptsIdnDomainsAndRejectsInvalidHosts()
        suffixLookalikesDoNotMatchCuratedDomainEntries()
    }

    @Test
    fun junitSuite() = runChecks()
}
