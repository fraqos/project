package com.dhyra.browser

import androidx.compose.ui.graphics.Color

/** Central palette and adaptive breakpoints for DHYRA's native Compose interface. */
object DhyraDesignTokens {
    const val COMPACT_MAX_WIDTH_DP = 599
    const val MEDIUM_MAX_WIDTH_DP = 839

    val LightCanvas = Color(0xFFF4F5F7)
    val LightSurface = Color(0xFFFFFFFF)
    val LightSurfaceRaised = Color(0xFFFAFAFB)
    val LightText = Color(0xFF17191D)
    val LightSecondaryText = Color(0xFF626873)
    val LightBorder = Color(0xFFE4E6EA)

    val DarkCanvas = Color(0xFF111316)
    val DarkSurface = Color(0xFF1B1E23)
    val DarkSurfaceRaised = Color(0xFF24282E)
    val DarkText = Color(0xFFF4F5F7)
    val DarkSecondaryText = Color(0xFFA5ABB5)
    val DarkBorder = Color(0xFF343941)

    val AccentBlue = Color(0xFF477FE8)
    val AccentViolet = Color(0xFF8175D8)
    val Success = Color(0xFF269B70)
    val Warning = Color(0xFFC58A35)
}
