# DHYRA Browser Android v1.8.0 — GitHub Actions

1. Create or open the GitHub repository.
2. Upload `DHYRA_BROWSER_v1.8.0.zip` to the repository root, or extract the project into the repository root.
3. Commit to `main` or `master`, or start the workflow from **Actions → DHYRA BROWSER Android Build → Run workflow**.
4. The workflow installs Android SDK 35, uses JDK 17 and Gradle 8.7, then runs unit tests, lint, and the debug APK build.
5. When successful, download `DHYRA-BROWSER-v1.8.0-debug` from the run's **Artifacts** section.

The APK artifact is a debug build. It is not a signed production release.
