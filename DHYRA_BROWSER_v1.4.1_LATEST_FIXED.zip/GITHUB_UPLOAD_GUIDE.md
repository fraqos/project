# DHYRA BROWSER 1.4.1 — GitHub build guide

This repository workflow can locate the project in any of these layouts:

1. Gradle project files at the repository root;
2. Gradle project inside one parent folder;
3. One source ZIP committed to the repository without extracting it.

## Recommended upload

1. Create or open your GitHub repository.
2. Extract the downloaded project ZIP.
3. Upload the **contents inside** the extracted folder to the repository root (recommended). Do not upload an extra parent folder.
4. Confirm that `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `gradlew`, `app/` and `.github/workflows/build.yml` are present.
5. Open **Actions** and run **DHYRA BROWSER - Android CI**, or push to `main` / `master`.
6. When all steps pass, download `DHYRA-BROWSER-v1.4.1-debug` from the workflow run's **Artifacts** section.

If you commit the ZIP itself instead of extracting it, the workflow will attempt to unpack and locate the Android project automatically. Only one valid project source should be present in the repository.

## Build configuration

- JDK: 17 (Temurin)
- Android SDK Platform: 35
- Android Build Tools: 35.0.0
- Gradle: 8.7
- Application ID: `com.dhyra.browser`
- Version: `1.4.1` (versionCode 6)
- Build variant: debug

The workflow runs the pure-JVM browser logic checks, Android lint, and `assembleDebug`, then uploads the generated APK and diagnostic reports. The debug APK is suitable for local installation and testing; it is not a Play Store release-signed build. No keystore or signing secret is assumed.
