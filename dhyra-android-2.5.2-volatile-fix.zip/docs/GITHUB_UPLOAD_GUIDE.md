# dhyra — GitHub Actions setup (2.5.2)

The canonical workflow is `.github/workflows/build.yml`. Replace old dhyra workflows (including older `main.yml` files) so that only this current workflow is active.

## Recommended ZIP-only setup

1. Create `.github/workflows/` in the GitHub repository.
2. Save the supplied current workflow as `.github/workflows/build.yml`.
3. Commit exactly one dhyra Android source ZIP to the repository root. Use `dhyra-android-2.5.2-adblock-plus.zip` or another single `.zip` filename.
4. Remove or move older dhyra Android project ZIPs out of the repository. The workflow intentionally fails if it finds more than one valid Android project ZIP.
5. Commit both the workflow and ZIP, then push to the default branch. You can also start a run from the Actions tab using `workflow_dispatch`.

Do not upload the workflow only inside the ZIP: GitHub must first see it as a committed file under `.github/workflows/`. The current workflow can extract the project ZIP automatically; manual extraction is not required.

## Source-at-root alternative

Instead of the ZIP-only setup, you may commit the extracted project contents directly to the repository root. The workflow recognizes `settings.gradle.kts`, `app/build.gradle.kts` and `app/src/main/AndroidManifest.xml` and then builds the root project. When the project root and a ZIP are both present, the repository-root project takes precedence.

## Toolchain and workflow jobs

- Checkout the repository with read-only contents permission.
- Locate the project at the repository root or safely validate/extract exactly one Android ZIP (ZIP path traversal and symlink entries are rejected; CRC is checked; expanded size is limited).
- Run the translation JavaScript checks and Compose/source contract checks.
- Set up JDK 21 and accept Android SDK licences.
- Install Android SDK Platform 37.1 and Build Tools 36.0.0. Platform 37.1 requires AGP 9.3.1; AGP 9.3 uses Gradle 9.5.x and Build Tools 36.0.0 as its default compatibility baseline.
- Set up Gradle 9.5.1. Generate the standard Wrapper in the real Android project root (not an empty temporary directory), pin the Gradle distribution SHA-256, and verify the generated Wrapper JAR SHA-256 against Gradle's published checksum.
- Run `:app:checkDebugAarMetadata`, `testDebugUnitTest`, `lintDebug` and `assembleDebug`.
- Validate the APK ZIP, Android manifest and DEX bytecode; build a clean source ZIP and SHA-256 checksum file; upload all results as GitHub Actions artifacts.

The default APK is `dhyra-v2.5.2.apk` (debug build). A manual workflow run can request an unsigned release APK, or a signed release APK and App Bundle. Signed releases require both `build_release=true` and `sign_release=true`, plus these GitHub Actions secrets: `DHYRA_RELEASE_KEYSTORE_BASE64`, `DHYRA_RELEASE_STORE_PASSWORD`, `DHYRA_RELEASE_KEY_ALIAS` and `DHYRA_RELEASE_KEY_PASSWORD`. Secrets are not committed into the source ZIP and are not passed to unsigned release builds.

## Troubleshooting

- **No Android project found:** ensure the repository contains one valid project ZIP, or commit the Android project at repository root.
- **More than one Android ZIP found:** remove/move older source ZIPs and keep only the intended version.
- **Invalid ZIP:** regenerate the archive and ensure it contains Gradle settings, the `app` module build file and Android manifest.
- **SDK package error:** keep current Android command-line tools and use the package IDs `platforms;android-37.1` and `build-tools;36.0.0`.
- **Wrapper checksum error:** do not replace the pinned hashes with hashes copied from an arbitrary download; compare with Gradle's official release checksum page.
- **Kotlin compilation error:** fix the first Kotlin compiler diagnostic, not only the final Gradle task failure.
- **Artifact missing:** inspect the first failed test/lint/build/validation step. APK upload runs only after all required build and validation steps pass.
