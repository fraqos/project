# dhyra 2.5.2 build verification

The working environment used to prepare this package does not contain an installed Android SDK or Gradle distribution. Therefore `:app:compileDebugKotlin`, Android Lint and `assembleDebug` have not been executed locally, and no APK build is claimed as successful.

The supplied repository workflow has been checked statically and its ZIP-locator and pre-Gradle validation steps have been simulated against the actual source archive. At package time, 84 source-contract checks, two translation JavaScript smoke tests, XML parsing/resource parity, Bash syntax, embedded Python syntax, YAML parsing, the focused duplicate-`@Volatile` compiler reproduction and the ShieldsFilterEngine Kotlin runtime regression harness passed. The source-contract suite specifically asserts that `shieldsFilterEngine` has exactly one `@Volatile` annotation. A standalone Kotlin compiler check confirmed that the corrected single-annotation property compiles and the previous duplicate-annotation form produces the reported “This annotation is not repeatable” diagnostic. The focused harness contains 21 regression cases and compiles the pure Kotlin filter engine and its test methods with a temporary local JUnit-compatible assertion stub; it is not a substitute for Gradle's actual `testDebugUnitTest` task. The filter-list manager was also compiled against minimal local Android API stubs and kotlinx-coroutines to catch Kotlin/API-shape errors, but this is not an Android Gradle build. The 21 cases cover exception ordering, `$important`, `$badfilter` option normalization, resource types, host/path/generic patterns, Ping/WebSocket header classification where exposed, explicit rejection of unsupported WebRTC and regex filters, popup resource rules with opener-site context, ID shorthand and child-combinator selectors, selector prioritization and valid CSS output. The manager subscribes to EasyList, EasyPrivacy, Fanboy’s Annoyance List and ABPindo. It:

1. Checks out the repository and locates either the Android project at repository root or exactly one source ZIP.
2. Validates ZIP entry paths, symlinks, duplicate names, expanded size and CRC before extracting it safely.
3. Runs Node translation tests and `scripts/check-compose-contracts.py`, including a regression check that the Activity saved-state Bundle is passed into the Compose root as a Boolean rather than referenced out of scope.
4. Installs JDK 21, Android SDK Platform 37.1 and Build Tools 36.0.0.
5. Uses Gradle 9.5.1, generates the Wrapper in the actual Android project root (which contains `settings.gradle.kts` and `build.gradle.kts`), and verifies the official Gradle distribution and Wrapper JAR SHA-256 values.
6. Runs AAR metadata validation, the dedicated `:app:compileDebugKotlin` task, JVM unit tests, Android Lint and `assembleDebug`.
7. Validates APK manifest/DEX entries, packages a clean source ZIP, creates SHA-256 sums and uploads the artifacts.

Unsigned and signed release builds are separate workflow paths. Signing secrets are exposed only to the signed-release step.

A successful GitHub Actions run is required before claiming that the Android APK has compiled successfully.
