package com.dhyra.browser.core.shields

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Owns bundled and downloaded filter subscriptions. Downloads happen only on Dispatchers.IO;
 * a newly compiled immutable engine is atomically published after a valid list is saved.
 */
class ShieldsFilterManager(context: Context) {
    data class UpdateResult(
        val changed: Boolean,
        val successfulSources: Int,
        val message: String,
        val ruleCount: Int,
        val cosmeticCount: Int
    )

    private data class Source(val id: String, val title: String, val url: String)

    private val appContext = context.applicationContext
    private val preferences = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val listDirectory = File(appContext.filesDir, "shields-filter-lists").apply { mkdirs() }
    private val updateLock = AtomicBoolean(false)

    @Volatile
    private var activeEngine = ShieldsFilterEngine(loadAllRules())

    val engine: ShieldsFilterEngine get() = activeEngine
    val lastUpdatedMillis: Long get() = preferences.getLong(KEY_LAST_UPDATED, 0L)
    val lastUpdatedLabel: String
        get() = if (lastUpdatedMillis == 0L) "Not updated yet" else
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(lastUpdatedMillis))

    val sources: List<String> = FILTER_SOURCES.map { it.title }

    suspend fun updateIfDue(): UpdateResult = withContext(Dispatchers.IO) {
        val due = FILTER_SOURCES.any { source ->
            val last = preferences.getLong("updated_${source.id}", 0L)
            System.currentTimeMillis() - last >= UPDATE_INTERVAL_MILLIS
        }
        if (!due) return@withContext result(false, 0, "Protection lists are up to date.")
        if (!isUnmeteredConnection()) {
            return@withContext result(false, 0, "Automatic list updates wait for an unmetered connection. You can update manually.")
        }
        refreshInternal(force = false)
    }

    suspend fun refreshNow(): UpdateResult = withContext(Dispatchers.IO) {
        refreshInternal(force = true)
    }

    private fun refreshInternal(force: Boolean): UpdateResult {
        if (!updateLock.compareAndSet(false, true)) {
            return result(false, 0, "A filter-list update is already running.")
        }
        try {
            var successes = 0
            val failures = ArrayList<String>()
            for (source in FILTER_SOURCES) {
                val previous = preferences.getLong("updated_${source.id}", 0L)
                if (!force && System.currentTimeMillis() - previous < UPDATE_INTERVAL_MILLIS) continue
                try {
                    val content = downloadList(source.url)
                    val target = File(listDirectory, "${source.id}.txt")
                    val temp = File(listDirectory, "${source.id}.txt.tmp")
                    temp.writeText(content, StandardCharsets.UTF_8)
                    try {
                        Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
                    } catch (_: AtomicMoveNotSupportedException) {
                        Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
                    }
                    preferences.edit()
                        .putLong("updated_${source.id}", System.currentTimeMillis())
                        .apply()
                    successes++
                } catch (error: Exception) {
                    failures += source.title
                    File(listDirectory, "${source.id}.txt.tmp").delete()
                }
            }

            if (successes > 0) {
                activeEngine = ShieldsFilterEngine(loadAllRules())
                preferences.edit().putLong(KEY_LAST_UPDATED, System.currentTimeMillis()).apply()
                val message = if (failures.isEmpty()) {
                    "Protection lists updated (${successes}/${FILTER_SOURCES.size})."
                } else {
                    "Updated ${successes} list(s); ${failures.size} could not be refreshed. Previous versions were kept."
                }
                return result(true, successes, message)
            }

            val message = if (failures.isEmpty()) "Protection lists are already current." else
                "Could not update protection lists. The last working lists remain active."
            return result(false, 0, message)
        } finally {
            updateLock.set(false)
        }
    }

    private fun result(changed: Boolean, successes: Int, message: String) = UpdateResult(
        changed = changed,
        successfulSources = successes,
        message = message,
        ruleCount = activeEngine.ruleCount,
        cosmeticCount = activeEngine.cosmeticRuleCount
    )

    private fun loadAllRules(): List<String> {
        val combined = ArrayList<String>(180_000)
        runCatching {
            appContext.assets.open(BUNDLED_LIST).bufferedReader(StandardCharsets.UTF_8).useLines { lines ->
                lines.forEach { if (combined.size < MAX_TOTAL_LINES) combined += it }
            }
        }
        FILTER_SOURCES.forEach { source ->
            val file = File(listDirectory, "${source.id}.txt")
            if (file.isFile && file.length() in 1..MAX_LIST_BYTES.toLong()) {
                runCatching {
                    file.bufferedReader(StandardCharsets.UTF_8).useLines { lines ->
                        lines.forEach { if (combined.size < MAX_TOTAL_LINES) combined += it }
                    }
                }
            }
        }
        return combined
    }

    private fun downloadList(address: String): String {
        val connection = (URI(address).toURL().openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            instanceFollowRedirects = true
            setRequestProperty("Accept", "text/plain, */*;q=0.8")
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("User-Agent", USER_AGENT)
        }
        try {
            val status = connection.responseCode
            if (connection.url.protocol != "https") error("Filter source redirected away from HTTPS")
            if (status != HttpURLConnection.HTTP_OK) error("Filter source returned HTTP $status")
            val declaredLength = connection.contentLengthLong
            if (declaredLength > MAX_LIST_BYTES) error("Filter source exceeded the size limit")
            val output = ByteArrayOutputStream()
            connection.inputStream.use { input ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_LIST_BYTES) error("Filter source exceeded the size limit")
                    output.write(buffer, 0, count)
                }
            }
            val text = output.toString(StandardCharsets.UTF_8.name())
            val firstLines = text.lineSequence().take(12).joinToString("\n")
            if (!firstLines.contains("[Adblock Plus", ignoreCase = true)) {
                error("Filter source header is missing or invalid")
            }
            val plausibleRules = text.lineSequence().count { line ->
                val trimmed = line.trim()
                trimmed.startsWith("||") || trimmed.startsWith("@@") || trimmed.startsWith("|") ||
                    trimmed.startsWith("/") || trimmed.contains("##") || trimmed.contains("#@#")
            }
            if (plausibleRules < MIN_RULE_LINES) error("Filter source did not contain enough valid-looking rules")
            return text
        } finally {
            connection.disconnect()
        }
    }

    private fun isUnmeteredConnection(): Boolean = runCatching {
        val manager = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = manager.activeNetwork ?: return@runCatching false
        val capabilities = manager.getNetworkCapabilities(network) ?: return@runCatching false
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }.getOrDefault(false)

    companion object {
        private const val PREFS_NAME = "dhyra_shields_filters"
        private const val KEY_LAST_UPDATED = "last_updated"
        private const val BUNDLED_LIST = "shields_blocklist.txt"
        private const val MAX_LIST_BYTES = 10 * 1024 * 1024
        private const val MAX_TOTAL_LINES = 300_000
        private const val MIN_RULE_LINES = 500
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val READ_TIMEOUT_MS = 25_000
        private const val UPDATE_INTERVAL_MILLIS = 4L * 24L * 60L * 60L * 1000L
        private const val USER_AGENT = "dhyra/2.5.2 (Android; filter-list updater)"
        private val FILTER_SOURCES = listOf(
            Source("easylist", "EasyList", "https://easylist.to/easylist/easylist.txt"),
            Source("easyprivacy", "EasyPrivacy", "https://easylist.to/easylist/easyprivacy.txt"),
            Source("fanboy-annoyance", "Fanboy’s Annoyance List", "https://secure.fanboy.co.nz/fanboy-annoyance.txt"),
            Source("abpindo", "ABPindo (Indonesia & Malaysia)", "https://raw.githubusercontent.com/ABPindo/indonesianadblockrules/master/subscriptions/abpindo.txt")
        )
    }
}
