#!/usr/bin/env python3
"""Fail-fast check that the CI workflow matches the actual dhyra Gradle project."""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path.cwd()


def fail(message: str) -> None:
    raise SystemExit(f"CI preflight failed: {message}")


def read_required(path: Path) -> str:
    if not path.is_file():
        fail(f"required project file is missing: {path.relative_to(ROOT)}")
    return path.read_text(encoding="utf-8")


def match(pattern: str, content: str, label: str) -> str:
    found = re.search(pattern, content, re.MULTILINE | re.DOTALL)
    if not found:
        fail(f"could not read {label} from project/workflow")
    return found.group(1)


settings = read_required(ROOT / "settings.gradle.kts")
root_build = read_required(ROOT / "build.gradle.kts")
app_build = read_required(ROOT / "app/build.gradle.kts")
wrapper = read_required(ROOT / "gradle/wrapper/gradle-wrapper.properties")

workflow_path = ROOT / ".github/workflows/build.yml"
if not workflow_path.is_file():
    workflow_path = ROOT / ".github/workflows/main.yml"
workflow = read_required(workflow_path)

if 'include(":app")' not in settings:
    fail("settings.gradle.kts does not include the expected :app module")

agp = match(r'id\("com\.android\.application"\)\s+version\s+"([0-9.]+)"', root_build, "AGP version")
kotlin_android = match(r'id\("org\.jetbrains\.kotlin\.android"\)\s+version\s+"([0-9.]+)"', root_build, "Kotlin Android plugin version")
kotlin_compose = match(r'id\("org\.jetbrains\.kotlin\.plugin\.compose"\)\s+version\s+"([0-9.]+)"', root_build, "Kotlin Compose plugin version")
if kotlin_android != kotlin_compose:
    fail(f"Kotlin plugin versions differ: android={kotlin_android}, compose={kotlin_compose}")

gradle_version = match(r'gradleVersion\s*=\s*"([0-9.]+)"', root_build, "Gradle wrapper version")
wrapper_url_version = match(r'distributionUrl=.*?gradle-([0-9.]+)-bin\.zip', wrapper, "wrapper distribution version")
if wrapper_url_version != gradle_version:
    fail(f"wrapper properties use Gradle {wrapper_url_version}, root build config uses {gradle_version}")

version_name = match(r'versionName\s*=\s*"([^"]+)"', app_build, "application versionName")
version_code = match(r'versionCode\s*=\s*(\d+)', app_build, "application versionCode")
compile_api_match = re.search(
    r'version\s*=\s*release\((\d+)\)\s*\{\s*minorApiLevel\s*=\s*(\d+)',
    app_build,
    re.MULTILINE | re.DOTALL,
)
if not compile_api_match:
    fail("could not read compileSdk release/minor API from app/build.gradle.kts")
compile_sdk = f"{compile_api_match.group(1)}.{compile_api_match.group(2)}"

# Read the versions actually configured by the workflow actions/SDK install steps.
workflow_gradle = match(r"gradle-version:\s*['\"]([^'\"]+)['\"]", workflow, "setup-gradle version")
workflow_wrapper_gradle = match(r"GRADLE_VERSION='([0-9.]+)'", workflow, "wrapper task Gradle version")
workflow_jdk = match(r"java-version:\s*['\"]([^'\"]+)['\"]", workflow, "setup-java version")
workflow_api = match(r"['\"]platforms;android-([0-9]+\.[0-9]+)['\"]", workflow, "Android SDK platform package")
workflow_build_tools = match(r"['\"]build-tools;([0-9.]+)['\"]", workflow, "Android Build Tools package")

expected = {
    "Gradle (setup action)": (gradle_version, workflow_gradle),
    "Gradle (wrapper task)": (gradle_version, workflow_wrapper_gradle),
    "compileSdk": (compile_sdk, workflow_api),
}
for label, (project_value, workflow_value) in expected.items():
    if project_value != workflow_value:
        fail(f"{label} mismatch: project={project_value}, workflow={workflow_value}")

if workflow_jdk != "21":
    fail(f"CI JDK is {workflow_jdk}; this project workflow is validated for JDK 21")
if workflow_build_tools != "36.0.0":
    fail(f"CI Build Tools is {workflow_build_tools}; AGP {agp} defaults to 36.0.0 for this project")
if agp != "9.3.1":
    fail(f"AGP is {agp}; API {compile_sdk} workflow compatibility has been checked for AGP 9.3.1")
if kotlin_android != "2.4.21":
    fail(f"Kotlin Gradle Plugin is {kotlin_android}; this workflow's compatibility check is for 2.4.21")

# Confirm the CI does not silently publish an APK under a stale version label.
if f"dhyra-v{version_name}.apk" not in workflow:
    fail(f"debug APK output name does not match app versionName {version_name}")
if f"dhyra-v{version_name}-release.apk" not in workflow:
    fail(f"signed release APK name does not match app versionName {version_name}")

# The distribution digest in the wrapper file and the value passed to the wrapper task must agree.
wrapper_sha = match(r'distributionSha256Sum=([0-9a-f]{64})', wrapper, "Gradle distribution SHA-256")
workflow_sha = match(r"EXPECTED_GRADLE_SHA256='([0-9a-f]{64})'", workflow, "workflow Gradle SHA-256 pin")
if wrapper_sha != workflow_sha:
    fail("Gradle distribution SHA-256 differs between gradle-wrapper.properties and workflow")

for task in (":app:compileDebugKotlin", "testDebugUnitTest", "lintDebug", "assembleDebug"):
    if task not in workflow:
        fail(f"required CI task is missing: {task}")

print("CI preflight: PASS")
print(f"  App: dhyra {version_name} (versionCode {version_code})")
print(f"  AGP: {agp}; Kotlin: {kotlin_android}; Gradle: {gradle_version}")
print(f"  JDK: {workflow_jdk}; compileSdk: {compile_sdk}; Build Tools: {workflow_build_tools}")
print("  CI compile/test/lint/debug APK tasks: present")
print("  Wrapper distribution URL and SHA-256: consistent")
