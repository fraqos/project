# DHYRA Browser Air Edition 1.4.0 — source fix

## Fixed

`TabsScreen` receives `tabs: List<BrowserTab>` as a parameter, but its header and empty-state condition incorrectly referenced `browserSnapshot`, which is scoped only inside `DhyraApplication()`.

Changed:
- `browserSnapshot.tabs.size` to `tabs.size` in the tab count label.
- `browserSnapshot.tabs.isEmpty()` to `tabs.isEmpty()` in the empty-state condition.

These changes directly address the three Kotlin compiler diagnostics reported by GitHub Actions for unresolved `browserSnapshot` references at `MainActivity.kt:847` and `MainActivity.kt:853`.

## Not claimed

A full Android Gradle build has not been completed in this environment because `services.gradle.org` was unreachable. The fix addresses the reported compiler error, but GitHub Actions must confirm whether any further compile or packaging issues remain.
