# DHYRA Browser — Android 2.0.0 Premium Evolution

DHYRA is a native Android browser built with Kotlin, Jetpack Compose and Android System WebView.

## 2.0.0 evolution

- Introduces a refined graphite / arctic-blue visual foundation and shared design tokens.
- Refreshes the homepage identity and search presentation while retaining existing navigation and browser actions.
- Unifies surface radius, contrast and settings-panel treatment.
- Keeps existing WebView engine adapter, tabs, private tabs, bookmarks, history, downloads, notes, privacy controls, diagnostics and DataStore persistence.
- Updates Android version metadata to `2.0.0` (`versionCode 14`).
- Reworks GitHub Actions to validate, test, lint, build and upload a debug APK.

## Build locally

Use JDK 17 and Android SDK 35. From the project root:

```bash
./gradlew testDebugUnitTest lintDebug :app:assembleDebug
```

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Build with GitHub Actions

1. Extract this ZIP into the repository root so `settings.gradle.kts` and `app/` are at the root, **or** upload exactly one `DHYRA_BROWSER*.zip` to the repository root.
2. Ensure `.github/workflows/build.yml` is present.
3. Open **Actions → DHYRA BROWSER Android Build → Run workflow**.
4. Download `DHYRA-BROWSER-v2.0.0-debug` from the successful run's Artifacts.

The workflow reports test, lint or compile failures separately and uploads diagnostics when a job fails.

## Engineering notes

- Min SDK: 26
- Compile SDK: 35
- Target SDK: 34
- Java/Kotlin JVM target: 17
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- Gradle: 8.7

This package has not been represented as a successful APK build unless GitHub Actions completes successfully.
