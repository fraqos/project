# DHYRA Browser 2.0.0 — GitHub upload guide

Recommended: extract the contents of this ZIP and upload the project files/folders directly into the repository root. `settings.gradle.kts`, `app/`, `gradle/`, and `.github/` must be at the repository root.

Alternative: upload exactly one `DHYRA_BROWSER*.zip` into the repository root; the workflow extracts it automatically when no root `settings.gradle.kts` exists.

Then open Actions, choose **DHYRA BROWSER Android Build**, and run the workflow. Download `DHYRA-BROWSER-v2.0.0-debug` from Artifacts after a successful run.
