# DHYRA Browser 2.0.0 — Premium Evolution

## Source baseline
Built from the supplied `DHYRA_BROWSER_v1.9.0_PREMIUM_FIXED2` project. Existing browser behavior and persisted user data paths are retained.

## Delivered changes
- Updated shared design tokens to a coherent graphite / arctic-blue / violet palette.
- Refined ambient mood presets.
- Refreshed homepage headline and brand language.
- Standardized settings surface radius and spacing.
- Updated app version to 2.0.0 / versionCode 14.
- Rebuilt GitHub Actions to support either extracted source at repository root or a single uploaded source ZIP.
- Removed the premature Gradle cache lookup from JDK setup; Gradle setup occurs after checkout and JDK provisioning.

## Validation status
Static source and package checks are performed before delivery. Full Android compilation requires Android SDK / Gradle dependencies and should be confirmed by the included GitHub Actions workflow. Do not treat this source ZIP as a verified APK until the workflow succeeds.

## Retained core areas
WebView browser controller, session restore, private tabs, bookmarks, history, downloads, notes, privacy controls, diagnostics, adaptive desktop-site policy, DataStore preferences and existing navigation routes.
