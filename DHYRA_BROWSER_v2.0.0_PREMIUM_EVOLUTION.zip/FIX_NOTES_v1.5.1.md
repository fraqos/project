# Dhyra Browser v1.5.2 - Kotlin build fix

## Root cause
GitHub Actions reported `Unresolved reference 'consume'` at MainActivity.kt line 77. The file imported `androidx.compose.ui.input.pointer.consume`, but the Compose PointerInputChange API exposes `consume()` as a member function for the configured Compose version.

## Fix
Removed the invalid `consume` import. Existing `change.consume()` calls remain and resolve against the PointerInputChange member API.

## Version
Android versionCode: 7
Android versionName: 1.5.2

## Validation
- ZIP archive integrity checked.
- Workflow YAML parsed.
- Verified invalid import is absent.
- Full Android Gradle compilation has not been run in this environment; GitHub Actions must confirm the APK build.
