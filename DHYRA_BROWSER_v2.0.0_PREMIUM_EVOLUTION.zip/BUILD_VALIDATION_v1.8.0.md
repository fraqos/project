# DHYRA Browser v1.8.0 — Build Validation

## Available in this environment

- ZIP archive integrity check.
- XML parsing for AndroidManifest and resource XML.
- YAML parsing for the GitHub Actions workflow.
- Shell syntax check for workflow shell snippets.
- Kotlin parser/static source checks where dependencies are not required.
- Pure Kotlin adaptive policy compilation and behavior tests (14 assertions passed for width classes, Auto policy, tab/site/global override precedence, stored preference parsing, and A–F grade boundaries).
- Kotlin parser pass across all app and unit-test source (no syntax diagnostics; full type checking unavailable without Android/Compose dependencies).
- Version metadata, required source/test file checks, and archive packaging integrity.

## Not available in this environment

- Android SDK / Android platform 35.
- Gradle wrapper JAR and installed Gradle runtime.
- Android emulator or attached physical Android device.
- Instrumented tests of WebView networking, rendering, permissions, downloads, splash presentation, or window resizing.

A Gradle build was attempted but could not start because the Gradle 8.7 distribution could not be downloaded in this network-restricted environment (`services.gradle.org` DNS resolution failed). Therefore, no APK build, Android lint result, emulator result, or device-grade UI validation is claimed. GitHub Actions workflow is configured to run `testDebugUnitTest`, `lintDebug`, and `:app:assembleDebug` after setting up Android SDK 35 and Gradle 8.7.
