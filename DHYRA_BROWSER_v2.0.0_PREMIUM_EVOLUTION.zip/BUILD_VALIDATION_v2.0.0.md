# Build validation — DHYRA Browser 2.0.0

- `versionName`: `2.0.0`
- `versionCode`: `14`
- JDK: 17
- Android SDK: 35
- Gradle: 8.7
- Workflow tasks: `testDebugUnitTest`, `lintDebug`, `:app:assembleDebug`
- Expected APK: `app/build/outputs/apk/debug/app-debug.apk`
- Expected artifact: `DHYRA-BROWSER-v2.0.0-debug`

Build status: **not yet verified in GitHub Actions**. A successful workflow run is required to confirm compilation and artifact upload.
