# DHYRA Browser v1.6.0 — functional development pass

## Implemented in this package

- Restores regular HTTP/HTTPS tabs from a local DataStore session on startup; private tabs are excluded from persistence.
- Saves up to 30 regular tab URLs for session recovery.
- Adds tab duplication and close-all operations in the controller.
- Adds tab search, duplicate-tab action, and close-all action to the tab manager.
- Adds long-press link actions in WebView: open in new tab, open in background tab, and copy link.
- Adds search to history and bookmark lists.
- Adds Yahoo and Ecosia search engine options and URL routing.
- Adds the missing Compose pointer-input `consume` extension import.
- Updates app version metadata and GitHub Actions artifact naming to v1.6.0.
- Makes the workflow install explicit SDK packages and avoids the deprecated `tools` package.

## Architecture retained

The project remains Kotlin + Jetpack Compose + Android System WebView. `BrowserController` continues to own retained WebView instances and publish tab snapshots via StateFlow. Preferences, history, bookmarks, and session URLs are stored using Preferences DataStore. Downloads continue to use Android DownloadManager.

## Verified in this packaging environment

- ZIP source was opened and all 24 original project entries were enumerated.
- Updated Android manifest parses as XML.
- GitHub Actions workflow parses as YAML.
- Every workflow `run` script passes `bash -n`.
- MainActivity and BrowserController brace counts are balanced.
- The previously reported edge gesture `change.consume()` call now has its Compose extension import.
- Archive integrity is checked after packaging.

## Not verified / limitations

- A full Gradle Android build and APK installation test were not run in this environment because an Android SDK and Gradle installation are not available here. GitHub Actions must confirm the final Android/Compose type-check and APK build.
- Private tabs still share Android System WebView's process-wide cookie/storage infrastructure; this is not profile-isolated private browsing.
- Tab restore stores URLs, not WebView back/forward stacks or form state.
- Tracker protection remains a small host deny-list, not a comprehensive content-blocking engine.
- Tab cards use lightweight preview artwork rather than live WebView snapshots.
- Features requiring a Gecko/Chromium engine API unavailable to Android WebView (for example full reader mode, full translation UI, true per-profile private storage, and full browser-grade safe-browsing controls) are not represented as completed.
