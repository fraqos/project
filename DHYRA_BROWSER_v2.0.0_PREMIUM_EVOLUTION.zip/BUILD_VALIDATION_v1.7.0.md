# DHYRA Browser v1.7.0 — validation report

## Static checks to run for this source package

- Android manifest XML parses.
- GitHub Actions workflow YAML parses.
- Workflow shell blocks pass `bash -n`.
- App metadata and workflow version checks match 1.7.0 / versionCode 11.
- Notes model and serializer are present.
- Address-bar URL resolver rejects unsafe schemes from direct navigation.
- Camera, microphone, and geolocation requests require per-request in-app confirmation after Android OS permission.
- Browser controller no longer matches the `facebook.com/tr` path as if it were a hostname.
- New vector launcher icon is present and referenced by the manifest.
- ZIP integrity passes after packaging.

## Not verified in this environment

- Full Gradle/Android Kotlin compilation.
- Debug APK generation and installation.
- Runtime WebView behavior across Android versions.
- Automated UI/E2E tests and real download/permission flows.

The source package does not contain `gradle-wrapper.jar`; its GitHub Actions workflow generates the wrapper with Gradle 8.7, installs Android SDK 35, and runs unit-test, lint, and debug-build tasks. A green Actions run is required to confirm compilation and APK packaging.
