# DHYRA Browser v1.8.0 — Development Notes

## Architecture changes

- Introduced `BrowserEngineProvider` as the engine boundary.
- Added `AndroidSystemWebViewProvider` as the active provider, responsible for applying a typed `BrowserEngineConfiguration` to WebView settings.
- Kept BrowserController as the tab/lifecycle/navigation coordinator; Compose remains the interface/state presentation layer.
- Added pure Kotlin adaptive policy models so width classification and desktop override precedence can be tested without Android runtime dependencies.

## Adaptive UI and website mode

- App-window classes: compact <600 dp, medium 600–839 dp, expanded >=840 dp.
- Website policy: Auto (desktop request in medium and expanded app windows), Mobile, Desktop.
- Priority order: tab override > persisted host preference > global policy. Per-tab overrides are session-only; per-site overrides persist locally.
- Desktop mode changes User-Agent and WebView `useWideViewPort` / `loadWithOverviewMode` options.
- Browser menu adds per-tab and per-site toggles. Those toggles reload the active website to apply request configuration.
- Expanded window gets a horizontally scrollable tab strip and a desktop toolbar. Compact/medium window keeps bottom navigation.

## Design and startup

- Added centralized DHYRA palette and breakpoint tokens.
- Follow System theme now follows Android system appearance independently from ambient mood.
- Added AndroidX SplashScreen branding using the DHYRA mark and a short exit fade/scale. No startup wait loop was introduced.

## Diagnostics

The diagnostics page collects current platform/runtime values: window dp dimensions, density, ActivityManager memory class/available RAM/low-memory flag, logical processor count, Debug PSS, active WebView tab count, WebView provider/version, and actual active palette contrast ratio.

The UI does not invent a full interface/compatibility grade. Theme contrast, device capability signals, and runtime health receive explicitly scoped scores; compatibility is ungraded without a controlled website test suite. Global Compose overflow and accessibility scanning is not implemented.

The diagnostics snapshots are stored locally, rolling over at 20 entries.

## Validation status

- Adaptive policy unit tests added for width breakpoints, Auto resolution, override precedence, and stored-mode parsing.
- Source-level build checks and archive integrity are run before release packaging.
- This container does not include Android SDK or Gradle wrapper JAR; a full Android Gradle build, Android lint, emulator run, WebView rendering test, and physical-device QA cannot be honestly claimed here. GitHub Actions is configured to run tests, lint, and debug APK assembly using Android SDK 35/JDK 17/Gradle 8.7.
