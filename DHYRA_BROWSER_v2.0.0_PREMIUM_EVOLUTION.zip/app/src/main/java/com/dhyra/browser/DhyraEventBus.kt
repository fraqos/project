package com.dhyra.browser

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/** One app-scoped event stream for cross-module browser state changes and recoverable failures. */
sealed interface DhyraBrowserEvent {
    data class ThemeChanged(val theme: String, val accentHex: String) : DhyraBrowserEvent
    data class DesktopModeChanged(val tracking: Boolean, val popup: Boolean, val policy: DesktopPolicy, val tabletWindow: Boolean) : DhyraBrowserEvent
    data class WindowProfileChanged(val widthDp: Int, val heightDp: Int, val windowClass: DhyraWindowClass) : DhyraBrowserEvent
    data class RenderingFailure(val url: String, val description: String) : DhyraBrowserEvent
}

class DhyraBrowserEventBus {
    private val mutableEvents = MutableSharedFlow<DhyraBrowserEvent>(
        replay = 0,
        extraBufferCapacity = 32,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val events = mutableEvents.asSharedFlow()

    fun publish(event: DhyraBrowserEvent) {
        mutableEvents.tryEmit(event)
    }
}
