package com.dhyra.browser.ui.theme

import androidx.compose.ui.graphics.Color

data class MoodPreset(
    val name: String,
    val shortName: String,
    val accent: Color,
    val canvasTop: Color,
    val canvasBottom: Color
) {
    companion object {
        val all = listOf(
            MoodPreset("Morning Mist", "Mist", Color(0xFF397BE8), Color(0xFFF4F7FC), Color(0xFFE8EFF9)),
            MoodPreset("Warm Sand", "Sand", Color(0xFF9B795E), Color(0xFFF8F6F2), Color(0xFFEDE7DE)),
            MoodPreset("Sage Calm", "Sage", Color(0xFF4F806B), Color(0xFFF1F6F2), Color(0xFFE2ECE5)),
            MoodPreset("Midnight Air", "Night", Color(0xFF9BA7FF), Color(0xFF0D1420), Color(0xFF182438))
        )

        fun fromName(name: String): MoodPreset = all.firstOrNull { it.name == name } ?: all.first()
    }
}
