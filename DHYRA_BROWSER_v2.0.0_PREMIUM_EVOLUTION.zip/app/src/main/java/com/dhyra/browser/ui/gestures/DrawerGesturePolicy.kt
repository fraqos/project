package com.dhyra.browser.ui.gestures

/** Gesture policy for the navigation drawer. Opening is edge-only so page carousels
 * and horizontal WebView interactions away from the left edge are not intercepted. */
object DrawerGesturePolicy {
    const val GESTURES_ENABLED: Boolean = true
    const val EDGE_SWIPE_ENABLED: Boolean = true
}
