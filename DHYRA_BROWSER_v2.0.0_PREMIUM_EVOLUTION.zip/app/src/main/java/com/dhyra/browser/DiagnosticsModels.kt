package com.dhyra.browser

/** Snapshot fields are populated from Android/runtime measurements at the time diagnostics opens. */
data class DhyraDiagnosticsSnapshot(
    val windowWidthDp: Int,
    val windowHeightDp: Int,
    val densityDpi: Int,
    val windowClass: DhyraWindowClass,
    val memoryClassMb: Int,
    val availableMemoryMb: Long,
    val lowMemory: Boolean,
    val processorCores: Int,
    val processPssMb: Long,
    val activeTabs: Int,
    val webViewProvider: String,
    val webViewVersion: String,
    val textContrastRatio: Double
)

data class DiagnosticGrade(val grade: String, val score: Int, val explanation: String)

fun deviceCapabilityGrade(snapshot: DhyraDiagnosticsSnapshot): DiagnosticGrade {
    var score = 45
    score += when {
        snapshot.memoryClassMb >= 512 -> 25
        snapshot.memoryClassMb >= 256 -> 18
        snapshot.memoryClassMb >= 192 -> 12
        else -> 5
    }
    score += when {
        snapshot.processorCores >= 8 -> 15
        snapshot.processorCores >= 6 -> 11
        snapshot.processorCores >= 4 -> 7
        else -> 3
    }
    if (!snapshot.lowMemory && snapshot.availableMemoryMb >= 512) score += 10
    return DiagnosticGrade(gradeFromScore(score.coerceAtMost(100)), score.coerceAtMost(100), "Based on Android memory class, available system RAM, low-memory state, and logical CPU core count; not a synthetic benchmark.")
}

fun browserRuntimeGrade(snapshot: DhyraDiagnosticsSnapshot): DiagnosticGrade {
    var score = 100
    if (snapshot.processPssMb > 650) score -= 35 else if (snapshot.processPssMb > 450) score -= 20 else if (snapshot.processPssMb > 300) score -= 10
    if (snapshot.activeTabs > 12) score -= 25 else if (snapshot.activeTabs > 8) score -= 15 else if (snapshot.activeTabs > 5) score -= 8
    if (snapshot.webViewVersion == "Unavailable") score -= 15
    score = score.coerceIn(0, 100)
    return DiagnosticGrade(gradeFromScore(score), score, "Point-in-time process PSS, active WebView tab count, and WebView provider availability. This is a runtime health heuristic, not a page-speed benchmark.")
}

fun uiContrastGrade(contrastRatio: Double): DiagnosticGrade {
    val score = when {
        contrastRatio >= 7.0 -> 100
        contrastRatio >= 4.5 -> 90
        contrastRatio >= 3.0 -> 65
        else -> 30
    }
    return DiagnosticGrade(gradeFromScore(score), score, "Measured contrast between the active theme's primary text and main background. It does not certify every component or external webpage.")
}
