package com.dhyra.browser

import androidx.compose.ui.graphics.Color

/** Shared visual language for DHYRA 2.0: calm surfaces, crisp contrast and a focused accent. */
object DhyraDesignTokens {
    const val COMPACT_MAX_WIDTH_DP = 599
    const val MEDIUM_MAX_WIDTH_DP = 839

    val LightCanvas = Color(0xFFF3F5F8)
    val LightSurface = Color(0xFFFFFFFF)
    val LightSurfaceRaised = Color(0xFFF9FAFC)
    val LightText = Color(0xFF151922)
    val LightSecondaryText = Color(0xFF687181)
    val LightBorder = Color(0xFFE3E7EE)

    val DarkCanvas = Color(0xFF0D1118)
    val DarkSurface = Color(0xFF151B25)
    val DarkSurfaceRaised = Color(0xFF1D2633)
    val DarkText = Color(0xFFF3F6FC)
    val DarkSecondaryText = Color(0xFFA4AFBF)
    val DarkBorder = Color(0xFF2B3645)

    // DHYRA signature: arctic blue with a restrained violet highlight.
    val AccentBlue = Color(0xFF397BE8)
    val AccentViolet = Color(0xFF7467E8)
    val AccentSoft = Color(0xFFE9EEFF)
    val AccentCyan = Color(0xFF56C5CB)
    val Success = Color(0xFF269B70)
    val Warning = Color(0xFFC58A35)
    val Danger = Color(0xFFD65D69)
    val FocusRing = Color(0xFF8B9CFF)

    const val CONTENT_MAX_WIDTH_DP = 1040
    const val SCREEN_GUTTER_COMPACT_DP = 18
    const val SCREEN_GUTTER_EXPANDED_DP = 32
    const val CARD_RADIUS_DP = 24
    const val CONTROL_RADIUS_DP = 16
    const val MIN_TAP_TARGET_DP = 48
}
