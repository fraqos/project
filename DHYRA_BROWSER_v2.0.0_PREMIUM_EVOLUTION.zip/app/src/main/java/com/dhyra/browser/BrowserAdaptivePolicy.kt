package com.dhyra.browser

/** Window classes are based on the available app window width, not the physical device label. */
enum class DhyraWindowClass { COMPACT, MEDIUM, EXPANDED }

enum class DesktopPolicy { MOBILE, DESKTOP, AUTOMATIC }

fun windowClassForWidth(widthDp: Int): DhyraWindowClass = when {
    widthDp < 600 -> DhyraWindowClass.COMPACT
    widthDp < 840 -> DhyraWindowClass.MEDIUM
    else -> DhyraWindowClass.EXPANDED
}

/** Per-tab overrides have priority, followed by per-site preferences, then the global policy. */
fun resolveDesktopRequest(
    policy: DesktopPolicy,
    windowClass: DhyraWindowClass,
    tabOverride: Boolean?,
    siteOverride: Boolean?
): Boolean = tabOverride ?: siteOverride ?: when (policy) {
    DesktopPolicy.MOBILE -> false
    DesktopPolicy.DESKTOP -> true
    DesktopPolicy.AUTOMATIC -> windowClass != DhyraWindowClass.COMPACT
}

fun desktopPolicyFromStored(value: String?): DesktopPolicy = when (value?.lowercase()) {
    "mobile" -> DesktopPolicy.MOBILE
    "desktop" -> DesktopPolicy.DESKTOP
    else -> DesktopPolicy.AUTOMATIC
}

fun desktopPolicyToStored(policy: DesktopPolicy): String = when (policy) {
    DesktopPolicy.MOBILE -> "Mobile"
    DesktopPolicy.DESKTOP -> "Desktop"
    DesktopPolicy.AUTOMATIC -> "Auto"
}

fun gradeFromScore(score: Int): String = when {
    score >= 90 -> "A"
    score >= 80 -> "B"
    score >= 70 -> "C"
    score >= 60 -> "D"
    else -> "F"
}
