package com.dhyra.browser

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** A small, local-first note model stored in Preferences DataStore. */
data class DhyraNote(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val body: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val isFavorite: Boolean = false,
    val color: String = "Violet"
)

fun decodeNotes(raw: String): List<DhyraNote> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val item = array.optJSONObject(index) ?: return@mapNotNull null
        val id = item.optString("id").takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
        DhyraNote(
            id = id,
            title = item.optString("title"),
            body = item.optString("body").take(20_000),
            createdAt = item.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = item.optLong("updatedAt", System.currentTimeMillis()),
            isPinned = item.optBoolean("isPinned", false),
            isFavorite = item.optBoolean("isFavorite", false),
            color = item.optString("color", "Violet").take(24)
        )
    }
}.getOrDefault(emptyList())

fun encodeNotes(notes: List<DhyraNote>): String {
    val array = JSONArray()
    notes.forEach { note ->
        array.put(
            JSONObject()
                .put("id", note.id)
                .put("title", note.title.take(200))
                .put("body", note.body.take(20_000))
                .put("createdAt", note.createdAt)
                .put("updatedAt", note.updatedAt)
                .put("isPinned", note.isPinned)
                .put("isFavorite", note.isFavorite)
                .put("color", note.color.take(24))
        )
    }
    return array.toString()
}
