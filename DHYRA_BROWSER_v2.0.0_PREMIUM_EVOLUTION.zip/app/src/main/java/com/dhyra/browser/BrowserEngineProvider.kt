package com.dhyra.browser

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView

/** Configuration passed across the engine boundary. Extend this instead of coupling UI to WebView. */
data class BrowserEngineConfiguration(
    val trackingProtection: Boolean,
    val popupBlocker: Boolean,
    val privateTab: Boolean,
    val requestDesktopSite: Boolean
)

/**
 * Rendering-engine boundary. The current production provider is Android System WebView;
 * a future GeckoView/Chromium provider can implement this contract without changing Compose UI.
 */
interface BrowserEngineProvider {
    val id: String
    val displayName: String
    fun configure(view: WebView, context: Context, configuration: BrowserEngineConfiguration)
}

class AndroidSystemWebViewProvider : BrowserEngineProvider {
    override val id: String = "android-system-webview"
    override val displayName: String = "Android System WebView"

    override fun configure(view: WebView, context: Context, configuration: BrowserEngineConfiguration) {
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setGeolocationEnabled(true)
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = !configuration.popupBlocker
            setSupportMultipleWindows(true)
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = if (configuration.privateTab) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            safeBrowsingEnabled = true
            useWideViewPort = configuration.requestDesktopSite
            loadWithOverviewMode = configuration.requestDesktopSite
            val systemUserAgent = WebSettings.getDefaultUserAgent(context)
            userAgentString = if (configuration.requestDesktopSite) {
                systemUserAgent
                    .replace(Regex("\\(Linux; Android [^)]*\\)"), "(X11; Linux x86_64)")
                    .replace("; wv", "")
                    .replace(" Version/4.0", "")
                    .replace(" Mobile", "")
            } else {
                systemUserAgent
            }
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, !configuration.trackingProtection)
    }
}
