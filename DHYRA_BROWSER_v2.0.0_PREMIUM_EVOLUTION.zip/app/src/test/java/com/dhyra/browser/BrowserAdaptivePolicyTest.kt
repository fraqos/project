package com.dhyra.browser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BrowserAdaptivePolicyTest {
    @Test fun windowClassesUseAvailableWidthBreakpoints() {
        assertEquals(DhyraWindowClass.COMPACT, windowClassForWidth(390))
        assertEquals(DhyraWindowClass.MEDIUM, windowClassForWidth(720))
        assertEquals(DhyraWindowClass.EXPANDED, windowClassForWidth(900))
    }

    @Test fun desktopPolicyAutoSelectsTabletAndExpandedWindows() {
        assertFalse(resolveDesktopRequest(DesktopPolicy.AUTOMATIC, DhyraWindowClass.COMPACT, null, null))
        assertTrue(resolveDesktopRequest(DesktopPolicy.AUTOMATIC, DhyraWindowClass.MEDIUM, null, null))
        assertTrue(resolveDesktopRequest(DesktopPolicy.AUTOMATIC, DhyraWindowClass.EXPANDED, null, null))
    }

    @Test fun perSiteAndPerTabOverridesTakePriority() {
        assertTrue(resolveDesktopRequest(DesktopPolicy.MOBILE, DhyraWindowClass.COMPACT, null, true))
        assertFalse(resolveDesktopRequest(DesktopPolicy.DESKTOP, DhyraWindowClass.EXPANDED, false, true))
        assertTrue(resolveDesktopRequest(DesktopPolicy.MOBILE, DhyraWindowClass.COMPACT, true, false))
    }

    @Test fun storedModeDefaultsToAutomatic() {
        assertEquals(DesktopPolicy.AUTOMATIC, desktopPolicyFromStored(null))
        assertEquals(DesktopPolicy.DESKTOP, desktopPolicyFromStored("Desktop"))
        assertEquals(DesktopPolicy.MOBILE, desktopPolicyFromStored("mobile"))
    }

    @Test fun scoreGradesUseExplicitBoundaries() {
        assertEquals("A", gradeFromScore(90))
        assertEquals("B", gradeFromScore(80))
        assertEquals("C", gradeFromScore(70))
        assertEquals("D", gradeFromScore(60))
        assertEquals("F", gradeFromScore(59))
    }
}
