# Dhyra Browser v1.5.2 — UI/UX refinement

## Included in this revision
- Refined a shared Material typography scale for consistent hierarchy and compact reading sizes.
- Tightened Home screen spacing and reduced the visual weight of the search capsule and action cards.
- Standardized browser address and bottom navigation heights at 48 dp with consistent radii.
- Added a contrast guard for custom font colors: custom foreground colors that fail a 4.5:1 contrast check against the main canvas fall back to the higher-contrast neutral.
- Added subtle content-size animation to expandable settings/action surfaces.
- Pauses the previously active WebView when creating/selecting another tab and resumes the selected tab to reduce background rendering work.
- Updated app/workflow version metadata to 1.5.2.

## Existing features retained
WebView navigation, tabs, downloads, bookmarks, history, settings, theme presets, color editor, find-in-page, popup control, lightweight tracker-host blocking, desktop user agent, file chooser, media permission, geolocation permission, and drawer navigation remain in the project.

## Known limitations retained
- Private tabs are not isolated in a separate cookie/storage profile; WebView's global CookieManager means this is not equivalent to Safari private-browsing isolation.
- Tracker protection is a small host deny-list, not a comprehensive content-blocking rules engine.
- Frosted surfaces use translucent gradients and highlights, not real-time backdrop blur.
- A full Android Gradle build has not been executed in this environment. GitHub Actions must confirm compilation and packaging.
