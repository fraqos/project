# DHYRA Browser v1.7.0 — development notes

## Implemented in this pass

- Added `DhyraNote` with bounded local JSON serialization (200 notes, 20,000 characters per body) and persistence through Preferences DataStore.
- Added Notes list/editor with create, edit, debounced autosave, save-failure state/retry, search, pin/favorite toggles, timestamps, delete confirmation, and text sharing.
- Added a Privacy Center for the real WebView controls, per-request camera/microphone/location site prompts, Android app permission settings shortcut, shared-profile data clearing, and an explicit private-mode caveat.
- Added entry points for Notes and Privacy from the home screen and drawer.
- Updated browser Home navigation to use the configured homepage.
- Restricted direct address-bar navigation to validated HTTP/HTTPS URLs and hardened untrusted external intent handling.
- Corrected tracker matching for Facebook pixel request paths.
- Improved DownloadManager status display and byte-progress feedback; opening is restricted to completed downloads.
- Added a DHYRA vector launcher icon, set `allowBackup=false`, and aligned version metadata/build workflow to 1.7.0.

## Important platform boundaries

- Android System WebView is retained; this change does not create a new browser engine.
- WebView private tabs share process-level cookies and website storage. The application now explains this in the Privacy Center and clears shared data with an explicit warning.
- Tracker protection remains a limited built-in list and is not equivalent to a full content-blocking filter engine.
- Notes are plain text and are persisted locally. Rich text, checklists, tags/categories, import, and file export are not part of this release; Android's share sheet provides text export.
- DownloadManager exposes status and bytes, but this build does not implement pause/resume/retry or a complete in-app download database.

## Validation status

Static validation is run on the packaged source (XML, YAML, workflow shell scripts, source-structure checks, address validation test cases, archive integrity). A full Android Gradle compilation/APK build and device interaction test still require Android SDK/Gradle execution in CI or on an Android development machine; they are not claimed as completed here.
