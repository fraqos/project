# Dhyra Browser — Air Edition UI Upgrade

## What changed in this iteration

- Added persistent ambient presets: Morning Mist, Warm Sand, Sage Calm, Midnight Air.
- Reworked New Tab into a calmer, intentionally sparse landing surface with a prominent search field and optional quick destinations (Saved, History, Downloads).
- Added a thumb-friendly floating address pill below the WebView with secure-origin indicator, Go, and Reload/Stop action.
- Added an understated browser top bar and kept page rendering in the native WebView surface.
- Enabled edge-to-edge at Activity startup; system bars are transparent and Compose surfaces apply safe-area padding.
- Disabled drawer drag gestures. The drawer opens only through its explicit menu affordance; its modal scrim prevents touches reaching the WebView while open.
- Added a reusable FrostedSurface component using translucent color layers, fine borders, and a static shadow. It intentionally does not run a blur shader on every scroll frame.
- Added an immutable `BrowserSnapshot` StateFlow contract. UI reads tab state from `collectAsState`; WebView remains owned by BrowserController and page scroll is not bridged into Compose state.

## UI architecture

- `MainActivity.kt`: Activity entry point, edge-to-edge setup, lifecycle, Compose route wiring and Android permission/result launchers.
- `BrowserController.kt`: WebView/tab engine owner, browser actions, callbacks and immutable StateFlow snapshots.
- `ui/theme/MoodPreset.kt`: pure ambient palette definitions.
- `ui/components/FrostedSurface.kt`: reusable lightweight translucent surface.
- `ui/gestures/DrawerGesturePolicy.kt`: explicit-only drawer policy; no edge swipe recognizer competes with WebView gestures.

## Compatibility and performance notes

- Minimum SDK remains 26. Edge-to-edge is enabled through `enableEdgeToEdge()` and works on older supported Android versions through AndroidX compatibility behavior.
- The acrylic treatment is a translucent fallback surface with static gradients/highlights, not a continuously recalculated backdrop blur. This is deliberate for WebView scrolling performance.
- WebView remains a native AndroidView and is not nested inside a Compose scroll container.
- No pointer-input gesture detector is installed over the WebView. Vertical scroll therefore remains owned by Chromium/WebView.
- The modal drawer scrim intercepts input while open; drawer gestures are disabled to prevent accidental opening during page scrolling.

## Verification status

Source structure and ZIP integrity are checked. A full Gradle build could not be completed in this environment because `services.gradle.org` was unreachable (DNS resolution failure). Please run `./gradlew assembleDebug` in GitHub Actions or a connected Android build environment before release.
