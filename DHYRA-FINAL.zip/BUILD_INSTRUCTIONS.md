# DHYRA Browser — Build Instructions

## Requirements

- JDK 17
- Android SDK Platform 35
- Android SDK Build Tools 35.0.0
- Android SDK licenses accepted
- Gradle 8.13 (the included `gradlew` uses PATH Gradle only when it is version 8.13, or downloads and checksum-verifies the pinned Gradle distribution)

## Local debug build

From the directory containing `settings.gradle.kts`:

```bash
./gradlew --version
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions setup

The included workflow supports two source layouts. Choose one; do not keep two active workflows that run the same build.

### Option A — Commit project contents (recommended)

1. Extract `DHYRA-FINAL.zip` once on your computer.
2. Commit the extracted project contents to the repository root.
3. Ensure `settings.gradle.kts`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`, `gradle/`, and `.github/workflows/build.yml` appear at the repository root.
4. Keep `.github/workflows/build.yml` as the active workflow. Remove or disable any older `.github/workflows/main.yml` to avoid duplicate runs.
5. Push to `main` or `master` and enable GitHub Actions.

### Option B — Keep one ZIP in the repository

1. Keep the active workflow at `.github/workflows/main.yml` (use the provided `main.yml` file).
2. Commit exactly one project archive, such as `DHYRA-FINAL.zip`, to the repository root.
3. Do not extract it manually. The workflow safely validates and extracts the ZIP into a temporary CI directory, locates the Android Gradle root, and builds it.
4. The workflow prefers a Gradle project already committed at repository root; only when that is absent does it look for exactly one root-level ZIP.

The workflow file must itself be committed under `.github/workflows/` to be activated by GitHub Actions. A workflow stored only inside a ZIP is not activated until committed to the repository.

## Manual workflow

GitHub repository → Actions → **DHYRA Android CI** → Run workflow. `build_release` is optional and produces an unsigned release APK. The normal CI artifact is a debug APK for testing, not a Play Store-signed release.

## Output artifact

Download `DHYRA-FINAL-<run number>` from the completed Actions run. It contains:

- `DHYRA-FINAL.zip` — clean source project archive
- `DHYRA-Browser-v2.0-Pro.apk` — verified debug APK
- `SHA256SUMS.txt` — SHA-256 digests for the ZIP and APK

To check checksums on Linux/macOS:

```bash
sha256sum --check SHA256SUMS.txt
```

## If a build fails

1. Open the failed Actions run and expand the first failing Gradle task.
2. Distinguish environment failures (JDK/SDK/license/download) from source failures (`compileDebugKotlin`, lint, test or resource processing).
3. Use the earliest meaningful `e:` Kotlin compiler message or Gradle `What went wrong` block; later task failures often cascade from the first one.
4. Download the `DHYRA-build-diagnostics-*` artifact if it was uploaded. It can contain lint reports and Gradle output logs.
5. Do not mark the release as built until `testDebugUnitTest`, `lintDebug`, `assembleDebug`, APK validation, source ZIP validation and checksum verification have all succeeded.

## Security and signing

No signing key, password, API key or keystore is included. `assembleRelease` yields an unsigned APK unless a separate protected signing process is configured with GitHub Secrets. Never put signing credentials in the repository or project ZIP.
