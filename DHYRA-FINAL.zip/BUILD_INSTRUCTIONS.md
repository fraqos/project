# DHYRA Browser — Build Instructions

## Requirements

- JDK 17
- Android SDK Platform 35
- Android SDK Build Tools 35.0.0
- Android SDK licenses accepted
- Gradle 8.13 (the included `gradlew` uses PATH Gradle only when it is version 8.13, or downloads and checksum-verifies the pinned Gradle distribution)

## Local debug build

From the directory containing `settings.gradle.kts`:

```bash
./gradlew --version
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## One-time GitHub setup

1. Create/open the repository.
2. Extract `DHYRA-FINAL.zip` once.
3. Commit the extracted project **contents** at repository root. Do not commit only the ZIP file.
4. Confirm the root contains `settings.gradle.kts`, `build.gradle.kts`, `gradle/`, `app/`, and `.github/workflows/build.yml`.
5. Push to `main` or `master`; make sure GitHub Actions are enabled.

After that setup, GitHub is the canonical source. Every push to the main branch and every pull request executes the CI workflow; there is no need to re-upload a project archive or extract one per run.

## Manual workflow

GitHub repository → Actions → **DHYRA Android CI** → Run workflow. `build_release` is optional and produces an unsigned release APK. The normal CI artifact is a debug APK for testing, not a Play Store-signed release.

## Output artifact

Download `DHYRA-FINAL-<run number>` from the completed Actions run. It contains:

- `DHYRA-FINAL.zip` — clean source project archive
- `DHYRA-Browser-v2.0-Pro.apk` — verified debug APK
- `SHA256SUMS.txt` — SHA-256 digests for the ZIP and APK

To check checksums on Linux/macOS:

```bash
sha256sum --check SHA256SUMS.txt
```

## If a build fails

1. Open the failed Actions run and expand the first failing Gradle task.
2. Distinguish environment failures (JDK/SDK/license/download) from source failures (`compileDebugKotlin`, lint, test or resource processing).
3. Use the earliest meaningful `e:` Kotlin compiler message or Gradle `What went wrong` block; later task failures often cascade from the first one.
4. Download the `DHYRA-build-diagnostics-*` artifact if it was uploaded. It can contain lint reports and Gradle output logs.
5. Do not mark the release as built until `testDebugUnitTest`, `lintDebug`, `assembleDebug`, APK validation, source ZIP validation and checksum verification have all succeeded.

## Security and signing

No signing key, password, API key or keystore is included. `assembleRelease` yields an unsigned APK unless a separate protected signing process is configured with GitHub Secrets. Never put signing credentials in the repository or project ZIP.
