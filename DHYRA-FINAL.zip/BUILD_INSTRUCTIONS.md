## DHYRA 2.1.2 update

The translation sheet now uses the Material 3 `ExposedDropdownMenuBoxScope.ExposedDropdownMenu` extension with an explicit `ExposedDropdownMenuAnchorType.PrimaryNotEditable` anchor. `BrowserController.restoreSession` is internal to match the internal `SessionTab` model. CI runs `scripts/check-compose-contracts.py` before the Gradle tasks.

# DHYRA Browser — Build Instructions

## Required toolchain

- JDK 17 or newer (CI uses JDK 21)
- Android SDK Platform 37.1
- Android SDK Build Tools 36.0.0
- Android SDK licenses accepted
- Gradle 9.5.1
- Android Studio version capable of syncing AGP 9.3.1 and API 37.1

The project compiles against API 37.1, targets API 36, and supports Android API 26+ by `minSdk`. The API target aligns with the Google Play requirement for new apps and updates effective 31 August 2026; it does not replace device compatibility testing.

## Local build

From the directory containing `settings.gradle.kts`:

```bash
./gradlew --version
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

### Gradle Wrapper note

The repository contains a SHA-256-pinned Gradle bootstrap script and `gradle-wrapper.properties`; the standard `gradle-wrapper.jar` is generated in GitHub Actions before build. For Android Studio sync on a fresh local clone before that artifact exists, install Gradle 9.5.1 and configure Android Studio to use the local Gradle installation. The bootstrap scripts can also download Gradle 9.5.1 when network access is available.

## GitHub Actions

Canonical workflow: `.github/workflows/build.yml`. Keep only one DHYRA workflow active.

### Preferred: commit source contents

1. Extract the supplied DHYRA project ZIP once.
2. Commit the contents of the extracted project to repository root.
3. Ensure `settings.gradle.kts`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`, `gradle/` and `.github/workflows/build.yml` are at their expected locations.
4. Push to `main` or `master`, open a pull request, or manually run the workflow.

### Alternative: ZIP-only repository

1. Commit `.github/workflows/build.yml` separately under the repository's `.github/workflows/` directory. GitHub cannot activate a workflow that exists only inside an unextracted ZIP.
2. Commit exactly one DHYRA `.zip` at repository root.
3. Do not manually extract it. The workflow validates the archive and extracts it into a temporary CI directory.
4. The workflow finds the Gradle project root and runs the same build steps against it. Keep only one root-level project ZIP; multiple ZIPs are rejected to prevent an ambiguous build.

If project source exists at repository root, it takes precedence over ZIP extraction.

## CI pipeline

- Checkout repository.
- Locate source at root or extract one ZIP safely.
- Set up JDK 21 and Android SDK licenses.
- Install API 37.1 and Build Tools 36.0.0.
- Set up Gradle 9.5.1 and generate a standard wrapper JAR in the CI working directory.
- Run `:app:checkDebugAarMetadata` before tests.
- Run deterministic Node translation DOM/retry smoke tests (Node is available on GitHub's Ubuntu runner).
- Run `testDebugUnitTest`.
- Run `lintDebug`.
- Run `assembleDebug`.
- Verify APK ZIP integrity, AndroidManifest.xml and DEX bytecode.
- Package clean source ZIP and generate/verify SHA-256 checksums.
- Upload APK, source ZIP and checksums as Actions artifacts.

The debug APK is for testing. Optional release output is unsigned unless a protected signing configuration is added. Never commit signing keys or passwords.

## Troubleshooting

- `No Android project ... no .zip was found`: commit project contents at root or exactly one ZIP at root.
- `No Android Gradle project was found in ZIP`: archive must contain `settings.gradle(.kts)`, `app/build.gradle(.kts)`, and `app/src/main/AndroidManifest.xml`.
- `Failed to find package 'tools'`: do not request obsolete SDK package `tools`; use `android-actions/setup-android@v4.0.4` and modern command-line tools.
- Kotlin metadata errors: inspect the first Kotlin compiler diagnostic and verify Kotlin plugin, AGP, Gradle and third-party dependency versions together.
- Android theme attribute `NewApi` lint errors: keep `windowLightNavigationBar` in `values-v27` / `values-night-v27` (API 27+) and `windowLayoutInDisplayCutoutMode` in `values-v28` / `values-night-v28` (API 28+); do not put these attributes in unqualified `values` resources while `minSdk` is 26.
- Missing wrapper JAR: CI generates the standard wrapper before build; local Android Studio sync can use installed Gradle 9.5.1 until the wrapper JAR is generated.
- Artifact missing: ensure tests, lint, assemble, APK checks and source ZIP checks completed successfully.

## On-device page translation

For local JavaScript regression checks (Node.js required), run:

```bash
node --check app/src/main/assets/PageTranslation.js
node scripts/test-page-translation.cjs
node scripts/test-translation-retries.cjs
```

The app includes Google ML Kit Translate and Language Identification. The first translation for a language pair downloads its model; Wi-Fi-only is enabled by default in the translation sheet. Once the model is present, translations run on-device. Do not expect translation to work offline before the required language model has been downloaded.
