# DHYRA Browser 2.0.2

DHYRA is an Android browser built with Kotlin, Jetpack Compose Material 3 and the Android System WebView supplied by the device. Websites are rendered by the real WebView engine; DHYRA does not simulate websites and does not bundle Chromium. This project builds an Android application for phones, foldables and tablets. Desktop-site mode requests a desktop version of a website; it is not a Windows/macOS/Linux browser.

## Project status

This is an engineering build candidate, **not yet production-certified**. The source has received privacy, lifecycle, UI and CI improvements described below. This authoring environment does not include Android SDK or Gradle 9.5.1 and outbound DNS is unavailable, so a full Android Gradle build, Android Lint, APK creation, emulator run and real-device QA have not been claimed. Run the included GitHub Actions workflow to perform the Android build gates.

## Toolchain

| Component | Version |
|---|---|
| Kotlin / Compose compiler plugin | 2.4.21 |
| Android Gradle Plugin | 9.3.1 |
| Gradle | 9.5.1 |
| JDK | 21 in CI (17 minimum) |
| compileSdk / targetSdk / minSdk | 37.1 / 36 / 26 |
| Compose BOM | 2026.11.01 |
| Activity Compose | 1.13.0 |
| Lifecycle runtime | 2.10.0 |
| Core KTX | 1.19.0 |
| Preferences DataStore | 1.2.1 |
| AndroidX WebKit | 1.17.1 |
| Web rendering | Android System WebView |
| UI | Jetpack Compose Material 3 |
| QR encoding | ZXing Core 3.5.3 |

The application targets API 36. Google Play requires new apps and app updates to target Android 16 / API 36 or higher from 31 August 2026. This API target does not mean that all Android 16 behavior or device compatibility has been validated; compatibility QA is still required. See [Google Play target API requirements](https://developer.android.com/google/play/requirements/target-sdk). The compile SDK is 37.1 specifically because Compose BOM 2026.11.01 / Compose 1.13.0 declares that requirement; compile SDK and target SDK serve different purposes.

Kotlin uses the typed `compilerOptions` DSL with `JvmTarget.JVM_17`, aligned with Java `sourceCompatibility` and `targetCompatibility`. The obsolete `kotlinOptions { jvmTarget = "17" }` block is not used.

## Architecture today

```text
app/src/main/java/com/dhyra/browser/
├── MainActivity.kt                 # Activity, Compose root, preferences and app routing
├── BrowserController.kt            # WebView sessions, tab lifecycle and browser callbacks
├── UiModels.kt                     # Preferences, lightweight data models and JSON codecs
├── core/
│   ├── downloads/                  # Download policy and status refresh rules
│   ├── nav/                        # Address resolver and Back policy
│   ├── network/                    # HTTPS-first, privacy headers and UA helpers
│   ├── shields/                    # Lightweight host/path blocking engine
│   ├── suggest/                    # Local history/bookmark suggestions
│   └── tabs/                       # Tab selection and private-session policies
└── ui/
    ├── components/                 # Omnibox, quick menu, sheets and controls
    ├── screens/                    # Home, browser, tabs, settings and library screens
    └── theme/                      # Material 3 themes and shared design tokens
```

The codebase is not yet a fully separated multi-module MVVM/Room/DI architecture. `MainActivity.kt`, `BrowserController.kt` and `UiModels.kt` remain relatively large; further extraction and a safe migration from JSON DataStore to Room are planned rather than being claimed complete. Existing JSON history/bookmark/session data is retained to avoid destructive migration.

## Implemented behavior in this source

- Material 3 theme with system, dynamic colour on supported Android versions, light, dark and AMOLED modes; shared spacing, shape and motion tokens.
- Address bar is fixed at the top. There is no setting or layout path to move it to the bottom. Fullscreen media hides browser chrome instead of relocating it.
- Home speed dial uses a responsive FlowRow rather than a fixed four-column grid; greeting/date refresh while the app is open.
- Tab overview uses adaptive grid sizing, search for larger tab sets, title/favicon/preview where available, private markers, close gestures and close-all undo for regular tabs.
- URL/search resolution, local suggestions, history/bookmark search, bookmark JSON import/export, loading, back/forward/reload, copy/share and horizontal tab switching.
- WebView lifecycle is forwarded from Activity pause/resume; inactive tabs are saved in memory and destroyed when over the live-WebView limit; renderer crash recovery remains enabled.
- **Private browsing is feature-gated.** It uses a named AndroidX WebKit profile only when runtime WebView supports both `MULTI_PROFILE` and `DELETE_BROWSING_DATA`. DHYRA assigns the profile before using each private WebView and clears profile data at startup and after the final private tab closes. If support/cleanup is missing, private tabs are disabled rather than silently using regular storage. Private downloads, bookmarks and speed-dial additions are blocked to avoid persistent traces; Reader/Translate remain explicit user actions, and Translate warns that the external service receives the page URL. Private WebViews also opt out of Android Autofill and saved view state.
- HTTPS-first for browser-initiated main-frame navigation, cancellation of TLS certificate errors, mixed-content restrictions, Safe Browsing, file access restrictions, DNT/GPC on browser-initiated top-level requests and third-party cookie controls.
- Lightweight host/path Shields interception with per-site enable/disable and observed blocked-request counters. Regular and private per-site overrides are held separately; request-thread interception reads concurrent URL/override state instead of Compose snapshots. The app no longer invents a byte-savings figure; transferred bytes are not measured.
- Downloads use Android `DownloadManager`, with notifications, status display, open-file action, sanitised leaf filenames and lifecycle-aware polling. Android `DownloadManager` does not provide app-controlled pause/resume in this implementation.
- Quick actions include find-in-page, desktop-site mode, external translation handoff, CSS reader presentation, share, print/PDF and QR.
- **AdMob and monetization are removed**: no Ads SDK dependency, application metadata, initialization, ad component, placement or affiliate tagging.

## Privacy model and limitations

Private profile isolation is attempted only when the installed WebView provider advertises both required features. The private profile is cleared through the profile-specific `WebStorageCompat.deleteBrowsingData` API; runtime support and behavior still require tests on physical devices and multiple WebView provider versions. If profile attachment fails at runtime, DHYRA disables private tabs rather than using the default profile. The private session is not backed up or restored. Private downloads and device permission requests (camera, microphone, protected media and geolocation) are refused. This is a real profile boundary offered by AndroidX WebKit, not a separate operating-system user or Chromium process sandbox.

Shields is a lightweight host/path matcher, not a full EasyList/uBlock engine. It does not implement full filter-list syntax, cosmetic filters, scriptlets, resource-type/initiator rules, regional auto-subscriptions or full compatibility testing. Counts describe only requests observed and intercepted by WebView callbacks. Bytes saved are not measured.

HTTPS-first applies to browser-initiated main-frame navigation. It does not guarantee HTTPS for links or redirects handled internally by every website. DNT/GPC headers are only attached to browser-initiated top-level requests; they are not guaranteed on all subresources. These headers are requests for privacy, not enforcement against sites.

Reader Mode remains a CSS presentation mode, not an article extraction engine. Translation opens Google Translate in a new tab and uses the device locale as the target language; it is an external service. DoH entries are provider presets only and do not route WebView DNS through a custom DoH transport. Anti-fingerprinting and WebRTC leak protection are not complete.

## Build locally

Requirements: JDK 17 or newer (CI uses JDK 21), Android SDK Platform 37.1, Android Build Tools 36.0.0, accepted SDK licenses and Gradle 9.5.1. The supplied `gradlew`/`gradlew.bat` are checksum-pinned bootstrap scripts, not the standard Gradle Wrapper launcher JAR. They invoke installed Gradle 9.5.1 or download the pinned distribution. For Android Studio sync, configure a local Gradle 9.5.1 installation if the wrapper JAR has not yet been generated.

From the project root:

```bash
./gradlew --version
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

The canonical workflow is `.github/workflows/build.yml`. Keep only this DHYRA workflow active.

The workflow supports:

1. **Source at repository root (recommended):** commit the extracted project contents, including `settings.gradle.kts`, `app/`, `gradle/` and `.github/workflows/build.yml`.
2. **One ZIP at repository root:** keep the workflow committed separately under `.github/workflows/build.yml` and commit exactly one DHYRA `.zip` at repository root. The workflow safely validates and extracts it into a temporary directory. No manual extraction is required for CI.

The workflow sets up JDK 21, Android SDK Platform 37.1 / Build Tools 36.0.0 and Gradle 9.5.1, generates a standard Gradle Wrapper in the CI working directory, runs `testDebugUnitTest`, `lintDebug` and `assembleDebug`, validates the APK manifest and DEX entries, creates a clean source ZIP and SHA-256 sums, and uploads artifacts. Optional unsigned release APK build is available via `workflow_dispatch`; unsigned output is not ready for public distribution.

## Documentation

- `BUILD_INSTRUCTIONS.md` — local build and GitHub Actions setup.
- `docs/AUDIT_AND_CHANGELOG.md` — source audit and engineering changes.
- `docs/IMPLEMENTATION_STATUS.md` — current implemented state and limitations.
- `docs/MANUAL_TEST_CHECKLIST.md` — physical-device QA plan.
- `docs/UI_UX_OVERHAUL.md` — Compose design system and layout behavior.
- `docs/BUILD_VERIFICATION.md` — checks performed and build verification boundary.
- `docs/GITHUB_UPLOAD_GUIDE.md` — canonical workflow setup.
- `THIRD_PARTY_NOTICES.md` — direct dependency notices.

## License

No project-level license file was present in the supplied source archive. Do not assume the project is open source or redistribute it under a license without the owner's decision.
