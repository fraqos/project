# DHYRA Browser 2.0.0

DHYRA is an **Android browser** built with Kotlin, Jetpack Compose Material 3 and the Android System WebView installed on the device. Websites are rendered by the real system WebView engine; DHYRA does not emulate pages and does not bundle a separate Chromium engine. This repository does not produce a Windows/macOS/Linux desktop executable. Tablet and large-screen layouts are Android layouts.

## Project status

This is a development release candidate, **not yet production-certified**. Source-level checks and pure-JVM unit tests can be run locally, but this authoring environment has no Android SDK, no Gradle distribution, and cannot resolve outbound DNS. Therefore a full Android Gradle build, lint run, APK generation and device QA have not been claimed as complete. GitHub Actions is configured to run those checks on the committed project.

## Technology and build versions

| Component | Version |
|---|---|
| Language | Kotlin 2.3.20 |
| UI | Jetpack Compose Material 3, Compose BOM 2024.10.01 |
| Android Gradle Plugin | 8.13.2 |
| Gradle | 8.13 |
| JDK | 17 |
| compileSdk / targetSdk / minSdk | 35 / 35 / 26 |
| Browser engine | Android System WebView |
| WebKit support library | AndroidX WebKit 1.12.1 |
| QR | ZXing Core 3.5.3 |

Kotlin uses the typed `compilerOptions` DSL with `JvmTarget.JVM_17`, aligned with Java `sourceCompatibility` and `targetCompatibility`. The obsolete `kotlinOptions { jvmTarget = "17" }` block is not used. Kotlin 2.3.20 is within the documented compatibility range for Gradle 8.13 and AGP 8.13.2. See the [Kotlin Gradle compatibility table](https://kotlinlang.org/docs/gradle-configure-project.html) and [Android Kotlin/R8 support table](https://developer.android.com/build/kotlin-support).

## Architecture

```text
app/src/main/java/com/dhyra/browser/
├── MainActivity.kt                 # Activity, Compose state, routing and platform integration
├── BrowserController.kt            # WebView instances, navigation, downloads and lifecycle
├── UiModels.kt                     # Preferences, UI models and JSON codecs
├── core/
│   ├── downloads/                  # Download state/presentation policy
│   ├── nav/                        # Address resolution and Back policy
│   ├── network/                    # HTTPS-first, privacy headers and UA presets
│   ├── shields/                    # Host/path filtering engine
│   ├── suggest/                    # Local history/bookmark suggestions
│   └── tabs/                       # Tab selection and private-session policy
└── ui/
    ├── components/                 # Omnibox and sheets
    ├── screens/                    # Home, browser, tabs, settings, history/bookmarks
    └── theme/                      # Material 3, dynamic, light, dark and AMOLED themes
```

`BrowserController` is still the WebView session coordinator. The app is not yet a full multi-module MVVM/Room/DI implementation.

## Current features

- Material 3 interface, system/dynamic colours, light/dark/AMOLED themes, Compose transitions and a tablet-friendly Android layout.
- **Address bar is fixed at the top.** There is no setting or code path to move it to the bottom. In WebView custom fullscreen media mode, browser chrome is hidden rather than moved.
- URL/search resolution, local history/bookmark suggestions, autocomplete, loading progress, back/forward/reload, copy/share and horizontal tab switching gesture.
- Multi-tab WebViews, tab grid/cards, current title, loading state, preview snapshots where available, favicon where WebView supplies one, private marker, close/restore actions and renderer-crash recovery.
- Home speed dial, recent pages, bookmarks/history search, bookmark JSON import/export, Downloads screen and Android `DownloadManager` notifications.
- Quick actions for find-in-page, desktop user agent/viewport, translation handoff, reader CSS mode, share, print-to-PDF and QR display.
- Lightweight host/path Shields interception, a bundled small blocklist, per-site enable/disable and in-memory blocked-request counts.
- HTTPS-first upgrade for browser-initiated main-frame HTTP navigation, cancellation of TLS certificate errors, DNT/GPC headers on browser-initiated top-level requests and third-party-cookie control.
- WebView file chooser, site permission forwarding, fullscreen custom view, and best-effort picture-in-picture entry on fullscreen video leave.
- **AdMob and monetization are disabled and removed**: no Ads SDK dependency, no AdMob application metadata, no AdMob lifecycle or UI component, no partner/affiliate tagging.

## Address bar invariant

The address bar is always rendered before the WebView in `BrowserPage`. The editable omnibox overlay is aligned to `Alignment.TopCenter`. The old address-position preference and selector were removed, so a saved `Bottom` preference cannot move it. Fullscreen custom media hides standard browser chrome by design; it does not relocate the address bar.

## Build locally

Requirements: JDK 17, Android SDK Platform 35 and Build Tools 35.0.0. Ensure Android SDK licenses are accepted. From the repository root:

```bash
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

The included portable `gradlew` bootstrap uses an installed Gradle only when its version is exactly 8.13; otherwise it downloads the pinned Gradle 8.13 distribution and verifies its SHA-256 before use. In a clean machine, network access to `services.gradle.org` is required. GitHub Actions provisions Gradle 8.13 and generates a standard Gradle Wrapper (including its JAR) before the build tasks.

## One-time GitHub repository setup

The repository—not an uploaded ZIP—is the source of truth for recurring builds.

1. Create or open the GitHub repository and extract `DHYRA-FINAL.zip` **once** on your computer.
2. Upload/commit the *contents* of the extracted project directory to the repository root. `settings.gradle.kts`, `app/`, `gradle/` and `.github/workflows/build.yml` must be visible at the root.
3. Commit and push to `main` (or `master`). Ensure Actions are enabled for the repository.
4. After this one-time setup, subsequent code changes are ordinary Git commits/pushes. No ZIP upload or manual extraction is needed for each build.
5. Every push to `main`/`master`, pull request, or manual `workflow_dispatch` runs `.github/workflows/build.yml`.
6. Download the workflow artifact named `DHYRA-FINAL-<run number>`. It contains the clean source archive `DHYRA-FINAL.zip`, debug APK `DHYRA-Browser-v2.0-Pro.apk`, and `SHA256SUMS.txt`.

The YAML file included in this archive must be committed to `.github/workflows/build.yml` in the repository. A workflow file merely stored outside that path is not activated by GitHub Actions.

## Honest feature limitations

- **Private tabs are not independent Chromium profiles.** System WebView cookie/storage managers are shared. Private tabs are omitted from persisted history/session and use no-cache settings; closing the final private tab clears shared cookies and WebStorage on a best-effort basis, which can sign out normal tabs. This is not true profile isolation.
- **Shields is a lightweight host/path matcher**, not a full EasyList/uBlock engine. It does not implement cosmetic filters, scriptlets, regular-expression rules, initiator/resource-type matching, regional subscriptions, or filter-list auto updates. It can miss many ads/trackers.
- WebView interception can only apply to requests exposed by the WebView callbacks. Browser cannot promise to inspect/block all service-worker, WebRTC, DNS or platform network traffic.
- HTTPS-first applies to browser-initiated main-frame HTTP navigation. HTTP-only sites may fail; there is no automatic insecure downgrade. DNT/GPC headers are not guaranteed on every subresource request.
- DNS-over-HTTPS entries are provider presets only; the app does not route Android/WebView DNS through a custom DoH transport.
- User-Agent cleanup and third-party-cookie controls do not provide complete anti-fingerprinting or WebRTC leak protection.
- Downloads use Android `DownloadManager`; the app does not expose true pause/resume controls.
- Reader mode is a CSS presentation rather than a robust article extractor. Translation opens an external translation page. Background media audio and PiP behavior depend on the device, Android WebView and website.
- The app is Android-only. Desktop-site mode requests desktop pages from websites; it is not a native desktop browser application.

## Documentation

- `BUILD_INSTRUCTIONS.md` — local build, one-time GitHub setup and artifact retrieval.
- `docs/AUDIT_AND_CHANGELOG.md` — audit of this supplied source and changes applied in this final package.
- `docs/IMPLEMENTATION_STATUS.md` — implemented capabilities and limits.
- `docs/MANUAL_TEST_CHECKLIST.md` — manual device test plan.
- `docs/UI_UX_OVERHAUL.md` — Compose UI structure and interaction notes.
- `docs/BUILD_VERIFICATION.md` — validation record and unverified tasks.
- `docs/GITHUB_UPLOAD_GUIDE.md` — source-repository workflow setup.
- `THIRD_PARTY_NOTICES.md` — direct dependency notices.

## License

No project-level license file was present in the supplied source archive. Do not assume the project is open source or redistribute it under a license without the owner's decision.
