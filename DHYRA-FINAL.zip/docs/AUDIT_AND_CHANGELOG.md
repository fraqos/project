# DHYRA Browser 2.0.0 — source audit and final-package changelog

## Source audited

The latest supplied archive `DHYRA_Browser_v2.0_Pro(1).zip` was extracted and inspected. It contains an Android Gradle project using Kotlin, Jetpack Compose Material 3 and Android System WebView. The original archive contained 104 ZIP entries, including `MainActivity.kt`, `BrowserController.kt`, Compose screens/components/theme, core navigation/network/shields/tab/download helpers, Gradle configuration, tests, resources and two competing workflow files.

## Verified baseline

- Application ID: `com.dhyra.browser`; app version: 2.0.0 (versionCode 7).
- compileSdk 35, targetSdk 35, minSdk 26.
- Kotlin/Compose plugin 2.3.20, AGP 8.13.2, Gradle 8.13, Java/Kotlin bytecode target 17.
- Android System WebView is the web rendering engine.
- The source already had WebView tab instances, local history/bookmark storage, DownloadManager, file chooser/site permissions, fullscreen custom view, local suggestions, a host/path Shields filter and HTTPS-first navigation.

## Changes in this delivery

1. **AdMob/monetization removed:** deleted Google Mobile Ads dependency, manifest application metadata, app startup initialization, Native/Rewarded ad manager and components, Home/Downloads placements, affiliate helper/config, partner shortcut UI and related test. Search URLs are plain provider URLs without inserted referral tags.
2. **Address bar fixed at top:** removed `omnibox_position` DataStore key, model property, settings selector, `BrowserPage` bottom address-bar path and omnibox bottom-entry path. The page address bar is composed before WebView; the edit overlay is `Alignment.TopCenter`. Fullscreen media hides browser chrome, it does not move it.
3. **CI consolidated:** removed obsolete `.github/workflows/main.yml`; `.github/workflows/build.yml` now builds the committed source project directly. It does not expect a ZIP to be uploaded per run.
4. **Artifact pipeline:** after Gradle tests, lint and debug assembly, workflow validates APK ZIP entries/DEX, creates `DHYRA-FINAL.zip`, writes SHA-256 sums and uploads all outputs.
5. **Documentation updated:** root README, standalone build instructions, third-party notices and docs now match the actual Android-only project and the current limitations.

## Known limits that remain

- WebView private tabs are not isolated storage profiles. Cookie and WebStorage are system-wide/shared.
- Shields is a limited host/path rule matcher, not a complete EasyList/uBlock engine.
- DoH providers are presets only; no custom DNS transport is active.
- DNT/GPC are attached to browser-initiated navigation requests only; comprehensive subresource coverage is not possible with this implementation.
- Anti-fingerprinting and WebRTC leak protection are incomplete.
- DownloadManager UI does not provide pause/resume.
- Reader mode is CSS based; translation is delegated to an external translation page.
- The application is Android-only; desktop-site mode is a WebView UA/viewport mode, not a native PC browser.

## Verification boundary

The archive has been statically inspected and the pure-JVM tests have been run with the Kotlin compiler available in this workspace. Full Android Gradle build/lint/APK creation cannot be claimed from this environment: it has no Android SDK, no installed Gradle distribution and outbound DNS is unavailable. CI and real-device QA remain release gates.
