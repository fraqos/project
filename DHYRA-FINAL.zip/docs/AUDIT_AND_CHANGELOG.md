# DHYRA Browser 2.0.2 — Source Audit and Engineering Changelog

## Source audited

The current work is based on the latest supplied `DHYRA-FINAL(2).zip` plus its attached development directive. The archive was extracted and reviewed before editing. DHYRA is an Android Gradle app using Kotlin, Jetpack Compose Material 3 and Android System WebView.

## Baseline verified in source

- Application ID: `com.dhyra.browser`.
- Version advanced to 2.0.2 (versionCode 9).
- Kotlin / Compose plugin 2.3.20; AGP 8.13.2; Gradle 8.13; JVM target 17.
- compileSdk 36, targetSdk 36, minSdk 26.
- AndroidX WebKit upgraded to 1.17.1; Compose BOM 2026.11.01, Activity Compose 1.13.0, Lifecycle 2.10.0, Core KTX 1.19.1 and Preferences DataStore 1.2.1 pinned to stable releases.
- App state uses Preferences DataStore with JSON codecs for history, bookmarks and regular session; this package does not claim a Room migration.

## Engineering changes made during this pass

### Privacy and browser engine

1. Added runtime feature detection for WebView `MULTI_PROFILE` and `DELETE_BROWSING_DATA`.
2. Created/uses a named private WebView profile only when both capabilities are present.
3. Assigns private profile via `WebViewCompat.setProfile` immediately after WebView construction and before touching settings, cookies, clients, JavaScript or navigation.
4. Clears only private-profile browsing data on application start and after the last private tab is closed. Private mode remains unavailable until the asynchronous cleanup callback has completed. A generation token prevents an older cleanup callback from incorrectly marking a newer cleanup as complete.
5. Exposes private-profile readiness in Compose so the private-tab action is disabled while cleanup is pending. Unsupported providers do not fall back to default profile storage.
6. Private blank tabs also instantiate/attach the named profile before becoming visible, so a runtime profile-attachment failure is detected at tab creation rather than after first navigation.
6. Blocks downloads from private tabs because Android DownloadManager persists public records and files outside the private WebView profile.
7. Removed application-wide `WebView.clearCache(true)` from private-tab destruction. Profile-scoped cleanup is responsible for private cookies/cache/site storage, avoiding accidental impact on regular-profile cache.
8. Activity teardown now determines whether each WebView is private instead of treating every live WebView as private. Regular cookies/storage are not cleared on ordinary Activity teardown.
9. Preserved regular per-site Shields overrides when a private session ends.
10. Added Activity pause/resume forwarding, memory trimming for inactive tabs and per-tab Reader Mode state restoration.
11. Private tabs opt out of Android Autofill and regular View state saving. Persistent private bookmarks and speed-dial additions are blocked, private Translate preserves the private profile and warns about external URL disclosure, and private per-site Shields overrides no longer affect regular tabs.
12. WebView `shouldInterceptRequest` now reads per-tab URLs and site overrides from concurrent maps rather than accessing Compose snapshot state in its non-UI callback thread.

### Reliability and UX

1. Download status polling runs only while the screen lifecycle is STARTED, refreshes quickly for pending/running downloads and more slowly while idle. If a refresh fails, the last successful list remains visible when available.
2. Settings search now includes isolated private browsing terms.
3. Home speed-dial uses width-adaptive layout, the start-page omnibox includes a search-engine selector, and date/greeting state refreshes every minute.
4. Tab switcher uses adaptive grid sizing and a tab search when the set is large.
5. Tab card close/search/desktop/omnibox actions use larger touch targets; key tab segments meet a 48dp minimum height.
6. AMOLED theme sets Material 3 surface containers to true black/near-black values, not only the background surface.
7. Shields UI reports requests blocked for the current page and explicitly says transferred bytes are not measured; fabricated 32KB-per-request estimates were removed.
8. Translate target language uses the device locale and the UI explains that Google Translate opens externally.
9. Reader Mode state is associated with each tab and its presentation CSS is re-applied after navigation. It remains CSS presentation, not article extraction.
10. Version bumped to 2.0.2 / versionCode 9.

### Build and documentation

- Target SDK and CI SDK packages updated to API 36 / Build Tools 36.0.0.
- WebKit support library updated to 1.17.1 for Multi-Profile and profile-scoped data deletion APIs.
- Documentation was rewritten to distinguish implemented behavior from remaining work.
- Canonical CI workflow remains `.github/workflows/build.yml`; it supports committed source at root or exactly one ZIP at repository root, then runs test, strict lint and debug build.

## Important remaining work

- `MainActivity.kt`, `BrowserController.kt` and `UiModels.kt` remain large coordinator/data files. A full ViewModel/use-case/repository separation is not complete.
- History/bookmarks/download metadata are not migrated to Room. Existing JSON DataStore storage is retained to avoid an unsafe/destructive migration. A Room migration requires explicit schema/data migration tests.
- Private-profile behavior needs physical-device verification across WebView provider versions, including cookie and localStorage separation. It is feature-gated and disabled when support or cleanup is unavailable.
- Shields is a lightweight host/path engine; no claim of full EasyList/uBlock compatibility.
- Per-origin permission-management screen, robust article extraction, custom DoH transport, full fingerprinting/WebRTC protections and true download pause/resume are not complete.
- Compose instrumentation tests, WebView instrumentation tests, Macrobenchmark, LeakCanary, release signing and AAB validation remain release work.

## Verification boundary

Source/static checks and pure-JVM tests are performed separately in this environment. No Android Gradle build, Gradle lint, APK assembly, emulator/device QA or Play publication is claimed until the hosted CI and device test results exist.


## Additional privacy hardening

- Private profile attachment now fails closed if `WebViewCompat.setProfile` throws, disables private mode and removes the just-created private WebView rather than leaving an unusable tab.
- Private camera, microphone, protected-media and geolocation requests are denied; regular-tab permission prompts remain explicit and origin-labelled.
- Popup-created tabs are closed if WebView/profile creation or the transport fails, avoiding orphaned tabs.
- Added a pure-JVM policy test ensuring private tabs cannot request device permissions.
- Sanitised untrusted download filenames before passing them to the public Downloads destination; path separators and invalid/control characters are removed and names are length-limited.
- Moved history/bookmark JSON decoding and suggestion index generation to a background dispatcher to avoid doing large in-memory transforms on the Compose UI thread.
- Version advanced to 2.0.2 / versionCode 9.
