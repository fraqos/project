# Build verification record — DHYRA Browser 2.0.0

## Changes included in this package

- Removed Google Mobile Ads SDK dependency, AdMob manifest metadata, app initialization, ad components, ad placements and partner/affiliate configuration.
- Removed the address-bar position preference and all bottom-position UI/layout paths. Browser address bar and edit overlay are top aligned.
- Retained Kotlin 2.3.20 / Compose plugin 2.3.20, AGP 8.13.2, Gradle 8.13 and the typed `compilerOptions` DSL with `JvmTarget.JVM_17`.
- Kept the explicit `WebResourceRequest` override in `BrowserController.shouldInterceptRequest`; unblocked resources return `null` to allow normal WebView loading.
- Consolidated CI into `.github/workflows/build.yml`. The workflow builds the checked-out repository directly, runs tests/lint/debug build, inspects the APK, packages the source archive, computes SHA-256 and uploads artifacts.
- Removed the obsolete `main.yml` ZIP-extraction workflow to avoid two competing CI entry points.

## Checks performed in this authoring environment

- Extracted and inspected the user-supplied ZIP (104 entries).
- Verified root Gradle files, Android module, manifest and resource paths.
- Scanned app sources and build files for remaining AdMob/affiliate references and legacy address-bar position keys.
- Parsed Android XML resources/manifest and the workflow YAML.
- Checked shell syntax in `gradlew` and the workflow's inline Bash sections.
- Ran the available pure-JVM unit test suite with the installed Kotlin compiler and a local JUnit-compatible runner.
- Verified output ZIP integrity and SHA-256 checksums.

## Not run / not claimed

- Android Gradle configuration/build, `testDebugUnitTest` through Gradle, `lintDebug`, `assembleDebug`, APK install, emulator tests and physical-device tests were not run here. The environment has no Android SDK or Gradle distribution and cannot resolve outbound DNS to download them.
- No APK binary is supplied as a locally built output. The GitHub workflow will produce it only after a successful Actions run.
- No production release, performance, accessibility, privacy-profile isolation or store compliance certification is claimed.
