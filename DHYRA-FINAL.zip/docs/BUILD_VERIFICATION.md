# DHYRA Browser — Build Verification Record

## Static/source checks performed in this environment

- Extracted and inspected the latest user-supplied `DHYRA-FINAL(2).zip` before editing.
- Confirmed Android Gradle project structure, Kotlin, Jetpack Compose Material 3 and Android System WebView.
- Updated `compileSdk` to API 37.1 and kept `targetSdk` at API 36; pinned Compose BOM 2026.11.01, Activity Compose 1.13.0, Lifecycle 2.10.0, Core KTX 1.19.0, Preferences DataStore 1.2.1 and AndroidX WebKit 1.17.1; app version 2.0.2 (versionCode 9).
- Removed/confirmed absence of AdMob, donation and affiliate integration in app source and app dependencies.
- Confirmed no bottom-address-bar preference; Home and browser omnibox remain top-pinned.
- Added a named AndroidX WebKit private profile, gated on runtime `MULTI_PROFILE` and `DELETE_BROWSING_DATA`; profile assignment occurs before other WebView operations and cleanup is profile-scoped. A synchronous profile-cleanup failure now disables private browsing and invalidates Compose UI state.
- Added private-session safeguards: no default-profile fallback, profile-scoped cleanup, runtime failure disables private tabs, no persistent private downloads/bookmarks/speed-dial entries, private camera/microphone/DRM/geolocation requests are denied, private translation remains in the private profile with external disclosure, no Android Autofill/view-state saving, and private per-site Shields overrides are separate.
- Moved request-interception context to concurrent maps so `shouldInterceptRequest` no longer reads Compose snapshot state from its background callback.
- Forwarded Activity lifecycle to WebViews, added inactive renderer trimming, and retained renderer crash recovery.
- Removed fabricated byte-saving estimates; Shields UI describes observed blocked requests only.
- Made download status refresh lifecycle-aware and confirmed pause/resume is not represented as supported by the current DownloadManager integration.
- Added the current search-engine selector to the Home omnibox and rechecked the fixed-top address-entry path.
- Added fail-closed private-profile attachment, denied device permission prompts inside private tabs, and sanitised public DownloadManager filenames.
- Moved larger history/bookmark JSON decoding and local suggestion index generation off the UI thread.
- Updated architecture, UI, privacy, build and device QA documentation to state implemented behavior and remaining limitations.

## Dependency metadata compatibility fix (2026-11-26)

- The previous CI failure was caused by Compose BOM `2026.11.01` selecting Compose `1.13.0`, whose AAR metadata requires `compileSdk 37.1`; the app was configured for API 36.
- API 37.1 requires AGP 9.3.1 or later. The toolchain is now aligned to AGP 9.3.1, Gradle 9.5.1 and Kotlin / Compose compiler plugin 2.4.21. Kotlin 2.4.21 officially supports AGP 9.3.1 and Gradle 9.7.0.
- The app uses the `compileSdk { version = release(37) { minorApiLevel = 1 } }` DSL and CI installs `platforms;android-37.1`.
- `targetSdk` remains 36; compile SDK and target SDK are intentionally separate.
- AGP 9's built-in Kotlin is temporarily opted out (`android.builtInKotlin=false`, `android.newDsl=false`) while the pinned Kotlin Android / Compose compiler plugins are used. This is the documented migration opt-out path.
- CI now runs `:app:checkDebugAarMetadata` as an explicit preflight task so any future dependency metadata rejection is reported before tests/lint/APK assembly.

## Executed local checks

| Check | Result |
|---|---|
| Pure Kotlin/JVM helper test suite (Kotlin 1.9 local compiler + lightweight JUnit-compatible harness) | **19 test methods passed, 0 failed** |
| `PrivateWebViewProfile.kt` Kotlin syntax/API-shape compile against minimal AndroidX/WebView stubs | **Passed**; this checks Kotlin structure only, not the real AndroidX artifact |
| Android XML parsing | **12 XML files passed** |
| GitHub Actions YAML parse | **Passed**; 17 workflow steps detected |
| Bash syntax checks for workflow scripts | **11 scripts passed** |
| Required project-root structure | **Passed** |
| AdMob/donate/affiliate scan of app source and Gradle dependency file | **No matches** |
| Bottom address-bar preference scan | **No matches** |
| ZIP package integrity | Final archive validated after packaging (see delivery checksum) |

The JVM test harness is not Gradle/JUnit execution. It exercises only pure Kotlin helper classes; it does not compile the Android Activity, Compose UI or WebView controller against the real Android SDK. `PrivateWebViewProfile.kt` was additionally syntax-checked against minimal API-shape stubs, which does not replace compilation against the real AndroidX WebKit AAR.

## Not run / not claimed

This environment has Kotlin compiler 1.9.0 and Java 21, but no Android SDK, no Gradle 9.5.1 installation/Gradle distribution, and outbound DNS resolution to the Gradle distribution host is unavailable. Therefore these tasks have **not** been run here:

- `./gradlew testDebugUnitTest`
- `./gradlew lintDebug`
- `./gradlew assembleDebug`
- APK install or runtime testing
- Compose UI or Android instrumentation tests
- Private profile cookie/localStorage/cache isolation on physical WebView providers
- Macrobenchmark, memory profiling and LeakCanary
- TalkBack/accessibility device QA
- Release signing or AAB validation
- Play publication certification

The canonical GitHub Actions workflow `.github/workflows/build.yml` is configured to create a standard Gradle Wrapper in the CI workspace, run `testDebugUnitTest`, strict `lintDebug`, `assembleDebug`, validate the resulting APK, create a clean source ZIP and SHA-256 checksums, then upload artifacts. Its green hosted-runner result is still required to establish an actual Android build.
