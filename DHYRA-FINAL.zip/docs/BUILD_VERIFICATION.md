# DHYRA Browser — Build Verification Record

## Static/source checks performed in this environment

- Extracted and inspected the latest user-supplied `DHYRA-FINAL(3).zip` before editing.
- Confirmed Android Gradle project structure, Kotlin, Jetpack Compose Material 3 and Android System WebView.
- Updated `compileSdk` to API 37.1 and kept `targetSdk` at API 36; pinned Compose BOM 2026.11.01, Activity Compose 1.13.0, Lifecycle 2.10.0, Core KTX 1.19.0, Preferences DataStore 1.2.1 and AndroidX WebKit 1.17.1; app version 2.1.2 (versionCode 12).
- Removed/confirmed absence of AdMob, donation and affiliate integration in app source and app dependencies.
- Confirmed no bottom-address-bar preference; Home and browser omnibox remain top-pinned.
- Added a named AndroidX WebKit private profile, gated on runtime `MULTI_PROFILE` and `DELETE_BROWSING_DATA`; profile assignment occurs before other WebView operations and cleanup is profile-scoped. A synchronous profile-cleanup failure now disables private browsing and invalidates Compose UI state.
- Added private-session safeguards: no default-profile fallback, profile-scoped cleanup, runtime failure disables private tabs, no persistent private downloads/bookmarks/speed-dial entries, private camera/microphone/DRM/geolocation requests are denied, private translation remains in the private profile with external disclosure, no Android Autofill/view-state saving, and private per-site Shields overrides are separate.
- Moved request-interception context to concurrent maps so `shouldInterceptRequest` no longer reads Compose snapshot state from its background callback.
- Forwarded Activity lifecycle to WebViews, added inactive renderer trimming, and retained renderer crash recovery.
- Removed fabricated byte-saving estimates; Shields UI describes observed blocked requests only.
- Made download status refresh lifecycle-aware and confirmed pause/resume is not represented as supported by the current DownloadManager integration.
- Added the current search-engine selector to the Home omnibox and rechecked the fixed-top address-entry path.
- Added fail-closed private-profile attachment, denied device permission prompts inside private tabs, and sanitised public DownloadManager filenames.
- Moved larger history/bookmark JSON decoding and local suggestion index generation off the UI thread.
- Updated architecture, UI, privacy, build and device QA documentation to state implemented behavior and remaining limitations.

## Dependency metadata compatibility fix (2026-11-26)

- The previous CI failure was caused by Compose BOM `2026.11.01` selecting Compose `1.13.0`, whose AAR metadata requires `compileSdk 37.1`; the app was configured for API 36.
- API 37.1 requires AGP 9.3.1 or later. The toolchain is now aligned to AGP 9.3.1, Gradle 9.5.1 and Kotlin / Compose compiler plugin 2.4.21. Kotlin 2.4.21 officially supports AGP 9.3.1 and Gradle 9.7.0.
- The app uses the `compileSdk { version = release(37) { minorApiLevel = 1 } }` DSL and CI installs `platforms;android-37.1`.
- `targetSdk` remains 36; compile SDK and target SDK are intentionally separate.
- AGP 9's built-in Kotlin is temporarily opted out (`android.builtInKotlin=false`, `android.newDsl=false`) while the pinned Kotlin Android / Compose compiler plugins are used. This is the documented migration opt-out path.
- CI now runs `:app:checkDebugAarMetadata` as an explicit preflight task so any future dependency metadata rejection is reported before tests/lint/APK assembly.

## Android resource API-level lint fix (2026-11-26)

- Removed `android:windowLightNavigationBar` from unqualified `values/` and `values-night/` themes because the theme attribute is not available on the project's minimum API level 26.
- Added day/night theme variants under `values-v27/` and `values-night-v27/`, where the API 27 navigation-bar appearance attribute is valid.
- Removed `android:windowLayoutInDisplayCutoutMode` from unqualified themes because display-cutout layout support starts at API 28.
- Added complete day/night variants under `values-v28/` and `values-night-v28/`, preserving the API 27 navigation-bar appearance and adding `shortEdges` only on API 28+.
- API 26 therefore receives the safe base theme; API 27 receives the light/dark navigation-bar flag; API 28+ additionally receives cutout layout behavior.
- This addresses all four occurrences of the two API-gated attributes in the previous base day/night styles. XML parsing and resource-qualifier assertions pass. Android `lintDebug` has not been run in this environment because Android SDK/Gradle are unavailable; the remaining 35 warnings from the previous hosted lint report have not been re-evaluated here.

## Executed local checks

| Check | Result |
|---|---|
| Pure Kotlin/JVM helper test suite (Kotlin 1.9 local compiler + lightweight JUnit-compatible harness from prior validation) | **19 test methods passed, 0 failed** |
| Translation queue Kotlin/coroutines smoke harness (local compiler) | **Passed**: batch validation, result mapping, pause/resume, LRU cache deduplication |
| PageTranslation.js DOM smoke test (Node) | **Passed**: extraction, hidden/editable exclusions, batch transport, restore and site-mutation safety |
| PageTranslation.js retry smoke test (Node) | **Passed**: retryable errors retry exactly twice, then stop |
| `PrivateWebViewProfile.kt` Kotlin syntax/API-shape compile against minimal AndroidX/WebView stubs | **Passed**; this checks Kotlin structure only, not the real AndroidX artifact |
| Android XML parsing | **16 XML files passed** |
| GitHub Actions YAML parse | **Passed**; 18 workflow steps detected |
| Bash syntax checks for workflow scripts | **12 scripts passed** |
| Required project-root structure | **Passed** |
| AdMob/donate/affiliate scan of app source and Gradle dependency file | **No matches** |
| Bottom address-bar preference scan | **No matches** |
| ZIP package integrity | Final archive validated after packaging (see delivery checksum) |

The JVM test harness is not Gradle/JUnit execution. It exercises only pure Kotlin helper classes; it does not compile the Android Activity, Compose UI or WebView controller against the real Android SDK. `PrivateWebViewProfile.kt` was additionally syntax-checked against minimal API-shape stubs, which does not replace compilation against the real AndroidX WebKit AAR.

## Not run / not claimed

This environment has Kotlin compiler 1.9.0 and Java 21, but no Android SDK, no Gradle 9.5.1 installation/Gradle distribution, and outbound DNS resolution to the Gradle distribution host is unavailable. Therefore these tasks have **not** been run here:

- `./gradlew testDebugUnitTest` (including the newly added `TranslationQueueExecutionTest`)
- `./gradlew lintDebug`
- `./gradlew assembleDebug`
- APK install or runtime testing
- Compose UI or Android instrumentation tests
- Private profile cookie/localStorage/cache isolation on physical WebView providers
- Macrobenchmark, memory profiling and LeakCanary
- TalkBack/accessibility device QA
- Release signing or AAB validation
- Play publication certification

The canonical GitHub Actions workflow `.github/workflows/build.yml` is configured to create a standard Gradle Wrapper in the CI workspace, run `testDebugUnitTest`, strict `lintDebug`, `assembleDebug`, validate the resulting APK, create a clean source ZIP and SHA-256 checksums, then upload artifacts. Its green hosted-runner result is still required to establish an actual Android build.

## Desktop mode and on-device translation implementation (2026-11-26)

- Added `WebViewModeManager` with dynamic runtime UA discovery, Linux X11 desktop UA transformation that preserves the Chromium version, wide viewport/overview/zoom settings, and per-tab mode restore. No Chrome version is hard-coded.
- Added ML Kit Translate 17.0.3 and Language ID 17.0.6 based on current Google documentation. Models download on demand; Wi-Fi-only is the default. Translation work uses a single-worker bounded queue per tab and a shared translator mutex to cap simultaneous native model operations.
- Added `PageTranslation.js`: TreeWalker TextNode extraction, excluded unsafe/editable tags, visible/near/far priority, incremental scan chunks, batches capped at 2,000 characters, a maximum of four in-flight requests, a bounded pending queue and tracked-node map, WeakMap/WeakRef state, limited retries, MutationObserver, SPA history hooks, and conditional restoration that leaves website-modified text untouched.
- Added an AndroidX WebMessageListener instead of exposing a general-purpose `@JavascriptInterface`. The listener validates HTTPS main-frame origin, payload type and size, batch rate, request IDs and a random per-run session token. No browser-native privileged API is exposed to page scripts.
- Added a translation bottom sheet for source/target language, Wi-Fi-only model downloads, pause/resume and restore-original controls. Translation manager pauses for inactive tabs and Activity lifecycle, and is torn down when a tab is closed or frozen. Frozen tabs with active translation discard translated DOM snapshots and reload the original page before restoring the explicit translation configuration.
- Added tests for the desktop UA transformer and translation batch validation. Added asynchronous translation queue tests for stable request/batch mapping and pause/resume behavior.
- Fixed retry accounting in `PageTranslation.js`: retries now persist across newly-issued request IDs and stop after two attempts; only native errors explicitly marked retryable are retried. Permanent language/model/validation errors are surfaced without an automatic retry loop.
- Improved hidden-content detection by checking display, visibility and zero opacity across the ancestor chain; detached-node range failures are handled safely. Added a user-visible Cancel Translation action while a model download/preparation is active.
- `node --check app/src/main/assets/PageTranslation.js` passes after the latest script changes.
- Reproducible Node smoke tests are stored in `scripts/test-page-translation.cjs` and `scripts/test-translation-retries.cjs`; the GitHub Actions workflow runs them before Gradle. They verify hidden/editable exclusions, DOM translation, restore safety when a website mutates text, retryable error handling and the two-retry cap.
- Local verification during this pass: the DOM translation smoke test passed; the retry cap test passed; a Kotlin/coroutines harness passed batch validation, result mapping, pause/resume and cache deduplication. The Kotlin WebView UA manager was separately compiled against minimal Android API-shape stubs in the earlier validation pass. These are targeted harness checks, not a real Android Gradle build.
- Static validation also includes Android XML parsing, workflow YAML parsing, shell syntax and embedded Python compilation. Android Gradle build, Lint, APK output and runtime ML Kit/WebView integration still require the hosted Android SDK runner and real devices.
