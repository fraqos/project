# DHYRA Browser — GitHub Actions source setup

The workflow supports both a normal committed Gradle project and a ZIP-only repository. The workflow YAML itself must be committed under `.github/workflows/`.

## Option A — Project contents in repository root (recommended)

1. Extract `DHYRA-FINAL.zip` once locally.
2. Commit the extracted project contents to the repository root.
3. Verify `settings.gradle.kts`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`, `gradle/` and `.github/workflows/build.yml` are visible at the root.
4. Keep `build.yml` as the only active DHYRA workflow; remove/disable an older `main.yml` to prevent duplicate runs.
5. Push to `main`/`master` or run the workflow manually.

## Option B — ZIP-only repository

1. Keep `.github/workflows/main.yml` in the repository (use the supplied `main.yml`).
2. Upload exactly one DHYRA project ZIP to the repository root, for example `DHYRA-FINAL.zip`.
3. Commit and push. Do not manually extract the ZIP: the workflow validates it, safely extracts it to a temporary CI directory and discovers the actual Gradle project root.
4. If more than one root-level ZIP is present, the workflow stops and names the ZIP files it found. Remove older project ZIPs so there is only one.

When both a root Gradle project and a ZIP are present, the workflow prefers the root Gradle project. ZIP extraction is only the fallback when the root project is absent.

## What CI does

- JDK 17 and Android SDK setup; installs API 35 and Build Tools 35.0.0.
- Gradle 8.13 wrapper generation (the repository archive contains wrapper properties; CI generates the standard wrapper JAR).
- `testDebugUnitTest`, `lintDebug` and `assembleDebug`.
- APK archive validation, clean source ZIP creation, SHA-256 verification and Actions artifact upload.

The normal APK is a debug build for testing. Optional `assembleRelease` output is unsigned unless a protected signing workflow is configured.

## Troubleshooting

- `No Android project ... no .zip was found`: commit the source contents at root or add exactly one `.zip` file at root when using ZIP-only mode.
- `No Android Gradle project was found in ZIP`: check that the archive contains `settings.gradle(.kts)`, `app/build.gradle(.kts)`, and `app/src/main/AndroidManifest.xml`.
- SDK setup: confirm licenses and inspect `sdkmanager` output.
- Kotlin compilation: fix the first compiler diagnostic rather than the final task summary.
- Artifact missing: confirm tests, lint, assemble, APK validation and source archive validation all completed.
