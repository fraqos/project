# DHYRA Browser — one-time GitHub source setup

GitHub Actions builds the committed Gradle project directly. It does **not** extract or consume a source ZIP on every run.

## One-time repository setup

1. Create/open the GitHub repository.
2. Extract `DHYRA-FINAL.zip` once on your computer.
3. Commit the extracted **contents** to the repository root. Do not commit only the ZIP file.
4. Ensure these paths are visible at repository root: `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`, `gradle/wrapper/gradle-wrapper.properties`, and `.github/workflows/build.yml`.
5. Push the commit to `main` or `master` and enable GitHub Actions.

## Normal development

Make source changes in the repository and commit/push them. Pushes to `main`/`master`, pull requests and manual `workflow_dispatch` run the build. No manual ZIP upload or extraction is needed for recurring builds.

## Artifacts

After a green workflow, download `DHYRA-FINAL-<run number>`. It contains the source archive, validated debug APK and `SHA256SUMS.txt`. The normal APK is a debug build for testing; optional release output is unsigned unless a separate signing configuration is provided.

## Troubleshooting

- `settings.gradle.kts missing`: only the contents of the source archive were supposed to be committed; the ZIP alone is not the repository source.
- SDK package failure: inspect the SDK setup/install step and verify the platform/build-tools versions match `app/build.gradle.kts`.
- Kotlin compilation: fix the first compiler error (not the later `compileDebugKotlin` summary) before rerunning.
- Artifact missing: confirm `assembleDebug` succeeded and the APK validation step found the APK.
