# DHYRA Browser — GitHub Actions Setup

The canonical workflow is `.github/workflows/build.yml`. Keep only this workflow active for DHYRA to prevent duplicate builds.

## Recommended source-at-root setup

1. Extract the DHYRA project ZIP once.
2. Commit the extracted project contents to the root of the GitHub repository.
3. Confirm `settings.gradle.kts`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`, `gradle/` and `.github/workflows/build.yml` are at the expected paths.
4. Push to `main`/`master`, create a pull request, or run the workflow manually.

## ZIP-only setup

1. Commit `.github/workflows/build.yml` separately; GitHub only activates workflows committed under `.github/workflows/`.
2. Commit exactly one DHYRA ZIP at repository root.
3. Do not extract it manually. The workflow validates and extracts that ZIP in CI, then locates `settings.gradle.kts` and the app module.
4. Keep only one ZIP at repository root. The workflow rejects multiple ZIPs to avoid building the wrong version.

Root Gradle source takes precedence if both source and ZIP are present.

## Workflow jobs

- Checkout repository.
- Locate Android source or safely extract one root ZIP.
- Set up JDK 17 and Android SDK licences.
- Install Android API 36 and Build Tools 36.0.0.
- Set up Gradle 8.13 and generate/verify a standard Gradle Wrapper in the CI working directory.
- Run `testDebugUnitTest`, `lintDebug`, and `assembleDebug`.
- Validate APK archive integrity, `AndroidManifest.xml` and DEX bytecode.
- Produce clean source ZIP and SHA256SUMS.
- Upload APK, source ZIP and checksums as GitHub Actions artifacts.

The normal APK is a debug build. Optional release assembly is unsigned until a release-signing process is configured with GitHub Secrets. Never put keystores or signing passwords in the repository.

## Troubleshooting

- Missing settings file: ensure project root is checked in or a single valid ZIP is committed at repository root.
- Invalid ZIP: regenerate the source ZIP and check that it contains Gradle settings, app build file and Android Manifest.
- SDK package errors: use current Android command-line tools; never request obsolete SDK package `tools`.
- Kotlin compilation error: fix the first compiler diagnostic, not only the final Gradle task failure.
- Artifact missing: confirm the test, lint, build, APK validation and checksum steps all passed.
