# DHYRA Browser 2.0.0 — implementation status

## Verified from the supplied source and this revision

- Android application: Kotlin, Jetpack Compose Material 3, Android System WebView.
- Toolchain: Kotlin 2.3.20, Compose compiler plugin 2.3.20, AGP 8.13.2, Gradle 8.13, JDK 17, compileSdk/targetSdk 35, minSdk 26.
- Address bar fixed at the top of the browser layout. The bottom-position preference, UI, and layout path have been removed.
- WebView-based real website rendering, tabs, loading progress, navigation callbacks, downloads and fullscreen media hooks remain in the project.
- Local history/bookmark suggestions, history/bookmark screens, bookmark import/export and Home speed dial remain.
- A lightweight host/path Shields matcher, HTTPS-first main-frame upgrade, DNT/GPC headers for browser-initiated navigations and cookie controls remain.
- AdMob, its SDK dependency, manifest metadata, Activity initialization and UI components have been removed. Affiliate partner configuration/UI is removed as unused for this iteration.
- A single source-repository GitHub Actions workflow now builds the committed Android project, validates the APK, creates a clean source ZIP and SHA-256 sums.

## Build/test status in this delivery environment

- ZIP integrity, required project files, XML well-formedness, workflow YAML syntax, shell syntax, source references and pure-JVM test execution are checked locally.
- A full Android Gradle build, Android lint and APK generation have **not** been run in this environment because Android SDK/Gradle are not installed and outbound DNS resolution is unavailable.
- GitHub Actions must still pass `testDebugUnitTest`, `lintDebug`, `assembleDebug`, APK inspection, source archive inspection and SHA-256 verification before this project is a validated build.

## Known functional limits

- Android System WebView is the engine; this is not a bundled Chromium fork or native desktop browser.
- Private tabs share Android System WebView cookie/storage managers; best-effort cleanup can affect regular sessions.
- Shields supports a deliberately small host/path syntax and is not a complete EasyList/uBlock parser or cosmetic/scriptlet blocker.
- DoH provider choices are configuration presets, not an active custom resolver transport.
- No complete anti-fingerprinting or guaranteed WebRTC leak protection is implemented.
- DownloadManager does not offer true app-controlled pause/resume.
- Reader mode is CSS-based; translation uses an external page. PiP/background media behavior varies by device, system WebView and site.
- Device/physical browser regression, accessibility, long-duration multi-tab memory and Android-version testing remain required.
