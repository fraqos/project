# DHYRA Browser — Implementation Status

This document describes the source state in this package. It is not a statement of device certification.

## Implemented in source

- Kotlin 2.4.21, AGP 9.3.1, Gradle 9.5.1, JDK 21 in CI, compileSdk 37.1 / targetSdk 36, minSdk 26; app version 2.0.2 (versionCode 9).
- Compose BOM 2026.11.01, Activity Compose 1.13.0, Lifecycle 2.10.0, Core KTX 1.19.0, Preferences DataStore 1.2.1, AndroidX WebKit 1.17.1.
- Jetpack Compose Material 3; system/dynamic/light/dark/AMOLED themes; central spacing, shape and motion tokens.
- Address bar fixed to top in Home and Browser; no persisted option to move it to the bottom.
- Responsive speed dial FlowRow and adaptive tab grid; search tabs for larger tab sets; private markers; close/undo interactions.
- Activity lifecycle forwarding to active WebViews; inactive WebViews are state-saved and lazily recreated within a four-live-WebView cap; renderer recovery.
- HTTPS-first for browser initiated top-level navigation, TLS certificate error cancellation, mixed content blocking, file access restrictions and Safe Browsing setting.
- Local search suggestions, JSON-backed history/bookmarks, bookmark import/export and regular-tab session restore. Larger history/bookmark parsing and index building are dispatched away from the UI thread.
- Private browsing is gated by WebView runtime support for `MULTI_PROFILE` and `DELETE_BROWSING_DATA`. A named profile is assigned before private WebView use. Profile-specific browsing data is cleared on startup and after the final private tab closes. Private downloads are refused to avoid persistent public DownloadManager entries. No private tab is written into regular history/session JSON.
- Download status polling is lifecycle-aware and slower while idle; it does not claim pause/resume support.
- Shields count is the number of requests observed and blocked for the current page. Byte savings are not measured.
- Reader mode state is tracked per tab and re-applied after page navigation, but the mode is still CSS-based, not a semantic article extractor.
- Translate opens an external Google Translate tab and uses the device locale as target language.
- AdMob, ad placements, affiliate tags and monetization code are absent.

## Deliberate limitations

- The app is not yet a full MVVM/Room/DI architecture. MainActivity and BrowserController remain large coordinator classes. History, bookmark and session persistence still use JSON strings in DataStore; a Room migration is not included because it must preserve existing user data and needs migration tests.
- WebView private profiles depend on the installed provider. If either required feature is missing, private browsing is disabled. Real cookie/storage isolation must still be tested on supported physical devices and provider versions.
- Private tab downloads are intentionally unavailable. Android DownloadManager persists records outside the ephemeral profile. Public download filenames are sanitised before use.
- Private camera, microphone, protected-media and geolocation permission requests are denied. A private WebView profile attachment error disables private browsing instead of falling back to the default profile.
- Shields only implements a lightweight host/path filter. Full EasyList/EasyPrivacy syntax, cosmetic filters, scriptlets, resource types, initiator exceptions, auto updates and regional lists are not implemented.
- HTTPS-first does not intercept every redirect or every website-created navigation; DNT/GPC are not guaranteed on all subresource requests.
- DoH presets do not implement a DNS transport. Anti-fingerprinting and WebRTC leak protection are incomplete.
- Website permission prompts show the requesting origin and request type; a full persistent per-origin permissions management screen is not yet implemented.
- DownloadManager does not expose true pause/resume in this application. UI shows status, progress, open action and system notifications.
- Reader Mode CSS does not extract the article author/date/content semantically. Translation is external.
- Desktop-site mode changes WebView UA/viewport. It is not a native desktop browser application.
- Room migration, Macrobenchmark, LeakCanary, instrumentation/UI tests, signed AAB release, SBOM and physical-device QA remain follow-up work.

## Release criteria not yet met

A release candidate still needs:

1. Successful `testDebugUnitTest`, strict `lintDebug` and `assembleDebug` on GitHub Actions.
2. Instrumentation tests for private profile cookie, cache and local storage isolation.
3. Permission lifecycle tests for camera, microphone, geolocation and file chooser.
4. Long-session memory and renderer-recovery testing on representative devices.
5. Accessibility validation with TalkBack and 200% font scale.
6. Release signing configuration stored only in GitHub Secrets and successful AAB validation.
7. Google Play policy, privacy policy, data safety and content compliance review.
