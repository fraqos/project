# DHYRA Browser — UI/UX structure and behavior

DHYRA's application UI uses Jetpack Compose Material 3. The Android System WebView remains responsible for website layout/rendering; Compose supplies browser chrome and internal screens.

## Browser frame

- The address bar is **fixed to the top** of `BrowserPage`, above the WebView container.
- The address editor overlay is aligned to `Alignment.TopCenter`; suggestions appear near the keyboard at the bottom of the screen without moving the editor.
- The position preference was removed. There is no UI or persisted setting that can move the address bar below the page.
- In fullscreen custom media view, browser chrome is hidden temporarily as expected for fullscreen playback; the address bar is not relocated.
- Horizontal swipe gesture on the address bar moves between tabs.

## Main screens and interactions

- Home: greeting, search entry, speed dials and recent pages.
- Browser: top address pill, progress, security/shields affordance, desktop-site toggle, reload/stop, WebView page, find-in-page and bottom navigation.
- Tabs: card/grid presentation with title/preview/favicon when available, private tab marker, close actions and undo flow.
- Settings: search engine, homepage, theme, fixed-top address-bar information, desktop-site toggle, tracker/popup controls and clear browsing data.
- Library: history/bookmarks search and bookmark JSON import/export.
- Downloads: Android DownloadManager status, open and remove actions.
- Quick sheets: find, translate handoff, reader presentation, share, print/PDF, QR and desktop site.

## Themes and accessibility

Material 3 theme supports system, dynamic color on supported Android versions, light, dark and AMOLED variants. Layout uses Compose text scaling and scrollable internal screens. Reduced-motion behavior and accessibility labels still require systematic device testing, especially TalkBack focus order and large-font layouts.

## Scope note

This is a mobile/tablet Android app, not a Windows/macOS/Linux desktop application. Desktop-site mode changes the WebView user agent and viewport; it does not create desktop-native window/tab chrome.
