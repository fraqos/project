# DHYRA Browser 1.4.1 — manual device verification

This checklist is for the first successful CI APK and real Android devices. It is not a claim that these device tests have already been run.

## Installation and startup

- [ ] Install the `DHYRA-BROWSER-v1.4.1-debug` APK from the successful GitHub Actions run.
- [ ] Confirm package ID `com.dhyra.browser` and version `1.4.1 (6)`.
- [ ] Launch after a clean install; confirm the New Tab screen appears without creating a site WebView.
- [ ] Open a URL and confirm navigation works; rotate the device and return from background.

## Navigation and session

- [ ] Enter `example.com`; confirm the app resolves it to HTTPS.
- [ ] Enter a search phrase; confirm the configured search engine is used.
- [ ] Open several tabs, switch between them and use back/forward/reload.
- [ ] Open more than four sites, switch back to an older tab, then navigate to a different URL. Confirm the new URL opens (not the previously frozen page).
- [ ] Force-stop and relaunch; confirm ordinary HTTP(S) tab URLs are restored.
- [ ] Confirm private tabs do not appear in restored sessions or history.
- [ ] Try an HTTP-only destination; it is expected to fail because cleartext is disabled and there is no downgrade interstitial yet.

## Privacy and security

- [ ] Confirm HTTP navigations are upgraded to HTTPS when possible.
- [ ] Test a certificate-error page such as `https://expired.badssl.com`; the certificate error must be cancelled, not bypassed.
- [ ] Open known tracker-heavy sites and observe the Shields badge. False positives/breakage are possible with this small host/path list.
- [ ] Confirm third-party cookies are disabled while tracking protection is enabled.
- [ ] Open a private tab, sign in to a test account in a regular tab, then verify/document that WebView cookies are shared. Close the final private tab and verify the shared cookies/storage are cleared (this may sign out regular tabs).
- [ ] Test `intent:` links, unsupported schemes, and top-level `data:`/`javascript:` navigation. Unsupported destinations should be blocked.
- [ ] Confirm app backup is disabled in Android settings / device backup inspection.

## Permissions, media and downloads

- [ ] On HTTPS test pages, test camera and microphone prompts; deny and allow paths.
- [ ] Test geolocation prompt; decisions are not remembered per origin.
- [ ] Test protected media/DRM on a device with supported WebView/DRM. Playback is device-dependent.
- [ ] Test ordinary HTTP(S) downloads and notification completion.
- [ ] `blob:` and `data:` downloads are not implemented; do not treat their absence as a regression in this version.
- [ ] Test popup blocker enabled/disabled and fullscreen video enter/exit.

## UI and system behavior

- [ ] Test Light, Dark and System theme, status/navigation bar icon contrast and edge-to-edge insets.
- [ ] Test browser default-role prompt on Android 10+ and default-app settings on API 26–28.
- [ ] Test font scaling, TalkBack, RTL and keyboard/D-pad navigation. Full 200% font-scale and accessibility QA remains outstanding.
- [ ] Simulate a renderer crash in a test build/device and confirm the affected tab can be reloaded without killing the Activity.

## Device coverage

- [ ] Android API 26–28
- [ ] Android API 29–30
- [ ] Android API 31–34
- [ ] Android API 35+

Record device model, Android version, WebView provider/version and test outcome for each run. The System WebView implementation and update level can change behavior across devices.

## UI/UX overhaul scenarios

1. **No page jump:** open a long page, tap the address pill, type slowly. The page behind must not move, resize or
   re-render; only the dimmed overlay, field and suggestion tray change.
2. **Font clipping:** type `ygpq` and `htl` in the omnibox and read the resting pill on a page; no letter is cut at
   the top or bottom, at normal and at the largest system font size.
3. **Suggestions:** type `y` — `youtube.com` appears lowest in the tray (closest to the keyboard) and is completed
   inline with the completion selected; Backspace removes only the completion; Go opens `https://youtube.com`.
   Type `hello world` — only "Search for…" appears.
4. **Web-page input still works:** focus a text field inside a web page. The page must shrink above the keyboard and
   keep the field visible; the bottom bar hides while the keyboard is open.
5. **New tab:** from a page tap New tab — scale/fade transition to the start page, keyboard opens automatically
   (Settings > Type on new tab). Pressing New tab on an untouched start page does not create another tab.
6. **Tab switcher:** previews appear for regular tabs; swipe a card sideways to close it; X closes with a fade;
   Close all cascades, returns to a clean start page, shows an Undo snackbar; Undo restores the regular tabs.
7. **Back order:** with omnibox open → closes it; tab switcher → closes it; fullscreen YouTube → exits fullscreen;
   page with history → goes back; link opened in a new tab (target=_blank) with no history → closes it and returns to
   the opener; page with no history → start page; start page → app minimises.
8. **Desktop site:** toggle from menu quick controls, from the pill indicator and from Settings; the active page reloads
   at once with the desktop layout (check a site that serves different mobile/desktop pages); switching to another tab
   that was open earlier reloads it with the new mode.
9. **Theme switch:** change the system dark mode while several tabs are open; tabs and the current page must survive.
10. **Close all with fullscreen/loading tabs:** no crash, no black screen, memory does not keep growing after repeated
    open-all/close-all cycles.



## Address bar position invariant

- [ ] Confirm the resting address bar is always at the top on phone and tablet layouts.
- [ ] Confirm the Settings screen has no bottom-position option.
- [ ] Confirm typing opens the editor overlay at the top, with suggestions above the keyboard.
- [ ] Confirm fullscreen custom media hides browser chrome and does not relocate the address bar.
- [ ] Confirm no AdMob ad view or Google Mobile Ads SDK is present in Home, Downloads or website content.
