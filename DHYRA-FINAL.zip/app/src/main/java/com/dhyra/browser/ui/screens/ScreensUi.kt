@file:OptIn(

    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser.ui.screens

import com.dhyra.browser.core.nav.BrowserAddressResolver

import com.dhyra.browser.*
import com.dhyra.browser.ui.theme.*
import com.dhyra.browser.ui.components.*

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.lifecycle.repeatOnLifecycle

// ---------- shared building blocks ----------

@Composable
internal fun SubpageBar(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = cs.onSurface)
        }
        Text(
            text = title,
            modifier = Modifier.weight(1f),
            fontSize = 20.sp,
            lineHeight = 28.sp,
            fontWeight = FontWeight.SemiBold,
            color = cs.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        trailing()
    }
}

@Composable
internal fun SectionTitle(text: String) {
    Text(
        text = text,
        modifier = Modifier.padding(start = 24.dp, top = 24.dp, bottom = 6.dp),
        fontSize = 13.sp,
        lineHeight = 18.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
internal fun SettingRow(icon: ImageVector, title: String, subtitle: String?, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = cs.onSurfaceVariant)
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(text = title, fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface)
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = cs.onSurfaceVariant)
    }
}

@Composable
internal fun SwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = cs.onSurfaceVariant)
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(text = title, fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface)
            Text(text = subtitle, fontSize = 13.sp, lineHeight = 19.sp, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<String>,
    selected: String,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { option ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(option) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = option == selected, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(option, fontSize = 16.sp, lineHeight = 24.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

// ---------- settings ----------

@Composable
internal fun SettingsScreen(
    state: PreferencesState,
    onBack: () -> Unit,
    onSave: (String, Any) -> Unit,
    onClear: () -> Unit,
    onSetDefaultBrowser: () -> Unit,
    onAbout: () -> Unit,
    privateBrowsingSupported: Boolean
) {
    val cs = MaterialTheme.colorScheme
    var showHome by remember { mutableStateOf(false) }
    var showEngine by remember { mutableStateOf(false) }
    var showTheme by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val normalizedQuery = query.trim()
    fun rowMatches(section: String, vararg values: String): Boolean = normalizedQuery.isBlank() ||
        section.contains(normalizedQuery, ignoreCase = true) ||
        values.any { it.contains(normalizedQuery, ignoreCase = true) }
    fun sectionMatches(section: String, vararg values: String): Boolean =
        normalizedQuery.isBlank() || section.contains(normalizedQuery, ignoreCase = true) ||
            values.any { it.contains(normalizedQuery, ignoreCase = true) }

    Column(Modifier.fillMaxSize().background(cs.background).navigationBarsPadding()) {
        SubpageBar(title = "Settings", onBack = onBack)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = DhyraSpacing.md, vertical = DhyraSpacing.xs),
            singleLine = true,
            shape = DhyraShapes.field,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                    Icon(Icons.Default.Close, contentDescription = "Clear settings search")
                }
            },
            placeholder = { Text("Search settings") }
        )
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (sectionMatches("General", "default browser", "homepage", "search engine", "type on new tab")) {
                item { SectionTitle("General") }
                if (rowMatches("General", "default browser", "set as default", "language")) item {
                    SettingRow(Icons.Default.Language, "Default browser", "Set DHYRA as your default browser") { onSetDefaultBrowser() }
                }
                if (rowMatches("General", "homepage", state.homepage, "start page")) item {
                    SettingRow(Icons.Default.Home, "Homepage", state.homepage.ifBlank { "DHYRA start page" }) { showHome = true }
                }
                if (rowMatches("General", "search engine", state.engine, "brave", "google", "bing", "duckduckgo")) item {
                    SettingRow(Icons.Default.Search, "Search engine", state.engine) { showEngine = true }
                }
                if (rowMatches("General", "type on new tab", "focus", "keyboard")) item {
                    SwitchRow(
                        icon = Icons.Default.Add,
                        title = "Type on new tab",
                        subtitle = "Open the keyboard as soon as a new tab opens",
                        checked = state.focusOnNewTab
                    ) { onSave("focus_on_new_tab", it) }
                }
            }

            if (sectionMatches("Appearance", "theme", "desktop site", "address bar", "top")) {
                item { SectionTitle("Appearance") }
                if (rowMatches("Appearance", "theme", state.theme, "light", "dark", "amoled", "dynamic color")) {
                    item { SettingRow(Icons.Default.Palette, "Theme", state.theme) { showTheme = true } }
                }
                if (rowMatches("Appearance", "address bar", "top", "omnibox")) item {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VerticalAlignTop, contentDescription = null, tint = cs.onSurfaceVariant)
                        Spacer(Modifier.width(18.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Address bar", fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface)
                            Text("Always pinned to the top", fontSize = 13.sp, lineHeight = 19.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
                if (rowMatches("Appearance", "desktop site", "desktop mode", "user agent")) item {
                    SwitchRow(
                        icon = Icons.Default.DesktopWindows,
                        title = "Desktop site",
                        subtitle = "Ask websites for their desktop version",
                        checked = state.desktop
                    ) { onSave("desktop_mode", it) }
                }
            }

            if (sectionMatches("Privacy", "shields", "trackers", "ads", "pop-ups", "clear browsing data", "cookies", "site storage", "private browsing", "incognito", "isolated profile")) {
                item { SectionTitle("Privacy") }
                if (rowMatches("Privacy", "shields", "trackers", "ads", "block list", "tracking protection")) item {
                    SwitchRow(
                        icon = Icons.Default.Shield,
                        title = "Block trackers & ads",
                        subtitle = "Uses the built-in block list",
                        checked = state.tracking
                    ) { onSave("tracking_protection", it) }
                }
                if (rowMatches("Privacy", "pop-ups", "popup", "windows")) item {
                    SwitchRow(
                        icon = Icons.Default.VisibilityOff,
                        title = "Block pop-ups",
                        subtitle = "Stops pop-up windows from opening",
                        checked = state.popup
                    ) { onSave("popup_blocker", it) }
                }
                if (rowMatches("Privacy", "clear browsing data", "cookies", "site storage", "history", "cache")) item {
                    SettingRow(Icons.Default.DeleteOutline, "Clear browsing data", "Cookies, site storage and history") { showClear = true }
                }
                if (rowMatches("Privacy", "private browsing", "incognito", "isolated profile")) item {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VisibilityOff, contentDescription = null, tint = cs.onSurfaceVariant)
                        Spacer(Modifier.width(18.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Private browsing", fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface)
                            Text(
                                if (privateBrowsingSupported) "Isolated WebView profile available on this device"
                                else "Unavailable: this WebView provider cannot safely isolate and clear private storage",
                                fontSize = 13.sp,
                                lineHeight = 19.sp,
                                color = if (privateBrowsingSupported) cs.onSurfaceVariant else cs.error
                            )
                        }
                    }
                }
            }

            if (sectionMatches("About", "about dhyra", BuildConfig.VERSION_NAME, "version")) {
                item { SectionTitle("About") }
                if (rowMatches("About", "about dhyra", BuildConfig.VERSION_NAME, "version")) {
                    item { SettingRow(Icons.Default.Info, "About DHYRA", "Version ${BuildConfig.VERSION_NAME}") { onAbout() } }
                }
            }
            if (normalizedQuery.isNotBlank() && !sectionMatches(
                    "General", "default browser", "homepage", "search engine", "type on new tab"
                ) && !sectionMatches("Appearance", "theme", "desktop site", "address bar", "top") &&
                !sectionMatches("Privacy", "shields", "trackers", "ads", "pop-ups", "clear browsing data", "cookies", "site storage", "private browsing", "incognito", "isolated profile") &&
                !sectionMatches("About", "about dhyra", BuildConfig.VERSION_NAME, "version")) {
                item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No settings found for ‘$normalizedQuery’", color = cs.onSurfaceVariant)
                    }
                }
            }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }

    if (showHome) {
        var draft by remember { mutableStateOf(state.homepage) }
        AlertDialog(
            onDismissRequest = { showHome = false },
            containerColor = cs.surface,
            title = { Text("Homepage") },
            text = {
                Column {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("https://example.com") }
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Leave empty to use the DHYRA start page.",
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                        color = cs.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onSave("homepage", if (draft.isBlank()) "" else BrowserAddressResolver.normalizeHomepage(draft))
                    showHome = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showHome = false }) { Text("Cancel") } }
        )
    }

    if (showEngine) {
        ChoiceDialog(
            title = "Search engine",
            options = ENGINE_OPTIONS,
            selected = state.engine,
            onPick = {
                onSave("search_engine", it)
                showEngine = false
            },
            onDismiss = { showEngine = false }
        )
    }

    if (showTheme) {
        ChoiceDialog(
            title = "Theme",
            options = THEME_OPTIONS,
            selected = state.theme,
            onPick = {
                onSave("theme", it)
                showTheme = false
            },
            onDismiss = { showTheme = false }
        )
    }

    if (showClear) {
        AlertDialog(
            onDismissRequest = { showClear = false },
            containerColor = cs.surface,
            title = { Text("Clear browsing data?") },
            text = { Text("This clears history, cookies and site storage of regular tabs. It can sign you out of websites.") },
            confirmButton = {
                TextButton(onClick = {
                    onClear()
                    showClear = false
                }) { Text("Clear", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { showClear = false }) { Text("Cancel") } }
        )
    }
}

// ---------- bookmarks and history ----------

@Composable
internal fun EntriesScreen(
    title: String,
    entries: List<SavedPage>,
    emptyText: String,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onDelete: (String) -> Unit,
    onClearAll: (() -> Unit)? = null,
    onImport: (() -> Unit)? = null,
    onExport: (() -> Unit)? = null
) {
    val cs = MaterialTheme.colorScheme
    var query by remember(title) { mutableStateOf("") }
    val filtered = remember(entries, query) {
        val terms = query.trim().lowercase()
        if (terms.isEmpty()) entries else entries.filter {
            it.title.lowercase().contains(terms) || it.url.lowercase().contains(terms)
        }
    }
    Column(Modifier.fillMaxSize().background(cs.background).navigationBarsPadding()) {
        SubpageBar(
            title = title,
            onBack = onBack,
            trailing = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onImport != null) IconButton(onClick = onImport) {
                        Icon(Icons.Default.FileOpen, contentDescription = "Import bookmarks", tint = cs.onSurface)
                    }
                    if (onExport != null) IconButton(onClick = onExport) {
                        Icon(Icons.Default.FileDownload, contentDescription = "Export bookmarks", tint = cs.onSurface)
                    }
                    if (onClearAll != null && entries.isNotEmpty()) {
                        TextButton(onClick = onClearAll) { Text("Clear", color = cs.primary) }
                    }
                }
            }
        )
        if (entries.isNotEmpty()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text("Search $title") }
            )
        }
        if (filtered.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    text = if (entries.isEmpty()) emptyText else "No matching entries",
                    fontSize = 15.sp,
                    lineHeight = 22.sp,
                    color = cs.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(filtered, key = { it.url + it.timestamp }) { entry ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onOpen(entry.url) }
                            .padding(start = 24.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = entry.title.ifBlank { entry.url },
                                fontSize = 15.sp,
                                lineHeight = 22.sp,
                                fontWeight = FontWeight.Medium,
                                color = cs.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = siteLabelOf(entry.url) + " • " +
                                    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                                        .format(Date(entry.timestamp)),
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                color = cs.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = { onDelete(entry.url) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

// ---------- downloads ----------

@Composable
internal fun DownloadsScreen(onBack: () -> Unit, refreshKey: Int) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf(emptyList<DownloadRow>()) }
    var loadError by remember { mutableStateOf(false) }

    suspend fun load() {
        try {
            val items = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                val cursor = manager.query(DownloadManager.Query())
                val result = mutableListOf<DownloadRow>()
                cursor?.use { c ->
                    val idCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
                    val titleCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
                    val statusCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                    val totalCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                    val soFarCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                    while (c.moveToNext()) {
                        result += DownloadRow(
                            id = c.getLong(idCol),
                            title = c.getString(titleCol) ?: "Download",
                            status = statusLabel(c.getInt(statusCol)),
                            total = c.getLong(totalCol),
                            downloaded = c.getLong(soFarCol)
                        )
                    }
                }
                result
            }
            rows = items.sortedByDescending { row -> row.id }
            loadError = false
        } catch (_: Exception) {
            // Keep the last successful snapshot visible while reporting that refresh failed.
            loadError = true
        }
    }

    LaunchedEffect(refreshKey, lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.STARTED) {
            while (true) {
                load()
                val active = com.dhyra.browser.core.downloads.shouldPollDownloadStatus(rows.map { it.status })
                delay(if (active) 1_200 else 15_000)
            }
        }
    }

    Column(Modifier.fillMaxSize().background(cs.background).navigationBarsPadding()) {
        SubpageBar(
            title = "Downloads",
            onBack = onBack,
            trailing = {
                IconButton(onClick = { scope.launch { load() } }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh downloads", tint = cs.onSurface)
                }
            }
        )
        when {
            loadError && rows.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Downloads could not be loaded", color = cs.onSurface)
                    TextButton(onClick = { scope.launch { load() } }) { Text("Try again") }
                }
            }
            rows.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(text = "No downloads yet", fontSize = 15.sp, lineHeight = 22.sp, color = cs.onSurfaceVariant)
            }
            else -> LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                if (loadError) item {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Showing the last successful refresh.", modifier = Modifier.weight(1f), color = cs.error, fontSize = 12.sp)
                        TextButton(onClick = { scope.launch { load() } }) { Text("Retry") }
                    }
                }
                items(rows, key = { it.id }) { row ->
                    Row(
                        Modifier.fillMaxWidth().padding(start = 24.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = cs.onSurfaceVariant)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = row.title,
                                fontSize = 15.sp,
                                lineHeight = 22.sp,
                                fontWeight = FontWeight.Medium,
                                color = cs.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${row.status} • ${formatBytes(row.downloaded)} / " +
                                    (if (row.total > 0) formatBytes(row.total) else "—"),
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                color = cs.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = {
                            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            runCatching {
                                val uri = manager.getUriForDownloadedFile(row.id)
                                if (uri != null) {
                                    val mime = context.contentResolver.getType(uri) ?: "*/*"
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, mime)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(intent)
                                } else Toast.makeText(context, "File is not ready yet", Toast.LENGTH_SHORT).show()
                            }.onFailure {
                                Toast.makeText(context, "No app can open this file", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(Icons.Default.OpenInNew, contentDescription = "Open ${row.title}", tint = cs.onSurfaceVariant)
                        }
                    }
                    HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.55f))
                }
            }
        }
    }
}

// ---------- about ----------

@Composable
internal fun AboutScreen(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().background(cs.background).navigationBarsPadding()) {
        SubpageBar(title = "About", onBack = onBack)
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(32.dp))
            Box(
                Modifier.size(84.dp).clip(RoundedCornerShape(26.dp)).background(cs.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Public,
                    contentDescription = null,
                    tint = cs.onPrimary,
                    modifier = Modifier.size(44.dp)
                )
            }
            Spacer(Modifier.height(20.dp))
            Text(
                text = "DHYRA BROWSER",
                fontSize = 22.sp,
                lineHeight = 30.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = cs.onSurface
            )
            Text(
                text = "Version ${BuildConfig.VERSION_NAME}",
                fontSize = 14.sp,
                lineHeight = 21.sp,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(18.dp))
            Text(
                text = "A calm, minimal Android browser powered by Android System WebView.",
                fontSize = 14.sp,
                lineHeight = 21.sp,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}
