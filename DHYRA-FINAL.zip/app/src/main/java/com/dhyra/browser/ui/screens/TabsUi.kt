@file:OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser.ui.screens

import com.dhyra.browser.*
import com.dhyra.browser.ui.theme.*
import com.dhyra.browser.ui.components.*

import android.graphics.Bitmap
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val CASCADE_STEP_MS = 50L

/**
 * Tab switcher: a two-column grid of cards. Cards can be swiped away, closed with their X,
 * and "Close all" fades them out in a short cascade before the tabs are actually closed.
 */
@Composable
internal fun TabsScreen(
    controller: BrowserController,
    startOnPrivate: Boolean,
    onBack: () -> Unit,
    onSelect: (Int) -> Unit,
    onClose: (Int) -> Unit,
    onNew: (Boolean) -> Unit,
    onCloseAll: (Boolean) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var showPrivate by remember { mutableStateOf(startOnPrivate) }
    var closingAll by remember { mutableStateOf(false) }
    val regularTabs = controller.tabs.filter { !it.isPrivate }
    val privateTabs = controller.tabs.filter { it.isPrivate }
    val visible = if (showPrivate) privateTabs else regularTabs

    Column(Modifier.fillMaxSize().background(cs.background)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = cs.onSurface)
            }
            Spacer(Modifier.weight(1f))
            ModeSwitch(
                showPrivate = showPrivate,
                regularCount = regularTabs.size,
                privateCount = privateTabs.size,
                onChange = { showPrivate = it }
            )
            Spacer(Modifier.weight(1f))
            IconButton(
                onClick = {
                    if (visible.isNotEmpty() && !closingAll) {
                        val group = showPrivate
                        closingAll = true
                        scope.launch {
                            delay(minOf(visible.size, 8) * CASCADE_STEP_MS + 240L)
                            onCloseAll(group)
                            closingAll = false
                        }
                    }
                },
                enabled = visible.isNotEmpty() && !closingAll
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Close all tabs",
                    tint = if (visible.isNotEmpty()) cs.onSurface else cs.onSurface.copy(alpha = 0.34f)
                )
            }
        }

        if (visible.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    text = if (showPrivate) "No private tabs" else "No open tabs",
                    fontSize = 15.sp,
                    lineHeight = 22.sp,
                    color = cs.onSurfaceVariant
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(visible, key = { it.id }) { tab ->
                    TabCard(
                        tab = tab,
                        selected = tab.id == controller.activeTabId,
                        thumbnail = controller.thumbnailOf(tab.id),
                        favicon = controller.faviconOf(tab.id),
                        cascadeIndex = visible.indexOf(tab),
                        closingAll = closingAll,
                        onClick = { onSelect(tab.id) },
                        onClose = { onClose(tab.id) }
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            Button(
                onClick = { onNew(showPrivate) },
                modifier = Modifier.height(52.dp).widthIn(min = 190.dp),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = cs.primary, contentColor = cs.onPrimary)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (showPrivate) "New private tab" else "New tab",
                    fontSize = 16.sp,
                    lineHeight = 22.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun ModeSwitch(showPrivate: Boolean, regularCount: Int, privateCount: Int, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(cs.surfaceVariant)
            .padding(3.dp)
    ) {
        ModeSegment("Tabs $regularCount", !showPrivate) { onChange(false) }
        ModeSegment("Private $privateCount", showPrivate) { onChange(true) }
    }
}

@Composable
private fun ModeSegment(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .clip(RoundedCornerShape(19.dp))
            .background(if (selected) cs.surface else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) cs.onSurface else cs.onSurfaceVariant,
            maxLines = 1
        )
    }
}

@Composable
private fun TabCard(
    tab: BrowserTab,
    selected: Boolean,
    thumbnail: Bitmap?,
    favicon: Bitmap?,
    cascadeIndex: Int,
    closingAll: Boolean,
    onClick: () -> Unit,
    onClose: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val offsetX = remember { Animatable(0f) }
    var widthPx by remember { mutableFloatStateOf(1f) }
    var closing by remember { mutableStateOf(false) }
    val visibility by animateFloatAsState(
        targetValue = if (closingAll || closing) 0f else 1f,
        animationSpec = tween(
            durationMillis = if (closingAll) 220 else 160,
            delayMillis = if (closingAll) minOf(cascadeIndex, 7) * CASCADE_STEP_MS.toInt() else 0
        ),
        label = "tabCardVisibility"
    )

    val blank = isBlankPage(tab.url)
    val title = if (blank) "New tab" else tab.title.ifBlank { siteLabelOf(tab.url) }
    val label = if (blank) "New tab" else siteLabelOf(tab.url)
    val accent = tileColorFor(label)
    val foreground = if (tab.isPrivate) PrivateText else cs.onSurface
    val muted = if (tab.isPrivate) PrivateText.copy(alpha = 0.7f) else cs.onSurfaceVariant
    val shape = RoundedCornerShape(20.dp)

    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(0.78f)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .graphicsLayer {
                translationX = offsetX.value
                val drag = (abs(offsetX.value) / widthPx).coerceIn(0f, 1f)
                alpha = visibility * (1f - drag)
                val scale = 0.92f + 0.08f * visibility
                scaleX = scale
                scaleY = scale
            }
            .pointerInput(tab.id) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (abs(offsetX.value) > widthPx * 0.35f) {
                                val direction = if (offsetX.value > 0f) 1f else -1f
                                offsetX.animateTo(direction * widthPx * 1.2f, tween(160))
                                onClose()
                            } else {
                                offsetX.animateTo(0f, tween(180))
                            }
                        }
                    },
                    onDragCancel = { scope.launch { offsetX.animateTo(0f, tween(180)) } },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        scope.launch { offsetX.snapTo(offsetX.value + dragAmount) }
                    }
                )
            }
    ) {
        Surface(
            modifier = Modifier.fillMaxSize().clip(shape).clickable(onClick = onClick),
            shape = shape,
            color = if (tab.isPrivate) PrivateTint else cs.surface,
            border = if (selected) BorderStroke(2.dp, cs.primary) else BorderStroke(1.dp, cs.outline)
        ) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().height(40.dp).padding(start = 12.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(18.dp).clip(CircleShape).background(accent.copy(alpha = 0.3f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (favicon != null && !tab.isPrivate) {
                            Image(
                                bitmap = remember(favicon) { favicon.asImageBitmap() },
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Fit
                            )
                        } else {
                            Text(
                                text = if (blank) "+" else monogramOf(label),
                                fontSize = 10.sp,
                                lineHeight = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = foreground
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = title,
                        modifier = Modifier.weight(1f),
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        fontWeight = FontWeight.Medium,
                        color = foreground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    IconButton(
                        onClick = {
                            if (!closing) {
                                closing = true
                                scope.launch {
                                    delay(170)
                                    onClose()
                                }
                            }
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close tab",
                            tint = muted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(start = 8.dp, end = 8.dp, bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (tab.isPrivate) Color.Black.copy(alpha = 0.22f) else cs.background),
                    contentAlignment = Alignment.Center
                ) {
                    if (thumbnail != null && !tab.isPrivate && !blank) {
                        val image = remember(thumbnail) { thumbnail.asImageBitmap() }
                        Image(
                            bitmap = image,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                            alignment = Alignment.TopCenter
                        )
                    } else {
                        Icon(
                            imageVector = when {
                                tab.isPrivate -> Icons.Default.VisibilityOff
                                blank -> Icons.Default.Search
                                else -> Icons.Default.Public
                            },
                            contentDescription = null,
                            tint = muted.copy(alpha = 0.6f),
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }
            }
        }
    }
}
