package com.dhyra.browser.core.tabs

object TabSelection {
    /**
     * Chooses the tab to show after [closingId] is closed.
     *
     * Closing a background tab keeps [activeId]. Closing the active tab returns to its
     * parent when the parent is still open, otherwise to the tab that slides into the
     * closed tab's position (or the last tab when the closed one was last).
     */
    fun afterClose(
        order: List<Int>,
        closingId: Int,
        activeId: Int,
        parentOf: (Int) -> Int?
    ): Int? {
        if (closingId != activeId) {
            return if (order.contains(activeId) && activeId != closingId) activeId else order.lastOrNull { it != closingId }
        }
        val remaining = order.filter { it != closingId }
        if (remaining.isEmpty()) return null
        val parent = parentOf(closingId)
        if (parent != null && remaining.contains(parent)) return parent
        val index = order.indexOf(closingId)
        return remaining.getOrNull(index) ?: remaining.last()
    }
}
