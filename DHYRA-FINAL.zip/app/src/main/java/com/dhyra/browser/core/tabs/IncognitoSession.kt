package com.dhyra.browser.core.tabs

/** Policy helpers for private tabs; persistence is deliberately disabled for this tab class. */
object IncognitoSession {
    fun shouldPersistHistory(isPrivate: Boolean): Boolean = !isPrivate
    fun shouldPersistSession(isPrivate: Boolean): Boolean = !isPrivate
    fun shouldPersistBookmarks(isPrivate: Boolean): Boolean = !isPrivate
    fun cacheModeNoCache(isPrivate: Boolean): Boolean = isPrivate
}
