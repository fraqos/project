@file:OptIn(ExperimentalMaterial3Api::class)

package com.dhyra.browser.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.dhyra.browser.core.translation.TranslationLanguage
import com.dhyra.browser.core.translation.TranslationPhase
import com.dhyra.browser.core.translation.TranslationState

@Composable
internal fun TranslationSheet(
    state: TranslationState,
    initialSource: String,
    initialTarget: String,
    onDismiss: () -> Unit,
    onStart: (source: String, target: String, wifiOnly: Boolean) -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRestore: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var source by remember(initialSource) { mutableStateOf(initialSource) }
    var target by remember(initialTarget) { mutableStateOf(initialTarget) }
    var wifiOnly by remember { mutableStateOf(true) }
    var sourceExpanded by remember { mutableStateOf(false) }
    var targetExpanded by remember { mutableStateOf(false) }
    val busy = state.phase in setOf(TranslationPhase.DOWNLOADING_MODEL, TranslationPhase.TRANSLATING, TranslationPhase.RESTORING)
    val sourceLabel = TranslationLanguage.supported.firstOrNull { it.tag == source }?.label ?: source
    val targetLabel = TranslationLanguage.supported.firstOrNull { it.tag == target }?.label ?: target

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.surface
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Translate this page", style = MaterialTheme.typography.titleLarge, color = colors.onSurface)
            Text(
                "Translation runs on this device after the required language model is downloaded. Only HTTPS pages are supported; site scripts can still modify or replace page content.",
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant
            )
            if (state.phase == TranslationPhase.DOWNLOADING_MODEL) {
                Text(
                    "Cancel stops page translation. ML Kit may finish an already-started model download in the background.",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.onSurfaceVariant
                )
            }

            ExposedDropdownMenuBox(expanded = sourceExpanded, onExpandedChange = { sourceExpanded = it }) {
                OutlinedTextField(
                    value = sourceLabel,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Page language") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(sourceExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    shape = RoundedCornerShape(16.dp)
                )
                androidx.compose.material3.ExposedDropdownMenu(
                    expanded = sourceExpanded,
                    onDismissRequest = { sourceExpanded = false }
                ) {
                    TranslationLanguage.supported.forEach { language ->
                        DropdownMenuItem(
                            text = { Text(language.label) },
                            onClick = { source = language.tag; sourceExpanded = false }
                        )
                    }
                }
            }

            ExposedDropdownMenuBox(expanded = targetExpanded, onExpandedChange = { targetExpanded = it }) {
                OutlinedTextField(
                    value = targetLabel,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Translate to") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(targetExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    shape = RoundedCornerShape(16.dp)
                )
                androidx.compose.material3.ExposedDropdownMenu(
                    expanded = targetExpanded,
                    onDismissRequest = { targetExpanded = false }
                ) {
                    TranslationLanguage.supported.filter { it.tag != "auto" && it.tag != source }.forEach { language ->
                        DropdownMenuItem(
                            text = { Text(language.label) },
                            onClick = { target = language.tag; targetExpanded = false }
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = wifiOnly, onCheckedChange = { wifiOnly = it })
                Column(Modifier.weight(1f)) {
                    Text("Download models over Wi-Fi only", style = MaterialTheme.typography.bodyMedium)
                    Text("Language models can be around 30 MB each.", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant)
                }
            }

            if (state.phase != TranslationPhase.IDLE) {
                HorizontalDivider(color = colors.outlineVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (busy) {
                        CircularProgressIndicator(modifier = Modifier.width(20.dp).height(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(state.phase.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.titleMedium)
                        state.message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant) }
                    }
                }
                if (state.contentLimited) {
                    Text(
                        "Some page content was skipped because it exceeded safe translation limits.",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.tertiary
                    )
                }
                if (state.translatedSegments > 0 || state.failedSegments > 0) {
                    Text(
                        "${state.translatedSegments} translated · ${state.failedSegments} failed · ${state.pendingBatches} batches pending",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant
                    )
                }
            }

            Button(
                onClick = { onStart(source, target, wifiOnly) },
                enabled = !busy && source != target,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text(if (state.phase == TranslationPhase.COMPLETED) "Translate again" else "Translate page") }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                when (state.phase) {
                    TranslationPhase.TRANSLATING -> TextButton(onClick = onPause) { Text("Pause") }
                    TranslationPhase.PAUSED -> TextButton(onClick = onResume) { Text("Resume") }
                    else -> TextButton(onClick = onDismiss) { Text("Close") }
                }
                TextButton(
                    onClick = onRestore,
                    enabled = state.phase !in setOf(TranslationPhase.IDLE, TranslationPhase.RESTORING)
                ) {
                    Text(if (state.phase == TranslationPhase.DOWNLOADING_MODEL) "Cancel translation" else "Show original")
                }
            }
        }
    }
}
