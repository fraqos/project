package com.dhyra.browser.core.downloads

/** Immutable download presentation model shared by internal download screens. */
data class DownloadProgress(
    val id: Long,
    val fileName: String,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val status: Status
) {
    val progressPercent: Int
        get() = if (totalBytes <= 0L) 0 else ((downloadedBytes.coerceAtLeast(0) * 100L) / totalBytes).toInt().coerceIn(0, 100)

    enum class Status { QUEUED, RUNNING, PAUSED, COMPLETE, FAILED }
}

/** DownloadManager does not expose pause/resume controls; this describes only safe UI actions. */
object DownloadActions {
    fun canPause(status: DownloadProgress.Status): Boolean = status == DownloadProgress.Status.RUNNING
    fun canResume(status: DownloadProgress.Status): Boolean = status == DownloadProgress.Status.PAUSED
}
