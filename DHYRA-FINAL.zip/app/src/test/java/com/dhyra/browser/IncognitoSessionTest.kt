package com.dhyra.browser

import com.dhyra.browser.core.tabs.IncognitoSession
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IncognitoSessionTest {
    @Test
    fun privateTabIsNotPersistedAndUsesNoCachePolicy() {
        assertFalse(IncognitoSession.shouldPersistHistory(true))
        assertFalse(IncognitoSession.shouldPersistSession(true))
        assertFalse(IncognitoSession.shouldPersistBookmarks(true))
        assertTrue(IncognitoSession.cacheModeNoCache(true))
    }

    @Test
    fun regularTabKeepsNormalPersistencePolicy() {
        assertTrue(IncognitoSession.shouldPersistHistory(false))
        assertTrue(IncognitoSession.shouldPersistSession(false))
        assertTrue(IncognitoSession.shouldPersistBookmarks(false))
        assertFalse(IncognitoSession.cacheModeNoCache(false))
    }
}
