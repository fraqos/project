package com.dhyra.browser

import com.dhyra.browser.core.downloads.DownloadActions
import com.dhyra.browser.core.downloads.DownloadProgress
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadSupportTest {
    @Test
    fun progressIsBoundedAndHandlesUnknownSize() {
        val half = DownloadProgress(1, "file.zip", 50, 100, DownloadProgress.Status.RUNNING)
        assertEquals(50, half.progressPercent)
        assertEquals(0, DownloadProgress(2, "file", 10, 0, DownloadProgress.Status.RUNNING).progressPercent)
        assertEquals(100, DownloadProgress(3, "file", 500, 100, DownloadProgress.Status.COMPLETE).progressPercent)
    }

    @Test
    fun pauseResumePolicyDoesNotClaimUnsupportedStates() {
        assertTrue(DownloadActions.canPause(DownloadProgress.Status.RUNNING))
        assertFalse(DownloadActions.canPause(DownloadProgress.Status.COMPLETE))
        assertTrue(DownloadActions.canResume(DownloadProgress.Status.PAUSED))
        assertFalse(DownloadActions.canResume(DownloadProgress.Status.RUNNING))
    }
}
