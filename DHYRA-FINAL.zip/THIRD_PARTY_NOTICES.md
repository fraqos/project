# Third-Party Notices

DHYRA Browser's direct dependencies in this build are listed below. Review current upstream license terms and include any required notices with distributed builds.

| Component | Purpose | License / notice |
|---|---|---|
| AndroidX Core / Activity / Lifecycle | Android platform integration | Apache License 2.0 |
| Jetpack Compose UI / Foundation / Material 3 | Declarative user interface | Apache License 2.0 |
| AndroidX DataStore | Preferences persistence | Apache License 2.0 |
| AndroidX WebKit | WebView compatibility APIs | Apache License 2.0 |
| ZXing Core | QR-code generation | Apache License 2.0 |
| Kotlin | Programming language and Gradle plugin | Apache License 2.0 |
| Android System WebView | Web content engine supplied by the device/vendor | Chromium and provider-specific notices apply |

Google Mobile Ads SDK is **not** a dependency in this build. This table lists direct dependencies visible in the app Gradle file; Gradle resolves transitive dependencies. Generate and inspect a complete dependency/license report before commercial distribution. No third-party source files are vendored into this archive.
