@echo off
setlocal EnableExtensions EnableDelayedExpansion
set VERSION=8.13
set EXPECTED_SHA256=20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78
set INSTALLED_VERSION=
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  for /f "tokens=2" %%V in ('gradle --version 2^>nul ^| findstr /b /c:"Gradle "') do set INSTALLED_VERSION=%%V
  if "!INSTALLED_VERSION!"=="%VERSION%" (
    gradle %*
    exit /b !ERRORLEVEL!
  )
  echo Gradle %VERSION% is required; PATH Gradle is "!INSTALLED_VERSION!". Using the pinned distribution.
)
set GH=%USERPROFILE%\.gradle\dhyra-wrapper
set DIST=%GH%\gradle-%VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%GH%" mkdir "%GH%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $zip='%GH%\gradle-%VERSION%-bin.zip'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile $zip; $actual=(Get-FileHash -Algorithm SHA256 $zip).Hash.ToLowerInvariant(); if ($actual -ne '%EXPECTED_SHA256%') { Remove-Item -Force $zip; throw 'Gradle distribution SHA-256 mismatch' }; Expand-Archive -Force $zip '%GH%'"
  if errorlevel 1 exit /b 1
)
call "%DIST%\bin\gradle.bat" %*
exit /b !ERRORLEVEL!
