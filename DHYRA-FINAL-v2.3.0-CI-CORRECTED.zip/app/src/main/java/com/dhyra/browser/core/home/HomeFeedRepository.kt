package com.dhyra.browser.core.home

import android.Manifest
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import android.util.Xml
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.resume

/** Current weather returned by Open-Meteo. Coordinates are never persisted by DHYRA. */
data class HomeWeather(
    val temperatureC: Double,
    val feelsLikeC: Double,
    val weatherCode: Int,
    val observedAt: String
) {
    val description: String get() = weatherDescription(weatherCode)
}

data class HomeNewsItem(
    val title: String,
    val url: String,
    val source: String
)

/**
 * Small, keyless homepage data sources. Weather only runs after an explicit user action and
 * uses the Android location permission already declared by the browser. News uses a public RSS
 * feed. Both clients have bounded timeouts and return parsed data rather than network objects.
 */
object HomeFeedRepository {
    suspend fun currentWeather(context: Context): HomeWeather {
        val location = currentLocation(context.applicationContext)
        return withContext(Dispatchers.IO) {
            val query = "latitude=${location.latitude}&longitude=${location.longitude}" +
                "&current=temperature_2m,apparent_temperature,weather_code&timezone=auto"
            val json = requestJson("https://api.open-meteo.com/v1/forecast?$query")
            val current = json.optJSONObject("current") ?: error("Weather data is unavailable.")
            val temperature = current.optDouble("temperature_2m", Double.NaN)
            val feelsLike = current.optDouble("apparent_temperature", Double.NaN)
            require(temperature.isFinite() && feelsLike.isFinite()) { "Weather data is incomplete." }
            HomeWeather(
                temperatureC = temperature,
                feelsLikeC = feelsLike,
                weatherCode = current.optInt("weather_code", -1),
                observedAt = current.optString("time")
            )
        }
    }

    suspend fun latestNews(limit: Int = 5): List<HomeNewsItem> = withContext(Dispatchers.IO) {
        val locale = Locale.getDefault()
        val language = locale.language.ifBlank { "en" }
        val country = locale.country.ifBlank { "US" }.uppercase(Locale.ROOT)
        val feed = "https://news.google.com/rss?hl=$language-$country&gl=$country&ceid=$country:$language"
        val connection = (URL(feed).openConnection() as HttpURLConnection).apply {
            connectTimeout = NETWORK_TIMEOUT_MS
            readTimeout = NETWORK_TIMEOUT_MS
            requestMethod = "GET"
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml")
            instanceFollowRedirects = true
        }
        try {
            val parser = Xml.newPullParser().apply {
                setFeature(XmlPullParser.FEATURE_PROCESS_DOCDECL, false)
                setInput(connection.inputStream, null)
            }
            val results = mutableListOf<HomeNewsItem>()
            var inItem = false
            var title = ""
            var link = ""
            var source = ""
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT && results.size < limit) {
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name.lowercase(Locale.ROOT)) {
                        "item" -> {
                            inItem = true
                            title = ""
                            link = ""
                            source = ""
                        }
                        "title" -> if (inItem) title = parser.nextText().trim()
                        "link" -> if (inItem) link = parser.nextText().trim()
                        "source" -> if (inItem) source = parser.nextText().trim()
                    }
                    XmlPullParser.END_TAG -> if (parser.name.equals("item", ignoreCase = true)) {
                        if (title.isNotBlank() && isWebUrl(link)) {
                            results += HomeNewsItem(
                                title = title.removeSuffix(" - $source").trim(),
                                url = link,
                                source = source.ifBlank { "Google News" }
                            )
                        }
                        inItem = false
                    }
                }
                event = parser.next()
            }
            results
        } finally {
            connection.disconnect()
        }
    }

    private suspend fun currentLocation(context: Context): Location {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        check(fine || coarse) { "Allow location access to show local weather." }

        val manager = context.getSystemService(LocationManager::class.java)
            ?: error("Location services are unavailable on this device.")
        val enabledProviders: List<String> = runCatching { manager.getProviders(true) }.getOrDefault(emptyList())
        // Avoid asking the GPS provider for a fix when Android granted approximate location only.
        val allowedProviders = enabledProviders.filter { fine || it != LocationManager.GPS_PROVIDER }
        val preferredProviders = buildList {
            add(LocationManager.NETWORK_PROVIDER)
            if (fine) add(LocationManager.GPS_PROVIDER)
            add(LocationManager.PASSIVE_PROVIDER)
        }
        val provider = preferredProviders.firstOrNull { it in allowedProviders }
        val fallback = {
            allowedProviders.mapNotNull { name ->
                runCatching { manager.getLastKnownLocation(name) }.getOrNull()
            }.maxByOrNull { it.elapsedRealtimeNanos }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && provider != null) {
            val fresh = withTimeoutOrNull(12_000) {
                suspendCancellableCoroutine<Location?> { continuation ->
                    val cancellation = CancellationSignal()
                    continuation.invokeOnCancellation { cancellation.cancel() }
                    runCatching {
                        manager.getCurrentLocation(provider, cancellation, context.mainExecutor) { result ->
                            if (continuation.isActive) continuation.resume(result)
                        }
                    }.onFailure {
                        if (continuation.isActive) continuation.resume(null)
                    }
                }
            }
            fresh?.let { return it }
        }
        return fallback() ?: error("No recent location is available. Turn on device location and try again.")
    }

    private fun requestJson(url: String): JSONObject {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = NETWORK_TIMEOUT_MS
            readTimeout = NETWORK_TIMEOUT_MS
            requestMethod = "GET"
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json")
            instanceFollowRedirects = true
        }
        try {
            val status = connection.responseCode
            if (status !in 200..299) error("Weather service returned HTTP $status.")
            return connection.inputStream.bufferedReader(Charsets.UTF_8).use { JSONObject(it.readText()) }
        } finally {
            connection.disconnect()
        }
    }

    private fun isWebUrl(value: String): Boolean = runCatching {
        val url = URL(value)
        url.protocol in setOf("http", "https") && !url.host.isNullOrBlank()
    }.getOrDefault(false)

    private const val NETWORK_TIMEOUT_MS = 8_000
    private const val USER_AGENT = "DHYRA-Browser/2.3.0 (Android; homepage-feed)"
}

private fun weatherDescription(code: Int): String = when (code) {
    0 -> "Clear sky"
    1 -> "Mainly clear"
    2 -> "Partly cloudy"
    3 -> "Overcast"
    45, 48 -> "Fog"
    51, 53, 55 -> "Drizzle"
    56, 57 -> "Freezing drizzle"
    61, 63, 65 -> "Rain"
    66, 67 -> "Freezing rain"
    71, 73, 75, 77 -> "Snow"
    80, 81, 82 -> "Rain showers"
    85, 86 -> "Snow showers"
    95, 96, 99 -> "Thunderstorms"
    else -> "Current conditions"
}
