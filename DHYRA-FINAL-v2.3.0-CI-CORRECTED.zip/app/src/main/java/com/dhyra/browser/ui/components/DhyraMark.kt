package com.dhyra.browser.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.Text
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** DHYRA's in-app monogram: a confident D with an open orbit detail. */
@Composable
internal fun DhyraMark(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp
) {
    val colors = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.32f))
            .background(colors.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "D",
            color = colors.onPrimaryContainer,
            fontSize = (size.value * 0.56f).sp,
            lineHeight = (size.value * 0.64f).sp,
            fontWeight = FontWeight.ExtraBold
        )
        Canvas(Modifier.size(size)) {
            val stroke = this.size.minDimension * 0.055f
            val center = Offset(this.size.width * 0.5f, this.size.height * 0.5f)
            val radius = this.size.minDimension * 0.40f
            drawArc(
                color = colors.primary,
                startAngle = -48f,
                sweepAngle = 238f,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            drawCircle(
                color = colors.primary,
                radius = stroke * 1.15f,
                center = Offset(this.size.width * 0.82f, this.size.height * 0.24f)
            )
        }
    }
}
