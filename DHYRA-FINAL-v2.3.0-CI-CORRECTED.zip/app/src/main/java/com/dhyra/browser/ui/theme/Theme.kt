package com.dhyra.browser.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.ui.platform.LocalContext
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Calm sage accent: readable on both the deep night and the soft day background. */
private val AccentDark = Color(0xFF9AE5D8)
private val AccentLight = Color(0xFF236F68)

/** Private tabs use a quiet violet so they are recognisable without shouting. */
internal val PrivateTint = Color(0xFF2B2542)
internal val PrivateText = Color(0xFFDCD3FF)

private val DarkScheme = darkColorScheme(
    primary = AccentDark,
    onPrimary = Color(0xFF04201C),
    primaryContainer = Color(0xFF1C3C38),
    onPrimaryContainer = Color(0xFFCDEFE9),
    inversePrimary = AccentLight,
    background = Color(0xFF0E1217),
    onBackground = Color(0xFFE6EAF0),
    surface = Color(0xFF151A21),
    onSurface = Color(0xFFE6EAF0),
    surfaceVariant = Color(0xFF1F262F),
    onSurfaceVariant = Color(0xFF93A0AF),
    inverseSurface = Color(0xFFE6EAF0),
    inverseOnSurface = Color(0xFF151A21),
    error = Color(0xFFFF8F85),
    onError = Color(0xFF3B0A06),
    outline = Color(0xFF2B333E),
    outlineVariant = Color(0xFF222932),
    surfaceContainerLowest = Color(0xFF0B0F13),
    surfaceContainerLow = Color(0xFF12171D),
    surfaceContainer = Color(0xFF151A21),
    surfaceContainerHigh = Color(0xFF1A2028),
    surfaceContainerHighest = Color(0xFF1F262F)
)

private val LightScheme = lightColorScheme(
    primary = AccentLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEFE9),
    onPrimaryContainer = Color(0xFF00201C),
    inversePrimary = AccentDark,
    background = Color(0xFFF7F9FA),
    onBackground = Color(0xFF141A21),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF141A21),
    surfaceVariant = Color(0xFFE9EEF1),
    onSurfaceVariant = Color(0xFF5A6673),
    inverseSurface = Color(0xFF2A3038),
    inverseOnSurface = Color(0xFFF1F4F6),
    error = Color(0xFFB3261E),
    onError = Color.White,
    outline = Color(0xFFD3DBE2),
    outlineVariant = Color(0xFFE3E9EE),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF4F7F8),
    surfaceContainer = Color(0xFFEFF3F5),
    surfaceContainerHigh = Color(0xFFE9EEF1),
    surfaceContainerHighest = Color(0xFFE3E9EC)
)

private val AmoledScheme = darkColorScheme(
    primary = Color(0xFF9DE3D7),
    onPrimary = Color(0xFF00201C),
    primaryContainer = Color(0xFF153A34),
    onPrimaryContainer = Color(0xFFB6F1E8),
    background = Color.Black,
    onBackground = Color(0xFFF2F4F5),
    surface = Color.Black,
    onSurface = Color(0xFFF2F4F5),
    surfaceVariant = Color(0xFF101315),
    onSurfaceVariant = Color(0xFFB1BBC3),
    inverseSurface = Color(0xFFE2E3E3),
    inverseOnSurface = Color(0xFF1B1C1C),
    outline = Color(0xFF343A40),
    outlineVariant = Color(0xFF22272C),
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Color.Black,
    surfaceContainer = Color.Black,
    surfaceContainerHigh = Color(0xFF050607),
    surfaceContainerHighest = Color(0xFF0A0C0D),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

/**
 * Every style carries a line height clearly larger than its font size, so ascenders
 * (h, t, l) and descenders (y, g, p, q) are never clipped inside fixed-height containers.
 * Compose has had includeFontPadding disabled by default since 1.6, so no extra
 * font padding is added on top.
 */
private val DhyraTypography = Typography(
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium)
)

@Composable
internal fun DhyraTheme(themeMode: String, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val scheme = when (themeMode) {
        "AMOLED" -> AmoledScheme
        "Dark" -> DarkScheme
        "Light" -> LightScheme
        "Dynamic" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (systemDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        } else if (systemDark) DarkScheme else LightScheme
        else -> if (systemDark) DarkScheme else LightScheme
    }
    MaterialTheme(colorScheme = scheme, typography = DhyraTypography, content = content)
}
