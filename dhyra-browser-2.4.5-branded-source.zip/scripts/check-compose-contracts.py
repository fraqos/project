#!/usr/bin/env python3
"""Fast source-contract checks for dhyra's Compose, privacy and CI integration."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
def read(path: str) -> str:
    file = ROOT / path
    if not file.is_file():
        raise SystemExit(f"Required source file is missing: {path}")
    return file.read_text(encoding="utf-8")

sheet = read("app/src/main/java/com/dhyra/browser/ui/components/TranslationSheet.kt")
controller = read("app/src/main/java/com/dhyra/browser/BrowserController.kt")
models = read("app/src/main/java/com/dhyra/browser/UiModels.kt")
settings = read("app/src/main/java/com/dhyra/browser/ui/screens/ScreensUi.kt")
home = read("app/src/main/java/com/dhyra/browser/ui/screens/HomeUi.kt")
workflow = read(".github/workflows/build.yml")
webview_policy = read("app/src/main/java/com/dhyra/browser/core/engine/DhyraWebViewController.kt")
main_activity = read("app/src/main/java/com/dhyra/browser/MainActivity.kt")
search_manager = read("app/src/main/java/com/dhyra/browser/core/search/SearchEngineManager.kt")
settings_manager = read("app/src/main/java/com/dhyra/browser/core/settings/DhyraSettingsManager.kt")
feeds = read("app/src/main/java/com/dhyra/browser/core/home/HomeFeedRepository.kt")
brand_vector = read("app/src/main/res/drawable/ic_launcher_foreground.xml")
brand_legacy = read("app/src/main/res/drawable/ic_launcher_legacy.xml")
brand_bg = read("app/src/main/res/drawable/ic_launcher_background.xml")
brand_compose = read("app/src/main/java/com/dhyra/browser/ui/components/DhyraMark.kt")
theme = read("app/src/main/java/com/dhyra/browser/ui/theme/Theme.kt")
tabs = read("app/src/main/java/com/dhyra/browser/ui/screens/TabsUi.kt")
build = read("app/build.gradle.kts")
manifest = read("app/src/main/AndroidManifest.xml")
address_tests = read("app/src/test/java/com/dhyra/browser/BrowserAddressResolverTest.kt")

checks = {
    "Material3 ExposedDropdownMenu extension import": "import androidx.compose.material3.ExposedDropdownMenu\n" in sheet,
    "Material3 anchor type import": "import androidx.compose.material3.ExposedDropdownMenuAnchorType\n" in sheet,
    "Both read-only anchors declare PrimaryNotEditable": sheet.count("menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable)") == 2,
    "Translation menus use scope extension": len(re.findall(r"^\s*ExposedDropdownMenu\s*\(", sheet, flags=re.MULTILINE)) == 2,
    "Translation DOM engine tests remain wired in CI": "test-page-translation.cjs" in workflow and "test-translation-retries.cjs" in workflow,
    "Application label uses exact lowercase brand": 'android:label="dhyra"' in manifest and 'android:label="DHYRA"' not in manifest,
    "Adaptive launcher foreground uses the official brand PNG": "dhyra_launcher_foreground" in brand_vector and all((ROOT / f"app/src/main/res/drawable-{density}/dhyra_launcher_foreground.png").is_file() for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi")),
    "Adaptive launcher no longer advertises the retired monochrome D glyph": "monochrome" not in read("app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml"),
    "Legacy launcher drawable resolves to the canonical DHYRA artwork": "@drawable/dhyra_brand_art" in brand_legacy,
    "Launcher background blends with the supplied white-blue artwork": "#FDFDFF" in brand_bg,
    "Compose brand mark displays the canonical PNG without cropping": "com.dhyra.browser.R.drawable.dhyra_brand_art" in brand_compose and "ContentScale.Fit" in brand_compose,
    "Retired appearance and motion options are absent from Settings": all(label not in settings for label in ("UI style", "Homepage layout", "Reduced motion", "Animation intensity", "Disable startup animation")),
    "Settings search does not return removed style or motion options": all(term not in settings for term in ("visual style", "glass dashboard", "reduced motion", "animation intensity")),
    "Retired appearance preferences are no longer part of app state": all(name not in models for name in ("UI_STYLE_KEY", "REDUCED_MOTION_KEY", "STARTUP_ANIMATION_DISABLED_KEY", "ANIMATION_INTENSITY_KEY", "uiStyle:", "reducedMotion:", "animationIntensity:")),
    "Theme uses the same dhyra violet accent as launcher across light and dark": "BrandViolet = Color(0xFF8067F0)" in theme and "BrandVioletDark" not in theme and "DhyraUiStyles" not in theme,
    "Theme and launcher use the same exact violet brand color": "#8067F0" in read("app/src/main/res/values/colors.xml") and "#8067F0" in read("app/src/main/res/values-night/colors.xml") and "0xFF8067F0" in theme,
    "Homepage legacy layout preference remains preserved without a settings row": "homeLayout = DhyraSettingsManager.normalizeHomeLayout(prefs[HOME_LAYOUT_KEY])" in main_activity and 'onSave("homepage_layout", it)' not in settings,
    "Homepage recent section retains layout-aware visibility": '"Search-Centric Homepage"' in home and "recent.isNotEmpty()" in home,
    "Custom search provider CRUD is wired": all(part in settings for part in ("CustomSearchEngineEditorDialog", "onAdd =", "onEdit =", "onDelete =", "Delete search engine?")),
    "Custom search stores multiple provider definitions": "CUSTOM_SEARCH_ENGINES_KEY" in models and "decodeCustomEngines" in main_activity,
    "Custom templates require HTTPS and exactly one placeholder": "Use exactly one %s or {query} placeholder." in search_manager and 'uri.scheme.equals("https"' in search_manager,
    "Custom search names are validated against built-ins and duplicates": "validateName" in search_manager and "hasDuplicateName" in search_manager,
    "Custom search terms are URL-encoded": "URLEncoder.encode(query" in search_manager,
    "Custom providers flow into homepage and omnibox": "availableEngines(state.customSearchEngines)" in main_activity and "state.customSearchUrl" in main_activity,
    "News supports all requested categories": all(category in feeds for category in ("World", "Technology", "Business", "Science", "Sports", "Entertainment", "Politics", "Breaking News", "Local News")),
    "News includes search, deduplication and publication timestamps": all(part in feeds for part in ("query: String", "seenLinks", "seenTitles", "publishedAt")) and "News search" in home,
    "News locale query is joined using an ampersand for search feeds": 'if (categoryPath.contains("?")) "&" else "?"' in feeds,
    "News feed timestamps and origin attribution are rendered": "formatNewsTimestamp" in home and "item.source" in home,
    "Weather requests Android permission after explicit user action": "RequestMultiplePermissions" in home and "ACCESS_COARSE_LOCATION" in home and "requestWeather" in home,
    "Weather service is Open-Meteo with bounded fix timeout": "api.open-meteo.com/v1/forecast" in feeds and "withTimeoutOrNull(12_000)" in feeds,
    "Approximate location does not use GPS provider": "fine || it != LocationManager.GPS_PROVIDER" in feeds,
    "Download confirmation is shown before enqueue": "onDownloadRequest = { request -> pendingDownload = request }" in main_activity and "Download file?" in main_activity and "startConfirmedDownload(request)" in main_activity,
    "Download confirmation includes true request host and executable warning": "val origin: String get() = Uri.parse(url).host" in read("app/src/main/java/com/dhyra/browser/core/downloads/DhyraDownloadManager.kt") and "request.mayBeExecutable" in main_activity,
    "SPACE downloads are blocked rather than silently persisted": "allowPersistentDownload(isPrivate)" in controller and "Downloads are disabled in SPACE" in controller,
    "Downloads screen supports progress, cancellation and opening": "LinearProgressIndicator" in settings and "manager.remove(row.id)" in settings and "getUriForDownloadedFile" in settings,
    "Native DownloadManager limitation is not disguised as pause-resume": "DownloadManager" in read("app/src/main/java/com/dhyra/browser/core/downloads/DhyraDownloadManager.kt"),
    "Fullscreen overlay identifies the requesting origin": 'text = "Fullscreen · $origin"' in controller and "Press Back to exit" in controller,
    "Fullscreen origin reads tab navigation state, not generic View.url": (
        "pageUrls[id]" in controller.split("override fun onShowCustomView", 1)[1].split("override fun onHideCustomView", 1)[0]
        and "tabs.firstOrNull { it.id == id }?.url" in controller.split("override fun onShowCustomView", 1)[1].split("override fun onHideCustomView", 1)[0]
        and "view.url" not in re.sub(r"//.*", "", controller.split("override fun onShowCustomView", 1)[1].split("override fun onHideCustomView", 1)[0])
    ),
    "WebView blocks mixed content and enables Safe Browsing": "MIXED_CONTENT_NEVER_ALLOW" in webview_policy and "safeBrowsingEnabled = true" in webview_policy,
    "WebView disables local file reads and media autoplay": "allowFileAccess = false" in webview_policy and "mediaPlaybackRequiresUserGesture = true" in webview_policy,
    "SSL certificate errors cancel": "handler?.cancel()" in controller,
    "SPACE profile requires multi-profile and scoped deletion": "MULTI_PROFILE" in read("app/src/main/java/com/dhyra/browser/core/tabs/SpaceWebViewProfile.kt") and "DELETE_BROWSING_DATA" in read("app/src/main/java/com/dhyra/browser/core/tabs/SpaceWebViewProfile.kt"),
    "SPACE profile cleanup is invoked when session ends": "clearSpaceProfileWhenSessionEnds" in controller and "clearBrowsingData()" in read("app/src/main/java/com/dhyra/browser/core/tabs/SpaceWebViewProfile.kt"),
    "Tab close uses a short exit animation and keyed lazy item movement": "CLOSE_TAB_ANIMATION_MS = 190L" in tabs and "Modifier.animateItem(" in tabs and "placementSpec = spring(" in tabs,
    "Close All uses bounded staggered exits and preserves group-close callback": "CLOSE_ALL_STAGGER_MS = 24L" in tabs and "CLOSE_ALL_STAGGER_LIMIT = 8" in tabs and "onCloseAll(privateGroup)" in tabs,
    "Tab animation no longer depends on removed motion settings": "reducedMotion" not in tabs and "animationIntensity" not in tabs and "state.reducedMotion" not in main_activity,
    "Startup logo is shown on every initialized app launch": "LaunchedEffect(initialized)" in main_activity and "showOpeningIntro = true" in main_activity and "DhyraMark(size = 56.dp)" in main_activity and "INTRO_SEEN_KEY" not in main_activity,
    "Theme exposes only System and Dark while migrating old values": 'THEME_OPTIONS = listOf("System", "Dark")' in models and 'supportedThemes = setOf("System", "Dark")' in settings_manager and '"AMOLED" -> "Dark"' in settings_manager,
    "SPACE is the user-facing private-session label": 'ModeSegment("SPACE $privateCount"' in tabs and '"SPACE tab"' in read("app/src/main/java/com/dhyra/browser/ui/components/SheetsUi.kt") and 'Text("SPACE"' in settings,
    "About screen uses fully-qualified generated Android R resource without crop": "com.dhyra.browser.R.drawable.dhyra_brand_art" in settings and "ContentScale.Fit" in settings and "contentScale = ContentScale.Crop" not in settings.split("// ---------- about ----------", 1)[1].split("// ----------", 1)[0],
    "Android 12 splash uses the canonical PNG in day and night themes": all("@drawable/dhyra_splash_logo" in read(f"app/src/main/res/{d}/styles.xml") for d in ("values-v31", "values-night-v31")) and all((ROOT / f"app/src/main/res/drawable-{density}/dhyra_splash_logo.png").is_file() for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi")),
    "Manifest round icon resolves to its adaptive resource": 'android:roundIcon="@mipmap/ic_launcher_round"' in manifest and (ROOT / "app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml").is_file(),
    "Legacy launcher PNGs exist for all standard densities": all((ROOT / f"app/src/main/res/mipmap-{density}/ic_launcher.png").is_file() for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi")),
    "Homepage and startup logo use the canonical PNG component": "DhyraMark(size = 32.dp)" in home and "DhyraMark(size = 56.dp)" in main_activity and "dhyra_brand_art" in brand_compose,
    "README references the supplied logo image": (ROOT / "docs/assets/dhyra-brand-reference.png").is_file(),
    "GitHub Actions uses current 2.4.5 artifact naming": "dhyra-v2.4.5.apk" in workflow and "dhyra-source.zip" in workflow,
    "App version and CI artifact version are synchronized": 'versionName = "2.4.5"' in build and 'versionCode = 23' in build and "dhyra-v2.4.5.apk" in workflow,
    "Release signing is opt-in and does not store secrets in the source": all(name in workflow for name in ("DHYRA_RELEASE_KEYSTORE_BASE64", "DHYRA_RELEASE_STORE_PASSWORD", "DHYRA_RELEASE_KEY_ALIAS", "DHYRA_RELEASE_KEY_PASSWORD")) and "DHYRA_RELEASE_STORE_FILE" in build and "sign_release" in workflow,
    "CI runs unit tests, lint and assemble": all(task in workflow for task in ("testDebugUnitTest", "lintDebug", "assembleDebug")),
    "Search, local address and validation regression tests are present": all(part in address_tests for part in ("localhost:8080/status", "[::1]:8080", "hello+dhyra", "hasDuplicateName", "buildNewsFeedUrl", "world+economy")),
    "GitHub workflow is stored in repository workflow path": (ROOT / ".github/workflows/build.yml").is_file(),
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(("PASS" if passed else "FAIL") + ": " + name)
if failed:
    print("Source contract validation failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
print(f"All {len(checks)} source contract checks passed.")
