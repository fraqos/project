# iOS Edition v1.5.0 — Change Notes

## Implemented in this source package

1. Replaced the previous bottom-floating address field with a pinned top address capsule.
2. Added secure-site indicator, reload/stop control, integrated progress line, compact bottom browser toolbar, and tab-count badge.
3. Applied reusable translucent `FrostedSurface` layers to the address bar and bottom navigation.
4. Enabled the Material 3 navigation drawer swipe interaction.
5. Added persistent accent HEX/RGB editor, custom font HEX/RGB editor, and automatic text contrast toggle.
6. Connected the glass transparency preference to the browser chrome.
7. Added WebView pause/resume handling when the host Activity leaves/returns to the foreground.
8. Updated version metadata to 1.5.0 and refreshed the GitHub Actions build workflow.
9. Reduced spacing and component sizing on the home, settings, and tab switcher screens.

## Known boundaries

- Build has not been executed in this packaging environment because Gradle and an Android SDK installation are not available here. GitHub Actions is configured to perform the full Android build.
- Translucent acrylic is used instead of live backdrop blur.
- Private WebView tabs do not have isolated cookies/storage profiles.
- Tracking protection remains a basic host blocklist, not a comprehensive ad-blocker.
