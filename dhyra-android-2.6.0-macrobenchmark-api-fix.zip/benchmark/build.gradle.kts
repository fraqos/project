import org.gradle.api.JavaVersion
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.test")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dhyra.browser.benchmark"
    compileSdk {
        version = release(37) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        minSdk = 26
        targetSdk = 36
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // Match the app module's bytecode baseline. Gradle runs on JDK 21 in CI,
    // but the Java compiler must not inherit the Android test plugin's default
    // target (11) while Kotlin implicitly targets the Gradle JDK (21).
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    targetProjectPath = ":app"
    experimentalProperties["android.experimental.self-instrumenting"] = true

    buildTypes {
        // This is a com.android.test module. It does not inherit the app module's
        // build types. Define the instrumentation variant directly instead of
        // looking up a release build type that may not exist in this module.
        create("benchmark") {
            // The test APK may be debuggable; the TARGET app variant remains
            // non-debuggable and profileable (configured in :app).
            isDebuggable = true
            // Keep dependency variant resolution aligned with release AARs.
            matchingFallbacks += listOf("release")
        }
    }
}

// Keep Kotlin bytecode aligned with compileOptions above and :app.
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // Macrobenchmark is a test-only library. The androidx.benchmark Gradle
    // plugin is for Microbenchmark modules and is intentionally not applied here.
    implementation("androidx.benchmark:benchmark-macro-junit4:1.5.0")
    implementation("androidx.test.ext:junit:1.3.0")
    implementation("androidx.test:runner:1.7.0")
    implementation("androidx.test.uiautomator:uiautomator:2.3.0")
}
