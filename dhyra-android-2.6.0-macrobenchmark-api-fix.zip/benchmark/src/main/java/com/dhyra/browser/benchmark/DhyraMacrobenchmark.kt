package com.dhyra.browser.benchmark

import androidx.benchmark.macro.FrameTimingMetric
import androidx.benchmark.macro.junit4.MacrobenchmarkRule
import androidx.benchmark.macro.StartupMode
import androidx.benchmark.macro.StartupTimingMetric
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Device-side benchmark suite. Use a physical device for representative performance measurements. */
@RunWith(AndroidJUnit4::class)
class DhyraMacrobenchmark {
    @get:Rule
    val benchmarkRule = MacrobenchmarkRule()

    // In Macrobenchmark 1.5.0, measureRepeated is a member of MacrobenchmarkRule.
    // Call it through this rule instance; no separate top-level function import is needed.

    @Test
    fun coldStartup() = benchmarkRule.measureRepeated(
        packageName = "com.dhyra.browser.benchmark",
        metrics = listOf(StartupTimingMetric()),
        iterations = 30,
        startupMode = StartupMode.COLD,
        setupBlock = { pressHome() }
    ) {
        startActivityAndWait()
    }

    @Test
    fun warmStartup() = benchmarkRule.measureRepeated(
        packageName = "com.dhyra.browser.benchmark",
        metrics = listOf(StartupTimingMetric()),
        iterations = 30,
        startupMode = StartupMode.WARM,
        setupBlock = {
            pressHome()
            startActivityAndWait()
            pressHome()
        }
    ) {
        startActivityAndWait()
    }

    @Test
    fun homeFrameTimingDuringSwipe() = benchmarkRule.measureRepeated(
        packageName = "com.dhyra.browser.benchmark",
        metrics = listOf(FrameTimingMetric()),
        iterations = 30,
        startupMode = StartupMode.COLD,
        setupBlock = { pressHome() }
    ) {
        startActivityAndWait()
        val centerX = device.displayWidth / 2
        val startY = (device.displayHeight * 0.78f).toInt()
        val endY = (device.displayHeight * 0.30f).toInt()
        repeat(3) { device.swipe(centerX, startY, centerX, endY, 18) }
    }
}
