# Macrobenchmark JVM target alignment

## Failure addressed

The CI failure reported `compileBenchmarkJavaWithJavac` with Java target 11 and `compileBenchmarkKotlin` with Kotlin target 21. The `:benchmark` Android test module had no explicit JVM bytecode target settings. With CI running Gradle on JDK 21, Kotlin inherited 21 while Android test Java compilation used its plugin default of 11.

## Correction

The `:benchmark` module now sets both sides explicitly to JVM 17:

- `android.compileOptions.sourceCompatibility = JavaVersion.VERSION_17`
- `android.compileOptions.targetCompatibility = JavaVersion.VERSION_17`
- `kotlin.compilerOptions.jvmTarget = JvmTarget.JVM_17`

This matches the existing `:app` module. CI still runs Gradle on JDK 21; this is intentional. The JDK used to execute Gradle is not the same setting as the bytecode target emitted by Java and Kotlin compilers.

## CI regression guard

`scripts/validate-ci-config.py` now fails early unless both `:benchmark` compiler settings are explicitly JVM 17. The workflow directly executes `:benchmark:compileBenchmarkJavaWithJavac` and `:benchmark:compileBenchmarkKotlin` before `:benchmark:assembleBenchmark`, so target mismatches are exposed at a dedicated step.

## Verification limits

Static source checks and workflow syntax checks can verify that both settings are present and aligned. Only a real Gradle run with the pinned AGP/Kotlin/Gradle dependencies can prove task configuration and compilation end-to-end.
