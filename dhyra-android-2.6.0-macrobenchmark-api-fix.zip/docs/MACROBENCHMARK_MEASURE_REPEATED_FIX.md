# Macrobenchmark `measureRepeated` Compile Fix

## Confirmed root cause

The benchmark source imported `androidx.benchmark.macro.junit4.measureRepeated` as a top-level symbol. That import is not part of the public Kotlin API for the project's pinned `androidx.benchmark:benchmark-macro-junit4:1.5.0` artifact.

In Macrobenchmark 1.5.0, `measureRepeated` is a public member function of `MacrobenchmarkRule`. The official API reference lists it under `MacrobenchmarkRule` public functions and its Kotlin sample calls `benchmarkRule.measureRepeated(...)`. The official sample imports `MacrobenchmarkRule` but does not import `measureRepeated` separately.

## Minimal correction

Removed the invalid import:

```kotlin
import androidx.benchmark.macro.junit4.measureRepeated
```

Kept the valid class import and the three member calls:

```kotlin
import androidx.benchmark.macro.junit4.MacrobenchmarkRule

val benchmarkRule = MacrobenchmarkRule()
benchmarkRule.measureRepeated(...)
```

No changes were made to the three benchmark methods, target package, startup modes, metrics, iteration count, benchmark dependency version, JVM targets, or Gradle task configuration.

## Dependency decision

Kept `androidx.benchmark:benchmark-macro-junit4:1.5.0`. The project uses the `com.android.test` plugin and places its instrumentation benchmark source under `benchmark/src/main/java`; using `implementation` in this test module matches AndroidX `com.android.test` Macrobenchmark modules. The compile log points at the invalid import, while `MacrobenchmarkRule`, `StartupMode`, `StartupTimingMetric`, and `FrameTimingMetric` are imported from the same already-resolved dependency.

## Regression guard

`scripts/check-compose-contracts.py` now verifies that:

- the `MacrobenchmarkRule` class import exists;
- no import line attempts to import `measureRepeated` as a top-level function;
- all three tests call `benchmarkRule.measureRepeated(...)`;
- the module continues to use `benchmark-macro-junit4:1.5.0`.

The existing GitHub Actions step `Validate source and AndroidX API contracts (including Macrobenchmark 1.5)` runs this script before Gradle compilation. A regression is therefore caught in the source-validation stage before `:benchmark:compileBenchmarkKotlin`.

## Local verification

- Source-contract checks: pass.
- CI toolchain preflight: pass.
- Kotlin syntax/signature fixture: pass against the documented member-function shape for `MacrobenchmarkRule.measureRepeated`.
- JavaScript regression tests: pass.
- XML/resource validation: pass.
- ZIP CRC and clean extraction: pass.

## Verification limitation

This packaging environment does not have the Android SDK, Gradle executable, Gradle wrapper JAR, or network access to fetch the Google Maven AAR / Gradle distribution. Therefore a full Android Gradle compile against the actual downloaded 1.5.0 artifact is not claimed as passed. GitHub Actions must still execute `:benchmark:compileBenchmarkKotlin` to confirm the complete toolchain build.
