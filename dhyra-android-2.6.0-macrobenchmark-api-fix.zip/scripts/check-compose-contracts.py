#!/usr/bin/env python3
"""Source-contract checks for dhyra 2.6.0 Stability, UI, localization and CI integration."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    file = ROOT / path
    if not file.is_file():
        raise SystemExit(f"Required source file is missing: {path}")
    return file.read_text(encoding="utf-8")

main = read("app/src/main/java/com/dhyra/browser/MainActivity.kt")
models = read("app/src/main/java/com/dhyra/browser/UiModels.kt")
home = read("app/src/main/java/com/dhyra/browser/ui/screens/HomeUi.kt")
settings = read("app/src/main/java/com/dhyra/browser/ui/screens/ScreensUi.kt")
settings_manager = read("app/src/main/java/com/dhyra/browser/core/settings/DhyraSettingsManager.kt")
theme = read("app/src/main/java/com/dhyra/browser/ui/theme/Theme.kt")
webview_policy = read("app/src/main/java/com/dhyra/browser/core/engine/DhyraWebViewController.kt")
controller = read("app/src/main/java/com/dhyra/browser/BrowserController.kt")
mark = read("app/src/main/java/com/dhyra/browser/ui/components/DhyraMark.kt")
build = read("app/build.gradle.kts")
manifest = read("app/src/main/AndroidManifest.xml")
workflow = read(".github/workflows/build.yml")
shields_engine = read("app/src/main/java/com/dhyra/browser/core/shields/ShieldsFilterEngine.kt")
shields_manager = read("app/src/main/java/com/dhyra/browser/core/shields/ShieldsFilterManager.kt")
shields_ui = read("app/src/main/java/com/dhyra/browser/ui/components/SheetsUi.kt")
shields_tests = read("app/src/test/java/com/dhyra/browser/ShieldsFilterEngineTest.kt")
judol_engine = read("app/src/main/java/com/dhyra/browser/core/shields/JudolIntelligence.kt")
judol_tests = read("app/src/test/java/com/dhyra/browser/JudolIntelligenceTest.kt")
strings_en = read("app/src/main/res/values-en/strings.xml")
strings_default = read("app/src/main/res/values/strings.xml")
strings_id = read("app/src/main/res/values-id/strings.xml")
locale_config = read("app/src/main/res/xml/locales_config.xml")
localized_text = read("app/src/main/java/com/dhyra/browser/ui/localization/LocalizedUiText.kt")
resolver_tests = read("app/src/test/java/com/dhyra/browser/BrowserAddressResolverTest.kt")
benchmark_source = read("benchmark/src/main/java/com/dhyra/browser/benchmark/DhyraMacrobenchmark.kt")
benchmark_gradle = read("benchmark/build.gradle.kts")

def xml(path: str):
    return ET.parse(ROOT / path).getroot()

checks = {
    "saved instance state is passed from Activity into Compose explicitly": (
        "val isColdLaunch = savedInstanceState == null" in main
        and "DhyraApplication(isColdLaunch = isColdLaunch)" in main
        and "private fun DhyraApplication(isColdLaunch: Boolean)" in main
        and "if (isColdLaunch)" in main
    ),
    "Composable body does not reference Activity savedInstanceState out of scope": (
        "if (savedInstanceState == null)" not in main
        and main.count("savedInstanceState") == 3
    ),
    "theme unit tests assert the current Light Dark and System default values": all(
        value in resolver_tests for value in (
            'normalizeTheme(null) == "System default"',
            'normalizeTheme("System") == "System default"',
            'normalizeTheme("Light") == "Light"',
            'normalizeTheme("Dark") == "Dark"',
        )
    ),
    "obsolete homepage RSS repository is not referenced by JVM tests": "HomeFeedRepository" not in resolver_tests,
    "homepage is native Compose and contains the three expected sections": all(
        item in home for item in ("R.string.search_or_enter_address", "R.string.speed_dial", "R.string.recently_visited")
    ),
    "homepage shows a compact dhyra brand header and cached site favicons": (
        "DhyraMark(size = 28.dp)" in home
        and "faviconForUrl(site.url)" in home
        and "faviconForUrl(entry.url)" in home
        and "faviconForUrl = controller::faviconForUrl" in main
    ),
    "favicon cache is bounded, host keyed and excludes space profile": (
        "faviconsByHost" in controller
        and "size > 64" in controller
        and "!isPrivate && icon != null" in controller
        and "override fun onReceivedIcon" in controller
    ),
    "cached site favicons are downscaled to limit bitmap memory": (
        "private fun compactFavicon(bitmap: Bitmap): Bitmap" in controller
        and "maxDimension <= 128" in controller
        and "Bitmap.createScaledBitmap(bitmap, width, height, true)" in controller
    ),
    "weather/news UI and feed service have been removed": (
        "weather" not in home.lower() and "news" not in home.lower()
        and not (ROOT / "app/src/main/java/com/dhyra/browser/core/home/HomeFeedRepository.kt").exists()
        and "HomeFeedRepository" not in main
    ),
    "recently visited deduplicates by normalized domain": all(
        value in home for value in ("dedupeRecentByDomain(recent)", "Uri.parse(entry.url).host", "www.", "removePrefix(prefix)")
    ),
    "recently visited is rendered in one single bordered card with row dividers": all(
        value in home for value in ("RoundedCornerShape(12.dp)", "BorderStroke(0.5.dp", "HorizontalDivider(", "uniqueRecent.take(5)")
    ),
    "six speed dial colors and labels are flat and rotated sequentially": all(
        value in home for value in (
            "0xFFE6F1FB", "0xFF0C447C", "0xFFFAECE7", "0xFF712B13",
            "0xFFF1EFE8", "0xFF444441", "0xFFEEEDFE", "0xFF3C3489",
            "0xFFE1F5EE", "0xFF085041", "0xFFFBEAF0", "0xFF72243E",
            "SPEED_DIAL_PALETTE[index % SPEED_DIAL_PALETTE.size]", ".size(54.dp)"
        )
    ),
    "speed dial dark colors use a separate high-contrast variant": "fun forMode(dark: Boolean)" in home and "Color(0xFF21364B)" in home,
    "homepage vertical rhythm and horizontal margins are 16/24dp": "padding(horizontal = 16.dp)" in home and "Arrangement.spacedBy(24.dp)" in home,
    "theme selector contains only Light, Dark and System default": 'THEME_OPTIONS = listOf("Light", "Dark", "System default")' in models,
    "theme normalization migrates previous System and AMOLED values": all(
        value in settings_manager for value in ('"Light" -> "Light"', '"Dark", "AMOLED" -> "Dark"', '"System", "System default"')
    ),
    "theme changes stay in Compose and do not recreate the Activity or destroy WebViews": (
        "DhyraTheme(state.theme)" in main
        and "Theme changes are rendered by DhyraTheme without AppCompatDelegate recreation" in main
        and "AppCompatDelegate.setDefaultNightMode" not in main
        and "animateColorAsState" in theme
        and "tween(180" in theme
    ),
    "Compose theme uses explicit Light Dark and system fallback": '"Light" -> false' in theme and '"Dark" -> true' in theme and 'isSystemInDarkTheme()' in theme,
    "Settings app language picker offers system English and Indonesian with search": all(
        value in settings for value in ("AppLanguageDialog", '"system" to stringResource', '"en" to stringResource', '"id" to stringResource', "R.string.search_languages")
    ),
    "application locale is set and auto-persisted via AppCompatDelegate": all(
        value in main for value in ("AppCompatDelegate.setApplicationLocales", "LocaleListCompat.forLanguageTags", 'key == "app_language"')
    ),
    "AppCompatActivity uses the backward-compatible locale storage service": "AppCompatActivity" in main and "AppLocalesMetadataHolderService" in manifest and "autoStoreLocales" in manifest,
    "supported language configuration is explicit": 'android:localeConfig="@xml/locales_config"' in manifest and '<locale android:name="en"' in locale_config and '<locale android:name="id"' in locale_config,
    "English and Indonesian string resource files are present": 'name="search_or_enter_address"' in strings_en and 'name="search_or_enter_address"' in strings_id and 'name="settings"' in strings_id and 'name="app_name">dhyra<' in strings_default,
    "Compose Text surfaces resolve localized Android resources": "localizeUiText(text)" in read("app/src/main/java/com/dhyra/browser/LocalizedText.kt") and "localizeUiText(text)" in read("app/src/main/java/com/dhyra/browser/ui/screens/LocalizedText.kt") and "localizeUiText(text)" in read("app/src/main/java/com/dhyra/browser/ui/components/LocalizedText.kt") and "localizePlainUiText" in main,
    "all private-mode user-facing labels keep space lowercase": not re.search(r'"[^"\\n]*\\b(?:SPACE|Space)\\b[^"\\n]*"', main + settings + home + read("app/src/main/java/com/dhyra/browser/ui/screens/TabsUi.kt") + read("app/src/main/java/com/dhyra/browser/ui/components/SheetsUi.kt")),
    "Settings sections are grouped into subtle cards": all(
        value in settings for value in ("private fun SettingsGroup", "RoundedCornerShape(12.dp)", "BorderStroke(0.5.dp", "padding(top = 24.dp")
    ),
    "overflow menu keeps Settings fixed outside the scroll list": (
        "LazyColumn(" in read("app/src/main/java/com/dhyra/browser/ui/components/SheetsUi.kt")
        and "MenuRow(Icons.Outlined.Settings, \"Settings\", emphasized = true)" in read("app/src/main/java/com/dhyra/browser/ui/components/SheetsUi.kt")
    ),
    "browser navigation, tabs, omnibox and menu use outlined icon variants": all(
        "Icons.Default." not in read(path) and "material.icons.filled" not in read(path)
        for path in (
            "app/src/main/java/com/dhyra/browser/ui/screens/BrowserUi.kt",
            "app/src/main/java/com/dhyra/browser/ui/screens/TabsUi.kt",
            "app/src/main/java/com/dhyra/browser/ui/components/OmniboxUi.kt",
            "app/src/main/java/com/dhyra/browser/ui/components/SheetsUi.kt",
        )
    ),
    "Settings uses outlined icons and the shared theme accent": all(
        value in settings for value in ("Icons.Outlined.Download", "Icons.Outlined.Search", "tint = cs.primary", "checkedThumbColor = cs.primary")
    ),
    "Settings rows have natural press feedback and switches do not double-toggle": (
        ".clickable(onClick = onClick)" in settings
        and ".toggleable(" in settings
        and "onValueChange = onChange" in settings
        and "onCheckedChange = null" in settings
        and "indication = null" not in settings
    ),
    "Settings category order places privacy directly after general": (
        settings.index('SettingsGroup("General"') < settings.index('SettingsGroup("Privacy and security"')
        < settings.index('SettingsGroup("Languages"')
    ),
    "theme is in General and language is a searchable Languages dialog": 'SettingRow(Icons.Outlined.Brightness6, "Theme"' in settings and "AppLanguageDialog(" in settings and 'SettingsGroup("Languages"' in settings,
    "logo is loaded from transparent PNG for startup": "dhyra_brand_art_transparent" in mark and "DhyraMark(size = 64.dp)" in main,
    "launcher art is transparent and density-aware": all(
        (ROOT / f"app/src/main/res/drawable-{density}/dhyra_launcher_foreground.png").is_file()
        for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi")
    ) and "<monochrome android:drawable=\"@drawable/dhyra_launcher_monochrome\"" in read("app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml"),
    "splash art is transparent and density-aware in day and night resources": all(
        (ROOT / f"app/src/main/res/drawable-{density}/dhyra_splash_logo.png").is_file()
        for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi")
    ) and all("@drawable/dhyra_splash_logo" in read(f"app/src/main/res/{folder}/styles.xml") for folder in ("values-v31", "values-night-v31")),
    "app uses the user logo as canonical About artwork": "dhyra_brand_art_transparent" in settings and "ContentScale.Fit" in settings,
    "light/dark brand colors have dedicated accessible variants": (
        "LightBrandViolet = Color(0xFF6F68C8)" in theme
        and "DarkBrandViolet = Color(0xFFAAA4FF)" in theme
        and "#6F68C8" in read("app/src/main/res/values/colors.xml")
        and "#AAA4FF" in read("app/src/main/res/values-night/colors.xml")
    ),
    "WebView uses normal cache and disables deprecated Web SQL Database": "cacheMode = if (isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT" in webview_policy and "databaseEnabled = false" in webview_policy and "domStorageEnabled = true" in webview_policy,
    "inactive WebView tabs receive onPause and selected tab resumes": "webViews[previousId]?.onPause()" in controller and "selected?.onResume()" in controller,
    "activity hardware acceleration remains enabled": 'android:hardwareAccelerated="true"' in manifest,
    "app version and build artifact are synchronized": 'versionName = "2.6.0"' in build and 'versionCode = 33' in build and "dhyra-v2.6.0.apk" in workflow,
    "release version omits debug suffix and shrinker remains enabled": 'versionNameSuffix = ""' in build and 'versionNameSuffix = "-debug"' in build and 'isMinifyEnabled = true' in build and 'isShrinkResources = true' in build,
    "Gradle wrapper is generated in real extracted project root": "Generate and verify Gradle Wrapper in the real dhyra project" in workflow and "gradle --no-daemon --stacktrace wrapper" in workflow and "TEMP_WRAPPER_DIR" not in workflow,
    "workflow accepts arbitrary source ZIP names and manual dispatch": "'*.zip'" in workflow and "'**/*.zip'" in workflow and "workflow_dispatch:" in workflow,
    "workflow extracts ZIP safely and finds Android root": all(
        value in workflow for value in ("zipfile.ZipFile", "archive_has_android_root", "AndroidManifest.xml", "Unsafe ZIP entry")
    ),
    "CI explicitly compiles Kotlin before tests lint and APK": all(task in workflow for task in (":app:compileDebugKotlin", ":app:compileDebugUnitTestKotlin", "testDebugUnitTest", "lintDebug", "assembleDebug")),
    "workflow uploads APK source archive and checksums": all(
        value in workflow for value in ("dhyra-source.zip", "SHA256SUMS.txt", "actions/upload-artifact@v7.0.2", "if-no-files-found: error")
    ),
    "release signing remains opt-in and secret-backed": all(
        value in workflow for value in ("DHYRA_RELEASE_KEYSTORE_BASE64", "DHYRA_RELEASE_STORE_PASSWORD", "DHYRA_RELEASE_KEY_ALIAS", "DHYRA_RELEASE_KEY_PASSWORD")
    ) and "DHYRA_RELEASE_STORE_FILE" in build,
    "ABP popup rules are scoped to the first popup document and regex filters use the bounded matcher": (
        "ResourceType.POPUP" in shields_engine
        and "isPopup: Boolean = false" in shields_engine
        and "popupTabIds.remove(id)" in controller
        and "popupTabIds.add(newId)" in controller
        and "popupOpenerUrls[newId]" in controller
        and "filteringPageUrl(sourcePageUrl, openerUrl, popupNavigation)" in controller
        and "fun filteringPageUrl(" in shields_engine
        and "if (popupBlocker || !isUserGesture) return false" in controller
        and "patternPart.startsWith('/') && patternPart.endsWith('/')" in shields_engine
        and "popupRulesOnlyApplyToTheFirstPopupDocumentAndRegexIsSupported" in shields_tests
    ),
    "Shields immutable engine snapshot is safely published across WebView request threads": "@Volatile private var shieldsFilterEngine" in controller,
    "Shields immutable engine snapshot uses exactly one non-repeatable Volatile annotation": (
        "@Volatile private var shieldsFilterEngine" in re.sub(r"\s+", " ", controller)
        and "@Volatile @Volatile private var shieldsFilterEngine" not in re.sub(r"\s+", " ", controller)
    ),
    "Popup opener context is cleared on tab release, controller teardown and non-HTTP navigation": all(
        value in controller for value in (
            "popupOpenerUrls.remove(tab.id)", "popupTabIds.clear()", "popupOpenerUrls.clear()",
            "isAboutBlankBootstrap", "popupOpenerUrls.remove(id)"
        )
    ),
    "Shields parser supports host/path anchors, wildcards, and ABP separator": all(
        value in shields_engine for value in ("startsWith(\"||\")", "globMatches", "pattern[p] == '*'", "pattern[p] == '^'")
    ),
    "Shields parser supports exceptions, resource types, third-party and domain scopes": all(
        value in shields_engine for value in ("exception", "includedTypes", "excludedTypes", "thirdParty", "domainScope", "domain=", "important")
    ),
    "Shields parser has generic-rule indexing and CSS cosmetic filters": all(
        value in shields_engine for value in ("genericByThreeCharKey", "genericByFourCharKey", "packChars", "cosmeticByDomain", "cosmeticCssFor", "MAX_COSMETIC_SELECTORS_PER_PAGE", "#@#")
    ),
    "Shields manager downloads EasyList, EasyPrivacy, Fanboy Annoyance and ABPindo over HTTPS": all(
        value in shields_manager for value in (
            "https://easylist.to/easylist/easylist.txt",
            "https://easylist.to/easylist/easyprivacy.txt",
            "https://secure.fanboy.co.nz/fanboy-annoyance.txt",
            "https://raw.githubusercontent.com/ABPindo/indonesianadblockrules/master/subscriptions/abpindo.txt",
            "HttpURLConnection",
        )
    ),
    "Filter updates are size-limited, validated and atomically stored": all(
        value in shields_manager for value in ("MAX_LIST_BYTES", "MIN_RULE_LINES", "[Adblock Plus", ".tmp", "Files.move", "ATOMIC_MOVE", "REPLACE_EXISTING", "READ_TIMEOUT_MS")
    ),
    "Automatic filter updates are restricted to unmetered networks and four-day cadence": all(
        value in shields_manager for value in ("NET_CAPABILITY_NOT_METERED", "UPDATE_INTERVAL_MILLIS", "updateIfDue")
    ),
    "Shields controller initializes its coroutine scope and request state before launching updates": (
        controller.index("private val shieldsUpdateScope") < controller.index("init {")
        and controller.index("private val pageUrls") < controller.index("init {")
        and controller.index("@Volatile var trackingProtection = true") < controller.index("init {")
        and "shieldsUpdateScope.launch" in controller
        and "catch (cancelled: CancellationException)" in controller
    ),
    "Shields request interception classifies resource type and page context": all(
        value in controller for value in (
            "classifyRequest(", "shieldsFilterEngine.shouldBlock(",
            "ShieldsFilterEngine.filteringPageUrl(sourcePageUrl, openerUrl, popupNavigation)",
            "popupOpenerUrls.remove(id)", "popupTabIds.remove(id)", "documentUrl = if (request.isForMainFrame) url else filterPageUrl"
        )
    ),
    "Shields injects document-start CSS and bounded destination content script": all(
        value in controller for value in (
            "cosmeticCssFor(pageUrl)", "ShieldsContentScript.build(",
            "WebViewCompat.addDocumentStartJavaScript", "WebViewFeature.DOCUMENT_START_SCRIPT",
            "applyCosmeticFilters(id, view, finalUrl, isPrivate)"
        )
    ),
    "Shields document-start content script is local-only and frame-batched": all(
        value in read("app/src/main/java/com/dhyra/browser/core/shields/ShieldsContentScript.kt")
        for value in ("MutationObserver", "requestAnimationFrame", "document.createTreeWalker", "document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT)", "data-dhyra-shields-hidden")
    ) and all(
        value not in read("app/src/main/java/com/dhyra/browser/core/shields/ShieldsContentScript.kt")
        for value in ("fetch(", "XMLHttpRequest", "sendBeacon(", "addJavascriptInterface")
    ),
    "Blocked main-frame navigation exposes continue-once and session whitelist actions": all(
        value in controller for value in (
            "dhyra-shields://continue", "dhyra-shields://whitelist",
            "bypassMainFrameOnce[tabId] = targetUrl", "overrides[host] = false",
            "wasRedirect = request.isRedirect", "hasUserGesture = request.hasGesture()"
        )
    ),
    "WebResourceRequest.hasGesture is invoked as a method, not a synthetic property": (
        controller.count("val hasUserGesture = request.hasGesture()") == 1
        and "val hasUserGesture = request.hasGesture\n" not in controller
    ),
    "Cosmetic rules prioritize site selectors and emit bounded valid CSS": (
        "MAX_COSMETIC_CSS_BYTES = 64 * 1024" in shields_engine
        and "pageRules.addAll(genericCosmeticRules)" in shields_engine
        and "selectors.append(declaration)" in shields_engine
        and "selector.none" in shields_engine
    ),
    "Blocked-request counter UI updates are coalesced during resource bursts": (
        "pendingShieldCounterUpdates" in controller
        and "SHIELDS_COUNTER_UI_INTERVAL_MS = 250L" in controller
        and "scheduleShieldCounterUiUpdate(id)" in controller
    ),
    "Shields sheet exposes rule counts, last update and manual list refresh": all(
        value in shields_ui for value in ("Protection lists", "networkRuleCount", "cosmeticRuleCount", "Update protection lists", "onUpdateLists")
    ),
    "Adblock unit tests cover resource type, exceptions, domain rules, wildcards and cosmetics": all(
        value in shields_tests for value in (
            "supportsResourceTypeOptionsAndNegations",
            "exceptionsOverrideBlockingRulesRegardlessOfOrder",
            "importantBlockingRulesCannotBeOverriddenByExceptions",
            "badfilterPreservesCaseForMatchCaseRules",
            "domainCosmeticRulesAreIndexedAndRespectSubdomains",
            "supportsCosmeticRulesAndDomainExceptions",
            "classifiesCommonWebViewRequestTypes",
            "cosmeticSelectorsAreCombinedIntoValidCssAndSupportChildCombinators",
            "siteSpecificCosmeticsArePrioritizedBeforeLargeGenericLists",
        )
    ),
    "App version and CI artifact names are synchronized for 2.6.0": (
        'versionName = "2.6.0"' in build and "versionCode = 33" in build and "dhyra-v2.6.0.apk" in workflow
    ),
    "renderer recovery cleans the failed WebView and rate-limits automatic reloads": (
        "onRenderProcessGone" in controller
        and "releaseAfterRendererGone" in controller
        and "RendererRecoveryPolicy" in controller
        and "loadInitialUrl = true" in controller
    ),
    "tab WebView limit adapts to device memory and evicts inactive LRU tabs": (
        "DhyraTabMemoryPolicy.maxLiveWebViews" in controller
        and "DhyraTabMemoryPolicy.evictionOrder" in controller
        and "TRIM_MEMORY_RUNNING_LOW" in controller
    ),
    "sensitive web permissions require secure origins": (
        "canRequestSensitiveWebFeature(request.origin?.toString())" in controller
        and "canRequestSensitiveWebFeature(origin)" in controller
    ),
    "frame timing is measured locally in debug builds": (
        "DhyraFrameMetricsMonitor" in main
        and "WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)" in main
        and "FrameMetrics.TOTAL_DURATION" in read("app/src/main/java/com/dhyra/browser/core/performance/DhyraFrameMetricsMonitor.kt")
    ),
    "macrobenchmark module provides startup and frame timing measurements": (
        ':benchmark' in read("settings.gradle.kts")
        and "StartupTimingMetric" in read("benchmark/src/main/java/com/dhyra/browser/benchmark/DhyraMacrobenchmark.kt")
        and "FrameTimingMetric" in read("benchmark/src/main/java/com/dhyra/browser/benchmark/DhyraMacrobenchmark.kt")
    ),
    "Macrobenchmark 1.5 uses MacrobenchmarkRule member measureRepeated without invalid top-level import": (
        "import androidx.benchmark.macro.junit4.MacrobenchmarkRule" in benchmark_source
        and not any(
            line.strip() == "import androidx.benchmark.macro.junit4.measureRepeated"
            for line in benchmark_source.splitlines()
        )
        and benchmark_source.count("benchmarkRule.measureRepeated(") == 3
        and 'androidx.benchmark:benchmark-macro-junit4:1.5.0' in benchmark_gradle
    ),
    "Macrobenchmark Java and Kotlin compile to the same JVM 17 bytecode target": all(
        value in read("benchmark/build.gradle.kts") for value in (
            "sourceCompatibility = JavaVersion.VERSION_17",
            "targetCompatibility = JavaVersion.VERSION_17",
            "jvmTarget.set(JvmTarget.JVM_17)",
        )
    ),
    "GitHub Actions offers optional physical-device Macrobenchmark execution": (
        "run_macrobenchmark" in workflow
        and "runs-on: [self-hosted, linux, android-physical]" in workflow
        and ":benchmark:connectedBenchmarkAndroidTest" in workflow
        and "ro.kernel.qemu" in workflow
        and "android.experimental.self-instrumenting" in read("benchmark/build.gradle.kts")
        and "androidx.profileinstaller:profileinstaller:1.4.1" in read("app/build.gradle.kts")
        and "<profileable android:shell=\"true\" />" in read("app/src/benchmark/AndroidManifest.xml")
    ),
    "ShieldsFilterEngineTest exposes runChecks for BrowserLogicChecks and invokes all JUnit tests": (
        "ShieldsFilterEngineTest().runChecks()" in read("app/src/test/java/com/dhyra/browser/BrowserLogicChecks.kt")
        and len(re.findall(r"(?m)^    @Test\s+    fun ([A-Za-z0-9_]+)\(", shields_tests)) >= 31
        and all(
            f"{name}()" in re.search(r"(?ms)^    fun runChecks\(\)\s*\{(.*?)^    \}", shields_tests).group(1)
            for name in re.findall(r"(?m)^    @Test\s+    fun ([A-Za-z0-9_]+)\(", shields_tests)
        )
    ),
    "ShieldsContentScriptTest is included in the standalone JVM regression runner": (
        "ShieldsContentScriptTest().runChecks()" in read("app/src/test/java/com/dhyra/browser/BrowserLogicChecks.kt")
        and "fun runChecks()" in read("app/src/test/java/com/dhyra/browser/ShieldsContentScriptTest.kt")
    ),
    "Judol intelligence blocks only high-confidence host signals and not ambiguous path-only terms": (
        "hasDomainAnchor && score >= blockThreshold" in judol_engine
        and "URL path/query context can raise REVIEW but never independently produce BLOCK" in judol_engine
        and "slot-ambiguous" in judol_engine
        and "toto" not in judol_engine.lower()
    ),
    "Judol allowlist overrides exact blocklist and heuristic matching": (
        "matchesDomain(host, allowedDomains)" in judol_engine
        and "matchesDomain(host, blockedDomains)" in judol_engine
        and judol_engine.index("allowedDomains)") < judol_engine.index("blockedDomains)")
    ),
    "Judol heuristic runs only for top-level navigation and has a user preference": (
        "request.isForMainFrame && siteJudolEnabled" in controller
        and "private fun judolEnabledForSite" in controller
        and "judolProtection = initialPreferences[JUDOL_PROTECTION_KEY] ?: true" in main
        and "Block high-confidence gambling sites" in shields_ui
    ),
    "Judol local domain files are bundled and no remote list URL is configured": (
        (ROOT / "app/src/main/assets/judol_domains.txt").is_file()
        and (ROOT / "app/src/main/assets/judol_allowlist.txt").is_file()
        and "https://" not in read("app/src/main/assets/judol_domains.txt")
    ),
    "Judol regression cases cover ambiguity, exact domain scope and IDN": all(
        case in judol_tests for case in (
            "ambiguousTermsDoNotBlockLegitimateDestinations",
            "urlPathAloneCannotCauseAutomaticBlock",
            "suffixLookalikesDoNotMatchCuratedDomainEntries",
            "parserAcceptsIdnDomainsAndRejectsInvalidHosts",
            "allowlistOverridesHeuristicsAndExactBlocklist",
        )
    ) and "JudolIntelligenceTest().runChecks()" in read("app/src/test/java/com/dhyra/browser/BrowserLogicChecks.kt"),
}

# Verify XML documents parse, plus the theme/splash resources refer to existing colors.
xml_files = [
    "app/src/main/AndroidManifest.xml",
    "app/src/main/res/values/strings.xml",
    "app/src/main/res/values-en/strings.xml",
    "app/src/main/res/values-id/strings.xml",
    "app/src/main/res/values-en/strings.xml",
    "app/src/main/res/xml/locales_config.xml",
    "app/src/main/res/values/styles.xml",
    "app/src/main/res/values-night/styles.xml",
    "app/src/main/res/values-v31/styles.xml",
    "app/src/main/res/values-night-v31/styles.xml",
    "app/src/main/res/values-v27/styles.xml",
    "app/src/main/res/values-v28/styles.xml",
    "app/src/main/res/values-night-v27/styles.xml",
    "app/src/main/res/values-night-v28/styles.xml",
]
for path in xml_files:
    try:
        xml(path)
        checks[f"XML parses: {path}"] = True
    except ET.ParseError as error:
        checks[f"XML parses: {path}"] = False
        print(f"XML parse error in {path}: {error}", file=sys.stderr)

# Keep the same resource keys in the shipped English and Indonesian catalogues.
try:
    resource_sets = []
    for folder in ("values", "values-en", "values-id"):
        resource_sets.append({item.attrib["name"] for item in xml(f"app/src/main/res/{folder}/strings.xml").findall("string")})
    checks["string resource key parity across default/en/id"] = resource_sets[0] == resource_sets[1] == resource_sets[2]
except (KeyError, ET.ParseError):
    checks["string resource key parity across default/en/id"] = False

# PNG color type 6 is RGBA, so the outer image canvas really is transparent.
for relative in (
    "app/src/main/res/drawable-nodpi/dhyra_brand_art_transparent.png",
    "app/src/main/res/drawable-nodpi/dhyra_launcher_monochrome.png",
    "app/src/main/res/drawable-xxxhdpi/dhyra_launcher_foreground.png",
    "app/src/main/res/drawable-xxxhdpi/dhyra_splash_logo.png",
):
    file = ROOT / relative
    data = file.read_bytes() if file.is_file() else b""
    checks[f"transparent PNG asset: {relative}"] = len(data) > 32 and data[:8] == b"\x89PNG\r\n\x1a\n" and data[25] == 6

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(("PASS" if passed else "FAIL") + ": " + name)
if failed:
    print("Source contract validation failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
print(f"All {len(checks)} source contract checks passed.")
