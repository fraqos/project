#!/usr/bin/env python3
"""Fail-fast check that the CI workflow matches the actual dhyra Gradle project."""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path.cwd()


def fail(message: str) -> None:
    raise SystemExit(f"CI preflight failed: {message}")


def read_required(path: Path) -> str:
    if not path.is_file():
        fail(f"required project file is missing: {path.relative_to(ROOT)}")
    return path.read_text(encoding="utf-8")


def match(pattern: str, content: str, label: str) -> str:
    found = re.search(pattern, content, re.MULTILINE | re.DOTALL)
    if not found:
        fail(f"could not read {label} from project/workflow")
    return found.group(1)


settings = read_required(ROOT / "settings.gradle.kts")
root_build = read_required(ROOT / "build.gradle.kts")
app_build = read_required(ROOT / "app/build.gradle.kts")
wrapper = read_required(ROOT / "gradle/wrapper/gradle-wrapper.properties")

workflow_path = ROOT / ".github/workflows/build.yml"
if not workflow_path.is_file():
    workflow_path = ROOT / ".github/workflows/main.yml"
workflow = read_required(workflow_path)

if '":app"' not in settings:
    fail("settings.gradle.kts does not include the expected :app module")

agp = match(r'id\("com\.android\.application"\)\s+version\s+"([0-9.]+)"', root_build, "AGP version")
kotlin_android = match(r'id\("org\.jetbrains\.kotlin\.android"\)\s+version\s+"([0-9.]+)"', root_build, "Kotlin Android plugin version")
kotlin_compose = match(r'id\("org\.jetbrains\.kotlin\.plugin\.compose"\)\s+version\s+"([0-9.]+)"', root_build, "Kotlin Compose plugin version")
if kotlin_android != kotlin_compose:
    fail(f"Kotlin plugin versions differ: android={kotlin_android}, compose={kotlin_compose}")

gradle_version = match(r'gradleVersion\s*=\s*"([0-9.]+)"', root_build, "Gradle wrapper version")
wrapper_url_version = match(r'distributionUrl=.*?gradle-([0-9.]+)-bin\.zip', wrapper, "wrapper distribution version")
if wrapper_url_version != gradle_version:
    fail(f"wrapper properties use Gradle {wrapper_url_version}, root build config uses {gradle_version}")

version_name = match(r'versionName\s*=\s*"([^"]+)"', app_build, "application versionName")
version_code = match(r'versionCode\s*=\s*(\d+)', app_build, "application versionCode")
compile_api_match = re.search(
    r'version\s*=\s*release\((\d+)\)\s*\{\s*minorApiLevel\s*=\s*(\d+)',
    app_build,
    re.MULTILINE | re.DOTALL,
)
if not compile_api_match:
    fail("could not read compileSdk release/minor API from app/build.gradle.kts")
compile_sdk = f"{compile_api_match.group(1)}.{compile_api_match.group(2)}"

# Read the versions actually configured by the workflow actions/SDK install steps.
workflow_gradle = match(r"gradle-version:\s*['\"]([^'\"]+)['\"]", workflow, "setup-gradle version")
workflow_wrapper_gradle = match(r"GRADLE_VERSION='([0-9.]+)'", workflow, "wrapper task Gradle version")
workflow_jdk = match(r"java-version:\s*['\"]([^'\"]+)['\"]", workflow, "setup-java version")
workflow_api = match(r"['\"]platforms;android-([0-9]+\.[0-9]+)['\"]", workflow, "Android SDK platform package")
workflow_build_tools = match(r"['\"]build-tools;([0-9.]+)['\"]", workflow, "Android Build Tools package")

expected = {
    "Gradle (setup action)": (gradle_version, workflow_gradle),
    "Gradle (wrapper task)": (gradle_version, workflow_wrapper_gradle),
    "compileSdk": (compile_sdk, workflow_api),
}
for label, (project_value, workflow_value) in expected.items():
    if project_value != workflow_value:
        fail(f"{label} mismatch: project={project_value}, workflow={workflow_value}")

if workflow_jdk != "21":
    fail(f"CI JDK is {workflow_jdk}; this project workflow is validated for JDK 21")
if workflow_build_tools != "36.0.0":
    fail(f"CI Build Tools is {workflow_build_tools}; AGP {agp} defaults to 36.0.0 for this project")
if agp != "9.3.1":
    fail(f"AGP is {agp}; API {compile_sdk} workflow compatibility has been checked for AGP 9.3.1")
if kotlin_android != "2.4.21":
    fail(f"Kotlin Gradle Plugin is {kotlin_android}; this workflow's compatibility check is for 2.4.21")

# Pin the hosted runner image; ubuntu-latest is intentionally not used because its
# SDK/toolchain image can change independently from the project configuration.
if "runs-on: ubuntu-24.04" not in workflow:
    fail("build job must use the pinned ubuntu-24.04 hosted runner")

# Validate action references which have previously caused avoidable workflow failures.
if "actions/download-artifact@v8.0.2" not in workflow:
    fail("download-artifact must use the verified v8.0.2 release (v7.0.2 does not exist)")
if "actions/download-artifact@v7.0.2" in workflow:
    fail("download-artifact v7.0.2 is invalid; use v8.0.2")
if "github.run_attempt" not in workflow:
    fail("artifact names must include github.run_attempt to avoid collisions when a job is rerun")
if "'*.zip'" not in workflow or "'**/*.zip'" not in workflow:
    fail("push trigger must include root and nested project ZIP paths")
if "actions/upload-artifact@v7.0.2" not in workflow:
    fail("upload-artifact must use the verified v7.0.2 release")
if "actions/checkout@v7.0.1" not in workflow:
    fail("checkout must use the verified v7.0.1 release")
if "actions/setup-java@v6.3.0" not in workflow:
    fail("setup-java must use the verified v6.3.0 release")
if "gradle/actions/setup-gradle@v6.4.1" not in workflow:
    fail("setup-gradle must use the verified v6.4.1 release")
if "android-actions/setup-android@v4.0.4" not in workflow:
    fail("setup-android must use the verified v4.0.4 release")

# Run `help` once before the task-specific steps. Gradle configures all included
# projects during this phase, so missing build types are reported immediately.
if "Validate Gradle project configuration" not in workflow or "./gradlew --no-daemon --stacktrace help" not in workflow:
    fail("workflow must validate all project Gradle configuration before compiling app tasks")

# Keep app-only Gradle tasks qualified: the :benchmark module has its own variants.
for task in (":app:testDebugUnitTest", ":app:lintDebug", ":app:assembleDebug"):
    if task not in workflow:
        fail(f"app Gradle task must be module-qualified: {task}")

# Confirm the CI does not silently publish an APK under a stale version label.
if f"dhyra-v{version_name}.apk" not in workflow:
    fail(f"debug APK output name does not match app versionName {version_name}")
if f"dhyra-v{version_name}-release.apk" not in workflow:
    fail(f"signed release APK name does not match app versionName {version_name}")

# The distribution digest in the wrapper file and the value passed to the wrapper task must agree.
wrapper_sha = match(r'distributionSha256Sum=([0-9a-f]{64})', wrapper, "Gradle distribution SHA-256")
workflow_sha = match(r"EXPECTED_GRADLE_SHA256='([0-9a-f]{64})'", workflow, "workflow Gradle SHA-256 pin")
if wrapper_sha != workflow_sha:
    fail("Gradle distribution SHA-256 differs between gradle-wrapper.properties and workflow")

benchmark_build = read_required(ROOT / "benchmark/build.gradle.kts")
benchmark_test = read_required(ROOT / "benchmark/src/main/java/com/dhyra/browser/benchmark/DhyraMacrobenchmark.kt")
if 'targetProjectPath = ":app"' not in benchmark_build or "StartupTimingMetric" not in benchmark_test or "FrameTimingMetric" not in benchmark_test:
    fail("Macrobenchmark module is missing app target/startup/frame timing tests")

# Android Java compilation and Kotlin compilation must emit the same bytecode.
# CI runs Gradle on JDK 21, but the app's supported build baseline is JVM 17;
# never let the :benchmark module inherit javac=11 and Kotlin=21 defaults.
benchmark_java_17 = all(
    token in benchmark_build for token in (
        "compileOptions {",
        "sourceCompatibility = JavaVersion.VERSION_17",
        "targetCompatibility = JavaVersion.VERSION_17",
    )
)
benchmark_kotlin_17 = all(
    token in benchmark_build for token in (
        "kotlin {",
        "compilerOptions {",
        "jvmTarget.set(JvmTarget.JVM_17)",
    )
)
if not benchmark_java_17 or not benchmark_kotlin_17:
    fail(":benchmark Java and Kotlin compiler targets must both be explicitly set to JVM 17")
if "import org.gradle.api.JavaVersion" not in benchmark_build or "import org.jetbrains.kotlin.gradle.dsl.JvmTarget" not in benchmark_build:
    fail(":benchmark must import typed JavaVersion and Kotlin JvmTarget values")
app_jvm_17 = all(
    token in app_build for token in (
        "sourceCompatibility = JavaVersion.VERSION_17",
        "targetCompatibility = JavaVersion.VERSION_17",
        "jvmTarget.set(JvmTarget.JVM_17)",
    )
)
if not app_jvm_17:
    fail(":app JVM target changed; review and align the benchmark Java/Kotlin targets")
if (
    ":benchmark:compileBenchmarkJavaWithJavac" not in workflow
    or ":benchmark:compileBenchmarkKotlin" not in workflow
    or "Verify aligned Macrobenchmark Java and Kotlin JVM 17 targets" not in workflow
):
    fail("workflow must compile both benchmark language tasks in a dedicated JVM-target validation step")

# The :benchmark module applies com.android.test. Its build types are independent
# from :app; do not read :app's release build type from this module. The app's
# benchmark target variant separately inherits the app release configuration.
if 'initWith(getByName("release"))' in benchmark_build:
    fail(":benchmark must not inherit a release build type that is not declared in the test module")
if 'id("androidx.benchmark")' in benchmark_build:
    fail(":benchmark is a Macrobenchmark module; remove the Microbenchmark Gradle plugin")
if 'id("androidx.benchmark")' in root_build:
    fail("root build still resolves the unnecessary androidx.benchmark Microbenchmark Gradle plugin")
if 'create("benchmark")' not in benchmark_build or "isDebuggable = true" not in benchmark_build:
    fail(":benchmark must define its own debuggable benchmark instrumentation variant")
if 'signingConfigs.getByName("debug")' in benchmark_build:
    fail(":benchmark should use the com.android.test module's default test APK signing configuration")
if 'create("benchmark")' not in app_build or 'initWith(getByName("release"))' not in app_build:
    fail(":app benchmark variant must inherit the app's declared release build type")
if not re.search(r'buildTypes\s*\{[\s\S]*?\brelease\s*\{', app_build):
    fail(":app must explicitly declare its release build type")
if (
    "run_macrobenchmark" not in workflow
    or "runs-on: [self-hosted, linux, android-physical]" not in workflow
    or ":benchmark:connectedBenchmarkAndroidTest" not in workflow
    or "ro.kernel.qemu" not in workflow
):
    fail("workflow is missing the opt-in physical-device Macrobenchmark path")
if "android.experimental.self-instrumenting" not in benchmark_build or 'create("benchmark")' not in benchmark_build:
    fail("Macrobenchmark module is not configured for the benchmark build variant")
if 'androidx.profileinstaller:profileinstaller:1.4.1' not in read_required(ROOT / "app/build.gradle.kts"):
    fail("app is missing ProfileInstaller for Macrobenchmark trace/profile support")
if not (ROOT / "app/src/benchmark/AndroidManifest.xml").is_file():
    fail("benchmark variant is missing its profileable manifest overlay")

for task in (
    ":app:compileDebugKotlin", ":app:compileDebugUnitTestKotlin", ":app:testDebugUnitTest",
    ":app:lintDebug", ":app:assembleDebug", ":app:assembleRelease", ":app:bundleRelease",
    ":benchmark:compileBenchmarkJavaWithJavac", ":benchmark:compileBenchmarkKotlin",
    ":benchmark:assembleBenchmark"
):
    if task not in workflow:
        fail(f"required CI task is missing: {task}")

print("CI preflight: PASS")
print(f"  App: dhyra {version_name} (versionCode {version_code})")
print(f"  AGP: {agp}; Kotlin: {kotlin_android}; Gradle: {gradle_version}")
print(f"  JDK: {workflow_jdk}; compileSdk: {compile_sdk}; Build Tools: {workflow_build_tools}")
print("  App JVM bytecode target: Java 17 / Kotlin 17")
print("  Macrobenchmark JVM bytecode target: Java 17 / Kotlin 17")
print("  CI compile/test/lint/debug APK + Macrobenchmark assemble tasks: present")
print("  Optional Macrobenchmark: self-hosted physical Android 14+ device")
print("  Wrapper distribution URL and SHA-256: consistent")
