# DHYRA Browser v2.1.0 — CI repair

## Applied
- Removed the duplicate `android:windowLightNavigationBar` item from `Theme.Dhyra` in `app/src/main/res/values/styles.xml`. The style retains one declaration.
- Added an always-run GitHub Actions artifact step for Android Lint HTML/XML reports, so subsequent lint findings can be inspected without relying only on truncated console output.
- Kept `abortOnError = true`; lint findings are not hidden or suppressed.

## Validation performed here
- Parsed every XML file in the project with an XML parser.
- Checked style item names for duplicates.
- Confirmed `Theme.Dhyra` now contains exactly one `android:windowLightNavigationBar` declaration.

## Not claimed
Android Gradle compilation, Android Lint execution, APK packaging, emulator testing, and device installation have not been run in this environment. A green GitHub Actions run is still required to verify those steps.
