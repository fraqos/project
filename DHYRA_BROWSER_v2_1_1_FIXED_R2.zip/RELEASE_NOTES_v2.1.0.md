# DHYRA Browser 2.1.0 — Premium Evolution

## Added
- Persistent Quick Access shortcuts on the start page, with add, remove, and move controls.
- Live date/time greeting on the start page.
- Top or bottom address-bar placement.
- OLED pure-black theme option.
- Optional shared WebView data clearing when the Activity is explicitly closed.
- Opaque custom HEX sidebar color.
- Separate controls for ad/tracker filtering, gambling-host filtering, JavaScript, and data saver.
- Real-time in-process blocked-request counters in the address bar and Privacy settings.
- Brave and Qwant search-engine endpoints.
- Debug and unsigned release APK artifacts in GitHub Actions.

## Improved
- WebView hardware layer configuration and reduced overscroll glow.
- Popup-window creation follows the popup-blocker preference.
- Private tabs avoid persisted history/session entries, use no-cache mode, reject third-party cookies, and disable DOM/database storage.
- Cleartext HTTP is no longer globally enabled by the Android application manifest.
- Request filtering is extracted into a deterministic, unit-testable host policy.

## Known limitations (must not be represented as complete browser-grade guarantees)
- The built-in hostname filter is not a full EasyList/uBlock filter engine and can miss first-party ads, cosmetic ads, scripts served from first-party domains, and obfuscated redirects.
- WebView request interception does not cover every browser/network API or service-worker/WebSocket flow.
- Android System WebView shares first-party cookie storage between regular and private WebViews. Full private-profile isolation requires a separate isolated engine/profile architecture.
- Data saver disables automatic image loading and prefers cache; it does not proxy/compress traffic.
- Session protection counters are process-local and reset after process death.
- Release APK is unsigned and must be signed by the distributor.

## Validation status
- ZIP structure and Kotlin source syntax scan: completed.
- Standalone JVM compilation and execution of `BrowserProtectionPolicy`: completed.
- Android Gradle build, Android Lint, emulator/device tests, and APK install test: not run in this environment because Gradle/Android SDK artifacts are unavailable. GitHub Actions is configured to perform these checks.
