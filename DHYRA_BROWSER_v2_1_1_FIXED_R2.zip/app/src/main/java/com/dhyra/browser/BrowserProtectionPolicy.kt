package com.dhyra.browser

/** Deterministic host-level request filtering. This is intentionally not advertised as EasyList. */
object BrowserProtectionPolicy {
    enum class BlockReason { AD, TRACKER, GAMBLING_HOST }

    private val advertisingHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "adsystem.com", "taboola.com",
        "outbrain.com", "popads.net", "propellerads.com", "adsterra.com",
        "exoclick.com", "trafficjunky.net"
    )
    private val trackingHosts = setOf(
        "scorecardresearch.com", "quantserve.com", "hotjar.com", "connect.facebook.net",
        "google-analytics.com", "analytics.google.com", "segment.io", "mixpanel.com", "clarity.ms"
    )
    private val gamblingLabels = setOf("slot", "gacor", "casino", "togel", "judol", "poker", "bet")

    fun classify(hostname: String?): BlockReason? {
        val host = hostname?.trim()?.lowercase()?.trim('.')?.takeIf { it.isNotBlank() } ?: return null
        if (advertisingHosts.any { host == it || host.endsWith(".$it") }) return BlockReason.AD
        if (trackingHosts.any { host == it || host.endsWith(".$it") }) return BlockReason.TRACKER
        // Match DNS labels, not URL paths or arbitrary substrings in page content.
        if (host.split('.').any { label ->
                gamblingLabels.any { keyword ->
                    if (keyword == "bet") label == keyword || label.startsWith("bet-") || label.startsWith("bet") && label.length > 3 && label[3].isDigit()
                    else label.contains(keyword)
                }
            }) return BlockReason.GAMBLING_HOST
        return null
    }
}
