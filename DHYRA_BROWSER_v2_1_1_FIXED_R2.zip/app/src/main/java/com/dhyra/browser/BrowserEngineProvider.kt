package com.dhyra.browser

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView

/** Configuration passed across the engine boundary. Extend this instead of coupling UI to WebView. */
data class BrowserEngineConfiguration(
    val trackingProtection: Boolean,
    val popupBlocker: Boolean,
    val privateTab: Boolean,
    val requestDesktopSite: Boolean,
    val javascriptEnabled: Boolean = true,
    val dataSaverEnabled: Boolean = false
)

/**
 * Rendering-engine boundary. The current production provider is Android System WebView;
 * a future GeckoView/Chromium provider can implement this contract without changing Compose UI.
 */
interface BrowserEngineProvider {
    val id: String
    val displayName: String
    fun configure(view: WebView, context: Context, configuration: BrowserEngineConfiguration)
}

class AndroidSystemWebViewProvider : BrowserEngineProvider {
    override val id: String = "android-system-webview"
    override val displayName: String = "Android System WebView"

    override fun configure(view: WebView, context: Context, configuration: BrowserEngineConfiguration) {
        view.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        view.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        view.settings.apply {
            javaScriptEnabled = configuration.javascriptEnabled
            domStorageEnabled = !configuration.privateTab
            databaseEnabled = !configuration.privateTab
            setGeolocationEnabled(true)
            loadsImagesAutomatically = !configuration.dataSaverEnabled
            javaScriptCanOpenWindowsAutomatically = !configuration.popupBlocker
            setSupportMultipleWindows(!configuration.popupBlocker)
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = when {
                configuration.privateTab -> WebSettings.LOAD_NO_CACHE
                configuration.dataSaverEnabled -> WebSettings.LOAD_CACHE_ELSE_NETWORK
                else -> WebSettings.LOAD_DEFAULT
            }
            safeBrowsingEnabled = true
            useWideViewPort = configuration.requestDesktopSite
            loadWithOverviewMode = configuration.requestDesktopSite
            val systemUserAgent = WebSettings.getDefaultUserAgent(context)
            userAgentString = if (configuration.requestDesktopSite) {
                systemUserAgent
                    .replace(Regex("\\(Linux; Android [^)]*\\)"), "(X11; Linux x86_64)")
                    .replace("; wv", "")
                    .replace(" Version/4.0", "")
                    .replace(" Mobile", "")
            } else {
                systemUserAgent
            }
        }
        // Private tabs reject third-party cookies and do not persist DOM/database storage.
        // Android System WebView still shares first-party cookie storage across WebViews.
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, !configuration.trackingProtection && !configuration.privateTab)
    }
}
