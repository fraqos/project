package com.dhyra.browser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BrowserAdaptivePolicyTest {
    @Test fun windowClassesUseAvailableWidthBreakpoints() {
        assertEquals(DhyraWindowClass.COMPACT, windowClassForWidth(390))
        assertEquals(DhyraWindowClass.MEDIUM, windowClassForWidth(720))
        assertEquals(DhyraWindowClass.EXPANDED, windowClassForWidth(900))
    }

    @Test fun desktopPolicyAutoSelectsTabletAndExpandedWindows() {
        assertFalse(resolveDesktopRequest(DesktopPolicy.AUTOMATIC, DhyraWindowClass.COMPACT, null, null))
        assertTrue(resolveDesktopRequest(DesktopPolicy.AUTOMATIC, DhyraWindowClass.MEDIUM, null, null))
        assertTrue(resolveDesktopRequest(DesktopPolicy.AUTOMATIC, DhyraWindowClass.EXPANDED, null, null))
    }

    @Test fun perSiteAndPerTabOverridesTakePriority() {
        assertTrue(resolveDesktopRequest(DesktopPolicy.MOBILE, DhyraWindowClass.COMPACT, null, true))
        assertFalse(resolveDesktopRequest(DesktopPolicy.DESKTOP, DhyraWindowClass.EXPANDED, false, true))
        assertTrue(resolveDesktopRequest(DesktopPolicy.MOBILE, DhyraWindowClass.COMPACT, true, false))
    }

    @Test fun storedModeDefaultsToAutomatic() {
        assertEquals(DesktopPolicy.AUTOMATIC, desktopPolicyFromStored(null))
        assertEquals(DesktopPolicy.DESKTOP, desktopPolicyFromStored("Desktop"))
        assertEquals(DesktopPolicy.MOBILE, desktopPolicyFromStored("mobile"))
    }

    @Test fun protectionPolicyMatchesKnownAdHostsAndSubdomains() {
        assertEquals(BrowserProtectionPolicy.BlockReason.AD, BrowserProtectionPolicy.classify("page.doubleclick.net"))
        assertEquals(BrowserProtectionPolicy.BlockReason.AD, BrowserProtectionPolicy.classify("googlesyndication.com"))
        assertEquals(BrowserProtectionPolicy.BlockReason.TRACKER, BrowserProtectionPolicy.classify("analytics.google.com"))
        assertEquals(null, BrowserProtectionPolicy.classify("example.com"))
    }

    @Test fun judolPolicyMatchesGamblingDnsLabelsOnly() {
        assertEquals(BrowserProtectionPolicy.BlockReason.GAMBLING_HOST, BrowserProtectionPolicy.classify("slot-gacor.example"))
        assertEquals(BrowserProtectionPolicy.BlockReason.GAMBLING_HOST, BrowserProtectionPolicy.classify("casino.example"))
        assertEquals(null, BrowserProtectionPolicy.classify("example.com"))
        assertEquals(null, BrowserProtectionPolicy.classify("example.com"))
        assertEquals(null, BrowserProtectionPolicy.classify("alphabet.com"))
    }

    @Test fun scoreGradesUseExplicitBoundaries() {
        assertEquals("A", gradeFromScore(90))
        assertEquals("B", gradeFromScore(80))
        assertEquals("C", gradeFromScore(70))
        assertEquals("D", gradeFromScore(60))
        assertEquals("F", gradeFromScore(59))
    }
}
