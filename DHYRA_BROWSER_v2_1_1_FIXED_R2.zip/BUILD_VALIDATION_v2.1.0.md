# Build validation — DHYRA Browser 2.1.0

- `versionName`: `2.1.0`
- `versionCode`: `15`
- JDK: 17
- Android SDK: 35
- Gradle: 8.7
- Workflow tasks: `testDebugUnitTest`, `lintDebug`, `:app:assembleDebug`, `:app:assembleRelease`
- Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
- Unsigned release APK: `app/build/outputs/apk/release/app-release-unsigned.apk`
- GitHub Actions artifact: `DHYRA-BROWSER-v2.1.0-android-apks`

## Local validation in this editing environment

- Source ZIP extracted successfully and the full project tree was retained.
- Kotlin compiler syntax scan: no parser/syntax diagnostics found. This scan is not an Android compilation because Android/Compose/Gradle dependencies are not installed.
- `BrowserProtectionPolicy.kt` compiled with the standalone Kotlin compiler and representative host classification cases executed successfully.
- Android Gradle tasks, lint, emulator/device runtime, WebView behavior, and APK packaging were not run because this environment has no Gradle distribution, wrapper JAR, or Android SDK installation.

A successful GitHub Actions run is still required before calling the Android build verified. The release APK is unsigned and must be signed with the distributor's key.
