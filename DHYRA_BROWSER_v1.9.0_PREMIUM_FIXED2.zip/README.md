# DHYRA Browser — Android v1.9.0 Premium Edition

**A Beautiful, Powerful & Private Browsing Experience.**

DHYRA is an Android browser built with Kotlin, Jetpack Compose, Preferences DataStore, Android DownloadManager, and an engine-provider boundary. The active rendering engine is **Android System WebView (Chromium-based)**. DHYRA's own layer manages the browser interface, tabs, navigation, settings, adaptive presentation, and native Android integrations. This is not an independent Chromium fork and does not claim to own the web rendering engine.

## v1.9.0 changes

- Refined the home experience with a branded welcome panel, calmer gradient treatment, clearer visual hierarchy, and a more prominent search field.
- Improved spacing, typography, border contrast, and adaptive gutters across the home experience while retaining all existing navigation actions.
- Expanded centralized design tokens for brand accent, status colors, content width, and reusable component sizing.
- Updated app version metadata to 1.9.0 (versionCode 13) and aligned GitHub Actions validation and artifact naming.
- Added release notes and a clearer GitHub upload/build handoff for this iteration.

- Added `BrowserEngineProvider` and `AndroidSystemWebViewProvider` as a provider configuration seam. Android System WebView is the only implemented provider in this build; GeckoView/Chromium adapters are not included. The controller still uses WebView-specific lifecycle/callback surfaces, so an alternate engine would need a proper session adapter and controller migration—not just a one-line provider swap.
- Added adaptive window classes based on available app-window width: compact (<600 dp), medium (600–839 dp), and expanded (>=840 dp). This uses the current window configuration, so rotation and supported multi-window resizing can update the layout.
- Added Auto / Mobile / Desktop website display policy. Auto requests a desktop layout when the app window is medium or expanded (>=600 dp); Mobile and Desktop are global policies.
- Added per-tab desktop-site override and persistent per-site desktop-site preferences, accessible from the browser menu. Changing a global/tab/site website mode reloads the active page so the new User-Agent and viewport settings take effect; unsaved website form content may therefore be lost on that reload. Cookies and the current WebView storage profile are not intentionally cleared by this operation.
- Added an expanded-window horizontal tab strip and desktop-style address toolbar. Compact windows retain the mobile bottom navigation bar.
- Added the AndroidX SplashScreen API with the DHYRA launcher mark and a short exit fade/scale; it does not impose an artificial loading delay.
- Added diagnostics snapshots for measured theme text/background contrast, app-window dimensions, density, Android memory class, currently available system RAM, low-memory status, CPU logical core count, process PSS, active tab count, and WebView provider/version.
- Added diagnostic grades only for measured theme contrast, device capability signals, and point-in-time browser runtime health. Web-content compatibility and global Compose overflow/accessibility scans explicitly remain ungraded because no controlled benchmark/scanner is integrated.
- Added Auto Fix for DHYRA's internal automatic text-contrast preference, manual Settings entry, restore appearance defaults, and a local rolling history of up to 20 diagnostic snapshots.
- Added unit tests for adaptive breakpoints, desktop policy precedence, stored-mode parsing, and score-grade boundaries.
- Corrected Follow System theme behavior so the System option now follows Android's active system theme rather than being overridden by the selected ambient mood.
- Updated app metadata and GitHub Actions validation/artifact labels to v1.9.0.

## Existing functionality retained

- Multiple retained WebView tabs, tab search, duplicate/close actions, background tab creation, and URL-based regular-session restore.
- Back, forward, reload, stop, page find, long-press link actions, fullscreen custom views, file chooser, camera/microphone runtime permission handling, and geolocation permission callbacks.
- Local history and bookmarks stored in Preferences DataStore, searchable lists, and item removal.
- Search-engine selection for Google, Bing, DuckDuckGo, Yahoo, and Ecosia.
- Download handling through Android DownloadManager.
- Notes, Privacy Center, dark/light/system themes, configurable accent/font colors, and acrylic-like surfaces.

## Desktop and viewport behavior

- Global Website Mode: Auto, Mobile, or Desktop.
- Auto resolves using the app window width: medium/expanded app windows (>=600 dp) request desktop sites; compact phone-sized windows request mobile sites.
- A per-tab override takes priority over the per-site preference, which takes priority over the global policy.
- Per-site choices are persisted in Preferences DataStore and shared across tabs for that host. Per-tab overrides are session-only and reset when that tab is recreated or the app process restarts.
- Desktop requests change the WebView User-Agent and enable wide viewport/overview layout settings. This is still website-requested desktop presentation, not a full PC browser environment; individual websites can ignore the User-Agent or force their own responsive layout.
- The expanded DHYRA browser interface is activated at >=840 dp. Medium windows show the tablet-width content layout and tab strip while retaining compact navigation controls.

## Diagnostics: interpretation and limits

- Theme contrast is calculated from the active DHYRA primary text and main background colors. It does not certify every component, disabled control, or third-party website.
- Device capability is a transparent score derived from Android memory class, free system RAM/low-memory state, and CPU logical core count. It is not a CPU/GPU benchmark.
- Browser runtime health is a point-in-time heuristic derived from process PSS, active tab count, and WebView provider availability. It is not a page-load or frame-time benchmark.
- Web-content compatibility is **not graded**. A credible score requires controlled test pages, load assertions, JavaScript/CSS behavior checks, and a repeatable device test matrix.
- Compose does not expose a reliable automatic scan of all descendants for clipped content and keyboard overlap in this implementation; global overflow/accessibility grades are therefore not claimed. Manual QA is still required on physical phones, tablets, and foldables.
- Diagnostic history stores the latest 20 local snapshots in Preferences DataStore. Measurements may change with device workload and available memory.

## Engine and security boundaries

- Android System WebView supplies Chromium-based HTML/CSS/JavaScript rendering and network behavior. DHYRA owns the surrounding native browser experience, not an independent browser engine.
- The provider contract is an integration seam only. No GeckoView or custom Chromium implementation is shipped in this version.
- Existing WebView restrictions remain: JavaScript is enabled for compatibility, file and content URI access from web content is disabled, mixed content is blocked, Safe Browsing is enabled where supported, and SSL certificate failures are cancelled rather than bypassed.
- Website desktop mode uses User-Agent and viewport settings. WebView cookies and website storage remain shared across normal/private tabs as documented previously; no isolated private profile is implemented.
- Tracking protection remains a small host/path deny-list plus third-party cookie restrictions, not a full ad-blocking filter engine.

## Known limitations / not represented as completed

- No Gecko/Chromium engine integration, extension platform, full browser-profile isolation, site-specific permission dashboard, or comprehensive ad-blocking engine.
- No independent Chromium fork and no custom HTML/CSS/JavaScript renderer.
- Notes remain plain text; rich text, checklist blocks, categories/tags, import, and automatic file backup are not implemented.
- Bookmark folders, bookmark import/export, favicon persistence, and drag-and-drop tab reordering are not implemented.
- DownloadManager does not provide reliable pause/resume/retry, download speed, or a persistent in-app download database in this build.
- No weather integration, wallpaper gallery, autocomplete/suggestion service, live tab thumbnails, or desktop extension support.
- Tablet/foldable adaptation uses current app-window width classes. It is not a complete window posture / hinge-aware foldable implementation.
- Splash screen branding is provided by AndroidX SplashScreen; no long blocking cinematic intro is used.

## Build configuration

- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- Gradle: 8.7
- compileSdk: 35
- targetSdk: 34
- minSdk: 26
- Java: 17
- app version: 1.9.0 (versionCode 13)

## Build locally

```bash
./gradlew testDebugUnitTest lintDebug :app:assembleDebug
```

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.
The GitHub Actions workflow can build either a project extracted into the repository root or a single source ZIP in the repository root. If the ZIP does not include the Gradle wrapper JAR, the workflow generates it using Gradle 8.7 before running tests, lint, and the debug build.
