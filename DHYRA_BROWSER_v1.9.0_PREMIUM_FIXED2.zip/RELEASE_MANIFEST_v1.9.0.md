# Release package manifest — DHYRA Browser v1.9.0 Premium Edition

Package: `DHYRA_BROWSER_v1.9.0_PREMIUM.zip`

This archive contains the Android Studio/Gradle source project and GitHub Actions workflow. It is intended to be uploaded to a GitHub repository root or extracted locally.

## Release highlights

- Premium home-screen refresh and improved search surface.
- Refined quick actions, frosted surfaces, and settings cards.
- Expanded centralized design tokens.
- Version metadata updated to 1.9.0 / versionCode 13.
- GitHub Actions configured to run unit tests, lint, assemble a debug APK, and publish the APK as a workflow artifact.

## Important build note

The ZIP does not include a compiled APK or a signed production release. The build workflow must run in GitHub Actions (or locally with Android SDK 35, JDK 17, and Gradle 8.7) to produce the debug APK. Build execution could not be completed in the packaging environment because Gradle distribution download was unavailable.
