# Build validation — DHYRA Browser v1.9.0

## Required CI checks

1. Confirm Android SDK platform 35 and build-tools 35.0.0 are installed.
2. Confirm Gradle 8.7 and JDK 17 are used.
3. Run `./gradlew --no-daemon --stacktrace testDebugUnitTest lintDebug :app:assembleDebug`.
4. Verify `app/build/outputs/apk/debug/app-debug.apk` exists and is non-empty.
5. Upload the APK as `DHYRA-BROWSER-v1.9.0-debug`.

## Release metadata

- `versionName`: `1.9.0`
- `versionCode`: `13`
- `compileSdk`: `35`
- `targetSdk`: `34`
- `minSdk`: `26`

## Scope

This package contains source and CI configuration. Build success and runtime behavior must be verified by GitHub Actions and on physical Android devices; this document is not a substitute for those results.
