# DHYRA Browser v1.9.0 — Premium Edition

## Experience and visual refinement

- Reworked the home hero into a branded welcome panel with a subtle multi-stop gradient, restrained decorative glow, compact eyebrow label, and clearer headline/subtitle hierarchy.
- Refined the search surface with a dedicated search icon tile, more consistent control height, rounded action button, and clearer placeholder copy.
- Improved home section labels and hierarchy for ambience presets and the saved-library shortcuts.
- Kept all existing callbacks and routes intact: search, tabs, settings, bookmarks, history, downloads, notes, privacy, and support.
- Preserved compact/medium/expanded window behavior and dynamic mood palettes.

## Design system

- Expanded `DhyraDesignTokens` with reusable brand, status, focus, width, gutter, and radius tokens.
- Updated the primary accent to a softer violet (`#7667D8`) while retaining the existing user-configurable accent setting.
- Kept surfaces lightweight: gradients and translucent fills are used instead of expensive live backdrop blur.

## Build and release

- Android version: `1.9.0`
- Version code: `13`
- Compile SDK: `35`
- Target SDK: `34`
- Minimum SDK: `26`
- Java: `17`
- GitHub Actions validates the 1.9.0 metadata and uploads a debug APK artifact after tests, lint, and assemble.

## Validation status

The source package is prepared for GitHub Actions. A successful Android build must still be confirmed by running the workflow in GitHub or running:

```bash
./gradlew testDebugUnitTest lintDebug :app:assembleDebug
```

No claim is made that a physical-device UI test or a signed release build has been completed in this environment.
