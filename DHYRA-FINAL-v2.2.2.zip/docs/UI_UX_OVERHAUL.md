# DHYRA Browser — UI/UX System

## Design direction

DHYRA uses a calm, minimal and functional visual identity: sage/teal accent, charcoal dark surfaces, pure-black AMOLED surfaces, consistent typography, outline icons, restrained elevation and short motion durations.

## Design tokens

Shared tokens are defined in `ui/theme/DesignTokens.kt`:

- Spacing: 4, 8, 12, 16, 24 and 32 dp.
- Shapes: card 20 dp, field 16 dp and pill/button families.
- Motion: 120, 180 and 240 ms duration tokens.

Colour and typography live in `ui/theme/Theme.kt`. New components should use MaterialTheme and shared tokens rather than arbitrary one-off sizes/colours. The current migration is partial; several legacy components still have explicit text sizes and padding and should be migrated incrementally.

## Screen behavior

- Home uses a fixed-top search/address field and responsive speed-dial FlowRow; the content below scrolls. Greeting/date refresh each minute.
- Browser address bar is always at the top, before the WebView host. The editable omnibox overlay is aligned to `TopCenter`. Fullscreen media hides browser chrome and does not relocate it.
- Tabs use a compact `GridCells.Adaptive` grid with a reduced card height, private marker, preview/favicons when available, title, active outline and 48dp close targets. Regular group-close supports Undo; private group-close requires confirmation. Private previews are not captured.
- Settings includes local search over available settings. Unavailable isolated private browsing is explicitly described rather than shown as working.
- Downloads refresh while the screen is active, poll quickly during active transfers and slowly while idle.
- Shields dashboard reports intercepted request counts, not estimated bytes saved.

## Responsive behavior

Home shortcut columns adapt to available width. Tab cards use adaptive grid cells. This is an Android phone/foldable/tablet UI and should continue to be tested in compact, medium and expanded windows; no native desktop executable is produced.

## Accessibility QA still required

- TalkBack focus order and labels.
- Text scale to 200%.
- Contrast for all theme modes.
- Touch targets at least 48 dp.
- Reduced motion and animation scaling.
- Keyboard navigation on tablets and resizable windows.

The source has not been physically device-tested for these items in this authoring environment.
