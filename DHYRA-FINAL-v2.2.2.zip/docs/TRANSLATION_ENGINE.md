# On-device page translation

## Components

- `core/network/WebViewModeManager.kt`: current WebView UA and per-tab Mobile/Desktop settings.
- `core/translation/TranslationState.kt`: phase and bridge payload models.
- `MLKitTranslator.kt`: one cached ML Kit Translator pair and a serialized Language Identifier.
- `TranslationQueue.kt`: one worker per WebView tab, a bounded channel (8 batches), up to 24 items / 2,000 characters per batch, and a bounded 512-entry result cache. The shared ML Kit client is guarded by a mutex, so only one translation operation uses the native translator pair at a time. Queue pause is observed between text segments; a running ML Kit task is allowed to finish safely.
- `TranslationBridge.kt`: AndroidX WebMessageListener transport; it rejects non-HTTPS, non-main-frame, mismatched-origin, oversized, invalid and over-rate requests. Each run also uses a random 128-bit session token.
- `TranslationManager.kt` (`DhyraTranslationManager`): model preparation, automatic language identification, queue coordination, lifecycle pause/resume, cancellation generations and state publication.
- `assets/PageTranslation.js`: incremental DOM text extraction and non-destructive text replacement. `scripts/test-page-translation.cjs` and `scripts/test-translation-retries.cjs` are Node-based deterministic smoke tests and are also run by CI before Gradle.
- `ui/components/TranslationSheet.kt`: language selection, model Wi-Fi policy, progress, pause/resume and restore controls. Translation is explicitly user-triggered; always-translate/never-translate-site policy storage is not yet implemented.

## Message flow

1. The user explicitly requests translation from an HTTPS page. DHYRA creates a random per-run token and registers a handler for that WebView.
2. ML Kit downloads the requested language pair on demand (Wi-Fi only by default). Auto-detect waits for a representative text sample, identifies its language, then prepares that language pair.
3. `PageTranslation.js` walks eligible TextNodes incrementally, prioritizing visible and near-viewport text. It batches segments with stable request and node IDs.
4. AndroidX WebMessageListener validates HTTPS origin, main-frame status, message size/type, rate and the session token before dispatching to Kotlin. It exposes no arbitrary native browser APIs.
5. The queue translates segments sequentially via ML Kit. Results are returned by request ID and applied only if the TextNode still contains the original text captured for that request.
6. Restore only reverts a node if the current value still matches DHYRA's translated value, so a later website text mutation is not overwritten with a stale snapshot.

## Safety and limits

- The bridge uses `WebMessageListener`, not `addJavascriptInterface`; it is still injected for all origins because DHYRA must support arbitrary websites, but native requests are accepted only from the current HTTPS main-frame origin, only while a user-started translation handler is active, and only for bounded translation payloads carrying the current run token. The bridge does not provide file, storage, permission or arbitrary command capabilities. Page scripts can still alter their own DOM and may interfere with page translation; translation is not a security boundary against the page itself.
- `PageTranslation.js` touches only eligible TextNodes. It skips scripts/styles/code/form controls/contenteditable, hidden content (including hidden ancestors), SVG and other unsafe elements. It never assigns `innerHTML` or replaces HTML elements. Request retries are bounded to two and permanent native errors are not automatically retried. Uncorrelated errors without a known request ID are ignored so malformed page-originated bridge messages cannot settle a separate pending batch. If a website mutates a node before the observer sees the translator's own mutation, the latest site-owned text is treated as new source. Newly inserted hidden text is not queued. Successfully translated segments may render while failed segments remain in the source language; restore still returns the node to the exact latest source text if the page has not subsequently changed it.
- Canvas/image text, closed shadow roots, cross-origin iframes and some embedded/virtualized application content are not accessible to the top-level TreeWalker. Those contents are not translated.
- Memory is bounded by the tracked-node map and queued-segment limits. If these limits are reached, the UI reports that some page content was skipped. The scan is best-effort, not full-document guaranteed for huge/infinite pages.
- ML Kit models must be downloaded before offline translation can work. Google recommends Wi-Fi and documents more than 50 supported languages. Exact availability can vary by ML Kit release; DHYRA's picker exposes a curated subset.
- On tab switch and Activity pause, the scan and queue pause. An ML Kit Task already executing may finish; no subsequent segment starts until resume. When a tab WebView is frozen, DHYRA destroys its translator manager and reloads the original URL on restore before optionally restarting the user's explicit translation configuration.
- Desktop mode changes UA and viewport settings only. It cannot force websites to serve a desktop-specific layout.

## Verification still required

Run `testDebugUnitTest`, `lintDebug`, `assembleDebug`, then test actual translation with the system WebView provider on physical devices. Verify Wi-Fi-only model download, no-network/model-missing error, auto language detection, manually selected languages, pause/resume during a batch, tab switch, page navigation, SPA updates, website text mutation, restore-original, and WebView recreation. Test a large article and an infinite-scroll page to confirm resource bounds.
