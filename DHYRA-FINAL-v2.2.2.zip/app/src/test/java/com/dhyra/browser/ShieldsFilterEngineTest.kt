package com.dhyra.browser

import org.junit.Test

import com.dhyra.browser.core.shields.ShieldsFilterEngine

class ShieldsFilterEngineTest {
    fun runChecks() {
        val engine = ShieldsFilterEngine(
            listOf("||doubleclick.net^", "||facebook.com/tr^", "@@||facebook.com/tr/allow^")
        )
        check(engine.shouldBlock("https://doubleclick.net/ad.js"))
        check(engine.shouldBlock("https://ad.doubleclick.net/ad.js"))
        check(engine.shouldBlock("https://www.facebook.com/tr/?id=1"))
        check(!engine.shouldBlock("https://www.facebook.com/profile.php"))
        check(!engine.shouldBlock("https://www.facebook.com/track-this"))
        check(!engine.shouldBlock("https://facebook.com/tr/allow/pixel"))
        check(!engine.shouldBlock("https://example.com/"))
    }

    @Test
    fun junitSuite() = runChecks()

}
