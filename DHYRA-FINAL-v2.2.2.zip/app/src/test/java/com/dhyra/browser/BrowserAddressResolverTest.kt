package com.dhyra.browser

import com.dhyra.browser.core.nav.BrowserAddressResolver
import com.dhyra.browser.core.search.SearchEngineManager
import com.dhyra.browser.core.settings.DhyraSettingsManager
import org.junit.Test

class BrowserAddressResolverTest {
    fun runChecks() {
        check(DhyraSettingsManager.normalizeSearchEngine(null) == "Google")
        check(DhyraSettingsManager.normalizeSearchEngine("unknown-provider") == "Google")
        check(BrowserAddressResolver.resolve("  ", "Google") == "https://www.google.com")
        check(BrowserAddressResolver.resolve("example.com", "Google") == "https://example.com")
        check(BrowserAddressResolver.resolve("https://example.com/path?q=1", "Google") == "https://example.com/path?q=1")
        check(BrowserAddressResolver.resolve("hello world", "DuckDuckGo") == "https://duckduckgo.com/?q=hello+world")
        check(BrowserAddressResolver.resolve("privacy browser", "Brave") == "https://search.brave.com/search?q=privacy+browser")
        check(BrowserAddressResolver.resolve("camera test", "Yahoo") == "https://search.yahoo.com/search?p=camera+test")
        check(BrowserAddressResolver.resolve("privacy browser", "Google").startsWith("https://www.google.com/search?q="))
        check(BrowserAddressResolver.resolve("javascript:alert(1)", "Google") == "https://www.google.com/search?q=javascript%3Aalert%281%29")
        check(BrowserAddressResolver.resolve("https://user:secret@example.com", "Google").startsWith("https://www.google.com/search?q="))
        check(BrowserAddressResolver.resolve("example.com:bad-port", "Google").startsWith("https://www.google.com/search?q="))
        check(!BrowserAddressResolver.looksLikeAddress("https://user:secret@example.com"))
        check(BrowserAddressResolver.looksLikeAddress("https://example.com/path"))
        check(BrowserAddressResolver.normalizeHomepage("file:///etc/passwd") == "https://www.google.com")
        check(BrowserAddressResolver.normalizeHomepage("https://user:secret@example.com") == "https://www.google.com")
        check(BrowserAddressResolver.normalizeHomepage("") == "https://www.google.com")

        val custom = "https://search.example.test/find?q={query}"
        check(SearchEngineManager.validateCustomTemplate(custom).getOrThrow() == custom)
        check(BrowserAddressResolver.resolve("hello world", "Custom", custom) == "https://search.example.test/find?q=hello+world")
        check(BrowserAddressResolver.resolve("hello world", "Custom", "http://insecure.example/?q={query}") == "https://www.google.com/search?q=hello+world")
        check(SearchEngineManager.validateCustomTemplate("https://user:password@example.test/?q={query}").isFailure)
        check(SearchEngineManager.validateCustomTemplate("https://example.test/?q={query}&again={query}").isFailure)
    }

    @Test
    fun junitSuite() = runChecks()
}
