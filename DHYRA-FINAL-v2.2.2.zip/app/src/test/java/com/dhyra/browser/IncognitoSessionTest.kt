package com.dhyra.browser

import com.dhyra.browser.core.tabs.IncognitoSession
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IncognitoSessionTest {
    @Test
    fun privateTabIsNotPersistedAndUsesNoCachePolicy() {
        assertFalse(IncognitoSession.shouldPersistHistory(true))
        assertFalse(IncognitoSession.shouldPersistSession(true))
        assertFalse(IncognitoSession.shouldPersistBookmarks(true))
        assertTrue(IncognitoSession.cacheModeNoCache(true))
    }

    @Test
    fun privateModeRequiresBothProfileIsolationAndCompleteDataDeletion() {
        assertTrue(IncognitoSession.canStartIsolatedSession(true, true))
        assertFalse(IncognitoSession.canStartIsolatedSession(false, true))
        assertFalse(IncognitoSession.canStartIsolatedSession(true, false))
        assertFalse(IncognitoSession.canStartIsolatedSession(false, false))
    }

    @Test
    fun privateTabRequiresProfileCreationAndCompletedCleanup() {
        assertFalse(IncognitoSession.canStartIsolatedSession(true, true, profileCreated = false))
        assertFalse(IncognitoSession.canOpenPrivateTab(isolatedProfileAvailable = true, cleanupCompleted = false))
        assertTrue(IncognitoSession.canOpenPrivateTab(isolatedProfileAvailable = true, cleanupCompleted = true))
        assertFalse(IncognitoSession.canOpenPrivateTab(isolatedProfileAvailable = false, cleanupCompleted = true))
    }

    @Test
    fun persistentDownloadsAreDisallowedForPrivateTabs() {
        assertFalse(IncognitoSession.allowPersistentDownload(true))
        assertTrue(IncognitoSession.allowPersistentDownload(false))
    }

    @Test
    fun privateTabsCannotRequestPersistentDevicePermissions() {
        assertFalse(IncognitoSession.allowDevicePermissions(true))
        assertTrue(IncognitoSession.allowDevicePermissions(false))
    }

    @Test
    fun regularTabKeepsNormalPersistencePolicy() {
        assertTrue(IncognitoSession.shouldPersistHistory(false))
        assertTrue(IncognitoSession.shouldPersistSession(false))
        assertTrue(IncognitoSession.shouldPersistBookmarks(false))
        assertFalse(IncognitoSession.cacheModeNoCache(false))
    }
}
