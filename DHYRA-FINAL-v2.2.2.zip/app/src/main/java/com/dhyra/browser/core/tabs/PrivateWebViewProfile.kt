package com.dhyra.browser.core.tabs

import android.util.Log
import android.webkit.CookieManager
import android.webkit.WebView
import androidx.webkit.Profile
import androidx.webkit.ProfileStore
import androidx.webkit.WebStorageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/**
 * Owns the dedicated WebView profile used by private tabs.
 *
 * This class is created and used on the main thread because ProfileStore and
 * WebViewCompat.setProfile are UI-thread APIs. It never falls back to the default
 * profile: when either required WebView feature is missing, [isSupported] is false.
 */
internal class PrivateWebViewProfile(
    private val onReadinessChanged: (Boolean) -> Unit = {}
) {
    private val multiProfileSupported = featureSupported(WebViewFeature.MULTI_PROFILE)
    private val browsingDataDeletionSupported = featureSupported(WebViewFeature.DELETE_BROWSING_DATA)

    private val profile: Profile? = if (multiProfileSupported && browsingDataDeletionSupported) {
        runCatching { ProfileStore.getInstance().getOrCreateProfile(PROFILE_NAME) }
            .onFailure { Log.w(TAG, "Unable to create isolated private WebView profile", it) }
            .getOrNull()
    } else {
        null
    }

    private var cleanupGeneration = 0L
    private var cleanupFailed = false
    var isReady: Boolean = false
        private set

    val isSupported: Boolean
        get() = !cleanupFailed && IncognitoSession.canStartIsolatedSession(
            multiProfileSupported = multiProfileSupported,
            fullDataDeletionSupported = browsingDataDeletionSupported,
            profileCreated = profile != null
        )

    val cookieManager: CookieManager?
        get() = profile?.cookieManager

    /** Begin a serialized profile-scoped data wipe; the caller receives readiness via callback. */
    fun clearBrowsingData() {
        val currentProfile = profile
        if (!multiProfileSupported || !browsingDataDeletionSupported || currentProfile == null || cleanupFailed) {
            setReady(false)
            return
        }

        setReady(false)
        val generation = ++cleanupGeneration
        try {
            WebStorageCompat.deleteBrowsingData(currentProfile.webStorage, Runnable {
                // A stale callback must not mark a newer cleanup operation as complete.
                if (generation == cleanupGeneration) {
                    runCatching { currentProfile.cookieManager.flush() }
                    setReady(true)
                }
            })
        } catch (error: Exception) {
            if (generation == cleanupGeneration) {
                cleanupFailed = true
                Log.w(TAG, "Private WebView data cleanup failed; private browsing stays disabled", error)
                setReady(false)
                // Notify even when readiness was already false so Compose can refresh isSupported.
                onReadinessChanged(false)
            }
        }
    }

    /** Must be the first operation performed on a newly-created private WebView. */
    fun attachTo(webView: WebView): Boolean {
        if (!isSupported || !isReady) return false
        return try {
            WebViewCompat.setProfile(webView, PROFILE_NAME)
            true
        } catch (error: Exception) {
            cleanupFailed = true
            setReady(false)
            // Invalidate even if readiness was already false so the UI re-reads isSupported.
            onReadinessChanged(false)
            Log.w(TAG, "Unable to attach the isolated profile; private browsing is disabled", error)
            false
        }
    }

    private fun setReady(value: Boolean) {
        if (isReady == value) return
        isReady = value
        onReadinessChanged(value)
    }

    private fun featureSupported(feature: String): Boolean =
        runCatching { WebViewFeature.isFeatureSupported(feature) }.getOrDefault(false)

    private companion object {
        const val TAG = "DhyraPrivateProfile"
        const val PROFILE_NAME = "dhyra-private-session"
    }
}
