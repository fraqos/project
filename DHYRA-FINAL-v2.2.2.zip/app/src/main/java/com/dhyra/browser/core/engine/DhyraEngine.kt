package com.dhyra.browser.core.engine

import android.content.Context
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.webkit.WebViewFeature

/**
 * DHYRA's browser-engine facade. Rendering and JavaScript execution are supplied by the
 * installed Android System WebView provider; DHYRA owns browser policy and tab/session layers.
 */
class DhyraEngine(context: Context) {
    private val appContext = context.applicationContext

    fun createWebView(activityContext: Context): WebView = WebView(activityContext)

    fun info(): DhyraEngineInfo {
        val provider = WebView.getCurrentWebViewPackage()
        val userAgent = runCatching { WebSettings.getDefaultUserAgent(appContext) }.getOrDefault("")
        val chromiumVersion = CHROMIUM_TOKEN.find(userAgent)?.groupValues?.getOrNull(1)
        return DhyraEngineInfo(
            backend = "Android System WebView",
            providerPackage = provider?.packageName ?: "System provider",
            providerVersion = provider?.versionName ?: "Unknown",
            chromiumVersion = chromiumVersion ?: "Not reported by provider",
            supportsSecureWebMessages = WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER),
            supportsNamedProfiles = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE),
            supportsProfileDataDeletion = WebViewFeature.isFeatureSupported(WebViewFeature.DELETE_BROWSING_DATA)
        )
    }

    private companion object {
        val CHROMIUM_TOKEN = Regex("Chrome/([0-9]+(?:\\.[0-9]+){1,3})")
    }
}

data class DhyraEngineInfo(
    val backend: String,
    val providerPackage: String,
    val providerVersion: String,
    val chromiumVersion: String,
    val supportsSecureWebMessages: Boolean,
    val supportsNamedProfiles: Boolean,
    val supportsProfileDataDeletion: Boolean
)
