package com.dhyra.browser.core.downloads

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil

/** Public-download adapter over Android DownloadManager. Private-tab downloads are blocked upstream. */
class DhyraDownloadManager(private val context: Context) {
    fun enqueue(
        url: String,
        userAgent: String,
        contentDisposition: String,
        mimeType: String
    ): Long? {
        val uri = Uri.parse(url)
        if (uri.scheme?.lowercase() !in setOf("http", "https") || uri.host.isNullOrBlank()) return null
        return runCatching {
            val suggested = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val fileName = DownloadFileNames.safeLeafName(suggested)
            val request = DownloadManager.Request(uri)
                .setTitle(fileName)
                .setDescription("Downloaded by DHYRA Browser")
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", userAgent)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            CookieManager.getInstance().getCookie(url)?.takeIf(String::isNotBlank)?.let {
                request.addRequestHeader("Cookie", it)
            }
            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        }.getOrNull()
    }
}
