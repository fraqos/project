package com.dhyra.browser.core.shields

import java.net.URI

/**
 * Small indexed host/path matcher for WebView request interception.
 * Supports ||host^, ||host/path^ and @@ exceptions. It intentionally does not claim to parse
 * all EasyList/uBlock syntax (resource options, initiators, regex, cosmetic rules, scriptlets).
 */
class ShieldsFilterEngine(rules: Collection<String>) {
    private data class Rule(
        val host: String,
        val pathPrefix: String?,
        val pathBoundary: Boolean,
        val exception: Boolean
    )

    private val rulesByHost: Map<String, List<Rule>> = rules.mapNotNull(::parseRule)
        .groupBy { it.host }

    fun shouldBlock(url: String): Boolean {
        val parsed = runCatching { URI(url) }.getOrNull() ?: return false
        val host = parsed.host?.lowercase()?.trimEnd('.') ?: return false
        val path = parsed.rawPath.orEmpty()
        val candidates = buildList {
            var current = host
            while (current.isNotEmpty()) {
                addAll(rulesByHost[current].orEmpty())
                val dot = current.indexOf('.')
                if (dot < 0) break
                current = current.substring(dot + 1)
            }
        }
        var blocked = false
        for (rule in candidates) {
            if (!matchesPath(path, rule.pathPrefix, rule.pathBoundary)) continue
            if (rule.exception) blocked = false else blocked = true
        }
        return blocked
    }

    val ruleCount: Int get() = rulesByHost.values.sumOf { it.size }

    private fun matchesPath(path: String, prefix: String?, boundary: Boolean): Boolean {
        if (prefix == null) return true
        if (!path.startsWith(prefix, ignoreCase = true)) return false
        if (!boundary || path.length == prefix.length) return true
        return path[prefix.length] in charArrayOf('/', '?', '#', '&', ';', '=')
    }

    private fun parseRule(raw: String): Rule? {
        var value = raw.trim()
        if (value.isEmpty() || value.startsWith("!") || value.startsWith("#")) return null
        val exception = value.startsWith("@@")
        if (exception) value = value.removePrefix("@@")
        if (!value.startsWith("||")) return null
        value = value.removePrefix("||")
        val optionsIndex = value.indexOf('$')
        if (optionsIndex >= 0) value = value.substring(0, optionsIndex)
        val pathBoundary = value.endsWith('^')
        value = value.removeSuffix("^")
        val slash = value.indexOf('/')
        val host = (if (slash >= 0) value.substring(0, slash) else value)
            .lowercase().trim().trimEnd('.')
        if (host.isBlank() || host.any { !(it.isLetterOrDigit() || it == '.' || it == '-') }) return null
        val path = if (slash >= 0) value.substring(slash).takeIf { it.isNotBlank() } else null
        return Rule(host, path, pathBoundary && path != null, exception)
    }
}
