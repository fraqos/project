package com.dhyra.browser.core.settings

import com.dhyra.browser.core.search.SearchEngineManager

/** Central defaults and validation for preferences surfaced by the current Settings UI. */
object DhyraSettingsManager {
    const val DEFAULT_SEARCH_ENGINE = SearchEngineManager.GOOGLE
    const val DEFAULT_THEME = "System"
    val supportedThemes = setOf("System", "Dynamic", "Light", "Dark", "AMOLED")

    fun normalizeSearchEngine(value: String?): String =
        value?.takeIf { it in SearchEngineManager.engines } ?: DEFAULT_SEARCH_ENGINE

    fun normalizeTheme(value: String?): String =
        value?.takeIf { it in supportedThemes } ?: DEFAULT_THEME
}
