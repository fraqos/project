@file:OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser.ui.screens

import com.dhyra.browser.*
import com.dhyra.browser.ui.theme.*
import com.dhyra.browser.ui.components.*

import android.widget.FrameLayout
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * The browsing screen: address pill, the WebView host and the bottom navigation.
 *
 * IME policy (the "no page jump" rule): while the omnibox overlay is typing, [resizeForIme] is
 * false, so the WebView host is not resized at all and the page behind the overlay stays still.
 * When a field inside the web page itself is focused, [resizeForIme] is true and the host
 * shrinks above the keyboard so the focused field stays visible, like Chromium does.
 */
@Composable
internal fun BrowserPage(
    controller: BrowserController,
    desktop: Boolean,
    resizeForIme: Boolean,
    imeVisible: Boolean,
    showFind: Boolean,
    findText: String,
    onFindChange: (String) -> Unit,
    onFindClose: () -> Unit,
    onOpenOmnibox: () -> Unit,
    onShields: () -> Unit,
    onToggleDesktop: () -> Unit,
    onHome: () -> Unit,
    onTabs: () -> Unit,
    onMenu: () -> Unit,
    onSwipeTabs: (Int) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val active = controller.activeTab()
    val fullscreen = controller.isFullscreen
    val holder = remember { arrayOfNulls<FrameLayout>(1) }

    // Release the host when this screen leaves; a newer host (quick back-and-forth) is untouched.
    DisposableEffect(controller) {
        onDispose { holder[0]?.let { controller.detach(it) } }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .then(if (resizeForIme) Modifier.imePadding() else Modifier)
    ) {
        if (!fullscreen) {
            Box(Modifier.fillMaxWidth().statusBarsPadding()) {
                BrowserTopBar(
                    url = active?.url.orEmpty(),
                    isPrivate = active?.isPrivate == true,
                    loading = active?.loading == true,
                    progress = active?.progress ?: 0,
                    blocked = controller.blockedRequestCount(controller.activeTabId),
                    desktop = desktop,
                    onOpenOmnibox = onOpenOmnibox,
                    onShields = onShields,
                    onReload = { if (active?.loading == true) controller.stop() else controller.reload() },
                    onToggleDesktop = onToggleDesktop,
                    onSwipeTabs = onSwipeTabs
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    FrameLayout(ctx).also {
                        holder[0] = it
                        controller.attach(it)
                    }
                }
            )
            if (showFind && !fullscreen) {
                FindBar(
                    text = findText,
                    onTextChange = onFindChange,
                    active = controller.findActiveMatch,
                    total = controller.findMatchCount,
                    onPrev = { controller.findNext(false) },
                    onNext = { controller.findNext(true) },
                    onClose = onFindClose,
                    modifier = Modifier.align(Alignment.TopCenter)
                )
            }
        }

        if (!fullscreen && !(imeVisible && resizeForIme)) {
            BottomNav(
                canBack = controller.canGoBack(),
                canForward = controller.activeWebView()?.canGoForward() == true,
                onBack = { controller.goBack() },
                onForward = { controller.goForward() },
                onHome = onHome,
                onTabs = onTabs,
                tabCount = controller.tabs.size,
                onMenu = onMenu
            )
        }
    }
}

/** The address pill in its resting state: tapping it opens the omnibox overlay. */
@Composable
internal fun BrowserTopBar(
    url: String,
    isPrivate: Boolean,
    loading: Boolean,
    progress: Int,
    blocked: Int,
    desktop: Boolean,
    onOpenOmnibox: () -> Unit,
    onShields: () -> Unit,
    onReload: () -> Unit,
    onToggleDesktop: () -> Unit,
    onSwipeTabs: (Int) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val foreground = if (isPrivate) PrivateText else cs.onSurface
    val muted = if (isPrivate) PrivateText.copy(alpha = 0.72f) else cs.onSurfaceVariant
    val pillColor = if (isPrivate) PrivateTint else cs.surfaceVariant
    val insecure = url.startsWith("http://")
    val secure = url.startsWith("https://")
    val label = if (isBlankPage(url)) null else siteLabelOf(url)
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0, 100) / 100f,
        animationSpec = tween(180),
        label = "pageProgress"
    )

    Column(Modifier.fillMaxWidth().background(cs.background)) {
        Row(
            Modifier.fillMaxWidth()
                .pointerInput(Unit) {
                    var drag = 0f
                    detectHorizontalDragGestures(
                        onHorizontalDrag = { _, amount -> drag += amount },
                        onDragEnd = {
                            if (kotlin.math.abs(drag) > 48f) onSwipeTabs(if (drag < 0f) 1 else -1)
                            drag = 0f
                        }
                    )
                }
                .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.weight(1f).height(48.dp),
                shape = RoundedCornerShape(24.dp),
                color = pillColor
            ) {
                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onShields, modifier = Modifier.size(48.dp)) {
                        CountBadge(count = blocked) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Shields",
                                tint = muted,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Row(
                        Modifier.weight(1f).fillMaxHeight().clickable(onClick = onOpenOmnibox),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when {
                                insecure -> Icons.Default.Warning
                                secure -> Icons.Default.Lock
                                else -> Icons.Default.Search
                            },
                            contentDescription = null,
                            tint = if (insecure) cs.error else muted,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = label ?: "Search or enter address",
                            fontSize = 15.sp,
                            lineHeight = 22.sp,
                            fontWeight = if (label == null) FontWeight.Normal else FontWeight.Medium,
                            color = if (label == null) muted else foreground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (desktop) {
                        IconButton(onClick = onToggleDesktop, modifier = Modifier.size(48.dp)) {
                            Icon(
                                imageVector = Icons.Default.DesktopWindows,
                                contentDescription = "Desktop site is on. Tap to turn it off",
                                tint = cs.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    IconButton(onClick = onReload, modifier = Modifier.size(48.dp)) {
                        Icon(
                            imageVector = if (loading) Icons.Default.Close else Icons.Default.Refresh,
                            contentDescription = if (loading) "Stop" else "Reload",
                            tint = foreground,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
        // The progress lane always keeps its 2dp, so the page never shifts when a load starts or ends.
        Box(Modifier.fillMaxWidth().height(2.dp)) {
            if (loading) {
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier.fillMaxSize(),
                    color = cs.primary,
                    trackColor = Color.Transparent
                )
            }
        }
    }
}

/** Find in page: a floating card over the top of the page, so nothing below it moves. */
@Composable
internal fun FindBar(
    text: String,
    onTextChange: (String) -> Unit,
    active: Int,
    total: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focusRequester.requestFocus() } }
    Surface(
        modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        shape = RoundedCornerShape(24.dp),
        color = cs.surface,
        shadowElevation = 8.dp,
        border = BorderStroke(1.dp, cs.outline)
    ) {
        Row(
            Modifier.fillMaxWidth().height(50.dp).padding(start = 18.dp, end = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f).focusRequester(focusRequester),
                singleLine = true,
                textStyle = TextStyle(color = cs.onSurface, fontSize = 16.sp, lineHeight = 24.sp),
                cursorBrush = SolidColor(cs.primary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onNext() }),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (text.isEmpty()) {
                            Text(
                                text = "Find in page",
                                fontSize = 16.sp,
                                lineHeight = 24.sp,
                                color = cs.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                        inner()
                    }
                }
            )
            if (text.isNotEmpty()) {
                Text(
                    text = if (total == 0) "0/0" else "${active + 1}/$total",
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = cs.onSurfaceVariant
                )
            }
            IconButton(onClick = onPrev, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous match", tint = cs.onSurface)
            }
            IconButton(onClick = onNext, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next match", tint = cs.onSurface)
            }
            IconButton(onClick = onClose, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close find", tint = cs.onSurfaceVariant)
            }
        }
    }
}

@Composable
internal fun BottomNav(
    canBack: Boolean,
    canForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onHome: () -> Unit,
    onTabs: () -> Unit,
    tabCount: Int,
    onMenu: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.background(cs.background)) {
        HorizontalDivider(color = cs.outline.copy(alpha = 0.5f))
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().height(56.dp).padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavIcon(Icons.Default.ArrowBack, "Back", canBack, onBack)
            NavIcon(Icons.Default.ArrowForward, "Forward", canForward, onForward)
            NavIcon(Icons.Default.Home, "Home", true, onHome)
            IconButton(onClick = onTabs) {
                Box(
                    Modifier.size(26.dp).border(1.5.dp, cs.onSurface, RoundedCornerShape(7.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (tabCount > 99) "99+" else tabCount.toString(),
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = cs.onSurface
                    )
                }
            }
            NavIcon(Icons.Default.MoreVert, "Menu", true, onMenu)
        }
    }
}

@Composable
private fun NavIcon(icon: ImageVector, description: String, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    IconButton(onClick = onClick, enabled = enabled) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.34f)
        )
    }
}

@Composable
internal fun CountBadge(count: Int, content: @Composable () -> Unit) {
    if (count > 0) {
        val cs = MaterialTheme.colorScheme
        BadgedBox(
            badge = {
                Badge(containerColor = cs.primary, contentColor = cs.onPrimary) {
                    Text(if (count > 99) "99+" else count.toString())
                }
            }
        ) { content() }
    } else {
        content()
    }
}
