package com.dhyra.browser.core.nav

import com.dhyra.browser.core.search.SearchEngineManager
import com.dhyra.browser.core.search.DhyraSearchManager

/** Resolves address-bar values into safe HTTP(S) navigation or a configured search URL. */
object BrowserAddressResolver {
    fun resolve(input: String, engine: String, customSearchTemplate: String? = null): String {
        val value = input.trim()
        if (value.isBlank()) return "https://www.google.com"

        if (value.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))) {
            val scheme = value.substringBefore(":").lowercase()
            return if (scheme in setOf("http", "https") &&
                com.dhyra.browser.core.security.DhyraSecurityManager.isHttpUrl(value)
            ) value else DhyraSearchManager.resolve(SearchEngineManager.GOOGLE, value)
        }

        val hostLike = value.contains(".") && !value.contains(" ") &&
            !value.startsWith(".") && !value.endsWith(".")
        if (hostLike) {
            val candidate = "https://$value"
            if (com.dhyra.browser.core.security.DhyraSecurityManager.isHttpUrl(candidate)) return candidate
        }

        return DhyraSearchManager.resolve(engine, value, customSearchTemplate)
    }

    /** True when [resolve] would open the text as an address instead of searching for it. */
    fun looksLikeAddress(input: String): Boolean {
        val value = input.trim()
        if (value.isBlank()) return false
        if (value.matches(Regex("^(?i)https?://.+"))) {
            return com.dhyra.browser.core.security.DhyraSecurityManager.isHttpUrl(value)
        }
        if (!value.contains(".") || value.contains(" ") || value.startsWith(".") || value.endsWith(".")) return false
        return com.dhyra.browser.core.security.DhyraSecurityManager.isHttpUrl("https://$value")
    }

    fun normalizeHomepage(input: String): String {
        val value = input.trim()
        if (value.isBlank()) return "https://www.google.com"
        val hasScheme = value.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:.*"))
        if (hasScheme && !value.startsWith("http://", true) && !value.startsWith("https://", true)) {
            return "https://www.google.com"
        }
        val candidate = if (hasScheme) value else "https://$value"
        return if (DhyraNavigationManager.isHttpUrl(candidate)) candidate else "https://www.google.com"
    }
}
