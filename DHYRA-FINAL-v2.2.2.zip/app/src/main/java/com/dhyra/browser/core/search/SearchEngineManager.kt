package com.dhyra.browser.core.search

import java.net.URI
import java.net.URLEncoder

/** Search provider registry. Custom providers must use an HTTPS URL with a {query} placeholder. */
object SearchEngineManager {
    const val GOOGLE = "Google"
    const val CUSTOM = "Custom"

    val engines: List<String> = listOf(
        GOOGLE,
        "Bing",
        "DuckDuckGo",
        "Yahoo",
        "Ecosia",
        "Startpage",
        "Qwant",
        "Brave",
        CUSTOM
    )

    private val templates = mapOf(
        GOOGLE to "https://www.google.com/search?q={query}",
        "Bing" to "https://www.bing.com/search?q={query}",
        "DuckDuckGo" to "https://duckduckgo.com/?q={query}",
        "Yahoo" to "https://search.yahoo.com/search?p={query}",
        "Ecosia" to "https://www.ecosia.org/search?q={query}",
        "Startpage" to "https://www.startpage.com/sp/search?query={query}",
        "Qwant" to "https://www.qwant.com/?q={query}",
        "Brave" to "https://search.brave.com/search?q={query}"
    )

    fun searchUrl(engine: String, query: String, customTemplate: String? = null): String {
        val template = if (engine == CUSTOM) {
            validateCustomTemplate(customTemplate).getOrNull() ?: templates.getValue(GOOGLE)
        } else {
            templates[engine] ?: templates.getValue(GOOGLE)
        }
        val encoded = URLEncoder.encode(query, Charsets.UTF_8.name())
        return template.replace("{query}", encoded)
    }

    /** Returns a normalized valid template, or a user-readable validation error. */
    fun validateCustomTemplate(raw: String?): Result<String> = runCatching {
        val template = raw?.trim().orEmpty()
        require(template.length in 12..2_000) { "Enter a search URL between 12 and 2,000 characters." }
        require(template.contains("{query}")) { "The URL must contain the {query} placeholder." }
        require(template.indexOf("{query}") == template.lastIndexOf("{query}")) {
            "Use the {query} placeholder only once."
        }
        val candidate = template.replace("{query}", "dhyra-test-query")
        val uri = URI(candidate)
        require(uri.scheme.equals("https", ignoreCase = true)) { "Custom search providers must use HTTPS." }
        require(!uri.host.isNullOrBlank()) { "Enter a valid HTTPS search URL." }
        require(uri.userInfo.isNullOrBlank()) { "Credentials are not allowed in a search URL." }
        template
    }.recoverCatching { error ->
        throw IllegalArgumentException(error.message ?: "Invalid custom search URL.")
    }
}


/** DHYRA-owned search policy facade used by address resolution and settings. */
object DhyraSearchManager {
    val engines: List<String> get() = SearchEngineManager.engines

    fun resolve(engine: String, query: String, customTemplate: String? = null): String =
        SearchEngineManager.searchUrl(engine, query, customTemplate)

    fun validateCustomTemplate(raw: String?): Result<String> =
        SearchEngineManager.validateCustomTemplate(raw)
}
