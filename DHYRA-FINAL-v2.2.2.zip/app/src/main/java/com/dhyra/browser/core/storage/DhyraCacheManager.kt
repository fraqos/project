package com.dhyra.browser.core.storage

import android.os.Handler
import android.os.Looper
import android.webkit.WebStorage
import androidx.webkit.WebStorageCompat
import androidx.webkit.WebViewFeature
import java.util.concurrent.atomic.AtomicBoolean

/** Clears only the default/regular WebView profile; named private profiles are managed separately. */
object DhyraCacheManager {
    private val mainHandler = Handler(Looper.getMainLooper())

    fun clearRegularProfile(onComplete: () -> Unit = {}) {
        val completed = AtomicBoolean(false)
        val finish = {
            if (completed.compareAndSet(false, true)) {
                if (Looper.myLooper() == Looper.getMainLooper()) onComplete()
                else mainHandler.post { onComplete() }
            }
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DELETE_BROWSING_DATA)) {
            try {
                WebStorageCompat.deleteBrowsingData(WebStorage.getInstance(), Runnable { finish() })
                return
            } catch (_: Exception) {
                // Older or misbehaving providers may advertise the API but fail at runtime.
            }
        }

        runCatching { WebStorage.getInstance().deleteAllData() }
        finish()
    }
}
