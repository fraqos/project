#!/usr/bin/env python3
"""Fast source-contract checks for critical Compose and browser integration boundaries."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sheet = (ROOT / "app/src/main/java/com/dhyra/browser/ui/components/TranslationSheet.kt").read_text(encoding="utf-8")
controller = (ROOT / "app/src/main/java/com/dhyra/browser/BrowserController.kt").read_text(encoding="utf-8")
models = (ROOT / "app/src/main/java/com/dhyra/browser/UiModels.kt").read_text(encoding="utf-8")
settings = (ROOT / "app/src/main/java/com/dhyra/browser/ui/screens/ScreensUi.kt").read_text(encoding="utf-8")
home = (ROOT / "app/src/main/java/com/dhyra/browser/ui/screens/HomeUi.kt").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/build.yml").read_text(encoding="utf-8")
webview_policy = (ROOT / "app/src/main/java/com/dhyra/browser/core/engine/DhyraWebViewController.kt").read_text(encoding="utf-8")
bookmark_route = (ROOT / "app/src/main/java/com/dhyra/browser/MainActivity.kt").read_text(encoding="utf-8")
search_manager = (ROOT / "app/src/main/java/com/dhyra/browser/core/search/SearchEngineManager.kt").read_text(encoding="utf-8")
settings_manager = (ROOT / "app/src/main/java/com/dhyra/browser/core/settings/DhyraSettingsManager.kt").read_text(encoding="utf-8")
engine_policy = (ROOT / "app/src/main/java/com/dhyra/browser/core/engine/DhyraWebViewController.kt").read_text(encoding="utf-8")
saved_page_tests = (ROOT / "app/src/test/java/com/dhyra/browser/SavedPagesManagerTest.kt").read_text(encoding="utf-8")
main_activity = (ROOT / "app/src/main/java/com/dhyra/browser/MainActivity.kt").read_text(encoding="utf-8")
permission_manager = (ROOT / "app/src/main/java/com/dhyra/browser/core/security/DhyraPermissionManager.kt").read_text(encoding="utf-8")
translator = (ROOT / "app/src/main/java/com/dhyra/browser/core/translation/MLKitTranslator.kt").read_text(encoding="utf-8")
translation_provider = (ROOT / "app/src/main/java/com/dhyra/browser/core/translation/TranslationProvider.kt").read_text(encoding="utf-8")
app_gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")

checks = {
    "Material3 ExposedDropdownMenu extension import": "import androidx.compose.material3.ExposedDropdownMenu\n" in sheet,
    "Material3 anchor type import": "import androidx.compose.material3.ExposedDropdownMenuAnchorType\n" in sheet,
    "Both read-only anchors declare PrimaryNotEditable": sheet.count("menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable)") == 2,
    "Both menus use the scope extension unqualified": len(re.findall(r"^\s*ExposedDropdownMenu\s*\(", sheet, flags=re.MULTILINE)) == 2,
    "No invalid fully-qualified top-level menu calls remain": "androidx.compose.material3.ExposedDropdownMenu(" not in sheet,
    "Translation sheet remains a Compose entry point": "@Composable\ninternal fun TranslationSheet(" in sheet,
    "restoreSession visibility matches internal API": re.search(r"^\s*internal fun restoreSession\(entries: List<SessionTab>\)", controller, re.MULTILINE) is not None,
    "SessionTab compatibility alias remains internal": re.search(r"^internal typealias SessionTab = DhyraSessionTab$", models, re.MULTILINE) is not None,
    "Address-bar pinned preference is absent from Settings": "Always pinned to the top" not in settings and "address_bar_pinned" not in settings,
    "Google is the first default speed dial entry": re.search(r"internal val DEFAULT_SPEED_DIAL = listOf\(\s*Shortcut\(\"Google\"", models) is not None,
    "Home supports Add shortcut interaction": "AddSpeedDialTile(" in home and "onSaveShortcut(original, Shortcut" in home,
    "Bookmark edit is wired to DataStore update": "onEdit = { original, replacement ->" in bookmark_route and "DhyraBookmarkManager.update" in bookmark_route,
    "History sections retain SavedPage list types": "val sections: List<Pair<String, List<SavedPage>>>" in settings and "val sectionEntries: List<SavedPage> = section.second" in settings,
    "LazyColumn uses the SavedPage list overload": "items = sectionEntries" in settings and "page: SavedPage" in settings and "entry: SavedPage" in settings,
    "Private WebView configuration requires profile cookies": "requireNotNull(profileCookies)" in webview_policy,
    "Versioned CI APK naming uses current package version": "DHYRA-Browser-v2.2.2.apk" in workflow,
    "CI runs unit tests, lint and assemble": all(task in workflow for task in ("testDebugUnitTest", "lintDebug", "assembleDebug")),
    "Google is the explicit first-run search default": "DEFAULT_SEARCH_ENGINE = SearchEngineManager.GOOGLE" in settings_manager,
    "Custom search requires HTTPS and one query token": "https" in search_manager.lower() and "indexOf" in search_manager and "lastIndexOf" in search_manager,
    "User-selected content URIs remain available while file:// stays disabled": "allowContentAccess = true" in engine_policy and "allowFileAccess = false" in engine_policy,
    "HTML media playback requires a user gesture": "mediaPlaybackRequiresUserGesture = true" in engine_policy,
    "History and bookmark edit behavior has a JVM regression suite": "DhyraBookmarkManager.update" in saved_page_tests and "DhyraHistoryManager.record" in saved_page_tests,
    "Permission resources remain an array at the WebView grant boundary": "fun supportedResources(resources: Array<String>): Array<String>" in permission_manager and "request.grant(supported)" in main_activity and "request.grant(supported.toTypedArray())" not in main_activity,
    "Translation overrides omit interface-owned default arguments": "wifiOnly: Boolean = true" not in re.search(r"override suspend fun prepare\([\s\S]*?\n    }", translator).group(0) and "wifiOnly: Boolean = true" not in re.search(r"override suspend fun translate\([\s\S]*?\n    }", translator).group(0),
    "Translation provider retains default arguments for callers": translation_provider.count("wifiOnly: Boolean = true") == 2,
    "Application version and CI artifact version are synchronized": "versionName = \"2.2.2\"" in app_gradle and "DHYRA-Browser-v2.2.2.apk" in workflow,
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(("PASS" if passed else "FAIL") + ": " + name)
if failed:
    print("Source contract validation failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
print(f"All {len(checks)} source contract checks passed.")
