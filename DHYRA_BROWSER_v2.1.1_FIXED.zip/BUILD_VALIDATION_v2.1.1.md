# Build validation — DHYRA Browser 2.1.1

- `versionName`: `2.1.1`
- `versionCode`: `16`
- `minSdk`: 26
- API 27+ navigation-bar light appearance is configured in `values-v27`.
- API 28+ display cutout mode is configured in `values-v28`.
- Android Lint remains enabled and strict.

Local validation: XML parsing, resource qualifier placement, and workflow/version consistency checks passed. Android Gradle compilation, lint execution, unit tests, APK packaging, and device testing were not run in this environment. A successful GitHub Actions run is required to claim the APK build is verified.
