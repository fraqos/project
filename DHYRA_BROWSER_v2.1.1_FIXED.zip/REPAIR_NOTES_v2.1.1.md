# DHYRA Browser v2.1.1 — Android API compatibility repair

## Changes
- Removed `android:windowLightNavigationBar` from the unqualified `values/styles.xml` and added it under `values-v27`.
- Removed `android:windowLayoutInDisplayCutoutMode` from the unqualified base theme and added it under `values-v28`.
- This keeps API-specific theme attributes out of the API 26 resource set while preserving their behavior on supported Android versions.
- Bumped `versionName` to `2.1.1` and `versionCode` to `16`.
- Updated the GitHub Actions workflow validation and artifact names to `2.1.1`.
- Kept lint strict (`abortOnError = true`).

## Validation performed
- Parsed every XML file in the project with Python's XML parser.
- Verified API 26 base styles do not contain the API 27/28 attributes.
- Verified the API 27 and API 28 resource overlays contain the intended attributes.
- Verified workflow version checks match the app version metadata.

## Important limitation
The supplied screenshot shows 3 lint errors and 12 warnings, but only the first lint failure is visible. This repair addresses the API-level resource error visible in the screenshot and the related API 28 cutout attribute. The remaining lint report is not included in the uploaded ZIP, and Android Gradle/Lint/APK builds could not be executed in this environment. Run GitHub Actions to confirm whether additional findings remain.
