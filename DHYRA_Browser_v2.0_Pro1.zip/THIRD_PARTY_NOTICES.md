# Third-Party Notices

DHYRA Browser depends on the following libraries and platform components. Review each upstream license and include required notices in any distributed build.

| Component | Purpose | License / notice |
|---|---|---|
| AndroidX Core / Activity / Lifecycle | Android platform integration | Apache License 2.0 |
| Jetpack Compose UI / Foundation / Material 3 | Declarative user interface | Apache License 2.0 |
| AndroidX DataStore | Preferences persistence | Apache License 2.0 |
| AndroidX WebKit | WebView compatibility APIs | Apache License 2.0 |
| Google Mobile Ads SDK | Internal app-owned ad placements | Google Mobile Ads SDK terms and policies |
| ZXing Core | QR-code generation | Apache License 2.0 |
| Kotlin | Programming language/runtime | Apache License 2.0 |
| Android System WebView | Web content engine supplied by Android/device vendor | Chromium / upstream component notices apply to the installed provider |

This table lists direct dependencies visible in the project build files. Gradle resolves transitive dependencies; generate and inspect a dependency/license report before a commercial release. No third-party source files are vendored into this archive.
