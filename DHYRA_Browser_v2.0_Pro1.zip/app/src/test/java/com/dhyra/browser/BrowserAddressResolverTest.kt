package com.dhyra.browser

import org.junit.Test

import com.dhyra.browser.core.nav.BrowserAddressResolver

class BrowserAddressResolverTest {
    fun runChecks() {
        check(BrowserAddressResolver.resolve("  ", "Google") == "https://www.google.com")
        check(BrowserAddressResolver.resolve("example.com", "Google") == "https://example.com")
        check(BrowserAddressResolver.resolve("hello world", "DuckDuckGo") == "https://duckduckgo.com/?q=hello+world")
        check(BrowserAddressResolver.resolve("javascript:alert(1)", "Google") == "https://www.google.com/search?q=javascript%3Aalert%281%29")
        check(BrowserAddressResolver.normalizeHomepage("file:///etc/passwd") == "https://www.google.com")
    }

    @Test
    fun junitSuite() = runChecks()

}
