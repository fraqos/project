package com.dhyra.browser

import com.dhyra.browser.monetization.AffiliateHelper
import com.dhyra.browser.monetization.MonetizationConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MonetizationConfigTest {
    @Test
    fun defaultSearchTagsDoNotInventAffiliateRevenue() {
        val input = "https://search.brave.com/search?q=browser"
        assertEquals(input, AffiliateHelper.tagSearchUrl("Brave", input))
        assertTrue(MonetizationConfig.searchTags.keys.containsAll(listOf("Brave", "DuckDuckGo", "Bing", "Google")))
    }

    @Test
    fun affiliateQueryParameterIsEncodedAndFragmentPreserved() {
        val tagged = AffiliateHelper.appendQueryParameter(
            "https://shop.example/deal?campaign=summer#details", "ref", "dhyra 20"
        )
        assertEquals("https://shop.example/deal?campaign=summer&ref=dhyra+20#details", tagged)
    }

    @Test
    fun affiliateParameterReplacesExistingValue() {
        val tagged = AffiliateHelper.appendQueryParameter("https://example.com/?ref=old", "ref", "new")
        assertEquals("https://example.com/?ref=new", tagged)
    }

    @Test
    fun disabledPartnerDealsAreNotPresentedAsLivePartners() {
        assertFalse(MonetizationConfig.partnerDeals.any { it.enabled })
        assertTrue(MonetizationConfig.partnerDeals.all { it.parameter.isEmpty() && it.value.isEmpty() })
    }
}
