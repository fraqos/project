package com.dhyra.browser.monetization

/**
 * Central monetization configuration. Google demo ad units are intentionally used for
 * development/CI. Replace these IDs only after creating a real AdMob app and ad units.
 * Affiliate identifiers are empty until DHYRA has an actual partner agreement.
 */
object MonetizationConfig {
    const val ADMOB_APPLICATION_ID = "ca-app-pub-3940256099942544~3347511713"
    const val NATIVE_AD_UNIT_ID = "ca-app-pub-3940256099942544/2247696110"
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
    const val INTERNAL_ADS_ENABLED = true

    data class SearchTag(
        val parameter: String = "",
        val value: String = ""
    )

    data class PartnerDeal(
        val id: String,
        val title: String,
        val category: String,
        val destinationUrl: String,
        val parameter: String = "",
        val value: String = "",
        val enabled: Boolean = false
    )

    /** Set parameter + value only when the search provider has issued DHYRA a tag. */
    val searchTags: Map<String, SearchTag> = mapOf(
        "Brave" to SearchTag(),
        "DuckDuckGo" to SearchTag(),
        "Bing" to SearchTag(),
        "Google" to SearchTag()
    )

    /**
     * Partner cards are intentionally disabled until the corresponding affiliate URLs/tags
     * are configured. This prevents a direct link from being misrepresented as a partnership.
     */
    val partnerDeals: List<PartnerDeal> = listOf(
        PartnerDeal("commerce-1", "Shop", "E-commerce", "https://www.tokopedia.com/"),
        PartnerDeal("travel-1", "Travel", "Travel", "https://www.traveloka.com/"),
        PartnerDeal("utility-1", "Utilities", "Utilities", "https://www.pln.co.id/")
    )
}
