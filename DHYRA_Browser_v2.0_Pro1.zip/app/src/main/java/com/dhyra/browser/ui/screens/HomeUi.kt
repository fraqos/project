@file:OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser.ui.screens

import com.dhyra.browser.*
import com.dhyra.browser.ui.theme.*
import com.dhyra.browser.ui.components.*
import com.dhyra.browser.monetization.AdBannerComponent
import com.dhyra.browser.monetization.MonetizationConfig

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * The start page. Zen, airy and one-handed: the greeting floats in open space at the top while
 * the speed dial and the search pill live at the bottom, inside the thumb zone. Short screens
 * scroll instead of clipping.
 */
@Composable
internal fun HomePage(
    isPrivate: Boolean,
    speedDial: List<Shortcut>,
    recent: List<SavedPage>,
    onOpenOmnibox: () -> Unit,
    onSite: (String) -> Unit,
    onRemoveSite: (Shortcut) -> Unit,
    onRecent: (String) -> Unit,
    tabCount: Int,
    onTabs: () -> Unit,
    onMenu: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val isDark = cs.background.luminance() < 0.5f
    val glow = if (isPrivate) PrivateText else cs.primary
    val dateLine = remember {
        SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()).uppercase(Locale.getDefault())
    }
    val greeting = remember { greetingForHour(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) }
    var removing by remember { mutableStateOf<Shortcut?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(cs.background, lerp(cs.background, glow, 0.05f))))
            .drawBehind {
                val radius = size.width * 0.95f
                val center = Offset(size.width * 0.5f, size.height * 0.18f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(glow.copy(alpha = if (isDark) 0.14f else 0.10f), Color.Transparent),
                        center = center,
                        radius = radius
                    ),
                    radius = radius,
                    center = center
                )
            }
            .statusBarsPadding()
    ) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val minHeight = maxHeight
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .heightIn(min = minHeight)
                    .padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Spacer(Modifier.height(44.dp))
                    Text(
                        text = if (isPrivate) "PRIVATE TAB" else dateLine,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Medium,
                        color = glow
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = if (isPrivate) "Browse quietly" else greeting,
                        fontSize = 34.sp,
                        lineHeight = 42.sp,
                        fontWeight = FontWeight.Light,
                        color = cs.onSurface
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = if (isPrivate) "Pages you visit here are not saved to history." else "Where to next?",
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        color = cs.onSurfaceVariant
                    )
                }

                Column {
                    Spacer(Modifier.height(28.dp))
                    SectionLabel("Speed dial")
                    if (speedDial.isEmpty()) {
                        Text(
                            text = "Add sites from the menu while you browse.",
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                            color = cs.onSurfaceVariant
                        )
                    } else {
                        speedDial.take(8).chunked(4).forEach { rowItems ->
                            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                                rowItems.forEach { site ->
                                    SpeedDialTile(
                                        site = site,
                                        isDark = isDark,
                                        modifier = Modifier.weight(1f),
                                        onClick = { onSite(site.url) },
                                        onLongClick = { removing = site }
                                    )
                                }
                                repeat(4 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }

                    if (!isPrivate && recent.isNotEmpty()) {
                        Spacer(Modifier.height(18.dp))
                        SectionLabel("Recently visited")
                        recent.take(3).forEach { entry ->
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onRecent(entry.url) }
                                    .padding(horizontal = 4.dp, vertical = 9.dp)
                            ) {
                                Text(
                                    text = entry.title.ifBlank { entry.url },
                                    fontSize = 15.sp,
                                    lineHeight = 22.sp,
                                    color = cs.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = siteLabelOf(entry.url),
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    val activePartners = MonetizationConfig.partnerDeals.filter {
                        it.enabled && it.parameter.isNotBlank() && it.value.isNotBlank()
                    }
                    if (!isPrivate && activePartners.isNotEmpty()) {
                        Spacer(Modifier.height(18.dp))
                        SectionLabel("Partner shortcuts")
                        activePartners.forEach { deal ->
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clickable {
                                    onSite(com.dhyra.browser.monetization.AffiliateHelper.tagPartnerUrl(deal))
                                },
                                shape = RoundedCornerShape(14.dp),
                                color = cs.surfaceVariant
                            ) {
                                Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(deal.title, color = cs.onSurface, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                        Text(deal.category, color = cs.onSurfaceVariant, fontSize = 12.sp)
                                    }
                                    Text("Partner", color = cs.primary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                    if (!isPrivate && MonetizationConfig.INTERNAL_ADS_ENABLED) {
                        Spacer(Modifier.height(18.dp))
                        AdBannerComponent(Modifier.fillMaxWidth())
                    }

                    Spacer(Modifier.height(22.dp))
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .clickable(onClick = onOpenOmnibox),
                        shape = RoundedCornerShape(28.dp),
                        color = cs.surfaceVariant,
                        border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.6f))
                    ) {
                        Row(
                            Modifier.padding(horizontal = 20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = cs.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = "Search or enter address",
                                fontSize = 16.sp,
                                lineHeight = 24.sp,
                                color = cs.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                }
            }
        }
        BottomNav(
            canBack = false,
            canForward = false,
            onBack = {},
            onForward = {},
            onHome = {},
            onTabs = onTabs,
            tabCount = tabCount,
            onMenu = onMenu
        )
    }

    removing?.let { site ->
        AlertDialog(
            onDismissRequest = { removing = null },
            containerColor = cs.surface,
            title = { Text("Remove ${site.label}?") },
            text = { Text("It will be removed from your speed dial.") },
            confirmButton = {
                TextButton(onClick = {
                    onRemoveSite(site)
                    removing = null
                }) { Text("Remove", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { removing = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SpeedDialTile(
    site: Shortcut,
    isDark: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val accent = tileColorFor(site.label)
    // Pastel accents read well on a tint, but the letter itself needs more contrast than the tile.
    val letter = if (isDark) lerp(accent, Color.White, 0.2f) else lerp(accent, Color.Black, 0.45f)
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(58.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(accent.copy(alpha = if (isDark) 0.22f else 0.24f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = monogramOf(site.label),
                fontSize = 22.sp,
                lineHeight = 28.sp,
                fontWeight = FontWeight.Medium,
                color = letter
            )
        }
        Spacer(Modifier.height(7.dp))
        Text(
            text = site.label,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            color = cs.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
internal fun SectionLabel(text: String) {
    Text(
        text = text.uppercase(),
        modifier = Modifier.padding(bottom = 10.dp),
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 1.5.sp,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
