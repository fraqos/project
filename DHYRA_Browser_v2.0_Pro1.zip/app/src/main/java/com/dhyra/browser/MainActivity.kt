@file:OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser

import com.dhyra.browser.core.nav.BrowserAddressResolver
import com.dhyra.browser.core.network.HttpsUpgrade
import com.dhyra.browser.ui.theme.*
import com.dhyra.browser.ui.components.*
import com.dhyra.browser.ui.screens.*
import com.dhyra.browser.monetization.AdManager

import android.content.Intent
import android.app.PictureInPictureParams
import android.content.ClipData
import android.content.ClipboardManager
import android.util.Rational
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.datastore.preferences.core.*
import com.dhyra.browser.core.nav.BackAction
import com.dhyra.browser.core.nav.BackContext
import com.dhyra.browser.core.nav.BackPolicy
import com.dhyra.browser.core.suggest.PageRef
import com.dhyra.browser.core.suggest.SmartSuggest
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    var pendingExternalUrl by mutableStateOf<String?>(null)
    var browserController: BrowserController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Keep the gesture/3-button bar fully transparent instead of adding a scrim.
            window.isNavigationBarContrastEnforced = false
        }
        acceptExternalIntent(intent)
        AdManager.initialize(this)
        setContent { DhyraApplication() }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && browserController?.isFullscreen == true) {
            runCatching {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        acceptExternalIntent(intent)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) browserController?.trimMemory()
    }

    private fun acceptExternalIntent(intent: Intent?) {
        if (intent == null) return
        pendingExternalUrl = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data?.takeIf {
                it.scheme.equals("http", true) || it.scheme.equals("https", true)
            }?.toString()
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_WEB_SEARCH -> intent.getStringExtra(android.app.SearchManager.QUERY)
            else -> null
        }?.takeIf { it.isNotBlank() }
    }
}

/**
 * Root of the UI. Responsibilities, in order: web-content callbacks (file chooser and
 * permissions), preferences, screen state and navigation, the omnibox, tabs, Back handling,
 * and finally the layered layout (screen, omnibox overlay, snackbar, sheets, dialogs).
 */
@Composable
private fun DhyraApplication() {
    val context = LocalContext.current
    val activity = context as MainActivity
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current

    val importBookmarksLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val imported = decodeEntries(raw)
                val existing = decodeEntries(context.dhyraStore.data.first()[BOOKMARKS_KEY] ?: "[]")
                val merged = (imported + existing).distinctBy { it.url }.take(500)
                context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries(merged) }
                Toast.makeText(context, "Imported ${imported.size} bookmark(s)", Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(context, "Could not import this bookmark file", Toast.LENGTH_LONG).show()
            }
        }
    }
    val exportBookmarksLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val latest = decodeEntries(context.dhyraStore.data.first()[BOOKMARKS_KEY] ?: "[]")
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(encodeEntries(latest)) }
                    ?: error("Unable to open export destination")
                Toast.makeText(context, "Exported ${latest.size} bookmark(s)", Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(context, "Could not export bookmarks", Toast.LENGTH_LONG).show()
            }
        }
    }

    var pendingFileChooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        pendingFileChooser?.onReceiveValue(uris.toTypedArray())
        pendingFileChooser = null
    }

    var pendingPermission by remember { mutableStateOf<PermissionRequest?>(null) }
    var showSitePermissionDialog by remember { mutableStateOf(false) }
    var pendingGeo by remember { mutableStateOf<Pair<String, GeolocationPermissions.Callback>?>(null) }
    var showGeoPermissionDialog by remember { mutableStateOf(false) }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val pending = pendingGeo
        if (pending != null) {
            val allowed = results.values.any { it }
            pending.second.invoke(pending.first, allowed, false)
        }
        pendingGeo = null
        showGeoPermissionDialog = false
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val request = pendingPermission
        if (request != null) {
            val granted = results.values.all { it }
            val supported = request.resources.filter {
                it == PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
                    it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
                    it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID
            }
            if (granted && supported.isNotEmpty()) runCatching { request.grant(supported.toTypedArray()) }
            else runCatching { request.deny() }
        }
        pendingPermission = null
        showSitePermissionDialog = false
    }

    val controller = remember(activity) {
        BrowserController(
            activity = activity,
            onFileChooser = { callback ->
                pendingFileChooser?.onReceiveValue(null)
                pendingFileChooser = callback
                filePicker.launch(arrayOf("*/*"))
            },
            onPermission = { request ->
                pendingPermission?.let { old -> runCatching { old.deny() } }
                pendingPermission = request
                showSitePermissionDialog = true
            },
            onGeolocation = { origin, callback ->
                pendingGeo?.second?.let { previous -> runCatching { previous.invoke(pendingGeo?.first.orEmpty(), false, false) } }
                pendingGeo = origin to callback
                showGeoPermissionDialog = true
            }
        )
    }

    // ---------- preferences and saved data ----------
    val prefs by context.dhyraStore.data.collectAsState(initial = emptyPreferences())
    val state = PreferencesState(
        homepage = prefs[HOME_KEY] ?: "",
        engine = prefs[ENGINE_KEY] ?: "Brave",
        theme = prefs[THEME_KEY] ?: "System",
        tracking = prefs[TRACKING_KEY] ?: true,
        popup = prefs[POPUP_KEY] ?: true,
        desktop = prefs[DESKTOP_KEY] ?: false,
        focusOnNewTab = prefs[FOCUS_NEW_TAB_KEY] ?: true,
        omniboxPosition = prefs[OMNIBOX_POSITION_KEY] ?: "Top"
    )
    val historyRaw = prefs[HISTORY_KEY] ?: "[]"
    val bookmarksRaw = prefs[BOOKMARKS_KEY] ?: "[]"
    val speedDialRaw = prefs[SPEED_DIAL_KEY]
    val history = remember(historyRaw) { decodeEntries(historyRaw) }
    val bookmarks = remember(bookmarksRaw) { decodeEntries(bookmarksRaw) }
    val speedDial = remember(speedDialRaw) { speedDialRaw?.let { decodeShortcuts(it) } ?: DEFAULT_SPEED_DIAL }
    val suggestIndex = remember(history, bookmarks) {
        SmartSuggest.buildIndex(
            history.map { PageRef(it.title, it.url) },
            bookmarks.map { PageRef(it.title, it.url) }
        )
    }

    // ---------- screen state ----------
    var route by remember { mutableStateOf(Route.HOME) }
    val routeStack = remember { mutableStateListOf<Route>() }
    var omniboxOpen by remember { mutableStateOf(false) }
    var omniboxValue by remember { mutableStateOf(TextFieldValue("")) }
    var showMenu by remember { mutableStateOf(false) }
    var showShields by remember { mutableStateOf(false) }
    var showQrDialog by remember { mutableStateOf(false) }
    var readerMode by remember { mutableStateOf(false) }
    var showFind by remember { mutableStateOf(false) }
    var findText by remember { mutableStateOf("") }
    var refreshDownloads by remember { mutableIntStateOf(0) }
    var focusAfterNewTab by remember { mutableStateOf(false) }
    var tabsStartPrivate by remember { mutableStateOf(false) }
    var initialized by remember { mutableStateOf(false) }
    val snackbarHost = remember { SnackbarHostState() }

    val isDark = when (state.theme) {
        "Dark", "AMOLED" -> true
        "Light" -> false
        else -> isSystemInDarkTheme()
    }
    SideEffect {
        val insets = WindowInsetsControllerCompat(activity.window, activity.window.decorView)
        insets.isAppearanceLightStatusBars = !isDark
        insets.isAppearanceLightNavigationBars = !isDark
    }

    controller.onPageFinished = { tab ->
        if (!tab.isPrivate && (tab.url.startsWith("https://") || tab.url.startsWith("http://"))) {
            scope.launch {
                val currentRaw = context.dhyraStore.data.first()[HISTORY_KEY] ?: "[]"
                val current = decodeEntries(currentRaw)
                val updated = (listOf(SavedPage(tab.title, tab.url)) + current.filterNot { it.url == tab.url }).take(5000)
                context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(updated) }
            }
        }
    }
    controller.onTabsChanged = { snapshot ->
        val json = JSONArray()
        snapshot.filter { !it.isPrivate && (it.url.startsWith("https://") || it.url.startsWith("http://")) }
            .takeLast(30).forEach { tab ->
                json.put(JSONObject().put("url", tab.url).put("title", tab.title))
            }
        scope.launch { context.dhyraStore.edit { it[SESSION_KEY] = json.toString() } }
    }
    activity.browserController = controller

    LaunchedEffect(controller) {
        if (controller.tabs.isEmpty()) {
            val persisted = context.dhyraStore.data.first()[SESSION_KEY] ?: "[]"
            val restored = decodeSession(persisted)
            if (restored.isNotEmpty()) controller.restoreSession(restored)
            // Always land on a clean start page; restored tabs wait in the tab switcher.
            controller.createTab()
        }
        initialized = true
    }
    LaunchedEffect(state.tracking, state.popup, state.desktop) {
        controller.applySettings(state.tracking, state.popup, state.desktop)
    }
    DisposableEffect(controller) {
        onDispose {
            pendingFileChooser?.onReceiveValue(null)
            controller.destroy()
            activity.browserController = null
        }
    }

    val activeTab = controller.activeTab()
    // A blank tab without a WebView is the start page, whatever route was requested.
    val contentRoute = when {
        route != Route.BROWSER -> route
        activeTab == null -> Route.HOME
        isBlankPage(activeTab.url) && !controller.hasWebView(activeTab.id) -> Route.HOME
        else -> Route.BROWSER
    }

    // ---------- IME policy: the page must not jump while the omnibox is typing ----------
    val imeVisible = WindowInsets.isImeVisible
    var imeLockedByOmnibox by remember { mutableStateOf(false) }
    LaunchedEffect(omniboxOpen) { if (omniboxOpen) imeLockedByOmnibox = true }
    LaunchedEffect(imeVisible, omniboxOpen) {
        if (!imeVisible && !omniboxOpen) imeLockedByOmnibox = false
    }
    val resizeForIme = !imeLockedByOmnibox

    // ---------- helpers ----------
    fun saveValue(key: String, value: Any) {
        scope.launch {
            context.dhyraStore.edit { p ->
                when (value) {
                    is String -> p[stringPreferencesKey(key)] = value
                    is Boolean -> p[booleanPreferencesKey(key)] = value
                }
            }
        }
    }

    /** Desktop site flips immediately: the page reloads now and the saved preference follows. */
    fun toggleDesktop() {
        val next = !state.desktop
        controller.applySettings(state.tracking, state.popup, next)
        saveValue("desktop_mode", next)
    }

    fun go(target: Route) {
        if (target == route) return
        routeStack.add(route)
        route = target
    }

    fun resetTo(target: Route) {
        routeStack.clear()
        route = target
    }

    fun popRoute(): Boolean {
        if (routeStack.isEmpty()) return false
        route = routeStack.removeAt(routeStack.size - 1)
        return true
    }

    fun closeFind() {
        showFind = false
        findText = ""
        controller.clearFind()
    }

    fun closeOmnibox() {
        omniboxOpen = false
        focusManager.clearFocus()
        keyboard?.hide()
    }

    fun openOmnibox(prefill: String) {
        omniboxValue = TextFieldValue(prefill, TextRange(0, prefill.length))
        omniboxOpen = true
    }

    fun openTarget(raw: String, newTab: Boolean = false, isPrivate: Boolean = false) {
        val target = BrowserAddressResolver.resolve(raw, state.engine)
        closeOmnibox()
        if (newTab || controller.activeTabId == -1) controller.createTab(target, isPrivate)
        else controller.navigate(target)
        resetTo(Route.BROWSER)
    }

    fun submitOmnibox() {
        if (omniboxValue.text.isBlank()) closeOmnibox() else openTarget(omniboxValue.text)
    }

    /** Typing forward completes the best host inline (the completion stays selected, so Backspace removes it). */
    fun onOmniboxChange(new: TextFieldValue) {
        val previous = omniboxValue
        val typedPart = previous.text.substring(0, previous.selection.min.coerceIn(0, previous.text.length))
        val typedForward = new.selection.collapsed &&
            new.selection.start == new.text.length &&
            new.text.length > typedPart.length &&
            new.text.startsWith(typedPart)
        omniboxValue = new
        if (typedForward) {
            val completion = SmartSuggest.inlineCompletion(new.text, suggestIndex)
            if (completion != null) {
                omniboxValue = TextFieldValue(completion, TextRange(new.text.length, completion.length))
            }
        }
    }

    fun openTabs() {
        controller.captureThumbnail()
        tabsStartPrivate = controller.activeTab()?.isPrivate == true
        go(Route.TABS)
    }

    fun goHome() {
        if (contentRoute == Route.HOME) return
        val custom = state.homepage
        if (custom.isNotBlank()) controller.navigate(custom) else go(Route.HOME)
    }

    /** Reuses an untouched start-page tab; otherwise opens a new tab whose parent is the current one. */
    fun newTab(isPrivate: Boolean) {
        val current = controller.activeTab()
        val reusable = current != null &&
            isBlankPage(current.url) &&
            !controller.hasWebView(current.id) &&
            current.isPrivate == isPrivate
        if (!reusable) {
            val parent = controller.activeTabId.takeIf { it != -1 }
            controller.createTab(isPrivate = isPrivate, parentId = parent)
        }
        resetTo(Route.BROWSER)
        if (state.focusOnNewTab) focusAfterNewTab = true
    }

    fun closeAllWithUndo(privateGroup: Boolean) {
        val closing = controller.tabs.filter { it.isPrivate == privateGroup }
        if (closing.isEmpty()) return
        val restorable: List<Pair<String, String>> = if (privateGroup) {
            emptyList()
        } else {
            closing.filter { it.url.startsWith("http") }.map { it.url to it.title }
        }
        val count = closing.size
        controller.closeAllTabs(onlyPrivate = privateGroup)
        resetTo(Route.BROWSER)
        scope.launch {
            snackbarHost.currentSnackbarData?.dismiss()
            val result = snackbarHost.showSnackbar(
                message = if (count == 1) "1 tab closed" else "$count tabs closed",
                actionLabel = if (restorable.isEmpty()) null else "Undo",
                duration = SnackbarDuration.Long
            )
            if (result == SnackbarResult.ActionPerformed && restorable.isNotEmpty()) {
                controller.restoreClosedTabs(restorable)
                resetTo(Route.BROWSER)
            }
        }
    }

    fun addBookmark() {
        val tab = controller.activeTab() ?: return
        if (!tab.url.startsWith("http")) return
        scope.launch {
            val latestRaw = context.dhyraStore.data.first()[BOOKMARKS_KEY] ?: "[]"
            val latest = decodeEntries(latestRaw).filterNot { it.url == tab.url }
            context.dhyraStore.edit {
                it[BOOKMARKS_KEY] = encodeEntries((listOf(SavedPage(tab.title, tab.url)) + latest).take(500))
            }
        }
        Toast.makeText(context, "Bookmark added", Toast.LENGTH_SHORT).show()
    }

    fun addSpeedDial() {
        val tab = controller.activeTab() ?: return
        val host = runCatching { Uri.parse(tab.url).host }.getOrNull()?.removePrefix("www.") ?: return
        if (!tab.url.startsWith("http")) return
        val site = "https://$host"
        if (speedDial.any { it.url.equals(site, true) }) {
            Toast.makeText(context, "Already in your speed dial", Toast.LENGTH_SHORT).show()
            return
        }
        if (speedDial.size >= 8) {
            Toast.makeText(context, "Speed dial is full. Long-press a site to remove it.", Toast.LENGTH_LONG).show()
            return
        }
        val label = tab.title.takeIf { it.isNotBlank() && it.length <= 14 } ?: host
        val updated = speedDial + Shortcut(label, site)
        scope.launch { context.dhyraStore.edit { it[SPEED_DIAL_KEY] = encodeShortcuts(updated) } }
        Toast.makeText(context, "Added to speed dial", Toast.LENGTH_SHORT).show()
    }

    fun removeSpeedDial(site: Shortcut) {
        val updated = speedDial.filterNot { it.url == site.url }
        scope.launch { context.dhyraStore.edit { it[SPEED_DIAL_KEY] = encodeShortcuts(updated) } }
    }

    fun translatePage() {
        val url = controller.activeTab()?.url?.takeUnless { isBlankPage(it) } ?: return
        openTarget("https://translate.google.com/translate?sl=auto&tl=en&u=${Uri.encode(url)}", newTab = true)
    }

    fun toggleReaderMode() {
        readerMode = !readerMode
        controller.setReaderMode(readerMode)
    }

    fun printPage() { controller.printCurrentPage() }

    fun burnPrivateSession() {
        controller.closeAllTabs(onlyPrivate = true)
        resetTo(Route.BROWSER)
        Toast.makeText(context, "Private session cleared", Toast.LENGTH_SHORT).show()
    }

    fun sharePage() {
        val url = controller.activeTab()?.url?.takeUnless { isBlankPage(it) } ?: return
        val share = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url)
        context.startActivity(Intent.createChooser(share, "Share page"))
    }

    // An external link reuses the untouched start-page tab, otherwise it gets its own tab.
    LaunchedEffect(activity.pendingExternalUrl, initialized) {
        val incoming = activity.pendingExternalUrl
        if (initialized && !incoming.isNullOrBlank()) {
            activity.pendingExternalUrl = null
            val current = controller.activeTab()
            val reuse = current != null &&
                isBlankPage(current.url) &&
                !controller.hasWebView(current.id) &&
                !current.isPrivate
            openTarget(incoming, newTab = !reuse)
        }
    }

    // After a deliberate "new tab", wait out the transition and open the keyboard. The flag is
    // always cleared so the keyboard can never pop up later for a request that already expired.
    LaunchedEffect(focusAfterNewTab, contentRoute) {
        if (focusAfterNewTab) {
            if (contentRoute == Route.HOME) {
                delay(260)
                openOmnibox("")
            }
            focusAfterNewTab = false
        }
    }
    LaunchedEffect(contentRoute, controller.activeTabId) {
        if (showFind && contentRoute != Route.BROWSER) closeFind()
    }

    // ---------- omnibox suggestions ----------
    // Suggestions follow what was actually typed, not the inline completion that follows it.
    val typedText = omniboxValue.text.substring(
        0,
        omniboxValue.selection.min.coerceIn(0, omniboxValue.text.length)
    )
    val omniItems = remember(typedText, suggestIndex, activeTab?.url) {
        buildOmniItems(typedText, activeTab?.url.orEmpty(), suggestIndex)
    }
    val pageSecure: Boolean? = activeTab?.url?.let {
        when {
            it.startsWith("https://") -> true
            it.startsWith("http://") -> false
            else -> null
        }
    }

    // ---------- Back: Chromium-style priority ----------
    fun currentBackAction(): BackAction = BackPolicy.decide(
        BackContext(
            omniboxOpen = omniboxOpen,
            findOpen = showFind && contentRoute == Route.BROWSER,
            hasScreenToPop = routeStack.isNotEmpty(),
            fullscreen = controller.isFullscreen,
            onBrowserPage = contentRoute == Route.BROWSER,
            canGoBack = controller.canGoBack(),
            hasParentTab = controller.parentOfActive() != null
        )
    )
    BackHandler(enabled = currentBackAction() != BackAction.SYSTEM) {
        when (currentBackAction()) {
            BackAction.CLOSE_OMNIBOX -> closeOmnibox()
            BackAction.CLOSE_FIND -> closeFind()
            BackAction.POP_SCREEN -> popRoute()
            BackAction.EXIT_FULLSCREEN -> controller.exitFullscreen()
            BackAction.WEB_BACK -> controller.goBack()
            BackAction.CLOSE_TAB_TO_PARENT -> {
                controller.closeActiveTabToParent()
                resetTo(Route.BROWSER)
            }
            BackAction.GO_TO_START_PAGE -> resetTo(Route.HOME)
            BackAction.SYSTEM -> Unit
        }
    }

    // ---------- layout ----------
    DhyraTheme(state.theme) {
        val cs = MaterialTheme.colorScheme
        Box(Modifier.fillMaxSize().background(cs.background)) {
            AnimatedContent(
                targetState = contentRoute,
                modifier = Modifier.fillMaxSize(),
                transitionSpec = {
                    (fadeIn(animationSpec = tween(220, delayMillis = 40)) +
                        scaleIn(initialScale = 0.96f, animationSpec = tween(220, delayMillis = 40)))
                        .togetherWith(fadeOut(animationSpec = tween(120)))
                },
                label = "screen"
            ) { target ->
                when (target) {
                    Route.HOME -> HomePage(
                        isPrivate = activeTab?.isPrivate == true,
                        speedDial = speedDial,
                        recent = history,
                        onOpenOmnibox = { openOmnibox("") },
                        onSite = { url -> openTarget(url) },
                        onRemoveSite = { site -> removeSpeedDial(site) },
                        onRecent = { url -> openTarget(url) },
                        tabCount = controller.tabs.size,
                        onTabs = { openTabs() },
                        onMenu = { showMenu = true }
                    )

                    Route.BROWSER -> BrowserPage(
                        controller = controller,
                        desktop = state.desktop,
                        omniboxPosition = state.omniboxPosition,
                        resizeForIme = resizeForIme,
                        imeVisible = imeVisible,
                        showFind = showFind,
                        findText = findText,
                        onFindChange = { text ->
                            findText = text
                            controller.find(text)
                        },
                        onFindClose = { closeFind() },
                        onOpenOmnibox = {
                            openOmnibox(activeTab?.url.orEmpty().takeUnless { isBlankPage(it) } ?: "")
                        },
                        onShields = { showShields = true },
                        onToggleDesktop = { toggleDesktop() },
                        onHome = { goHome() },
                        onTabs = { openTabs() },
                        onMenu = { showMenu = true },
                        onSwipeTabs = { direction -> controller.selectRelativeTab(direction) }
                    )

                    Route.TABS -> TabsScreen(
                        controller = controller,
                        startOnPrivate = tabsStartPrivate,
                        onBack = { if (!popRoute()) resetTo(Route.BROWSER) },
                        onSelect = { id ->
                            controller.selectTab(id)
                            resetTo(Route.BROWSER)
                        },
                        onClose = { id -> controller.closeTab(id) },
                        onNew = { privateTab -> newTab(privateTab) },
                        onCloseAll = { privateGroup -> closeAllWithUndo(privateGroup) }
                    )

                    Route.SETTINGS -> SettingsScreen(
                        state = state,
                        onBack = { if (!popRoute()) resetTo(Route.HOME) },
                        onSave = { key, value -> saveValue(key, value) },
                        onClear = {
                            controller.clearRegularData()
                            scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                        },
                        onSetDefaultBrowser = { requestDefaultBrowserRole(activity) },
                        onAbout = { go(Route.ABOUT) }
                    )

                    Route.BOOKMARKS -> EntriesScreen(
                        title = "Bookmarks",
                        entries = bookmarks,
                        emptyText = "No bookmarks yet",
                        onBack = { if (!popRoute()) resetTo(Route.HOME) },
                        onOpen = { url -> openTarget(url) },
                        onDelete = { url ->
                            scope.launch {
                                val remaining = bookmarks.filterNot { it.url == url }
                                context.dhyraStore.edit { it[BOOKMARKS_KEY] = encodeEntries(remaining) }
                            }
                        },
                        onImport = { importBookmarksLauncher.launch(arrayOf("application/json", "text/json", "text/*")) },
                        onExport = { exportBookmarksLauncher.launch("DHYRA-bookmarks.json") }
                    )

                    Route.HISTORY -> EntriesScreen(
                        title = "History",
                        entries = history,
                        emptyText = "No history yet",
                        onBack = { if (!popRoute()) resetTo(Route.HOME) },
                        onOpen = { url -> openTarget(url) },
                        onDelete = { url ->
                            scope.launch {
                                val remaining = history.filterNot { it.url == url }
                                context.dhyraStore.edit { it[HISTORY_KEY] = encodeEntries(remaining) }
                            }
                        },
                        onClearAll = {
                            scope.launch { context.dhyraStore.edit { it.remove(HISTORY_KEY) } }
                        }
                    )

                    Route.DOWNLOADS -> DownloadsScreen(
                        onBack = { if (!popRoute()) resetTo(Route.HOME) },
                        refreshKey = refreshDownloads
                    )
                    Route.ABOUT -> AboutScreen(onBack = { if (!popRoute()) resetTo(Route.SETTINGS) })
                }
            }

            OmniboxOverlay(
                visible = omniboxOpen,
                value = omniboxValue,
                onValueChange = { onOmniboxChange(it) },
                items = omniItems,
                secure = pageSecure,
                position = state.omniboxPosition,
                onSubmit = { submitOmnibox() },
                onPick = { item -> openTarget(item.target()) },
                onFill = { item ->
                    val text = item.fillText()
                    omniboxValue = TextFieldValue(text, TextRange(text.length))
                },
                onDismiss = { closeOmnibox() }
            )

            SnackbarHost(
                hostState = snackbarHost,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 68.dp)
            ) { data ->
                Snackbar(
                    snackbarData = data,
                    shape = RoundedCornerShape(16.dp),
                    containerColor = cs.surfaceVariant,
                    contentColor = cs.onSurface,
                    actionColor = cs.primary
                )
            }
        }

        if (showMenu) {
            MenuSheet(
                inPage = contentRoute == Route.BROWSER,
                isPrivate = activeTab?.isPrivate == true,
                desktop = state.desktop,
                readerMode = readerMode,
                onDismiss = { showMenu = false },
                onToggleDesktop = { toggleDesktop() },
                onNewTab = { newTab(false) },
                onNewPrivate = { newTab(true) },
                onFind = { showFind = true },
                onTranslate = { translatePage() },
                onReader = { toggleReaderMode() },
                onPrint = { printPage() },
                onQr = { showQrDialog = true },
                onBurnPrivate = { burnPrivateSession() },
                onBookmark = { addBookmark() },
                onShare = { sharePage() },
                onAddSpeedDial = { addSpeedDial() },
                onBookmarks = { go(Route.BOOKMARKS) },
                onHistory = { go(Route.HISTORY) },
                onDownloads = {
                    refreshDownloads++
                    go(Route.DOWNLOADS)
                },
                onSettings = { go(Route.SETTINGS) }
            )
        }

        if (showShields) {
            ShieldsSheet(
                siteLabel = siteLabelOf(activeTab?.url),
                blocked = controller.blockedRequestCount(controller.activeTabId),
                savedBytes = controller.estimatedDataSavedBytes(controller.activeTabId),
                tracking = state.tracking,
                shieldsEnabled = controller.shieldsEnabledForActiveSite(),
                popup = state.popup,
                onDismiss = { showShields = false },
                onSiteShieldsChange = { enabled -> controller.setShieldsEnabledForActiveSite(enabled) },
                onSave = { key, value -> saveValue(key, value) }
            )
        }

        if (showQrDialog) {
            val qrUrl = activeTab?.url?.takeUnless { isBlankPage(it) }.orEmpty()
            AlertDialog(
                onDismissRequest = { showQrDialog = false },
                containerColor = cs.surface,
                title = { Text("Share page QR code") },
                text = {
                    if (qrUrl.isNotBlank()) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(
                                bitmap = remember(qrUrl) { makeQr(qrUrl) }.asImageBitmap(),
                                contentDescription = "QR code for the current page",
                                modifier = Modifier.size(220.dp)
                            )
                            Text(qrUrl, color = cs.onSurfaceVariant, fontSize = 12.sp, maxLines = 2)
                        }
                    } else Text("Open a web page to create its QR code.")
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (qrUrl.isNotBlank()) {
                            val clipboard = context.getSystemService(ClipboardManager::class.java)
                            clipboard?.setPrimaryClip(ClipData.newPlainText("DHYRA link", qrUrl))
                        }
                        showQrDialog = false
                    }) { Text("Copy link") }
                },
                dismissButton = { TextButton(onClick = { showQrDialog = false }) { Text("Close") } }
            )
        }

        if (showSitePermissionDialog && pendingPermission != null) {
            val request = pendingPermission
            val origin = request?.origin?.toString() ?: "This website"
            val requestedResources = request?.resources?.joinToString { resource ->
                when (resource) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "camera"
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "microphone"
                    PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID -> "protected media / DRM"
                    else -> "unsupported resource"
                }
            } ?: "device resources"
            AlertDialog(
                containerColor = cs.surface,
                onDismissRequest = {
                    runCatching { request?.deny() }
                    pendingPermission = null
                    showSitePermissionDialog = false
                },
                title = { Text("Allow site permission?") },
                text = { Text("$origin is requesting: $requestedResources. Only approve sites you trust.") },
                confirmButton = {
                    TextButton(onClick = {
                        val current = pendingPermission
                        val resources = current?.resources.orEmpty()
                        val runtimePermissions = buildList {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in resources) add(android.Manifest.permission.CAMERA)
                            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in resources) add(android.Manifest.permission.RECORD_AUDIO)
                        }
                        if (runtimePermissions.isNotEmpty()) {
                            permissionLauncher.launch(runtimePermissions.distinct().toTypedArray())
                        } else {
                            val supported = resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }
                            if (supported.isNotEmpty()) runCatching { current?.grant(supported.toTypedArray()) }
                            else runCatching { current?.deny() }
                            pendingPermission = null
                            showSitePermissionDialog = false
                        }
                    }) { Text("Allow") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        runCatching { request?.deny() }
                        pendingPermission = null
                        showSitePermissionDialog = false
                    }) { Text("Block") }
                }
            )
        }

        if (showGeoPermissionDialog && pendingGeo != null) {
            val (origin, callback) = pendingGeo!!
            AlertDialog(
                containerColor = cs.surface,
                onDismissRequest = {
                    runCatching { callback.invoke(origin, false, false) }
                    pendingGeo = null
                    showGeoPermissionDialog = false
                },
                title = { Text("Allow location access?") },
                text = { Text("$origin is requesting your device location. This request is not saved for future visits.") },
                confirmButton = {
                    TextButton(onClick = {
                        val fineGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        val coarseGranted = activity.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        if (fineGranted || coarseGranted) {
                            runCatching { callback.invoke(origin, true, false) }
                            pendingGeo = null
                            showGeoPermissionDialog = false
                        } else {
                            locationLauncher.launch(arrayOf(
                                android.Manifest.permission.ACCESS_FINE_LOCATION,
                                android.Manifest.permission.ACCESS_COARSE_LOCATION
                            ))
                        }
                    }) { Text("Allow once") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        runCatching { callback.invoke(origin, false, false) }
                        pendingGeo = null
                        showGeoPermissionDialog = false
                    }) { Text("Block") }
                }
            )
        }
    }
}
