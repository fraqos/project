package com.dhyra.browser

import android.app.DownloadManager
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.ui.graphics.Color
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import org.json.JSONArray
import org.json.JSONObject

internal val Context.dhyraStore by preferencesDataStore(name = "dhyra_settings")

internal val HOME_KEY = stringPreferencesKey("homepage")
internal val ENGINE_KEY = stringPreferencesKey("search_engine")
internal val THEME_KEY = stringPreferencesKey("theme")
internal val TRACKING_KEY = booleanPreferencesKey("tracking_protection")
internal val POPUP_KEY = booleanPreferencesKey("popup_blocker")
internal val DESKTOP_KEY = booleanPreferencesKey("desktop_mode")
internal val FOCUS_NEW_TAB_KEY = booleanPreferencesKey("focus_on_new_tab")
internal val OMNIBOX_POSITION_KEY = stringPreferencesKey("omnibox_position")
internal val SESSION_KEY = stringPreferencesKey("session_json")
internal val HISTORY_KEY = stringPreferencesKey("history_json")
internal val BOOKMARKS_KEY = stringPreferencesKey("bookmarks_json")
internal val SPEED_DIAL_KEY = stringPreferencesKey("speed_dial_json")

internal const val ABOUT_BLANK = "about:blank"

internal val ENGINE_OPTIONS = listOf("Brave", "Google", "Bing", "DuckDuckGo", "Ecosia", "Startpage", "Qwant")
internal val THEME_OPTIONS = listOf("System", "Dynamic", "Light", "Dark", "AMOLED")

internal enum class Route { HOME, BROWSER, SETTINGS, TABS, BOOKMARKS, HISTORY, DOWNLOADS, ABOUT }

internal data class PreferencesState(
    /** Empty means the DHYRA start page. */
    val homepage: String,
    val engine: String,
    val theme: String,
    val tracking: Boolean,
    val popup: Boolean,
    val desktop: Boolean,
    val focusOnNewTab: Boolean,
    val omniboxPosition: String
)

internal data class SavedPage(val title: String, val url: String, val timestamp: Long = System.currentTimeMillis())
internal data class Shortcut(val label: String, val url: String)
internal data class DownloadRow(val id: Long, val title: String, val status: String, val total: Long, val downloaded: Long)

internal val DEFAULT_SPEED_DIAL = listOf(
    Shortcut("Google", "https://www.google.com"),
    Shortcut("YouTube", "https://m.youtube.com"),
    Shortcut("Wikipedia", "https://wikipedia.org"),
    Shortcut("GitHub", "https://github.com"),
    Shortcut("Reddit", "https://www.reddit.com"),
    Shortcut("Telegram", "https://web.telegram.org"),
    Shortcut("DuckDuckGo", "https://duckduckgo.com"),
    Shortcut("Bing", "https://www.bing.com")
)

// ---------- address helpers ----------

/** Host without "www.", "New tab" for a blank page, or the raw text when it is not a URL. */
internal fun siteLabelOf(url: String?): String {
    if (url.isNullOrBlank() || url == ABOUT_BLANK) return "New tab"
    return runCatching { Uri.parse(url).host }.getOrNull()?.removePrefix("www.") ?: url
}

internal fun isBlankPage(url: String?): Boolean = url.isNullOrBlank() || url == ABOUT_BLANK

// ---------- monogram tiles ----------

private val TileColors = listOf(
    Color(0xFF6FB4AC), Color(0xFFA99BD6), Color(0xFFE0A07D), Color(0xFF86BE82),
    Color(0xFFD98AA0), Color(0xFF7F9FDB), Color(0xFFCDB968), Color(0xFF98A4B1)
)

internal fun tileColorFor(key: String): Color =
    TileColors[(key.lowercase().hashCode() and 0x7FFFFFFF) % TileColors.size]

internal fun monogramOf(label: String): String =
    label.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "•"

internal fun greetingForHour(hour: Int): String = when (hour) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..20 -> "Good evening"
    else -> "Good night"
}

// ---------- persistence codecs ----------

internal fun decodeEntries(raw: String): List<SavedPage> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val obj = array.optJSONObject(index) ?: return@mapNotNull null
        val url = obj.optString("url")
        if (url.isBlank()) null else SavedPage(
            title = obj.optString("title", url),
            url = url,
            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
        )
    }
}.getOrDefault(emptyList())

internal fun encodeEntries(entries: List<SavedPage>): String {
    val array = JSONArray()
    entries.forEach { entry ->
        array.put(JSONObject().put("title", entry.title).put("url", entry.url).put("timestamp", entry.timestamp))
    }
    return array.toString()
}

internal fun decodeShortcuts(raw: String): List<Shortcut>? = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val obj = array.optJSONObject(index) ?: return@mapNotNull null
        val url = obj.optString("url")
        if (!url.startsWith("https://", true) && !url.startsWith("http://", true)) null
        else Shortcut(obj.optString("label").ifBlank { siteLabelOf(url) }, url)
    }
}.getOrNull()

internal fun encodeShortcuts(items: List<Shortcut>): String {
    val array = JSONArray()
    items.forEach { array.put(JSONObject().put("label", it.label).put("url", it.url)) }
    return array.toString()
}

internal fun decodeSession(raw: String): List<Pair<String, String>> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val item = array.optJSONObject(index) ?: return@mapNotNull null
        val url = item.optString("url")
        if (url.startsWith("https://", true) || url.startsWith("http://", true)) {
            url to item.optString("title", url)
        } else null
    }
}.getOrDefault(emptyList())

// ---------- downloads, QR and system helpers ----------

internal fun statusLabel(status: Int): String = when (status) {
    DownloadManager.STATUS_PENDING -> "Pending"
    DownloadManager.STATUS_RUNNING -> "Downloading"
    DownloadManager.STATUS_PAUSED -> "Paused"
    DownloadManager.STATUS_SUCCESSFUL -> "Completed"
    DownloadManager.STATUS_FAILED -> "Failed"
    else -> "Unknown"
}

internal fun formatBytes(value: Long): String {
    if (value < 1024) return "$value B"
    if (value < 1024 * 1024) return "%.1f KB".format(value / 1024f)
    return "%.1f MB".format(value / (1024f * 1024f))
}

internal fun makeQr(payload: String): Bitmap {
    val matrix = com.google.zxing.qrcode.QRCodeWriter().encode(payload, com.google.zxing.BarcodeFormat.QR_CODE, 560, 560)
    return Bitmap.createBitmap(560, 560, Bitmap.Config.ARGB_8888).also { bmp ->
        for (x in 0 until 560) for (y in 0 until 560) {
            bmp.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
}

internal fun requestDefaultBrowserRole(activity: MainActivity) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val manager = activity.getSystemService(RoleManager::class.java)
            if (manager != null && manager.isRoleAvailable(RoleManager.ROLE_BROWSER)) {
                activity.startActivity(manager.createRequestRoleIntent(RoleManager.ROLE_BROWSER))
            } else {
                activity.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            }
        } else {
            activity.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        }
    } catch (_: Exception) {
        runCatching { activity.startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
}
