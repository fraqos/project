package com.dhyra.browser.monetization

import android.graphics.Color as AndroidColor
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.AdChoicesView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

/**
 * Native ad slot for DHYRA-owned UI only. It is hosted by Home/Downloads screens and is never
 * attached to or injected into the WebView displaying a third-party website.
 */
@Composable
fun AdBannerComponent(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val container = remember { mutableStateOf<FrameLayout?>(null) }
    val loaded = remember { mutableStateOf(false) }
    val nativeAd = remember { mutableStateOf<NativeAd?>(null) }

    AndroidView(
        modifier = modifier.fillMaxWidth().heightIn(min = if (loaded.value) 112.dp else 0.dp),
        factory = { ctx -> FrameLayout(ctx).apply { container.value = this } }
    )

    LaunchedEffect(context) {
        if (!MonetizationConfig.INTERNAL_ADS_ENABLED) return@LaunchedEffect
        AdManager.initialize(context)
        AdLoader.Builder(context, MonetizationConfig.NATIVE_AD_UNIT_ID)
            .forNativeAd { ad ->
                nativeAd.value?.destroy()
                nativeAd.value = ad
                loaded.value = true
                container.value?.let { host -> renderNativeAd(host, ad) }
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    // Keep the internal slot collapsed when no test ad is returned.
                    loaded.value = false
                    container.value?.removeAllViews()
                }
            })
            .build()
            .loadAd(AdRequest.Builder().build())
    }

    DisposableEffect(Unit) {
        onDispose {
            nativeAd.value?.destroy()
            nativeAd.value = null
            loaded.value = false
            container.value?.removeAllViews()
            container.value = null
        }
    }
}

private fun renderNativeAd(host: FrameLayout, ad: NativeAd) {
    val context = host.context
    val adView = NativeAdView(context)
    val panel = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 18, 24, 18)
        setBackgroundColor(AndroidColor.rgb(236, 241, 240))
    }
    val sponsored = TextView(context).apply {
        text = "SPONSORED"
        textSize = 10f
        setTextColor(AndroidColor.rgb(65, 89, 85))
        letterSpacing = 0.08f
    }
    val headline = TextView(context).apply {
        textSize = 16f
        setTextColor(AndroidColor.rgb(20, 32, 31))
        setPadding(0, 4, 0, 4)
    }
    val body = TextView(context).apply {
        textSize = 13f
        setTextColor(AndroidColor.rgb(75, 88, 86))
        setPadding(0, 0, 0, 8)
    }
    val callToAction = Button(context).apply {
        textSize = 12f
        isAllCaps = false
        gravity = Gravity.CENTER
    }
    val adChoices = AdChoicesView(context)
    val labelRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(sponsored, LinearLayout.LayoutParams(0, -2, 1f))
        addView(adChoices, LinearLayout.LayoutParams(24, 24))
    }
    panel.addView(labelRow)
    panel.addView(headline)
    panel.addView(body)
    panel.addView(callToAction)
    adView.addView(panel, FrameLayout.LayoutParams(-1, -2))
    adView.adChoicesView = adChoices
    adView.headlineView = headline
    adView.bodyView = body
    adView.callToActionView = callToAction
    headline.text = ad.headline
    body.text = ad.body.orEmpty()
    body.visibility = if (ad.body.isNullOrBlank()) android.view.View.GONE else android.view.View.VISIBLE
    callToAction.text = ad.callToAction.orEmpty()
    callToAction.visibility = if (ad.callToAction.isNullOrBlank()) android.view.View.GONE else android.view.View.VISIBLE
    adView.setNativeAd(ad)
    host.removeAllViews()
    host.addView(adView, FrameLayout.LayoutParams(-1, -2))
}
