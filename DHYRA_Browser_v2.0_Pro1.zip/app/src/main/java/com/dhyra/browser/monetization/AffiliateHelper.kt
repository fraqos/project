package com.dhyra.browser.monetization

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/** URL-safe tagging helpers; no tag is added unless a real partner parameter/value is supplied. */
object AffiliateHelper {
    fun tagSearchUrl(engine: String, url: String): String {
        val tag = MonetizationConfig.searchTags.entries
            .firstOrNull { it.key.equals(engine, ignoreCase = true) }?.value ?: return url
        return appendQueryParameter(url, tag.parameter, tag.value)
    }

    fun tagPartnerUrl(deal: MonetizationConfig.PartnerDeal): String =
        if (deal.enabled) appendQueryParameter(deal.destinationUrl, deal.parameter, deal.value)
        else deal.destinationUrl

    fun appendQueryParameter(url: String, parameter: String, value: String): String {
        val key = parameter.trim()
        val content = value.trim()
        if (key.isEmpty() || content.isEmpty()) return url
        if (!key.matches(Regex("[A-Za-z0-9_.~-]{1,80}"))) return url

        val fragmentAt = url.indexOf('#')
        val head = if (fragmentAt >= 0) url.substring(0, fragmentAt) else url
        val fragment = if (fragmentAt >= 0) url.substring(fragmentAt) else ""
        val encodedKey = encode(key)
        val encodedValue = encode(content)
        val queryAt = head.indexOf('?')
        val base = if (queryAt >= 0) head.substring(0, queryAt) else head
        val query = if (queryAt >= 0) head.substring(queryAt + 1) else ""
        val kept = query.split('&').filter { part ->
            part.isNotEmpty() && part.substringBefore('=').let { existing ->
                decode(existing).equals(key, ignoreCase = true).not()
            }
        }
        val updated = kept + "$encodedKey=$encodedValue"
        return base + "?" + updated.joinToString("&") + fragment
    }

    private fun encode(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.name())
    private fun decode(value: String): String = runCatching {
        java.net.URLDecoder.decode(value, StandardCharsets.UTF_8.name())
    }.getOrDefault(value)
}
