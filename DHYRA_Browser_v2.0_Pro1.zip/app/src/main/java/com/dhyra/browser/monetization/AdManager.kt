package com.dhyra.browser.monetization

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.util.concurrent.atomic.AtomicBoolean

/** App-level AdMob lifecycle and optional local rewarded unlock entry point. */
object AdManager {
    private val initialized = AtomicBoolean(false)

    fun initialize(context: Context) {
        if (!MonetizationConfig.INTERNAL_ADS_ENABLED || !initialized.compareAndSet(false, true)) return
        MobileAds.initialize(context.applicationContext)
    }

    /**
     * Displays a Google test rewarded ad and invokes [onReward] only after the SDK reports a
     * completed reward. The primary browser experience never depends on this callback.
     */
    fun showRewardedUnlock(activity: Activity, onReward: () -> Unit, onUnavailable: () -> Unit = {}) {
        initialize(activity)
        RewardedAd.load(
            activity,
            MonetizationConfig.REWARDED_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    ad.show(activity) { onReward() }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    onUnavailable()
                }
            }
        )
    }
}
