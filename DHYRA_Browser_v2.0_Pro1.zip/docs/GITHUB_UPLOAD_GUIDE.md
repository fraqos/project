# DHYRA Browser — ZIP-only GitHub Actions upload

This repository is configured so you can upload **one project ZIP only**. Do not extract it or upload Kotlin/source folders individually.

## One-time repository setup

1. Keep the workflow file at `.github/workflows/main.yml` in the GitHub repository. GitHub only discovers workflow files stored in this path in the repository; a workflow inside the uploaded ZIP is not activated automatically.
2. The workflow checks out the repository, finds the single `.zip` file at repository root, safely extracts it to a temporary directory, locates `settings.gradle` or `settings.gradle.kts`, and confirms `app/build.gradle(.kts)` exists.
3. The workflow installs JDK 17, Android SDK Command-line Tools, Platform 35 and Build Tools 35.0.0, generates the Gradle Wrapper when needed, and runs `testDebugUnitTest`, `lintDebug` and `assembleDebug`.

## Upload each project update

1. Delete/replace the old project ZIP in the repository root. Keep **exactly one** `.zip` file there; the workflow intentionally fails if none or multiple ZIP files are found.
2. Upload the new `DHYRA_Browser_v2.0_Pro.zip` to the repository root and commit/push. Do not extract it.
3. Open **Actions** and inspect the `DHYRA Browser - Build Android APK from ZIP` run.
4. After all build steps succeed, download the `DHYRA-Browser-v2.0-Pro` artifact. It contains `DHYRA-Browser-v2.0-Pro.apk`.

The optional unsigned release APK is available only through `workflow_dispatch` with `build_release` enabled. It is not signed; production release signing must be configured separately using GitHub Secrets and a protected signing workflow.
