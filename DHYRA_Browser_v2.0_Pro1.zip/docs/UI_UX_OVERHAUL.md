# DHYRA Browser — UI/UX overhaul

A calm, minimal redesign (original; inspired by the "distraction-free" philosophy, not copied from any browser)
plus Chromium-style navigation logic. The app UI is 100% Jetpack Compose, so there are **no layout XML files**:
what a View-based app would do with `EditText`, `includeFontPadding` and `res/anim` is done in Kotlin here
(`BasicTextField`, Compose `tween`/`AnimatedContent`). XML is used only where the platform needs it
(manifest, window theme, colours).

## Architecture

```
MainActivity.kt        Activity + root composable: state, routing, Back, IME policy, layering
BrowserController.kt   Engine: tabs, WebViews, parent tabs, close-all, thumbnails, find, desktop UA
Theme.kt               Calm day/night colour schemes and typography (generous line heights)
UiModels.kt            Routes, models, preference keys, JSON codecs, small helpers
OmniboxUi.kt           Omnibox overlay (field + thumb-zone suggestion tray), suggestion items
BrowserUi.kt           Address pill, browser page (WebView host), find bar, bottom navigation
HomeUi.kt              Zen start page + speed dial
TabsUi.kt              Tab switcher: cards, swipe-to-dismiss, close-all cascade
SheetsUi.kt            Menu (quick controls incl. Desktop toggle) and Shields sheet
ScreensUi.kt           Settings, bookmarks/history, downloads, support, about
core/suggest/          SmartSuggest      – ranking, inline completion (pure JVM)
core/nav/              BackPolicy        – Back priority order (pure JVM)
core/web/              UserAgents        – mobile/desktop user agents (pure JVM)
core/tabs/             TabSelection      – which tab to show after a close (pure JVM)
```

The four `core/` objects are plain Kotlin with unit checks in `src/test` that run in CI (`verifyCoreLogic`).

## Behaviour

**URL bar and font.** The resting address pill is a fixed 48dp capsule containing plain `Text` (15sp / 22sp line
height). The editable field is a `BasicTextField` (16sp / 24sp) in a 52dp capsule with a focus border. Material's
`TextField` has a 56dp minimum height and clipped the text in shorter boxes; that was the cause of cut-off letters.
Compose has had `includeFontPadding` disabled by default since 1.6, so nothing extra is added. The progress lane
keeps a constant 2dp so the page never shifts when a load starts or ends.

**No page jump.** Tapping the pill opens an overlay *above* the WebView; the page is never resized while typing.
`MainActivity` keeps `resizeForIme = false` from the moment the overlay opens until the keyboard is fully hidden.
When a field *inside* a web page is focused, `resizeForIme` is true and the WebView host shrinks above the
keyboard so the field stays visible (the manifest uses `adjustResize`, which Compose needs to receive IME insets).

**Suggestions.** `SmartSuggest.buildIndex` is built once per history/bookmark change; each keystroke only filters it.
Typing `y` offers `youtube.com` and completes it inline (the completion is selected, so Backspace removes it).
Ranking: bookmarks, then hosts visited repeatedly, then a built-in popular list (one visit never beats the top
popular site). The tray floats directly above the keyboard with the best match lowest, within thumb reach.

**Tabs.** New tabs are lazy (no WebView until a page is opened). A tab opened from another remembers its parent.
Tab switcher: 2-column cards with page previews (regular tabs only), swipe or X to close, Regular/Private switch,
and Close all with a fade/scale cascade. `closeAllTabs()` stops, clears history, removes from the parent view and
destroys every WebView, then guarantees a fresh start-page tab (never a black screen). Closing regular tabs shows
an Undo snackbar; private tabs are never restored.

**Back (priority order).** omnibox / find bar / any screen above the page → fullscreen video → page history →
close a child tab and return to its parent → page with no history returns to the start page → system minimises.

**Desktop site.** Toggle in the menu's quick controls (clear On/Off label), an indicator in the address pill while
active, and a switch in Settings. It swaps a real desktop user agent (`Windows NT 10.0; Win64; x64`, Chrome major
version only), turns on wide viewport and overview mode, and reloads the active tab immediately. Background tabs
reload when selected.

**Start page.** Greeting by time of day, soft gradient, rounded speed-dial cards (long-press to remove, "Add to
speed dial" in the menu), recently visited, and the search pill in the lower thumb zone. No elements of the previous
Brave-style design remain (the Brave *search engine* option is still available in Settings).

## XML resources

- `AndroidManifest.xml`: `configChanges` now includes `uiMode|density|fontScale|locale|…` so switching the system
  theme no longer destroys the browser session; `adjustResize` and predictive back are unchanged.
- `values/` and `values-night/` `colors.xml` + `styles.xml`: window background and accent per theme (no white flash
  before the first frame; the old purple accent is gone).

## Not verified here

The authoring environment has no Android SDK, Gradle or Kotlin compiler. The pure-logic checks were simulated, and
the UI sources were cross-checked statically (imports, argument names, scopes), but **a real CI build and a run on a
device are still required**. See `MANUAL_TEST_CHECKLIST.md` for the new scenarios.
