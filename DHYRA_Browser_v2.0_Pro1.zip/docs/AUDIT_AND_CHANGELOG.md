# DHYRA Browser — audit of v1.3.0 source and v1.4.1 changes

## Source ZIP inventory (verified)

The supplied `DHYRA_BROWSER_Full_Complete_v1.3.0_GitHub.zip` contained 15 files before changes:

- Gradle root/configuration: `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `gradle/wrapper/gradle-wrapper.properties`, `gradlew`, `gradlew.bat`
- App config: `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`, `app/src/main/res/values/styles.xml`
- App source: `MainActivity.kt`, `BrowserController.kt`
- CI/docs: `.github/workflows/build.yml`, `README.md`, `GITHUB_UPLOAD_GUIDE.md`, `.gitignore`

The submitted audit description was checked against the source. It was not accepted as proof without inspecting the files.

## Part 3 verification against v1.3.0

| Item | Result in original source |
|---|---|
| Stack and package | Verified: Kotlin 2.0.21, Compose BOM 2024.10.01, DataStore Preferences 1.1.1, AndroidX WebKit 1.12.1, ZXing 3.5.3, package `com.dhyra.browser`, versionName `1.3.0`, versionCode `4`, compileSdk 35, minSdk 26, Gradle 8.7, AGP 8.6.1, JDK 17. |
| Main file structure | Verified: UI/routing/state lived in `MainActivity.kt`; WebView/tab logic lived in `BrowserController.kt`. There was no Room/ViewModel/DI feature architecture. |
| Existing features | Verified in source: multi-tab WebViews, private boolean/no-cache behavior, DataStore JSON history/bookmarks, DownloadManager, file chooser, camera/microphone permission forwarding, geolocation callback, popup control, fullscreen custom view, desktop UA, basic host blocklist, third-party-cookie setting, clear-data, theme/transparency, search choices and BTC support QR. |
| Tab management issues | Verified: a WebView was created for each tab, tab UI was a text list, there was no persisted session restore, thumbnail, pin, group, or renderer-gone handler. |
| Private mode | Verified: WebView CookieManager and WebStorage were shared; `isPrivate` only affected no-cache/history logic. |
| Tracker blocking | Verified: a short host list was used; `facebook.com/tr` was incorrectly listed as a host even though `/tr` is a path; blocks returned an empty `text/plain` response with status 200. |
| External intents | Verified: `Intent.parseUri` results were launched without clearing component/selector/package/flags or restricting target schemes. |
| Manifest | Verified: backup was enabled, cleartext was enabled, there were no HTTP/HTTPS browser intent filters, default platform icon was used, and no network security config/data extraction rules existed. |
| Permissions | Verified: camera/microphone requests were forwarded to Android runtime permission; unsupported WebView resources were denied. No per-origin permission persistence existed. |
| User agent | Verified: mobile branch used the default WebView UA unchanged; only desktop branch removed `; wv`, `Version/4.0`, and ` Mobile`. |
| History/downloads | Verified: history capped at 300, bookmarks at 500; downloads used DownloadManager only; no blob/data download path or in-app pause/resume existed. |
| UI quality | Verified: several UI strings were hardcoded; `Muted` was `#8490A6` in light mode; the browser overflow menu had no explicit anchor to the menu button. |
| Release/quality | Verified: there was no R8 shrink/release ProGuard config, no unit tests, and CI only built a debug APK. |
| Support address | Verified and preserved unchanged: `bc1qrdlrhldck8pz6mtcaths86htz3g3hjyhsa44q5`. |

## Changes made in v1.4.1

- Incremented `versionName` to `1.4.1` and `versionCode` to `5`; kept `applicationId` as `com.dhyra.browser`.
- Hardened the manifest: backup disabled, data-extraction exclusions, cleartext disabled, optional hardware declarations, browser VIEW/WEB_SEARCH/SEND filters, `singleTask`, and back-invoked callback enabled.
- Added a DHYRA adaptive launcher icon and monochrome icon layer.
- Fixed navigation and reload behavior for frozen tabs; blocked top-level `data:`, `javascript:`, `file:` and `content:` navigations.
- Made the Shields toolbar count observable so the badge can refresh as requests are intercepted.
- Added HTTPS-first URL transformation for address-bar/main-frame navigations. HTTP-only websites can fail; there is no insecure fallback UI.
- Sanitized `intent:` handling (component/selector/package/flags cleared, `ACTION_VIEW`, BROWSABLE category, allowed schemes restricted). Unsupported schemes are blocked rather than launched.
- Added `onRenderProcessGone` handling to recover from renderer termination without directly crashing the Activity.
- Made blank tabs lazy and capped concurrently live WebViews at four. Inactive WebViews are saved in process memory and restored/reloaded when selected; this is not a durable tab database.
- Added normal-tab session snapshot/restore with private tabs omitted.
- Added per-request confirmation dialogs for camera, microphone, protected media/DRM and geolocation. Permission decisions are not saved per origin.
- Added a basic immutable Shields host/path matcher supporting `||host^`, `||host/path^`, and `@@` exceptions. The built-in rules include a path-aware Facebook tracking rule. Blocked responses now use JavaScript/image response types or 204 for other requests. In-memory blocked counts are exposed in the browser toolbar badge.
- Cleaned WebView mobile user-agent markers.
- Disabled file URL cross-access settings and enabled Safe Browsing as before.
- Replaced deprecated fullscreen system-UI flag handling with `WindowInsetsControllerCompat`.
- Added default-browser role/settings entry point and external-intent handling.
- Added R8/resource shrinking and a ProGuard rules file for release builds.
- Added standalone JVM logic checks and a CI workflow for logic checks, lint and debug APK.
- Improved muted text contrast by selecting theme-specific colors.

## Not completed (do not advertise as implemented)

The following required roadmap work remains incomplete: full MVVM/StateFlow/Channel architecture; `AppContainer`; Room/FTS schema and JSON-to-Room migration; full `BrowserEngine`/`EngineSession` abstraction and GeckoView adapter; complete ABP/uBlock parser/indexing and downloaded regional filter lists; filter update worker/ETag/attribution; WebView resource-type/initiator inference; cosmetic filtering and document-start scripts; site-specific shields and permissions persistence; true private multi-profile isolation; anti-fingerprinting farbling; GPC; HTTPS failure interstitial with user-confirmed downgrade; per-site security/permission panels; favicon/thumbnail tab cards, groups, pinning and drag reorder; full NTP privacy report; four-page onboarding; reader mode; blob/data downloads; PiP/background audio; full localization with all UI strings in resources; full 200% font scale/RTL/accessibility QA; browser shortcut intents; automated migration tests; release signing workflow; and device/manual regression tests.

This ZIP should be treated as an improved **v1.4.1 foundation**, not as completion of all F1–F9 or a Brave-equivalent browser.


## Manual verification required

`MANUAL_TEST_CHECKLIST.md` contains the device test matrix and expected outcomes. No physical-device test is claimed by this source update.


## v1.4.1 patch — GitHub Actions Kotlin compile fix

- Fixed the CI-reported `Unresolved reference: openTarget` in `MainActivity.kt`: the `LaunchedEffect` handling external URLs was placed before the local `openTarget` function declaration. The effect now appears after the local function, preserving behavior while satisfying Kotlin local declaration resolution.
- Bumped `versionName` to `1.4.1` and `versionCode` to `6`.
- The uploaded CI log showed failure at `:app:compileDebugKotlin`; this patch addresses the exact reported compiler error. A successful remote rerun is still required to verify the complete build.


## v2.0.0 patch — CI Kotlin compile failure

- Fixed `Unresolved reference: sp` at `MainActivity.kt:798` by importing `androidx.compose.ui.unit.sp`.
- Updated Kotlin Android and Compose Gradle plugins to `2.1.20`; the root build still uses AGP `8.6.1` and Gradle `8.7`.
- Recompiled the JVM-only logic and test sources locally: 17 test methods passed. Android Gradle compilation remains pending the ZIP-driven GitHub Actions run.
