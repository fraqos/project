# DHYRA Browser v2.0.0 — implementation status

## Package and toolchain

- Version name: **2.0.0**
- Version code: **7**
- Application ID: `com.dhyra.browser`
- Rendering engine: Android System WebView
- Android Gradle Plugin: **8.6.1**
- Kotlin Android + Compose compiler plugins: **2.1.20**
- Gradle: **8.7**
- JDK: **17**
- compileSdk / targetSdk / minSdk: **35 / 35 / 26**

Kotlin 2.1.20 is used because the published Kotlin compatibility matrix includes AGP 8.6.x and Gradle 8.7. This avoids the previous Kotlin 2.0.21 + AGP 8.6.1 version mismatch.

## Scope delivered

The archive contains the refactored package layout, Material 3 UI, address bar placement options, tab grid, local suggestions, History/Bookmarks search, bookmark import/export, internal quick actions, a small host/path Shields matcher, HTTPS-first main-frame navigation, privacy headers for browser-initiated navigations, Android DownloadManager integration, AdMob test-ad slots on DHYRA-owned screens, affiliate configuration hooks, and JVM tests.

## Verification and remaining gaps

- The latest supplied CI failure at `MainActivity.kt:798` (`Unresolved reference: sp`) is fixed by importing `androidx.compose.ui.unit.sp`.
- Pure-JVM production helpers and test sources were compiled locally; 17 test methods passed using a local JUnit-compatible test shim. This is useful source-level validation, **not** a successful Gradle/Android build.
- The Android SDK and Gradle distribution are unavailable in the authoring environment, and outbound DNS is blocked. A GitHub Actions run is still required to verify `testDebugUnitTest`, `lintDebug`, and `assembleDebug`.
- Private tabs still do not have separate WebView storage profiles. DoH endpoints are presets, not a custom DNS transport. WebRTC/fingerprinting protections are not comprehensive. DownloadManager does not implement app-controlled pause/resume. Shields syntax is deliberately limited.

Do not claim production certification until the ZIP-driven GitHub Actions run succeeds and physical-device regression tests are complete.
