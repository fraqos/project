package com.dhyra.browser

import com.dhyra.browser.core.shields.ShieldsFilterEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ShieldsFilterEngineTest {
    @Test
    fun blocksHostAndSubdomainButNotLookalikeHost() {
        val engine = ShieldsFilterEngine(listOf("||doubleclick.net^"))
        assertTrue(engine.shouldBlock("https://doubleclick.net/ad.js", "https://news.example/"))
        assertTrue(engine.shouldBlock("https://ad.doubleclick.net/ad.js", "https://news.example/"))
        assertFalse(engine.shouldBlock("https://notdoubleclick.net/ad.js", "https://news.example/"))
        assertFalse(engine.shouldBlock("https://example.com/", "https://news.example/"))
    }

    @Test
    fun supportsResourceTypeOptionsAndNegations() {
        val engine = ShieldsFilterEngine(
            listOf(
                "||ads.example^\$script,image,third-party",
                "||assets.example^\$~stylesheet"
            )
        )
        assertTrue(engine.shouldBlock("https://ads.example/a.js", "https://site.test/", ShieldsFilterEngine.ResourceType.SCRIPT))
        assertTrue(engine.shouldBlock("https://ads.example/a.png", "https://site.test/", ShieldsFilterEngine.ResourceType.IMAGE))
        assertFalse(engine.shouldBlock("https://ads.example/a.css", "https://site.test/", ShieldsFilterEngine.ResourceType.STYLESHEET))
        assertFalse(engine.shouldBlock("https://ads.example/a.js", "https://ads.example/", ShieldsFilterEngine.ResourceType.SCRIPT))
        assertFalse(engine.shouldBlock("https://assets.example/app.css", "https://site.test/", ShieldsFilterEngine.ResourceType.STYLESHEET))
        assertTrue(engine.shouldBlock("https://assets.example/app.js", "https://site.test/", ShieldsFilterEngine.ResourceType.SCRIPT))
    }

    @Test
    fun supportsDomainOptionsAndThirdPartyExceptions() {
        val engine = ShieldsFilterEngine(
            listOf(
                "||metrics.example^\$domain=publisher.test|~allowed.publisher.test,third-party",
                "@@||metrics.example/safe^"
            )
        )
        assertTrue(engine.shouldBlock("https://metrics.example/pixel", "https://publisher.test/article"))
        assertFalse(engine.shouldBlock("https://metrics.example/pixel", "https://allowed.publisher.test/"))
        assertFalse(engine.shouldBlock("https://metrics.example/pixel", "https://elsewhere.test/"))
        assertFalse(engine.shouldBlock("https://metrics.example/safe/ok", "https://publisher.test/"))
    }

    @Test
    fun exceptionsOverrideBlockingRulesRegardlessOfOrder() {
        val first = ShieldsFilterEngine(listOf("@@||ads.example^", "||ads.example^"))
        val second = ShieldsFilterEngine(listOf("||ads.example^", "@@||ads.example^"))
        assertFalse(first.shouldBlock("https://ads.example/banner.js", "https://site.test/"))
        assertFalse(second.shouldBlock("https://ads.example/banner.js", "https://site.test/"))
    }

    @Test
    fun supportsPathAnchorsWildcardsAndSeparators() {
        val engine = ShieldsFilterEngine(
            listOf(
                "||cdn.example/ads/*/banner^",
                "|https://site.test/tracker.gif|",
                "/pixel?event=*"
            )
        )
        assertTrue(engine.shouldBlock("https://cdn.example/ads/home/banner?id=7", "https://publisher.test/"))
        assertFalse(engine.shouldBlock("https://cdn.example/advert/home/banner?id=7", "https://publisher.test/"))
        assertTrue(engine.shouldBlock("https://site.test/tracker.gif", "https://site.test/"))
        assertFalse(engine.shouldBlock("https://site.test/tracker.gif?v=2", "https://site.test/"))
        assertTrue(engine.shouldBlock("https://analytics.test/pixel?event=view", "https://publisher.test/"))
    }

    @Test
    fun supportsCosmeticRulesAndDomainExceptions() {
        val engine = ShieldsFilterEngine(
            listOf(
                "##.generic-ad",
                "publisher.test##.sponsor-box",
                "publisher.test#@#.sponsor-box",
                "~allowed.test##.site-promo"
            )
        )
        val css = engine.cosmeticCssFor("https://publisher.test/article")
        assertTrue(css.contains(".generic-ad"))
        assertFalse(css.contains(".sponsor-box"))
        assertTrue(css.contains(".site-promo"))
        assertFalse(engine.cosmeticCssFor("https://allowed.test/").contains(".site-promo"))
    }

    @Test
    fun classifiesCommonWebViewRequestTypes() {
        assertEquals(
            ShieldsFilterEngine.ResourceType.DOCUMENT,
            ShieldsFilterEngine.classifyRequest("https://site.test/", true, "GET", emptyMap())
        )
        assertEquals(
            ShieldsFilterEngine.ResourceType.SCRIPT,
            ShieldsFilterEngine.classifyRequest("https://cdn.test/app.js", false, "GET", mapOf("Sec-Fetch-Dest" to "script"))
        )
        assertEquals(
            ShieldsFilterEngine.ResourceType.XMLHTTPREQUEST,
            ShieldsFilterEngine.classifyRequest("https://api.test/data", false, "GET", mapOf("Sec-Fetch-Dest" to "empty", "Sec-Fetch-Mode" to "cors"))
        )
    }

    @Test
    fun classifiesPingAndWebSocketHeadersWithoutPretendingToSupportWebRTC() {
        assertEquals(
            ShieldsFilterEngine.ResourceType.PING,
            ShieldsFilterEngine.classifyRequest(
                "https://metrics.test/ping", false, "POST", mapOf("Ping-From" to "https://site.test/")
            )
        )
        assertEquals(
            ShieldsFilterEngine.ResourceType.WEBSOCKET,
            ShieldsFilterEngine.classifyRequest(
                "https://socket.test/connect", false, "GET", mapOf("Upgrade" to "websocket")
            )
        )
        val unsupportedWebRtc = ShieldsFilterEngine(listOf("||peer.test^\$webrtc"))
        assertEquals(0, unsupportedWebRtc.stats.networkRules)
        assertTrue(unsupportedWebRtc.stats.skippedRules >= 1)
    }

    @Test
    fun popupRulesOnlyApplyToTheFirstPopupDocumentAndRegexIsSkipped() {
        val engine = ShieldsFilterEngine(listOf("||popup-ad.example^\$popup", """/^https://[a-z]+\.example/ads$/"""))
        assertTrue(engine.shouldBlock(
            "https://popup-ad.example/landing", "https://publisher.test/",
            ShieldsFilterEngine.ResourceType.POPUP
        ))
        assertFalse(engine.shouldBlock(
            "https://popup-ad.example/landing", "https://publisher.test/",
            ShieldsFilterEngine.ResourceType.DOCUMENT
        ))
        assertEquals(1, engine.stats.networkRules)
        assertTrue(engine.stats.skippedRules >= 1)
    }

    @Test
    fun popupRulesUseTheOpenerSiteForThirdPartyAndDomainScopes() {
        val engine = ShieldsFilterEngine(listOf("||popup-ad.example^\$popup,third-party,domain=publisher.test"))
        val opener = "https://publisher.test/article"
        val destination = "https://popup-ad.example/landing"
        val filterContext = ShieldsFilterEngine.filteringPageUrl(destination, opener, isPopupNavigation = true)
        assertEquals(opener, filterContext)
        assertTrue(engine.shouldBlock(destination, filterContext, ShieldsFilterEngine.ResourceType.POPUP))
        assertFalse(engine.shouldBlock(destination, destination, ShieldsFilterEngine.ResourceType.POPUP))
        assertEquals(destination, ShieldsFilterEngine.filteringPageUrl(destination, opener, isPopupNavigation = false))
        assertEquals(destination, ShieldsFilterEngine.filteringPageUrl(destination, "about:blank", isPopupNavigation = true))
    }

    @Test
    fun ignoresUnsupportedFilterDirectivesInsteadOfOverBlocking() {
        val engine = ShieldsFilterEngine(listOf("||ads.example^\$redirect=noop.js", "||ads.example^\$script"))
        assertTrue(engine.shouldBlock("https://ads.example/a.js", "https://publisher.test/", ShieldsFilterEngine.ResourceType.SCRIPT))
        assertFalse(engine.shouldBlock("https://ads.example/a.css", "https://publisher.test/", ShieldsFilterEngine.ResourceType.STYLESHEET))
    }

    @Test
    fun badfilterIgnoresOptionOrderAndWhitespace() {
        val engine = ShieldsFilterEngine(
            listOf(
                "||disabled-order.example^\$script,important",
                "||disabled-order.example^\$ important , script , badfilter "
            )
        )
        assertFalse(
            engine.shouldBlock(
                "https://disabled-order.example/ad.js",
                "https://publisher.test/",
                ShieldsFilterEngine.ResourceType.SCRIPT
            )
        )
    }

    @Test
    fun badfilterPreservesCaseForMatchCaseRules() {
        val engine = ShieldsFilterEngine(
            listOf(
                "||case.example/Ad.js^\$script,match-case",
                "||case.example/ad.js^\$script,match-case,badfilter"
            )
        )
        assertTrue(engine.shouldBlock("https://case.example/Ad.js", "https://publisher.test/", ShieldsFilterEngine.ResourceType.SCRIPT))
        assertFalse(engine.shouldBlock("https://case.example/ad.js", "https://publisher.test/", ShieldsFilterEngine.ResourceType.SCRIPT))
    }

    @Test
    fun importantBlockingRulesCannotBeOverriddenByExceptions() {
        val exceptionFirst = ShieldsFilterEngine(
            listOf("@@||ads.example^", "||ads.example^\$important")
        )
        val importantFirst = ShieldsFilterEngine(
            listOf("||ads.example^\$important", "@@||ads.example^")
        )
        val regularAllow = ShieldsFilterEngine(
            listOf("||ads.example^", "@@||ads.example^")
        )
        assertTrue(exceptionFirst.shouldBlock("https://ads.example/ad.js", "https://publisher.test/"))
        assertTrue(importantFirst.shouldBlock("https://ads.example/ad.js", "https://publisher.test/"))
        assertFalse(regularAllow.shouldBlock("https://ads.example/ad.js", "https://publisher.test/"))
    }

    @Test
    fun domainCosmeticRulesAreIndexedAndRespectSubdomains() {
        val engine = ShieldsFilterEngine(
            listOf("publisher.test##.ad-slot", "other.test##.other-ad", "##.global-ad")
        )
        val css = engine.cosmeticCssFor("https://news.publisher.test/story")
        assertTrue(css.contains(".ad-slot"))
        assertTrue(css.contains(".global-ad"))
        assertFalse(css.contains(".other-ad"))
    }

    @Test
    fun badfilterDisablesTheMatchingNetworkRule() {
        val engine = ShieldsFilterEngine(
            listOf("||disabled.example^\$script", "||disabled.example^\$script,badfilter")
        )
        assertFalse(engine.shouldBlock("https://disabled.example/ad.js", "https://publisher.test/", ShieldsFilterEngine.ResourceType.SCRIPT))
    }

    @Test
    fun recognizesSameRegistrableDomainAsFirstParty() {
        val engine = ShieldsFilterEngine(listOf("||api.publisher.co.uk^\$third-party"))
        assertFalse(engine.shouldBlock("https://api.publisher.co.uk/metrics", "https://www.publisher.co.uk/"))
        assertTrue(engine.shouldBlock("https://api.publisher.co.uk/metrics", "https://another.co.uk/"))
    }

    @Test
    fun indexesShortGenericPathFilters() {
        val engine = ShieldsFilterEngine(listOf("*ads*"))
        assertTrue(engine.shouldBlock("https://cdn.example/adserver/ads.js", "https://publisher.test/"))
    }

    @Test
    fun cosmeticSelectorsAreCombinedIntoValidCssAndSupportChildCombinators() {
        val engine = ShieldsFilterEngine(
            listOf(
                "###cookie-layer",
                "##div.notice > .banner",
                "publisher.test##.site-specific",
                "pinterest.com,reddit.com###credential_picker_iframe",
                "###credential_picker_container",
                "dashboard.razorpay.com#@##credential_picker_container"
            )
        )
        val css = engine.cosmeticCssFor("https://publisher.test/article")
        assertTrue(css.contains("#cookie-layer"))
        assertTrue(css.contains("div.notice > .banner"))
        assertTrue(css.contains(".site-specific"))
        assertTrue(css.contains(",\n"))
        assertTrue(css.endsWith("{display:none!important;visibility:hidden!important}"))
        assertFalse(css.contains("},\n"))
        assertTrue(engine.cosmeticCssFor("https://reddit.com/").contains("#credential_picker_iframe"))
        assertFalse(engine.cosmeticCssFor("https://dashboard.razorpay.com/").contains("#credential_picker_container"))
    }

    @Test
    fun siteSpecificCosmeticsArePrioritizedBeforeLargeGenericLists() {
        val rules = (0 until 720).map { "##.generic-$it" } + "publisher.test##.publisher-banner"
        val css = ShieldsFilterEngine(rules).cosmeticCssFor("https://publisher.test/article")
        assertTrue(css.contains(".publisher-banner"))
        assertTrue(css.contains(".generic-0"))
    }

    @Test
    fun exposesUsefulFilterStatistics() {
        val engine = ShieldsFilterEngine(listOf("||ads.example^", "##.ad", "||bad.example^\$not-a-valid-filter-option"))
        assertEquals(1, engine.stats.networkRules)
        assertEquals(1, engine.stats.cosmeticRules)
        assertTrue(engine.stats.skippedRules >= 1)
    }


    /**
     * Entry point used by BrowserLogicChecks for the standalone JVM regression runner.
     * JUnit still discovers each @Test method independently through the normal test task.
     */
    fun runChecks() {
        blocksHostAndSubdomainButNotLookalikeHost()
        supportsResourceTypeOptionsAndNegations()
        supportsDomainOptionsAndThirdPartyExceptions()
        exceptionsOverrideBlockingRulesRegardlessOfOrder()
        supportsPathAnchorsWildcardsAndSeparators()
        supportsCosmeticRulesAndDomainExceptions()
        classifiesCommonWebViewRequestTypes()
        classifiesPingAndWebSocketHeadersWithoutPretendingToSupportWebRTC()
        popupRulesOnlyApplyToTheFirstPopupDocumentAndRegexIsSkipped()
        popupRulesUseTheOpenerSiteForThirdPartyAndDomainScopes()
        ignoresUnsupportedFilterDirectivesInsteadOfOverBlocking()
        badfilterIgnoresOptionOrderAndWhitespace()
        badfilterPreservesCaseForMatchCaseRules()
        importantBlockingRulesCannotBeOverriddenByExceptions()
        domainCosmeticRulesAreIndexedAndRespectSubdomains()
        badfilterDisablesTheMatchingNetworkRule()
        recognizesSameRegistrableDomainAsFirstParty()
        indexesShortGenericPathFilters()
        cosmeticSelectorsAreCombinedIntoValidCssAndSupportChildCombinators()
        siteSpecificCosmeticsArePrioritizedBeforeLargeGenericLists()
        exposesUsefulFilterStatistics()
    }
}
