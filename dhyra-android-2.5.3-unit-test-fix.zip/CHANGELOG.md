## 2.5.3 — Shields JVM test runner compile fix

- Added `ShieldsFilterEngineTest.runChecks()` as the standalone `BrowserLogicChecks` entry point, invoking all 21 existing JUnit test methods without duplicating JUnit discovery.
- Added an explicit `:app:compileDebugUnitTestKotlin` CI step before `testDebugUnitTest`, so test-source compilation failures are reported as a distinct build stage.
- Added a source-contract regression check that verifies the helper exists and covers every `@Test` method.

- Fixed `BrowserController.kt` compilation: removed the duplicate `@Volatile` annotation on `shieldsFilterEngine`; the property remains volatile for safe publication of immutable filter-engine snapshots across WebView request threads.
- Added a source-contract regression check that fails if the `shieldsFilterEngine` property receives duplicate `@Volatile` annotations.
- Updated the application to versionCode 31 / versionName 2.5.3 and synchronized the filter updater User-Agent, workflow APK names, and documentation.

## 2.5.1 CI workflow audit

- Added `scripts/validate-ci-config.py`, which fails early when Gradle, AGP, Kotlin, JDK, compile SDK, Android Build Tools, wrapper distribution checksum or APK artifact naming drift away from the project configuration.
- The workflow now clears the artifact staging `dist/` directory before copying build outputs, preventing stale APKs or unrelated files from being included in the upload.
- Kept the Android project toolchain pinned to AGP 9.3.1, Kotlin Gradle Plugin 2.4.21, Gradle 9.5.1, JDK 21, Android SDK Platform 37.1 and Build Tools 36.0.0.
- The workflow and embedded copy in the source ZIP are byte-for-byte identical.

## 2.5.1 — regional filter coverage and popup-context correctness

- Added ABPindo as a fourth HTTPS subscription for Indonesian and Malay site coverage, alongside EasyList, EasyPrivacy and Fanboy’s Annoyance List.
- Added `$popup` resource-type handling for the first HTTP(S) document request created through `WebChromeClient.onCreateWindow`; matching uses the opener page's origin for `$third-party` and `domain=` conditions, then drops the popup context so later manual navigation is treated as a normal document.
- Clears popup context on tab release, controller teardown and non-web navigation to prevent stale classification; a blocked popup tab is closed on the UI thread so it does not remain as an empty foreground tab.
- Added a validated filter-context helper and JVM regression coverage for popup resource matching, opener-site domain scope, first/third-party behavior and unsupported regular-expression filters.
- Publishes the immutable filter-engine snapshot through a volatile reference because `shouldInterceptRequest` may execute on WebView background request threads.
- Updated source, updater User-Agent, UI subscription label, CI artifacts and documentation to versionCode 29 / versionName 2.5.1.

## 2.5.0 — expanded Shields ad, tracker and annoyance protection

- Replaced the starter host-only filter matcher with an indexed Adblock Plus subset supporting host/path anchors, wildcards, separator tokens, exceptions, resource types, third-party rules, and domain scopes.
- Added supported domain-scoped and generic CSS cosmetic filtering on completed pages; cosmetic rules are indexed by domain to avoid scanning the full list on every navigation.
- Implemented `$important` precedence and canonicalized `$badfilter` option signatures so exception/disable semantics do not depend on list order or option spacing; `$match-case` signatures retain case sensitivity.
- Added HTTPS subscriptions for EasyList, EasyPrivacy and the official Fanboy’s Annoyance List, bounded downloads, header/size validation, atomic storage, and four-day update cadence on unmetered connections. Manual refresh is available in the Shields sheet.
- Added request-resource classification, filter rule counters, update status, and JVM regression tests for supported syntax, `$important`, `$badfilter`, ID shorthand selectors, child combinators and domain-indexed cosmetic rules.
- Reduced per-request work by indexing generic filters with packed 3/4-character keys, deriving host path/query once, bounding URL matching and cosmetic CSS (64 KiB/page), indexing cosmetic rules by domain, and reusing a static common-suffix table for best-effort first/third-party classification. Site-specific cosmetic selectors take priority over generic selectors.
- Moved Shields controller startup after all dependent properties are initialized and added cancellation/error handling so filter-list failures cannot crash controller construction or leave the update control busy. Blocked-request counter UI updates are coalesced during high-volume request bursts.
- Preserved per-site Shields controls, global tracking protection, popup blocking, and third-party cookie restrictions.
- VersionCode 28 / versionName 2.5.0.

# Changelog

## 2.4.9 — native UI polish, stable theme transitions and favicon-backed homepage

- Standardized browser controls, tab overview, omnibox and overflow-menu icons on Compose Material Icons Outlined.
- Kept Settings pinned at the bottom of the overflow sheet, outside the scrollable action list, so it remains discoverable on compact screens.
- Restored default Material press feedback on Settings rows and changed switch rows to one parent toggle interaction to prevent double toggles.
- Reordered Settings categories to General, Privacy and security, Languages, Downloads, Notifications, Advanced and About.
- Removed Activity-recreating AppCompat night-mode switching; Light/Dark/System default now update the Compose theme in place with 180 ms color transitions, keeping Activity-owned WebViews attached.
- Added a bounded regular-profile favicon cache keyed by normalized host and show available favicons in homepage speed dial/recently visited rows; private-profile icons are not copied into the shared cache. Cached images are scaled to a maximum 128px dimension to limit memory use.
- Updated typography and brand surface tokens with matched light/dark violet accents.
- Updated to versionCode 26 / versionName 2.4.9 and synchronized CI artifact names.

## 2.4.7 — Compose saved-state compile fix

- Fixed the Kotlin compilation error caused by referencing `savedInstanceState` inside the top-level `DhyraApplication()` composable.
- `MainActivity.onCreate()` now passes `isColdLaunch = savedInstanceState == null` into the Compose root; the startup reveal uses that explicit parameter.
- Added source-contract regression checks for Activity-to-Compose saved-state flow and absence of out-of-scope Bundle references.
- CI now runs `:app:compileDebugKotlin` as a dedicated step before unit tests, lint and APK assembly.
- Updated to versionCode 25 / versionName 2.4.7.

## 2.4.6 — homepage, Settings, language and transparent branding

- Rebuilt homepage as a minimal native Compose surface: search/address, speed dial and recently visited only.
- Removed weather/news homepage cards and the associated feed repository.
- Added six rotating flat speed-dial color pairs, dark variants, 54dp tiles and host-based recent-visit deduplication.
- Added three explicit theme choices: Light, Dark and System default, applied via AppCompatDelegate.
- Added searchable app-language choices: System default, English and Bahasa Indonesia. Added locale configuration and resource catalogues; native Compose text and Toasts use the active app locale.
- Replaced logo image assets with the user-provided D/globe/orbit mark on transparent canvases. Reduced adaptive icon/splash occupancy and added a monochrome launcher layer.
- Aligned Settings sections, row touch targets, outlined icons, card borders and accent `#7F77DD`.
- Updated to versionCode 24 / versionName 2.4.6.
- Updated CI to generate Gradle Wrapper in the actual Android project root and accept any source ZIP filename.

## 2.4.5 and earlier

See repository history for previous browser engine, tab management, translation, download and security changes.
