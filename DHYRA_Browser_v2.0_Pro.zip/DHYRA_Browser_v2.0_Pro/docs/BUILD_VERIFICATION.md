# Build Verification

## Build environment

- JDK 17
- Gradle 8.7
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21

## Required CI commands

```bash
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

The workflow first installs Gradle 8.7 and generates a standard wrapper JAR because the supplied source ZIP did not contain one. It then invokes the project wrapper for test, lint and assemble tasks. The debug APK is copied to `DHYRA-Browser-v2.0-Pro.apk` and uploaded as an Actions artifact. A manual workflow-dispatch input enables the optional unsigned release assemble job.

## Current verification record

- All 17 pure-JVM JUnit-style test methods were compiled and executed with the available Kotlin compiler plus a minimal local JUnit API compatibility shim. The checks cover address resolution, HTTPS upgrade, Shields matching/exceptions, privacy headers and DoH presets, tab selection, incognito persistence policy, download progress policy, affiliate URL encoding/configuration, local suggestions and User-Agent transformation. This is a logic check, not a substitute for the Gradle `testDebugUnitTest` task.
- Kotlin source parse pass: no syntax diagnostics were observed when invoking the local compiler without Android/Compose libraries; full source compilation could not be completed because those dependencies are not present.
- `testDebugUnitTest`, `lintDebug` and `assembleDebug` have **not** been run in this environment. No Gradle installation or Android SDK is available, and network access to the Gradle distribution host failed. The first GitHub Actions run is the authoritative Android build verification.

A green workflow is necessary but not sufficient for release; complete `MANUAL_TEST_CHECKLIST.md` on real hardware and review the limitations in `README.md`.
