# Source Audit and Changelog — DHYRA Browser v2.0 Pro

## Baseline audit

The supplied project was a Kotlin/Jetpack Compose browser built on Android System WebView. It already contained a tab/session coordinator, DataStore-backed history and bookmarks, Android DownloadManager integration, a first-pass filter matcher, HTTPS URL normalization, address suggestions and several browser permission callbacks. The original UI sources and helper classes were concentrated in the main package. The archive did not contain `gradle-wrapper.jar`.

## Refactor applied

- Grouped navigation, networking, tabs, downloads, Shields, suggestions and monetization helpers under `core/` and `monetization/`.
- Split theme, components and screens into `ui/theme`, `ui/components` and `ui/screens`.
- Moved the six requested project documents into `docs/` and refreshed the root README and third-party inventory.
- Removed the in-app contribution screen, address/QR flow, route and associated UI references.
- Added centralized AdMob demo IDs, affiliate URL tagging utilities, partner card configuration and internal-only Native ad rendering.
- Added asset-backed host/path filtering rules and site-level Shields override.
- Added Material 3 Dynamic Color, explicit Light/Dark/AMOLED schemes, address-bar placement and tab swipe selection.
- Added tab grid favicon support where WebView supplies one, local History/Bookmarks filtering, JSON bookmark transfer, quick menu actions and Downloads status refresh.
- Converted logic checks into JUnit-discoverable tests and updated the workflow to run `testDebugUnitTest`.

## Architecture boundaries retained

The refactor does not replace WebView with a new engine or migrate the app to full MVVM/Room/DI. `MainActivity` retains Compose orchestration and `BrowserController` remains the WebView session coordinator. See `IMPLEMENTATION_STATUS.md` for incomplete requirements and `README.md` for privacy/security qualifications.
