# GitHub Upload Guide

1. Extract `DHYRA_Browser_v2.0_Pro.zip` into a new repository directory.
2. Commit all project files, including `.github/workflows/build.yml`, `gradle/wrapper/gradle-wrapper.properties`, the custom Gradle bootstrap scripts and the `docs/` folder.
3. Push to `main` or `master`, or open a pull request. The Android CI workflow runs automatically.
4. In the Actions run, wait for `testDebugUnitTest`, `lintDebug` and `assembleDebug` to complete. Download the artifact named `DHYRA-Browser-v2.0-Pro` to obtain the APK file.
5. Use the Actions workflow-dispatch input `build_release=true` only when you need to verify the unsigned release variant. Configure signing secrets and a signing config separately before distributing a signed APK/AAB.
6. Before a production release, replace the Google demo ad IDs, configure only authorized affiliate IDs, complete the manual device checklist and re-check third-party license notices.

## Local commands

```bash
chmod +x gradlew
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

The source ZIP originally lacked the Gradle wrapper JAR. CI generates the official wrapper JAR after provisioning Gradle 8.7. The included shell/Windows launchers bootstrap Gradle 8.7 when no system Gradle executable is present.
