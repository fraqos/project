# Manual Device Test Checklist

Run this checklist on at least one Android 8+ phone and a second recent Android device before release.

## Install and navigation
- [ ] Install the debug APK from Actions and launch without a crash.
- [ ] Open HTTP and HTTPS addresses; verify HTTP is upgraded where available and HTTP-only sites fail transparently.
- [ ] Verify invalid TLS certificates are rejected and no bypass is offered.
- [ ] Open external HTTP(S) links, shared URLs and browser search intents.
- [ ] Test Back priority: omnibox, find bar, sheets/screens, fullscreen, page history and tab parent.

## Tabs and privacy
- [ ] Open regular and private tabs, switch between them and inspect the grid preview.
- [ ] Check favicon and monogram fallback, title truncation, private marker and tab selection.
- [ ] Close one tab, close all tabs, use Undo, then repeat in private mode.
- [ ] Verify private tabs do not appear in history/session persistence.
- [ ] Verify the global storage cleanup consequence: clearing the final private tab may sign out a regular tab because WebView storage is shared.
- [ ] Use Burn and confirm all private tabs close.

## Shields and networking
- [ ] Check known blocklist hosts and exceptions using a test page.
- [ ] Toggle Shields globally and per site; verify blocked-request counts update.
- [ ] Compare the displayed data-saved estimate with its explanatory label.
- [ ] Confirm DNT/GPC headers on browser-initiated navigations with a test endpoint.
- [ ] Confirm third-party cookies are blocked when tracking protection is enabled.
- [ ] Do not treat the DoH entries as active routing; verify Android DNS remains the resolver in this build.

## UI and productivity
- [ ] Switch System, Dynamic, Light, Dark and AMOLED modes.
- [ ] Move the address bar to top and bottom; test keyboard and status/navigation insets.
- [ ] Swipe the address bar left/right and check tab wraparound.
- [ ] Search History and Bookmarks using title and URL substrings.
- [ ] Export bookmarks to JSON, import into an empty profile, and test malformed JSON.
- [ ] Test Find in Page, translation, CSS Reader presentation, Share, QR display and Print/Save as PDF.
- [ ] Download small/large files, observe Android notification progress and in-app polling; test open/delete.
- [ ] Test HTML video fullscreen, orientation restoration and PiP on a device that supports it.

## Monetization
- [ ] Verify Google demo ads appear only on Home/Downloads internal app screens.
- [ ] Navigate several third-party websites and confirm no app ad component overlays the WebView.
- [ ] Verify partner cards stay hidden with empty tag config.
- [ ] Only enable cards/search tags after receiving real partner identifiers.
- [ ] Never publish with Google demo AdMob identifiers.
