# UI/UX Notes — v2.0 Pro

## Theme system

`ui/theme/Theme.kt` owns the Material 3 color schemes and typography. Available modes are System, Dynamic Color on Android 12+, Light, Dark and AMOLED black. Private tabs use a subdued violet tint to distinguish their state from regular browsing.

## Navigation ergonomics

- Address bar placement can be changed between top and bottom in Settings.
- Horizontal drag on the address bar changes the active tab.
- The omnibox editor aligns to the configured edge of the viewport.
- The tab switcher uses a two-column card grid, page snapshot where available, favicon when provided by WebView, a private-tab marker and close-all animation. Closing all tabs presents an Undo snackbar through the existing screen state.

## Home and internal surfaces

Home contains local speed dials, recent regular history, configured partner shortcuts and a Native ad slot. Partner cards are hidden unless a partner tag is supplied. The Downloads screen also contains an internal ad slot. The ad component is not attached to, injected into, or overlaid on a third-party WebView page.

## Quick actions

The quick menu links to Desktop Site, Find in Page, Translate, CSS Reader Mode, Print/Save as PDF, QR display, Share, bookmark and speed-dial actions. Shields has a site toggle and displays a request count with an explicitly estimated data-saved figure.

## Manual QA still required

Check layouts on small screens, gesture navigation, IME positioning, accessibility font scaling, RTL/localized layouts, tablet/foldable breakpoints, ad loading/error states, fullscreen media, orientation changes and actual PiP support on representative Android versions. The tab grid displays a fallback monogram when WebView has no favicon.
