# Implementation Status — v2.0 Pro

| Requirement area | Status | Notes |
|---|---|---|
| Package/UI folder refactor | Implemented | MainActivity and BrowserController remain in the application root package. |
| Remove contribution UI and stored address flow | Implemented | Route, screen and UI references removed. |
| Material 3 and themes | Implemented in source | System, Dynamic, Light, Dark and AMOLED schemes; Android device validation remains. |
| Omnibox top/bottom and tab swipe | Implemented in source | Needs touch/IME QA. |
| Tab grid, favicons and private marker | Implemented in source | Favicon depends on WebView callback availability; monogram fallback is used. |
| Close-all and undo | Implemented in source | Manual snackbar verification required. |
| Quick actions, QR and print/PDF | Implemented in source | Print output depends on Android print framework and page behavior. |
| Reader mode | Partial | CSS presentation only; not article extraction. |
| Shields host/path matching | Partial | Lightweight rules only; not a full filter-list engine. |
| Shields per-site control/counters | Implemented in source | Counters are in memory; saved bytes are estimates. |
| HTTPS-first | Partial | Main-frame upgrade; no transparent HTTP fallback. |
| DNT/GPC and third-party cookie setting | Partial | Browser navigation headers only; no guaranteed subresource rewrite. |
| True isolated private profiles | Not implemented | System WebView profile/storage remains shared. Cleanup on last private tab closure is global and can affect normal tabs. |
| DoH | Presets only | Provider endpoints are listed, but no DNS-over-HTTPS transport is connected. |
| Anti-fingerprinting and WebRTC leak protection | Not implemented | User-Agent normalization is not randomized fingerprint protection. |
| Android DownloadManager | Implemented | Notifications and in-app status refresh; no app-controlled pause/resume API. |
| History/Bookmarks search and JSON transfer | Implemented in source | Needs round-trip testing with malformed/large files. |
| Smart local suggestions | Implemented | Local history/bookmarks are indexed locally; no per-keystroke remote suggestion endpoint. |
| AdMob Native/Rewarded demo integration | Implemented in source | Test IDs only. Native slots appear only on internal Home/Downloads surfaces. |
| Real affiliate/revenue-share tags | Not configured | Requires issued IDs/parameters from partner programs. |
| PiP | Partial | Entry is attempted from fullscreen; media playback lifecycle/device QA remains. |
| Automated test suite | Added | Pure JVM logic assertions run locally; Gradle/JUnit task awaits CI verification. |
| Android APK build | Not verified locally | No Android SDK/Gradle runtime/network available in the authoring environment. GitHub Actions is configured to run it. |

This status reflects the source changes, not a claim that every item has been certified on physical devices or CI.
