# DHYRA Browser v2.0 Pro

DHYRA is an Android browser built with Kotlin, Jetpack Compose Material 3 and the Android System WebView supplied by the device. It is **not** a Chromium fork and does not bundle a separate browser engine.

> **Release status:** this archive is a refactored engineering build. The pure-JVM test sources were compiled and 17 test methods passed in local validation. The Android Gradle test/lint/APK pipeline still requires a successful GitHub Actions run, followed by on-device QA. The previous CI logs reported a missing Compose `sp` import and an ambiguous WebView interception overload; those source fixes are included in this archive. Do not publish it as a production-certified browser until Android CI is green and the limitations below have been reviewed.

## Architecture

```text
app/src/main/java/com/dhyra/browser/
├── BrowserController.kt       # WebView lifecycle, navigation, downloads, fullscreen
├── MainActivity.kt            # Compose app state, routing, platform integration
├── UiModels.kt                # UI models, DataStore keys and codecs
├── core/
│   ├── downloads/             # Download presentation/action policy
│   ├── nav/                   # Address resolver and Back policy
│   ├── network/               # HTTPS-first, privacy headers, UA and DoH presets
│   ├── shields/               # Asset-backed host/path filtering engine
│   ├── suggest/               # Local history/bookmark suggestions
│   └── tabs/                  # Tab selection and private-session policy
├── monetization/              # AdMob, affiliate URL helpers and config
└── ui/
    ├── components/            # Omnibox and bottom sheets
    ├── screens/               # Home, browser, tabs and library screens
    └── theme/                 # Material 3, dynamic, light, dark and AMOLED themes
```

The current `BrowserController` remains the WebView session coordinator. This archive organizes its supporting logic and UI by responsibility; it is not yet a full MVVM/Room/DI migration.

## Included features

- Material 3 interface with System, Dynamic Color (Android 12+), Light, Dark and AMOLED modes.
- Address bar at the top or bottom, horizontal tab switching gestures, and a grid tab switcher with WebView snapshots, favicons when supplied by WebView, private-tab indication and close-all undo.
- Internal quick actions for find-in-page, translate, CSS-based reader presentation, print/save as PDF, QR display, share and bookmark.
- Host/path Shields rules loaded from `app/src/main/assets/shields_blocklist.txt`, per-site on/off override and in-memory request counts.
- HTTPS-first main-frame navigation, cancellation of certificate errors, browser-initiated DNT/GPC headers and third-party-cookie control.
- Local history/bookmark suggestions, History/Bookmarks search, JSON bookmark import/export and recent history.
- Android `DownloadManager` with system notifications and an in-app progress list; list status refreshes while the Downloads screen is visible.
- AdMob Native slot on DHYRA-owned Home and Downloads screens only. It is never inserted into the WebView page. Optional rewarded-ad callback is provided for future local unlocks.
- Optional partner shortcuts and search tags. They are hidden/inactive until a real partner parameter/value is configured.

## Build configuration

| Component | Version |
|---|---|
| Android Gradle Plugin | 8.13.2 |
| Kotlin + Compose compiler plugin | 2.3.20 |
| Gradle | 8.13 |
| JDK | 17 |
| compileSdk / targetSdk / minSdk | 35 / 35 / 26 |
| Compose BOM | 2024.10.01 |
| AndroidX WebKit | 1.12.1 |
| Google Mobile Ads SDK | 25.5.0 |

Install Android SDK Platform 35 and Build Tools 35.0.0, then run:

```bash
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

The included `gradlew` bootstrap uses an installed `gradle` command when available; otherwise it downloads Gradle 8.13. GitHub Actions installs Gradle 8.13, generates the standard wrapper JAR as part of CI, runs unit tests and lint, builds the debug APK and uploads `DHYRA-Browser-v2.0-Pro.apk` as an Actions artifact. The optional release job produces an **unsigned** release APK unless signing is configured separately.

## Monetization configuration

All AdMob unit IDs and partner tagging are centralized in `app/src/main/java/com/dhyra/browser/monetization/MonetizationConfig.kt`.

1. For a real release, replace `NATIVE_AD_UNIT_ID` and `REWARDED_AD_UNIT_ID` with units created in your AdMob account.
2. Replace the sample AdMob application ID in both `MonetizationConfig.ADMOB_APPLICATION_ID` and `app/src/main/AndroidManifest.xml` (`com.google.android.gms.ads.APPLICATION_ID`). The sample application ID and Native/Rewarded unit IDs are Google's official demo values for development only. See [Google's Android test-ad documentation](https://developers.google.com/admob/android/test-ads) and [SDK quick start](https://developers.google.com/admob/android/quick-start).
3. For a search provider, fill its `SearchTag(parameter, value)` with the tracking parameter issued under a genuine partner agreement. Empty values intentionally leave search URLs unchanged.
4. For a Home partner card, configure `PartnerDeal.parameter`, `PartnerDeal.value` and set `enabled = true` only after the affiliate destination and attribution tag have been issued by that partner. Cards without a configured tag are not shown or labelled as partners.

Do not use Google's demo IDs in a published release. Do not guess partner parameters or represent a direct link as a revenue-share agreement.

## Explicit implementation limits

These limits are important; the corresponding features must not be marketed as stronger than they are:

- **Private tabs are not separate WebView profiles.** Android System WebView's CookieManager and WebStorage are shared. Private tabs are excluded from history/session persistence and use `LOAD_NO_CACHE`. Closing the final private tab clears shared cookies and WebStorage as a best-effort fallback; this can sign out regular tabs. This is not equivalent to a browser engine with isolated incognito profiles. The Burn action closes private tabs and invokes that same cleanup.
- **Shields is a lightweight host/path matcher, not a complete EasyList/uBlock engine.** It supports `||host^`, `||host/path^` and `@@` exceptions. It does not implement cosmetic filters, scriptlets, regex/resource-type/initiator rules, remote list updates or all WebView traffic. The byte-saved figure is an estimate (32 KiB per blocked request), not measured transfer accounting.
- **HTTPS-first is best effort for main-frame navigation.** There is no transparent HTTP fallback. HTTP-only sites can fail, and TLS certificate errors are always cancelled. DNT/GPC headers are attached to browser-initiated top-level navigations; WebView does not let this implementation rewrite every subresource request.
- **DoH is represented by provider presets only.** Cloudflare, AdGuard and Quad9 endpoints are listed in `core/network/PrivacyHeaders.kt`, but the app does not yet route WebView DNS through a DoH transport. DNS remains controlled by Android/system networking.
- **Anti-fingerprinting/WebRTC hardening is incomplete.** The app normalizes the WebView User-Agent and controls third-party cookies, but does not implement randomized fingerprint surfaces or guaranteed WebRTC leak prevention.
- **Downloads use Android `DownloadManager`.** System notifications provide download status; the app displays progress by polling the manager. Android's public DownloadManager API does not provide the pause/resume controls exposed by this UI policy model, so pause/resume is not claimed.
- **Reader mode is a CSS-based in-page presentation**, not a robust article extractor. Dynamic sites may need manual verification. Translation opens Google's translation page in a new tab.
- **PiP entry is attempted when the user leaves while WebView fullscreen is active.** Actual PiP/media behavior depends on the device, WebView and media site; background audio is not guaranteed.
- Partner revenue share is not active by default; real commercial identifiers must be supplied by the owner.

## Project documentation

- `docs/AUDIT_AND_CHANGELOG.md` — source audit and architecture changes.
- `docs/UI_UX_OVERHAUL.md` — UI/UX implementation notes.
- `docs/IMPLEMENTATION_STATUS.md` — implemented items and known gaps.
- `docs/MANUAL_TEST_CHECKLIST.md` — device verification plan.
- `docs/BUILD_VERIFICATION.md` — CI/build verification procedure and current status.
- `docs/GITHUB_UPLOAD_GUIDE.md` — repository upload and Actions usage.

## Third-party notices

See `THIRD_PARTY_NOTICES.md` for direct dependencies and license references. Transitive dependencies are resolved by Gradle and should be re-inventoried before distributing a release.
