package com.dhyra.browser

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.PermissionRequest
import android.webkit.GeolocationPermissions
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import java.io.ByteArrayInputStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class BrowserTab(
    val id: Int,
    val url: String,
    val title: String,
    val progress: Int,
    val loading: Boolean,
    val isPrivate: Boolean
)

data class BrowserSnapshot(val tabs: List<BrowserTab> = emptyList(), val activeTabId: Int = -1)

class BrowserController(
    private val activity: Activity,
    private val onFileChooser: (ValueCallback<Array<Uri>>) -> Unit,
    private val onPermission: (PermissionRequest) -> Unit,
    private val onGeolocation: (String, GeolocationPermissions.Callback) -> Unit
) {
    private val tabs = mutableListOf<BrowserTab>()
    private val _snapshot = MutableStateFlow(BrowserSnapshot())
    val snapshot: StateFlow<BrowserSnapshot> = _snapshot.asStateFlow()
    private fun publishSnapshot() { _snapshot.value = BrowserSnapshot(tabs.toList(), activeTabId) }
    var activeTabId: Int = -1
        private set

    private val webViews = linkedMapOf<Int, WebView>()
    private var nextId = 1
    private var host: FrameLayout? = null
    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var savedSystemUiVisibility: Int = 0
    var isFullscreen by androidx.compose.runtime.mutableStateOf(false)
        private set

    var trackingProtection = true
    var popupBlocker = true
    var desktopMode = false
    var onPageFinished: (BrowserTab) -> Unit = {}

    fun activeTab(): BrowserTab? = tabs.firstOrNull { it.id == activeTabId }
    fun activeWebView(): WebView? = webViews[activeTabId]

    fun createTab(url: String = "about:blank", isPrivate: Boolean = false): Int {
        val id = nextId++
        val tab = BrowserTab(id, url, "New tab", 0, false, isPrivate)
        tabs.add(tab)
        val view = buildWebView(id, isPrivate)
        webViews[id] = view
        activeTabId = id
        attachToHost()
        publishSnapshot()
        if (url != "about:blank") view.loadUrl(url)
        return id
    }

    fun selectTab(id: Int) {
        if (webViews.containsKey(id)) {
            activeTabId = id
            attachToHost()
            publishSnapshot()
        }
    }

    fun navigate(url: String) {
        val id = activeTabId
        val view = webViews[id]
        if (view == null) {
            createTab(url)
        } else {
            updateTab(id, url = url, loading = true, progress = 0)
            view.loadUrl(url)
        }
    }

    fun exitFullscreen() {
        val view = fullscreenView ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        fullscreenCallback?.onCustomViewHidden()
        fullscreenView = null
        fullscreenCallback = null
        activity.window.decorView.systemUiVisibility = savedSystemUiVisibility
        isFullscreen = false
    }

    fun goBack() { activeWebView()?.let { if (it.canGoBack()) it.goBack() } }
    fun goForward() { activeWebView()?.let { if (it.canGoForward()) it.goForward() } }
    fun reload() { activeWebView()?.reload() }
    fun stop() { activeWebView()?.stopLoading() }

    /** Pause timers and rendering while the Activity is backgrounded. */
    fun pause() {
        webViews.values.forEach { view -> runCatching { view.onPause() } }
        webViews.values.firstOrNull()?.let { runCatching { it.pauseTimers() } }
    }

    /** Resume all retained tabs when the Activity returns to the foreground. */
    fun resume() {
        webViews.values.forEach { view -> runCatching { view.onResume() } }
        webViews.values.firstOrNull()?.let { runCatching { it.resumeTimers() } }
    }

    fun closeTab(id: Int) {
        val view = webViews.remove(id)
        if (view != null) {
            (view.parent as? ViewGroup)?.removeView(view)
            view.stopLoading()
            if (tabs.firstOrNull { it.id == id }?.isPrivate == true) {
                view.clearHistory()
                view.clearCache(true)
                view.clearFormData()
            }
            view.loadUrl("about:blank")
            view.destroy()
        }
        tabs.removeAll { it.id == id }
        if (activeTabId == id) {
            activeTabId = tabs.lastOrNull()?.id ?: -1
            if (activeTabId == -1) createTab()
            attachToHost()
        }
        publishSnapshot()
    }

    fun attach(container: FrameLayout) {
        host = container
        attachToHost()
    }

    private fun attachToHost() {
        val container = host ?: return
        val view = webViews[activeTabId]
        if (view == null) {
            container.removeAllViews()
            return
        }
        if (view.parent !== container) {
            (view.parent as? ViewGroup)?.removeView(view)
            container.removeAllViews()
            container.addView(
                view,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }
    }

    fun applySettings(tracking: Boolean, popup: Boolean, desktop: Boolean) {
        trackingProtection = tracking
        popupBlocker = popup
        desktopMode = desktop
        webViews.forEach { (id, view) ->
            configureSettings(view, tabs.firstOrNull { it.id == id }?.isPrivate == true)
        }
    }

    fun clearRegularData() {
        webViews.forEach { (id, view) ->
            if (tabs.firstOrNull { it.id == id }?.isPrivate != true) {
                view.clearCache(true)
                view.clearHistory()
                view.clearFormData()
            }
        }
        CookieManager.getInstance().removeAllCookies(null)
        android.webkit.WebStorage.getInstance().deleteAllData()
        CookieManager.getInstance().flush()
    }

    fun destroy() {
        webViews.values.toList().forEach { view ->
            (view.parent as? ViewGroup)?.removeView(view)
            runCatching { view.onPause() }
            view.stopLoading()
            view.loadUrl("about:blank")
            view.destroy()
        }
        webViews.clear()
        tabs.clear()
        host?.removeAllViews()
        host = null
        exitFullscreen()
        publishSnapshot()
    }

    private fun buildWebView(id: Int, isPrivate: Boolean): WebView {
        return WebView(activity).apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            configureSettings(this, isPrivate)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    if (url != null) updateTab(id, url = url, loading = true, progress = 5)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    val finalUrl = url ?: view?.url ?: "about:blank"
                    val current = updateTab(
                        id,
                        url = finalUrl,
                        title = view?.title?.takeIf { it.isNotBlank() } ?: finalUrl,
                        loading = false,
                        progress = 100
                    )
                    if (current != null) this@BrowserController.onPageFinished(current)
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        updateTab(id, loading = false)
                    }
                }

                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: android.net.http.SslError?) {
                    // Never bypass certificate errors automatically.
                    handler?.cancel()
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val scheme = uri.scheme?.lowercase()
                    if (scheme in setOf("http", "https", "about", "blob", "data", "javascript")) return false
                    return openExternal(uri)
                }

                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    if (!trackingProtection) return super.shouldInterceptRequest(view, request)
                    val host = request?.url?.host?.lowercase() ?: return super.shouldInterceptRequest(view, request)
                    if (isKnownTracker(host)) {
                        return WebResourceResponse(
                            "text/plain",
                            "UTF-8",
                            ByteArrayInputStream(ByteArray(0))
                        )
                    }
                    return super.shouldInterceptRequest(view, request)
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    updateTab(id, progress = newProgress, loading = newProgress < 100)
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                    if (!title.isNullOrBlank()) updateTab(id, title = title)
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    if (filePathCallback == null) return false
                    onFileChooser(filePathCallback)
                    return true
                }

                override fun onPermissionRequest(request: PermissionRequest?) {
                    if (request == null) return
                    activity.runOnUiThread { onPermission(request) }
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    if (origin == null || callback == null) return
                    activity.runOnUiThread { onGeolocation(origin, callback) }
                }

                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (view == null) return
                    if (fullscreenView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    fullscreenView = view
                    fullscreenCallback = callback
                    val decor = activity.window.decorView as? ViewGroup
                    if (decor != null) {
                        savedSystemUiVisibility = decor.systemUiVisibility
                        decor.addView(
                            view,
                            ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                        decor.systemUiVisibility = (
                            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_FULLSCREEN
                                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            )
                        isFullscreen = true
                    }
                }

                override fun onHideCustomView() {
                    exitFullscreen()
                }

                override fun onCreateWindow(
                    view: WebView?,
                    isDialog: Boolean,
                    isUserGesture: Boolean,
                    resultMsg: android.os.Message?
                ): Boolean {
                    if (popupBlocker) return false
                    val newId = createTab("about:blank", isPrivate)
                    val newView = webViews[newId] ?: return false
                    val message = resultMsg ?: return false
                    val transport = message.obj as? WebView.WebViewTransport ?: return false
                    transport.webView = newView
                    message.sendToTarget()
                    return true
                }

                override fun onCloseWindow(window: WebView?) {
                    val tabId = webViews.entries.firstOrNull { it.value == window }?.key
                    if (tabId != null) closeTab(tabId)
                }
            }

            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                enqueueDownload(activity, url, userAgent, contentDisposition, mimeType)
            })
        }
    }

    private fun configureSettings(view: WebView, isPrivate: Boolean) {
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setGeolocationEnabled(true)
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = !popupBlocker
            setSupportMultipleWindows(true)
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = if (isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            safeBrowsingEnabled = true
            userAgentString = if (desktopMode) {
                WebSettings.getDefaultUserAgent(activity)
                    .replace("; wv", "")
                    .replace(" Version/4.0", "")
                    .replace(" Mobile", "")
            } else {
                WebSettings.getDefaultUserAgent(activity)
            }
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, !trackingProtection)
    }

    private fun updateTab(
        id: Int,
        url: String? = null,
        title: String? = null,
        progress: Int? = null,
        loading: Boolean? = null
    ): BrowserTab? {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return null
        val old = tabs[index]
        val updated = old.copy(
            url = url ?: old.url,
            title = title ?: old.title,
            progress = progress ?: old.progress,
            loading = loading ?: old.loading
        )
        tabs[index] = updated
        publishSnapshot()
        return updated
    }

    private fun openExternal(uri: Uri): Boolean {
        return try {
            val intent = if (uri.scheme == "intent") {
                Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(Intent.ACTION_VIEW, uri)
            }
            activity.startActivity(intent)
            true
        } catch (_: Exception) {
            try {
                val fallback = if (uri.scheme == "intent") {
                    Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                        .getStringExtra("browser_fallback_url")
                } else null
                if (!fallback.isNullOrBlank()) {
                    webViews[activeTabId]?.loadUrl(fallback)
                    true
                } else {
                    Toast.makeText(activity, "Tidak ada aplikasi untuk membuka tautan ini", Toast.LENGTH_SHORT).show()
                    true
                }
            } catch (_: Exception) {
                true
            }
        }
    }

    private fun isKnownTracker(host: String): Boolean {
        val blocked = listOf(
            "doubleclick.net",
            "googletagmanager.com",
            "google-analytics.com",
            "connect.facebook.net",
            "facebook.com/tr",
            "hotjar.com",
            "segment.io",
            "segment.com",
            "ads-twitter.com",
            "adservice.google.com",
            "scorecardresearch.com",
            "quantserve.com"
        )
        return blocked.any { host == it || host.endsWith(".$it") }
    }

    private fun enqueueDownload(
        context: Context,
        url: String,
        userAgent: String,
        contentDisposition: String,
        mimeType: String
    ) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                .setDescription("Downloaded by DHYRA Browser")
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", userAgent)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, contentDisposition, mimeType)
                )
            val cookie = CookieManager.getInstance().getCookie(url)
            if (!cookie.isNullOrBlank()) request.addRequestHeader("Cookie", cookie)
            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(context, "Unduhan dimulai", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(context, "Unduhan gagal dimulai", Toast.LENGTH_LONG).show()
        }
    }
}
