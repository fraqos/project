# dhyra 2.4.3 — Build Instructions

## Required toolchain

- JDK 21 (the Gradle/Android toolchain is pinned for JDK 21)
- Android SDK Platform 37.1
- Android SDK Build Tools selected/installed by Android Gradle Plugin 9.3.1 for the project.
- Android SDK licences accepted
- Gradle 9.5.1
- Android Studio capable of syncing Android Gradle Plugin 9.3.1 and API 37.1

The project compiles against API 37.1, targets API 36 and has `minSdk = 26`. The Java/Kotlin bytecode target is 17. The app version is 2.4.3 / versionCode 21.

## Local build

From the directory containing `settings.gradle.kts`:

```bash
./gradlew --version
./gradlew :app:checkDebugAarMetadata
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

### Gradle Wrapper note

The project includes the wrapper properties and bootstrap scripts, but the standard `gradle-wrapper.jar` is intentionally omitted from the source archive. The hosted workflow installs the pinned Gradle 9.5.1 distribution, creates a **minimal valid temporary Gradle build** containing both `settings.gradle` and `build.gradle`, and only then invokes the built-in `wrapper` task. This avoids the previous `Directory ... does not contain a Gradle build` failure while keeping Android/Kotlin plugins out of the bootstrap phase. The generated Wrapper JAR and Gradle distribution are SHA-256 verified before the Wrapper files are copied into the dhyra project and used for the Android build. For a fresh local checkout before the JAR has been generated, install Gradle 9.5.1 and use it directly or run the GitHub Actions workflow.

## GitHub Actions

Canonical workflow: `.github/workflows/build.yml`. Keep only this dhyra workflow active.

### Preferred: commit source contents

1. Extract the dhyra project ZIP.
2. Commit the extracted project contents to repository root.
3. Ensure `settings.gradle.kts`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`, `gradle/` and `.github/workflows/build.yml` are at their expected paths.
4. Push to `main` or `master`, open a pull request, or manually run the workflow.

### Alternative: ZIP-only repository

1. Commit `.github/workflows/build.yml` separately under the repository's `.github/workflows/` directory. GitHub cannot activate a workflow that exists only inside a ZIP.
2. Commit exactly one dhyra project `.zip` at repository root.
3. Do not extract it manually. The workflow validates the archive, safely extracts it into a temporary directory and locates the Android Gradle root.
4. Keep only one root-level project ZIP; multiple ZIPs are rejected to avoid ambiguous source selection.

If valid Android source exists at repository root, it takes precedence over ZIP extraction.

## CI pipeline

- Checkout the repository and locate source at root or extract one ZIP safely.
- Validate translation JavaScript and source-contract checks.
- Set up JDK 21 and Android SDK licenses; install Android SDK Platform 37.1. Android Gradle Plugin selects/installs the compatible Build Tools version for the project.
- Set up Gradle 9.5.1, generate the standard Gradle Wrapper JAR and verify its official SHA-256 plus the pinned Gradle distribution checksum.
- Run `:app:checkDebugAarMetadata`, `testDebugUnitTest`, `lintDebug` and `assembleDebug`.
- Validate APK ZIP integrity, Android manifest and DEX entries.
- Create a clean source ZIP and SHA-256 sums, then upload them with the APK.

Expected debug APK artifact name: `dhyra-v2.4.3.apk`. Optional workflow-dispatch release output is unsigned (`dhyra-v2.4.3-release-unsigned.apk`) by default. A signed release APK and AAB can be produced by enabling both `build_release` and `sign_release` in the manual workflow dispatch and configuring these GitHub repository Actions secrets:

- `DHYRA_RELEASE_KEYSTORE_BASE64`: base64-encoded release `.jks` or `.keystore` file (generate a single-line value with `base64 -w 0 release.jks` on Linux).
- `DHYRA_RELEASE_STORE_PASSWORD`: keystore password.
- `DHYRA_RELEASE_KEY_ALIAS`: signing key alias.
- `DHYRA_RELEASE_KEY_PASSWORD`: signing key password.

The workflow writes the decoded keystore only under the hosted runner's temporary directory and the project ZIP excludes keystore/credential files. Local builds can use the equivalent `DHYRA_RELEASE_STORE_FILE`, `DHYRA_RELEASE_STORE_PASSWORD`, `DHYRA_RELEASE_KEY_ALIAS` and `DHYRA_RELEASE_KEY_PASSWORD` Gradle properties or environment variables. Set all four or none; a partial configuration fails with a clear Gradle error. Unsigned APKs are for engineering tests, not public distribution. Never commit keystores or signing passwords.

## Local source checks

```bash
node --check app/src/main/assets/PageTranslation.js
node scripts/test-page-translation.cjs
node scripts/test-translation-retries.cjs
python3 scripts/check-compose-contracts.py
```

## Known integration boundaries

- Rendering and JavaScript execution are provided by the Android System WebView installed on the device; this project does not bundle or fork Chromium.
- Google ML Kit translation downloads language models on demand; models are not embedded as a complete offline language pack.
- Weather uses Open-Meteo and requires network access plus user-granted approximate/precise Android location. No IP-location fallback is implemented.
- News uses Google News RSS, an unofficial endpoint that can change and has no public SLA.
- Android DownloadManager controls transfer lifecycle. In-app pause/resume and precise speed/remaining-time are not available in this implementation.
- Full Indonesian/English UI localization, freeform homepage widget editor, persistent per-origin permissions center and complete Chromium-grade site isolation are not implemented.

## Troubleshooting

- `No Android project ... no .zip was found`: commit source contents at root or exactly one project ZIP at root.
- `No Android Gradle project was found in ZIP`: the archive must contain `settings.gradle(.kts)`, `app/build.gradle(.kts)` and `app/src/main/AndroidManifest.xml`.
- `Failed to find package 'tools'`: the workflow intentionally does not request obsolete SDK package `tools`; use modern Android command-line tools.
- Missing wrapper JAR on a clean checkout: generate it from the verified Gradle 9.5.1 distribution or let GitHub Actions generate and verify it.
- Missing APK artifact: inspect the first failed Gradle task; artifacts are uploaded only after tests, lint, APK validation and archive checks succeed.

## CI bootstrap correction

The wrapper generation step must not invoke `gradle wrapper` in a blank temporary directory. The current workflow creates `settings.gradle` and `build.gradle` first, checks both files, then runs the Wrapper task from that valid temporary Gradle root. This directly avoids the Gradle 9 error: `Directory ... does not contain a Gradle build`.


## 2.4.2 UI and branding update (previous release)

- The launcher and in-app mark are a single geometric capital D. Obsidian is the launcher surface and electric violet remains the brand accent.
- The D-only startup overlay is short and shown after the browser has initialized on each app launch. It does not wait for network access.
- Settings no longer shows UI Styles, Homepage Layout, Reduce Motion, Animation Intensity or Disable Startup Animation. Existing homepage layout data is retained for backward compatibility; retired style/motion keys are removed from the preferences store during initialization.
- The tab switcher uses Compose lazy-item removal/placement animations with a short per-card exit and bounded stagger for Close All. The browser controller's tab creation/selection/close APIs and close-all undo behavior are unchanged.

- Single-tab close and Close All use short staggered card exits plus keyed grid-placement animation; browser-controller tab actions remain unchanged.
- The single D monogram uses the same `#8067F0` brand accent in launcher assets and Compose light/dark/dynamic schemes.
- The five obsolete Settings options are removed; legacy homepage layout data remains readable, and obsolete appearance/motion preferences are cleaned only when present.


## 2.4.3 release hardening

- Manual CI dispatch can build a release APK and AAB; signing is opt-in and requires the four GitHub Actions secrets listed above.
- Theme choices are limited to System/Dark with safe migration from older stored values.
- Local-host omnibox and filter exception precedence have regression tests.
- The SPACE UI label does not change underlying tab persistence identifiers.
