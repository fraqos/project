# SPACE — privacy architecture and limitations

## Product behavior

SPACE is DHYRA's temporary browsing session. Its user-facing surfaces are labelled **SPACE**; internal identifiers such as `isPrivate` and `SpaceSessionPolicy` are retained to avoid breaking persisted code or public API compatibility in this patch.

SPACE tabs are kept separate from normal tab/session persistence. The project excludes SPACE activity from normal history/session serialization, does not include SPACE pages in regular recently visited data, does not create regular bookmarks or speed-dial entries from SPACE, and refuses downloads and device permission requests in SPACE. The tab switcher does not create page thumbnails for SPACE tabs. The session is not restored after process restart.

## WebView profile boundary

The implementation uses AndroidX WebKit named profiles through `SpaceWebViewProfile`:

- Profile name: `dhyra-private-session`.
- Required runtime capabilities: `WebViewFeature.MULTI_PROFILE` and `WebViewFeature.DELETE_BROWSING_DATA`.
- A newly-created SPACE WebView is attached to the named profile immediately after construction and before WebSettings, clients, storage or navigation are touched.
- SPACE uses the named profile's `CookieManager`, disables normal cache use, and denies persistent downloads and native device permissions.
- `WebStorageCompat.deleteBrowsingData(profile.webStorage, callback)` clears the profile data through the provider-supported API. The app waits for the deletion callback before marking the profile ready; deletion/attachment failure disables SPACE instead of falling back to the default profile.
- Profile data is cleared on startup to remove leftovers after an unexpected process death, after the final SPACE tab closes, and when a live SPACE session's controller is destroyed.

This is an AndroidX WebKit profile/storage boundary. It is **not** a separate Android OS user, a guaranteed independent renderer process, a VPN, an anonymity network or protection from network observers. Sites can still identify visitors through IP address, account sign-in, browser/device characteristics, timing and other signals. Downloads and device permissions are disabled rather than being persisted in a separate secure vault.

## Compatibility caveats

Named-profile and profile-data-deletion support vary by installed Android System WebView provider and version. If either feature is unavailable, or profile initialization/cleanup fails, SPACE is disabled. Do not weaken this gate by silently using the regular default WebView profile.

The provider implementation and behavior for cookies, cache, service workers, IndexedDB, localStorage, other web storage and renderer/process boundaries must be validated on physical devices across supported WebView versions. A successful API callback is not a substitute for an adversarial device matrix test. This archive has not been emulator- or device-tested in the current environment.

## Manual validation matrix

1. Open a normal tab, sign in to a test origin, then open the same origin in SPACE; confirm the normal authenticated cookie/session is not present.
2. Create cookies, localStorage, IndexedDB and a service worker in SPACE; close the final SPACE tab; reopen SPACE and confirm they are removed.
3. Force-stop the process with SPACE open; relaunch and confirm startup cleanup occurs before SPACE becomes available.
4. Test cache behavior, file uploads, service workers, IndexedDB, localStorage, WebSQL if the provider exposes it, and `navigator.storage.estimate()` on several WebView releases.
5. Test WebView update/unavailable-feature paths and forced cleanup errors; confirm SPACE remains disabled instead of falling back to the normal profile.
6. Confirm SPACE URLs are absent from normal history, bookmarks, speed dial, restored session, normal autocomplete suggestions and download records.
7. Confirm camera, microphone and geolocation requests are refused in SPACE.

## User-facing privacy statement

SPACE keeps its supported browsing profile and session data separate from normal DHYRA browsing and clears that profile when the session ends. It does not hide the user's IP address, prevent websites from identifying a signed-in account, or provide network anonymity. Compatibility and storage clearing depend on the installed WebView provider. The feature is unavailable when the provider cannot supply the required profile and deletion APIs.
