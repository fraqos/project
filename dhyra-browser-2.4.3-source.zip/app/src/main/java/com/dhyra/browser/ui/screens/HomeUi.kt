@file:OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser.ui.screens

import com.dhyra.browser.*
import com.dhyra.browser.ui.theme.*
import com.dhyra.browser.ui.components.*
import com.dhyra.browser.core.home.HomeFeedRepository
import com.dhyra.browser.core.home.HomeNewsItem
import com.dhyra.browser.core.home.HomeWeather

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * The start page. The search/address entry stays pinned at the top; speed dials and recent pages
 * occupy a scrollable content area below it. Short screens scroll instead of clipping.
 */
@Composable
internal fun HomePage(
    isPrivate: Boolean,
    searchEngine: String,
    searchEngineOptions: List<String>,
    homeLayout: String,
    onSearchEngine: (String) -> Unit,
    speedDial: List<Shortcut>,
    recent: List<SavedPage>,
    onOpenOmnibox: () -> Unit,
    onSite: (String) -> Unit,
    onRemoveSite: (Shortcut) -> Unit,
    onSaveShortcut: (Shortcut?, Shortcut) -> Unit,
    onRecent: (String) -> Unit,
    tabCount: Int,
    onTabs: () -> Unit,
    onMenu: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val isDark = cs.background.luminance() < 0.5f
    val glow = if (isPrivate) SpaceText else cs.primary
    var clockMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var weather by remember { mutableStateOf<HomeWeather?>(null) }
    var weatherLoading by remember { mutableStateOf(false) }
    var weatherError by remember { mutableStateOf<String?>(null) }
    var news by remember { mutableStateOf<List<HomeNewsItem>>(emptyList()) }
    var newsLoading by remember { mutableStateOf(!isPrivate) }
    var newsError by remember { mutableStateOf<String?>(null) }
    var newsCategory by remember { mutableStateOf("Top stories") }
    var newsQuery by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            clockMillis = System.currentTimeMillis()
        }
    }
    val dateLine = remember(clockMillis) {
        SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(clockMillis))
    }
    val timeLine = remember(clockMillis) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(clockMillis))
    }
    val greeting = remember(clockMillis) {
        val hour = Calendar.getInstance().apply { timeInMillis = clockMillis }.get(Calendar.HOUR_OF_DAY)
        greetingForHour(hour)
    }
    var editingShortcut by remember { mutableStateOf<Shortcut?>(null) }
    var addingShortcut by remember { mutableStateOf(false) }
    var engineMenuExpanded by remember { mutableStateOf(false) }

    val loadWeather: () -> Unit = {
        scope.launch {
            weatherLoading = true
            weatherError = null
            runCatching { HomeFeedRepository.currentWeather(context) }
                .onSuccess { weather = it }
                .onFailure { weatherError = it.message?.takeIf(String::isNotBlank) ?: "Weather is temporarily unavailable." }
            weatherLoading = false
        }
    }
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.any { it }) loadWeather()
        else weatherError = "Location access was not granted. Weather remains off until you enable it."
    }
    val requestWeather: () -> Unit = {
        val hasLocationPermission =
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (hasLocationPermission) loadWeather()
        else locationPermissionLauncher.launch(
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        )
    }

    LaunchedEffect(isPrivate, homeLayout) {
        if (!isPrivate && homeLayout !in setOf("Minimal Homepage", "Productivity Dashboard", "Search-Centric Homepage")) {
            newsLoading = true
            newsError = null
            runCatching { HomeFeedRepository.latestNews(category = newsCategory, query = newsQuery, limit = 8) }
                .onSuccess { news = it }
                .onFailure { newsError = "News could not be loaded right now." }
            newsLoading = false
        } else {
            news = emptyList()
            newsLoading = false
            weather = null
            weatherError = null
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(cs.background, lerp(cs.background, glow, 0.05f))))
            .drawBehind {
                val radius = size.width * 0.95f
                val center = Offset(size.width * 0.5f, size.height * 0.18f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(glow.copy(alpha = if (isDark) 0.14f else 0.10f), Color.Transparent),
                        center = center,
                        radius = radius
                    ),
                    radius = radius,
                    center = center
                )
            }
            .statusBarsPadding()
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .height(52.dp),
            shape = MaterialTheme.shapes.extraLarge,
            color = cs.surfaceVariant,
            border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.6f))
        ) {
            Row(
                Modifier.fillMaxSize().padding(start = 16.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    Modifier.weight(1f).fillMaxHeight().clickable(onClick = onOpenOmnibox),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = cs.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = "Search or enter address",
                        fontSize = 16.sp,
                        lineHeight = 24.sp,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Box {
                    TextButton(
                        onClick = { engineMenuExpanded = true },
                        modifier = Modifier.height(48.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text(searchEngine, fontSize = 13.sp, maxLines = 1)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Choose search engine")
                    }
                    DropdownMenu(
                        expanded = engineMenuExpanded,
                        onDismissRequest = { engineMenuExpanded = false }
                    ) {
                        searchEngineOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    onSearchEngine(option)
                                    engineMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val minHeight = maxHeight
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .heightIn(min = minHeight)
                    .padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Spacer(Modifier.height(22.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        DhyraMark(size = 32.dp)
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "dhyra",
                                color = cs.onSurface,
                                fontSize = 14.sp,
                                lineHeight = 18.sp,
                                letterSpacing = 2.2.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                if (isPrivate) "SPACE session" else "Your space to explore",
                                color = cs.onSurfaceVariant,
                                fontSize = 10.sp,
                                lineHeight = 14.sp,
                                letterSpacing = 1.1.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                timeLine,
                                color = cs.onSurface,
                                fontSize = 27.sp,
                                lineHeight = 32.sp,
                                fontWeight = FontWeight.Light
                            )
                            Text(dateLine, color = cs.onSurfaceVariant, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                    Spacer(Modifier.height(30.dp))
                    Text(
                        text = if (isPrivate) "Browse quietly" else greeting,
                        fontSize = 34.sp,
                        lineHeight = 42.sp,
                        fontWeight = FontWeight.Light,
                        color = cs.onSurface
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = if (isPrivate) "Your SPACE session is isolated from regular browsing." else "A fresh start, with the things you need close by.",
                        fontSize = 14.sp,
                        lineHeight = 21.sp,
                        color = cs.onSurfaceVariant
                    )
                }

                Column {
                    Spacer(Modifier.height(26.dp))
                    val showWeather = !isPrivate && homeLayout !in setOf(
                        "Minimal Homepage", "Productivity Dashboard", "Search-Centric Homepage"
                    )
                    val showNews = !isPrivate && homeLayout !in setOf(
                        "Minimal Homepage", "Productivity Dashboard", "Search-Centric Homepage"
                    )
                    val newsFirst = homeLayout in setOf("Editorial Homepage", "News Dashboard")
                    val retryNews: () -> Unit = {
                        scope.launch {
                            newsLoading = true
                            newsError = null
                            runCatching { HomeFeedRepository.latestNews(category = newsCategory, query = newsQuery, limit = 8) }
                                .onSuccess { news = it }
                                .onFailure { newsError = "News could not be loaded right now." }
                            newsLoading = false
                        }
                    }
                    if (showNews && newsFirst) {
                        NewsPanel(
                            items = news, loading = newsLoading, error = newsError, category = newsCategory, query = newsQuery,
                            onCategory = { selected ->
                                newsCategory = selected
                                newsQuery = ""
                                scope.launch {
                                    newsLoading = true; newsError = null
                                    runCatching { HomeFeedRepository.latestNews(category = selected, limit = 8) }
                                        .onSuccess { news = it }.onFailure { newsError = "News could not be loaded right now." }
                                    newsLoading = false
                                }
                            },
                            onQuery = { q ->
                                newsQuery = q
                                scope.launch {
                                    newsLoading = true; newsError = null
                                    runCatching { HomeFeedRepository.latestNews(query = q, limit = 8) }
                                        .onSuccess { news = it }.onFailure { newsError = "News search is temporarily unavailable." }
                                    newsLoading = false
                                }
                            },
                            onRetry = retryNews, onOpen = onSite
                        )
                        Spacer(Modifier.height(18.dp))
                    }
                    if (showWeather) {
                        WeatherPanel(weather = weather, loading = weatherLoading, error = weatherError, onRefresh = requestWeather)
                        Text(
                            "Weather by Open-Meteo · location is requested only after you tap the location control.",
                            modifier = Modifier.padding(start = 6.dp, top = 6.dp),
                            fontSize = 10.sp,
                            lineHeight = 14.sp,
                            color = cs.onSurfaceVariant
                        )
                        Spacer(Modifier.height(18.dp))
                    }
                    if (showNews && !newsFirst) {
                        NewsPanel(
                            items = news, loading = newsLoading, error = newsError, category = newsCategory, query = newsQuery,
                            onCategory = { selected ->
                                newsCategory = selected
                                newsQuery = ""
                                scope.launch {
                                    newsLoading = true; newsError = null
                                    runCatching { HomeFeedRepository.latestNews(category = selected, limit = 8) }
                                        .onSuccess { news = it }.onFailure { newsError = "News could not be loaded right now." }
                                    newsLoading = false
                                }
                            },
                            onQuery = { q ->
                                newsQuery = q
                                scope.launch {
                                    newsLoading = true; newsError = null
                                    runCatching { HomeFeedRepository.latestNews(query = q, limit = 8) }
                                        .onSuccess { news = it }.onFailure { newsError = "News search is temporarily unavailable." }
                                    newsLoading = false
                                }
                            },
                            onRetry = retryNews, onOpen = onSite
                        )
                        Spacer(Modifier.height(22.dp))
                    }
                    SectionLabel("Speed dial")
                    if (speedDial.isEmpty() && !isPrivate) {
                        Text(
                            text = "Add your favourite websites for quick access.",
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                            color = cs.onSurfaceVariant
                        )
                    }
                    if (!isPrivate || speedDial.isNotEmpty()) {
                        BoxWithConstraints(Modifier.fillMaxWidth()) {
                            val columns = (maxWidth / 92.dp).toInt().coerceIn(3, 6)
                            val gap = 8.dp
                            val tileWidth = (maxWidth - gap * (columns - 1)) / columns
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                maxItemsInEachRow = columns,
                                horizontalArrangement = Arrangement.spacedBy(gap),
                                verticalArrangement = Arrangement.spacedBy(gap)
                            ) {
                                speedDial.take(8).forEach { site ->
                                    SpeedDialTile(
                                        site = site,
                                        isDark = isDark,
                                        modifier = Modifier.width(tileWidth),
                                        onClick = { onSite(site.url) },
                                        onLongClick = { if (!isPrivate) editingShortcut = site }
                                    )
                                }
                                if (!isPrivate && speedDial.size < 8) {
                                    AddSpeedDialTile(
                                        modifier = Modifier.width(tileWidth),
                                        onClick = { addingShortcut = true }
                                    )
                                }
                            }
                        }
                    }

                    if (!isPrivate && recent.isNotEmpty() && homeLayout !in setOf("Minimal Homepage", "Search-Centric Homepage")) {
                        Spacer(Modifier.height(18.dp))
                        SectionLabel("Recently visited")
                        recent.take(3).forEach { entry ->
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onRecent(entry.url) }
                                    .padding(horizontal = 4.dp, vertical = 9.dp)
                            ) {
                                Text(
                                    text = entry.title.ifBlank { entry.url },
                                    fontSize = 15.sp,
                                    lineHeight = 22.sp,
                                    color = cs.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = siteLabelOf(entry.url),
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(18.dp))
                }
            }
        }
        BottomNav(
            canBack = false,
            canForward = false,
            onBack = {},
            onForward = {},
            onHome = {},
            onTabs = onTabs,
            tabCount = tabCount,
            onMenu = onMenu
        )
    }

    if (addingShortcut || editingShortcut != null) {
        val original = editingShortcut
        var label by remember(original, addingShortcut) { mutableStateOf(original?.label.orEmpty()) }
        var url by remember(original, addingShortcut) { mutableStateOf(original?.url.orEmpty()) }
        var validationError by remember(original, addingShortcut) { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { addingShortcut = false; editingShortcut = null },
            containerColor = cs.surface,
            title = { Text(if (original == null) "Add shortcut" else "Edit shortcut") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = it.take(28); validationError = null },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Name") }
                    )
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it; validationError = null },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        isError = validationError != null,
                        label = { Text("Website URL") },
                        placeholder = { Text("https://example.com") }
                    )
                    validationError?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
                    Text("Long-press any shortcut to edit or remove it.", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val trimmedUrl = url.trim()
                    val candidate = if (trimmedUrl.contains("://")) trimmedUrl else "https://$trimmedUrl"
                    if (label.isBlank()) {
                        validationError = "Enter a name for this shortcut."
                    } else if (!com.dhyra.browser.core.nav.DhyraNavigationManager.isHttpUrl(candidate)) {
                        validationError = "Enter a valid HTTP or HTTPS website URL."
                    } else if (speedDial.any { it.url.equals(candidate, ignoreCase = true) && it.url != original?.url }) {
                        validationError = "That website is already in your speed dial."
                    } else {
                        onSaveShortcut(original, Shortcut(label.trim(), candidate))
                        addingShortcut = false
                        editingShortcut = null
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    if (original != null) TextButton(onClick = {
                        onRemoveSite(original)
                        editingShortcut = null
                    }) { Text("Remove", color = cs.error) }
                    TextButton(onClick = { addingShortcut = false; editingShortcut = null }) { Text("Cancel") }
                }
            }
        )
    }

}

@Composable
private fun WeatherPanel(
    weather: HomeWeather?,
    loading: Boolean,
    error: String?,
    onRefresh: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = cs.surfaceContainerLow,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.72f))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(cs.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        weather == null -> Icons.Default.WbSunny
                        weather.weatherCode == 0 -> Icons.Default.WbSunny
                        weather.weatherCode in 1..3 -> Icons.Default.Cloud
                        weather.weatherCode in 51..86 -> Icons.Default.Grain
                        else -> Icons.Default.Thunderstorm
                    },
                    contentDescription = null,
                    tint = cs.onPrimaryContainer,
                    modifier = Modifier.size(25.dp)
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("LOCAL WEATHER", fontSize = 10.sp, lineHeight = 14.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.SemiBold, color = cs.primary)
                when {
                    loading -> Text("Checking conditions…", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    weather != null -> {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text("${weather.temperatureC.toInt()}°", fontSize = 27.sp, lineHeight = 32.sp, fontWeight = FontWeight.Light, color = cs.onSurface)
                            Spacer(Modifier.width(8.dp))
                            Text(weather.description, fontSize = 13.sp, lineHeight = 19.sp, color = cs.onSurfaceVariant)
                        }
                        Text("Feels like ${weather.feelsLikeC.toInt()}°C", fontSize = 11.sp, lineHeight = 16.sp, color = cs.onSurfaceVariant)
                    }
                    error != null -> Text(error, fontSize = 12.sp, lineHeight = 17.sp, color = cs.error, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    else -> Text("Use your location for current conditions", fontSize = 12.sp, lineHeight = 17.sp, color = cs.onSurfaceVariant)
                }
            }
            if (loading) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
            } else {
                IconButton(onClick = onRefresh) {
                    Icon(
                        imageVector = if (weather == null && error == null) Icons.Default.MyLocation else Icons.Default.Refresh,
                        contentDescription = if (weather == null) "Enable local weather" else "Refresh local weather",
                        tint = cs.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun NewsPanel(
    items: List<HomeNewsItem>,
    loading: Boolean,
    error: String?,
    category: String,
    query: String,
    onCategory: (String) -> Unit,
    onQuery: (String) -> Unit,
    onRetry: () -> Unit,
    onOpen: (String) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val categories = listOf("Top stories", "Breaking News", "World", "Technology", "Business", "Science", "Sports", "Entertainment", "Politics", "Local News")
    var searchDraft by remember { mutableStateOf(query) }
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionLabel(if (query.isBlank()) category else "News search")
            Spacer(Modifier.weight(1f))
            Text("Google News · RSS", fontSize = 9.sp, lineHeight = 14.sp, letterSpacing = 0.4.sp, color = cs.onSurfaceVariant)
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            categories.forEach { option ->
                val selected = option == category && query.isBlank()
                Surface(
                    onClick = { searchDraft = ""; onCategory(option) },
                    shape = RoundedCornerShape(50),
                    color = if (selected) cs.primaryContainer else cs.surfaceContainerLow,
                    border = BorderStroke(1.dp, if (selected) cs.primary.copy(alpha = 0.35f) else cs.outlineVariant)
                ) {
                    Text(
                        option,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        color = if (selected) cs.onPrimaryContainer else cs.onSurfaceVariant,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = searchDraft,
            onValueChange = { searchDraft = it.take(100) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            placeholder = { Text("Search news") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                IconButton(onClick = { onQuery(searchDraft.trim()) }) {
                    Icon(Icons.Default.ArrowForward, contentDescription = "Search news")
                }
            }
        )
        Spacer(Modifier.height(8.dp))
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = cs.surfaceContainerLow,
            border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.72f))
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                when {
                    loading -> Row(Modifier.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Loading latest stories…", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    error != null -> Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(error, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        TextButton(onClick = onRetry) { Text("Retry") }
                    }
                    items.isEmpty() -> Text("No stories are available right now.", modifier = Modifier.padding(vertical = 14.dp), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    else -> items.take(6).forEachIndexed { index, item ->
                        Column(
                            Modifier.fillMaxWidth().clickable { onOpen(item.url) }.padding(vertical = 11.dp)
                        ) {
                            Text(item.title, fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium, color = cs.onSurface, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(3.dp))
                            val timestamp = item.publishedAt.takeIf { it.isNotBlank() }?.let(::formatNewsTimestamp)
                            Text(
                                listOf(item.source, timestamp).filterNotNull().filter { it.isNotBlank() }.joinToString(" · "),
                                fontSize = 11.sp, lineHeight = 16.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (index < minOf(items.size, 6) - 1) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.65f))
                    }
                }
            }
        }
    }
}

private fun formatNewsTimestamp(raw: String): String {
    val patterns = listOf(
        "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, d MMM yyyy HH:mm:ss zzz",
        "dd MMM yyyy HH:mm:ss zzz", "d MMM yyyy HH:mm:ss zzz"
    )
    for (pattern in patterns) {
        val parsed = runCatching { SimpleDateFormat(pattern, Locale.US).parse(raw) }.getOrNull()
        if (parsed != null) return runCatching {
            SimpleDateFormat("d MMM · HH:mm", Locale.getDefault()).format(parsed)
        }.getOrDefault(raw)
    }
    return raw.take(40)
}

@Composable
private fun AddSpeedDialTile(modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(58.dp).clip(RoundedCornerShape(20.dp))
                .background(cs.surfaceVariant.copy(alpha = 0.8f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add website shortcut", tint = cs.primary)
        }
        Spacer(Modifier.height(7.dp))
        Text("Add", fontSize = 12.sp, lineHeight = 17.sp, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun SpeedDialTile(
    site: Shortcut,
    isDark: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val accent = tileColorFor(site.label)
    // Pastel accents read well on a tint, but the letter itself needs more contrast than the tile.
    val letter = if (isDark) lerp(accent, Color.White, 0.2f) else lerp(accent, Color.Black, 0.45f)
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(58.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(accent.copy(alpha = if (isDark) 0.22f else 0.24f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = monogramOf(site.label),
                fontSize = 22.sp,
                lineHeight = 28.sp,
                fontWeight = FontWeight.Medium,
                color = letter
            )
        }
        Spacer(Modifier.height(7.dp))
        Text(
            text = site.label,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            color = cs.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
internal fun SectionLabel(text: String) {
    Text(
        text = text,
        modifier = Modifier.padding(bottom = 10.dp),
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 1.5.sp,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
