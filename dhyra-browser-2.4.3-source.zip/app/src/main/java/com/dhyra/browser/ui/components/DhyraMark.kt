package com.dhyra.browser.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** dhyra's compact geometric D monogram. The mark intentionally contains no secondary symbol. */
@Composable
internal fun DhyraMark(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    framed: Boolean = false
) {
    val accent = MaterialTheme.colorScheme.primary
    Box(
        modifier = modifier
            .size(size)
            .then(
                if (framed) Modifier
                    .clip(RoundedCornerShape(size * 0.28f))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(size * 0.88f)) {
            val w = this.size.width
            val h = this.size.height
            val mark = Path().apply {
                fillType = PathFillType.EvenOdd
                // Outer D: firm vertical stem and a restrained geometric bowl.
                moveTo(w * 0.22f, h * 0.14f)
                lineTo(w * 0.48f, h * 0.14f)
                cubicTo(w * 0.73f, h * 0.14f, w * 0.88f, h * 0.31f, w * 0.88f, h * 0.50f)
                cubicTo(w * 0.88f, h * 0.69f, w * 0.73f, h * 0.86f, w * 0.48f, h * 0.86f)
                lineTo(w * 0.22f, h * 0.86f)
                close()

                // Counter-space keeps the D legible at favicon and launcher sizes.
                moveTo(w * 0.40f, h * 0.31f)
                lineTo(w * 0.48f, h * 0.31f)
                cubicTo(w * 0.63f, h * 0.31f, w * 0.70f, h * 0.39f, w * 0.70f, h * 0.50f)
                cubicTo(w * 0.70f, h * 0.61f, w * 0.63f, h * 0.69f, w * 0.48f, h * 0.69f)
                lineTo(w * 0.40f, h * 0.69f)
                close()
            }
            drawPath(mark, color = accent)
        }
    }
}
